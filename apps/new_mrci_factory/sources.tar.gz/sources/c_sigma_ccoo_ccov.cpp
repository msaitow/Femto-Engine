                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccoo_ccov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  `7MM"""YMM                         mm               
//    MM    `7                         MM                  
//    MM   d  .gP"Ya `7MMpMMMb.pMMMb.mmMMmm ,pW"Wq.      
//    MM""MM ,M'   Yb  MM    MM    MM  MM  6W'   `Wb   
//    MM   Y 8M""""""  MM    MM    MM  MM  8M     M8 
//    MM     YM.    ,  MM    MM    MM  MM  YA.   ,A9       
//  .JMML.    `Mbmmd'.JMML  JMML  JMML.`Mbmo`Ybmd9'        

//                                   Generated date : Wed Feb 19 15:55:51 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccoo_ccov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  if(myrank == 0){
  { 
  // No. 0, [2]
  // W0(w,y,o2,o1) += (    1.00000000) Fc1(o2,v1) T2(w,y,o1,v1) 
  // S2(w,y,i,k) += (    1.00000000) D2(i,o1,k,o2) W0(w,y,o2,o1) 
  double flops = 0; // Flop count
  orz::DTensor W0ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x0_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X0_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W0ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x0_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X0_TYPE1_NOERI)
      (sk, ik, W0ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 1, [2]
  // W1(w,y,o1,o2) += (    1.00000000) Fc1(o1,v1) T2(w,y,v1,o2) 
  // S2(w,y,i,k) += (    1.00000000) D2(i,o1,k,o2) W1(w,y,o1,o2) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    T2b = T2.get_amp2(io2);
    orz::DTensor W1cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so2));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x1_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X1_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W1cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x1_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X1_TYPE1_NOERI)
        (sk, ik, so2, io2, W1cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W2(k,v1) += (    1.00000000) D1(k,o1) Fc1(o1,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,i,v1) W2(k,v1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double W2_sigma_ccoo_ccov = 0;
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x2_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X2_TYPE1_NOERI)
        (sk, ik, sv1, iv1, &W2_sigma_ccoo_ccov, nir, nsym, psym, &flops);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x2_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X2_TYPE1_NOERI)
        (sk, ik, sv1, iv1, T2b.cptr(), &W2_sigma_ccoo_ccov, S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [2]
  // W3(k,v1) += (    1.00000000) D1(k,o1) Fc1(o1,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,v1,i) W3(k,v1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W3v_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xv(symblockinfo, sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x3_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X3_TYPE1_NOERI)
      (sk, ik, W3v_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x3_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X3_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W3v_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [2]
  // W4(w,y,k,v1) += (    1.00000000) D1(k,o1) T2(w,y,v1,o1) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(i,v1) W4(w,y,k,v1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W4ccv_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccv(symblockinfo, sk));
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x4_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X4_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), W4ccv_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x4_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X4_TYPE1_NOERI)
      (sk, ik, W4ccv_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W5(w,y,k,v1) += (    1.00000000) D1(k,o1) T2(w,y,o1,v1) 
  // S2(w,y,i,k) += (    1.00000000) Fc1(i,v1) W5(w,y,k,v1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      orz::DTensor W5cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x5_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X5_TYPE1_NOERI)
        (sk, ik, sv1, iv1, T2b.cptr(), W5cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x5_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X5_TYPE1_NOERI)
        (sk, ik, sv1, iv1, W5cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 6, [2]
  // W6(i,v1) += (    1.00000000) D1(i,o1) Fc1(o1,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,v1,k) W6(i,v1) 
  double flops = 0; // Flop count
  orz::DTensor W6av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x6_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X6_TYPE1_NOERI)
    (W6av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x6_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X6_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W6av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 7, [2]
  // W7(i,v1) += (    1.00000000) D1(i,o1) Fc1(o1,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,v1,k) W7(i,v1) 
  double flops = 0; // Flop count
  orz::DTensor W7av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x7_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X7_TYPE1_NOERI)
    (W7av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x7_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X7_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W7av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 8, [2]
  // W8(w,y,i,v1) += (    1.00000000) D1(i,o1) T2(w,y,v1,o1) 
  // S2(w,y,i,k) += (    1.00000000) Fc1(k,v1) W8(w,y,i,v1) 
  double flops = 0; // Flop count
  orz::DTensor W8ccav_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccav(symblockinfo, 0));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x8_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X8_TYPE1_NOERI)
      (so1, io1, T2b.cptr(), W8ccav_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x8_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X8_TYPE1_NOERI)
      (sk, ik, W8ccav_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 9, [2]
  // W9(w,y,i,v1) += (    1.00000000) D1(i,o1) T2(w,y,o1,v1) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(k,v1) W9(w,y,i,v1) 
  double flops = 0; // Flop count
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    if(hintmo.iproc_havingimo()[iv1] == myrank) {           
    T2b = T2.get_amp2(iv1);
    orz::DTensor W9cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x9_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X9_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W9cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x9_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO1_X9_TYPE1_NOERI)
        (sk, ik, sv1, iv1, W9cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 10, [1]
  // S2(w,y,i,k) += (    4.00000000) Fc1(k,v1) T2(w,y,i,v1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x10_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X10_TYPE1_NOERI)
        (sk, ik, sv1, iv1, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 11, [1]
  // S2(w,y,i,k) += (   -2.00000000) Fc1(k,v1) T2(w,y,v1,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    T2b = T2.get_amp2(ii);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x11_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X11_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 12, [1]
  // S2(w,y,i,k) += (    4.00000000) Fc1(i,v1) T2(w,y,v1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x12_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X12_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 13, [1]
  // S2(w,y,i,k) += (   -2.00000000) Fc1(i,v1) T2(y,w,v1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x13_type1_noeri,G_IF_SIGMA_CCOO_CCOV_NO0_X13_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccoo_ccov
  { 
  // No. 0, [2]
  // W0(y,w,o1,k) += (    1.00000000) T2(c1,y,v1,o1) V2(k,v1,c1,w) 
  // S2(w,y,i,k) += (   -1.00000000) D1(i,o1) W0(y,w,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W0cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x0_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X0_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), W0cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x0_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X0_TYPE1_ERI_O)
      (sk, ik, so1, io1, W0cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(y,w,o1,k) += (    1.00000000) T2(c1,y,o1,v1) V2(k,v1,c1,w) 
  // S2(w,y,i,k) += (    2.00000000) D1(i,o1) W1(y,w,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W1cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x1_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X1_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccoo_ccov_no1_x1_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X1_TYPE1_ERI_O)
    (sk, ik, W1cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,y,o1,k) += (    1.00000000) T2(c1,w,o1,v1) V2(k,v1,c1,y) 
  // S2(w,y,i,k) += (   -1.00000000) D1(i,o1) W2(w,y,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W2cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x2_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X2_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W2cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccoo_ccov_no1_x2_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X2_TYPE1_ERI_O)
    (sk, ik, W2cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,y,o1,k) += (    1.00000000) T2(c1,w,v1,o1) V2(k,v1,c1,y) 
  // S2(w,y,i,k) += (    2.00000000) D1(i,o1) W3(w,y,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W3cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x3_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X3_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), W3cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x3_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X3_TYPE1_ERI_O)
      (sk, ik, so1, io1, W3cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(c1,w,v1,i) V2(k,v1,c1,y) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x4_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X4_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,y,i,k) += (    2.00000000) T2(c1,w,i,v1) V2(k,v1,c1,y) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x5_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X5_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,y,i,k) += (    2.00000000) T2(c1,y,v1,i) V2(k,v1,c1,w) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x6_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X6_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(c1,y,i,v1) V2(k,v1,c1,w) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x7_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X7_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W4(y,w,o1,k) += (    1.00000000) T2(c1,y,o1,v1) V2(k,w,c1,v1) 
  // S2(w,y,i,k) += (   -1.00000000) D1(i,o1) W4(y,w,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W4cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x8_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X8_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W4cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccoo_ccov_no1_x8_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X8_TYPE1_ERI_O)
    (sk, ik, W4cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W5(w,y,o1,k) += (    1.00000000) T2(c1,w,o1,v1) V2(k,y,c1,v1) 
  // S2(w,y,i,k) += (    2.00000000) D1(i,o1) W5(w,y,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W5cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x9_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X9_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W5cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccoo_ccov_no1_x9_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X9_TYPE1_ERI_O)
    (sk, ik, W5cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W6(y,w,o1,k) += (    1.00000000) T2(c1,y,v1,o1) V2(k,w,c1,v1) 
  // S2(w,y,i,k) += (    2.00000000) D1(i,o1) W6(y,w,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W6cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x10_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X10_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), W6cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x10_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X10_TYPE1_ERI_O)
      (sk, ik, so1, io1, W6cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W7(w,y,o1,k) += (    1.00000000) T2(c1,w,v1,o1) V2(k,y,c1,v1) 
  // S2(w,y,i,k) += (   -4.00000000) D1(i,o1) W7(w,y,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W7cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x11_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X11_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), W7cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x11_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X11_TYPE1_ERI_O)
      (sk, ik, so1, io1, W7cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,y,i,k) += (    8.00000000) T2(c1,w,v1,i) V2(k,y,c1,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x12_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X12_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(c1,w,i,v1) V2(k,y,c1,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x13_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X13_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 14, [1]
  // S2(w,y,i,k) += (    2.00000000) T2(c1,y,i,v1) V2(k,w,c1,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x14_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X14_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 15, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(c1,y,v1,i) V2(k,w,c1,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x15_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X15_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 16, [2]
  // W8(i,o2,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(k,o3,o1,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,o2,v1) W8(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W8aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x16_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X16_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W8aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x16_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X16_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), W8aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 17, [2]
  // W9(i,o1,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(k,o3,o2,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,v1,o1) W9(i,o1,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W9av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x17_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X17_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W9av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x17_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X17_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W9av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 18, [2]
  // W10(i,o2,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(k,v1,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,v1,o2) W10(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W10av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x18_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X18_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W10av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x18_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X18_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W10av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 19, [2]
  // W11(i,o2,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(k,v1,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,o2,v1) W11(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W11aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x19_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X19_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W11aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x19_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X19_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), W11aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 20, [2]
  // W12(k,v1) += (    1.00000000) D1(o1,o2) V2(k,o1,o2,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,i,v1) W12(k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    double W12_sigma_ccoo_ccov = 0;
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x20_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X20_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), &W12_sigma_ccoo_ccov, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x20_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X20_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), &W12_sigma_ccoo_ccov, S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 21, [2]
  // W13(k,v1) += (    1.00000000) D1(o1,o2) V2(k,o1,o2,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,v1,i) W13(k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W13v_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xv(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x21_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X21_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W13v_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x21_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X21_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W13v_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 22, [2]
  // W14(k,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,o1,o2) 
  // S2(w,y,i,k) += (    4.00000000) T2(w,y,i,v1) W14(k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    double W14_sigma_ccoo_ccov = 0;
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x22_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X22_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), &W14_sigma_ccoo_ccov, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x22_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X22_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), &W14_sigma_ccoo_ccov, S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 23, [2]
  // W15(k,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,o1,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,v1,i) W15(k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W15v_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xv(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x23_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X23_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W15v_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x23_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X23_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W15v_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 24, [2]
  // W16(o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,i,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,v1,o2) W16(o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W16av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x24_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X24_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W16av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x24_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X24_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W16av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 25, [2]
  // W17(o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,i,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,o2,v1) W17(o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W17aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x25_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X25_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W17aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x25_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X25_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), W17aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 26, [2]
  // W18(o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,o1,i,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,o2,v1) W18(o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W18aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x26_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X26_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W18aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x26_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X26_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), W18aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 27, [2]
  // W19(o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,o1,i,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,v1,o2) W19(o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W19av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x27_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X27_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W19av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x27_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X27_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W19av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 28, [2]
  // W20(i,k,o1,v1) += (    1.00000000) D2(i,o3,k,o2) V2(o1,o3,o2,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,v1,o1) W20(i,k,o1,v1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W20av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x28_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X28_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W20av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x28_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X28_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W20av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 29, [2]
  // W21(k,o1,i,v1) += (    1.00000000) D1(k,o2) V2(o1,i,o2,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,w,v1,o1) W21(k,o1,i,v1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W21av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x29_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X29_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W21av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x29_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X29_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W21av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 30, [2]
  // W22(k,o1,i,v1) += (    1.00000000) D1(k,o2) V2(o1,i,o2,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,v1,o1) W22(k,o1,i,v1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W22av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x30_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X30_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W22av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x30_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X30_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W22av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 31, [2]
  // W23(i,k,o1,v1) += (    1.00000000) D1(i,o2) V2(k,o1,o2,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,v1,o1) W23(i,k,o1,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W23av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x31_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X31_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W23av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x31_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X31_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W23av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 32, [2]
  // W24(i,k,o2,v1) += (    1.00000000) D1(i,o1) V2(k,o2,o1,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,o2,v1) W24(i,k,o2,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W24aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x32_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X32_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W24aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x32_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X32_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), W24aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 33, [2]
  // W25(i,k,o1,v1) += (    1.00000000) D1(i,o2) V2(k,v1,o1,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,v1,o1) W25(i,k,o1,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W25av_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x33_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X33_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W25av_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x33_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X33_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W25av_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 34, [2]
  // W26(i,k,o2,v1) += (    1.00000000) D1(i,o1) V2(k,v1,o1,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,o2,v1) W26(i,k,o2,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W26aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x34_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X34_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W26aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x34_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO1_X34_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), W26aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 35, [1]
  // S2(w,y,i,k) += (    4.00000000) T2(w,y,o1,v1) V2(k,v1,i,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x35_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X35_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 36, [1]
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,v1,o1) V2(k,v1,i,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x36_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X36_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 37, [1]
  // S2(w,y,i,k) += (    4.00000000) T2(w,y,v1,o1) V2(k,o1,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x37_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X37_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 38, [1]
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,o1,v1) V2(k,o1,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x38_type1_eri_o,G_IF_SIGMA_CCOO_CCOV_NO0_X38_TYPE1_ERI_O)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_ccoo_ccov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W1ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W2ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W3ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W8ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W9ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W10ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W11ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W16ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W17ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W18ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W19ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W24ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W25ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W26ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  orz::DTensor W27ccaa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccoo_ccov
  { 
  // No. 0, [1]
  // W0(w,y,o1,o2) += (    1.00000000) T2(c1,w,o1,v1) V2(v1,o2,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x0_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X0_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W0ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 1, [1]
  // W1(y,w,o2,o1) += (    1.00000000) T2(c1,y,o2,v1) V2(v1,o1,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x1_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X1_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 2, [1]
  // W2(w,y,o2,o1) += (    1.00000000) T2(w,c1,o2,v1) V2(v1,o1,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x2_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X2_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W2ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 3, [1]
  // W3(y,w,o1,o2) += (    1.00000000) T2(y,c1,o1,v1) V2(v1,o2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x3_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X3_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W3ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 4, [2]
  // W4(c1,y,k,v1) += (    1.00000000) D1(k,o1) V2(v1,o1,c1,y) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,c1,i,v1) W4(c1,y,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W4cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x4_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X4_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W4cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x4_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X4_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W4cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W5(c1,y,k,v1) += (    1.00000000) D1(k,o1) V2(v1,o1,c1,y) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,w,i,v1) W5(c1,y,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W5cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x5_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X5_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W5cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x5_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X5_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W5cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [2]
  // W6(c1,w,k,v1) += (    1.00000000) D1(k,o1) V2(v1,o1,c1,w) 
  // S2(w,y,i,k) += (    2.00000000) T2(c1,y,i,v1) W6(c1,w,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W6cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x6_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X6_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W6cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x6_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X6_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W6cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [2]
  // W7(c1,w,k,v1) += (    1.00000000) D1(k,o1) V2(v1,o1,c1,w) 
  // S2(w,y,i,k) += (   -1.00000000) T2(y,c1,i,v1) W7(c1,w,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W7cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x7_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X7_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W7cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x7_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X7_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W7cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [1]
  // W8(w,y,o1,i) += (    1.00000000) T2(w,c1,o1,v1) V2(v1,i,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x8_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X8_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W8ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 9, [1]
  // W9(w,y,o1,i) += (    1.00000000) T2(c1,w,o1,v1) V2(v1,i,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x9_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X9_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W9ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 10, [1]
  // W10(y,w,o1,i) += (    1.00000000) T2(c1,y,o1,v1) V2(v1,i,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x10_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X10_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W10ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 11, [1]
  // W11(y,w,o1,i) += (    1.00000000) T2(y,c1,o1,v1) V2(v1,i,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x11_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X11_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W11ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 12, [2]
  // W12(c1,w,i,v1) += (    1.00000000) D1(i,o1) V2(v1,o1,c1,w) 
  // S2(w,y,i,k) += (    2.00000000) T2(y,c1,k,v1) W12(c1,w,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W12cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x12_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X12_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W12cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x12_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X12_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W12cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W13(c1,w,i,v1) += (    1.00000000) D1(i,o1) V2(v1,o1,c1,w) 
  // S2(w,y,i,k) += (   -1.00000000) T2(y,c1,v1,k) W13(c1,w,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W13cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x13_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X13_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W13cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x13_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X13_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W13cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [2]
  // W14(c1,y,i,v1) += (    1.00000000) D1(i,o1) V2(v1,o1,c1,y) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,c1,v1,k) W14(c1,y,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W14cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x14_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X14_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W14cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x14_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X14_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W14cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [2]
  // W15(c1,y,i,v1) += (    1.00000000) D1(i,o1) V2(v1,o1,c1,y) 
  // S2(w,y,i,k) += (   -1.00000000) T2(w,c1,k,v1) W15(c1,y,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W15cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x15_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X15_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W15cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x15_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X15_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W15cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(y,c1,k,v1) V2(v1,i,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x16_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X16_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 17, [1]
  // S2(w,y,i,k) += (    2.00000000) T2(y,c1,v1,k) V2(v1,i,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x17_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X17_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 18, [1]
  // S2(w,y,i,k) += (    2.00000000) T2(w,c1,k,v1) V2(v1,i,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x18_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X18_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 19, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(w,c1,v1,k) V2(v1,i,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x19_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X19_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 20, [1]
  // W16(w,y,o2,o1) += (    1.00000000) T2(c1,w,o2,v1) V2(v1,c1,y,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x20_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X20_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W16ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 21, [1]
  // W17(y,w,o1,o2) += (    1.00000000) T2(c1,y,o1,v1) V2(v1,c1,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x21_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X21_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W17ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 22, [1]
  // W18(w,y,o2,o1) += (    1.00000000) T2(w,c1,o2,v1) V2(v1,c1,y,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x22_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X22_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W18ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 23, [1]
  // W19(y,w,o1,o2) += (    1.00000000) T2(y,c1,o1,v1) V2(v1,c1,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x23_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X23_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W19ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 24, [2]
  // W20(c1,y,k,v1) += (    1.00000000) D1(k,o1) V2(v1,c1,y,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(w,c1,i,v1) W20(c1,y,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W20cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x24_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X24_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W20cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x24_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X24_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W20cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 25, [2]
  // W21(c1,y,k,v1) += (    1.00000000) D1(k,o1) V2(v1,c1,y,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(c1,w,i,v1) W21(c1,y,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W21cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x25_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X25_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W21cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x25_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X25_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W21cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 26, [2]
  // W22(c1,w,k,v1) += (    1.00000000) D1(k,o1) V2(v1,c1,w,o1) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,y,i,v1) W22(c1,w,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W22cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x26_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X26_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W22cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x26_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X26_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W22cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 27, [2]
  // W23(c1,w,k,v1) += (    1.00000000) D1(k,o1) V2(v1,c1,w,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(y,c1,i,v1) W23(c1,w,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W23cc_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x27_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X27_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W23cc_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x27_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X27_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W23cc_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 28, [1]
  // W24(w,y,o1,i) += (    1.00000000) T2(c1,w,o1,v1) V2(v1,c1,y,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x28_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X28_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W24ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 29, [1]
  // W25(y,w,o1,i) += (    1.00000000) T2(c1,y,o1,v1) V2(v1,c1,w,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x29_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X29_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W25ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 30, [1]
  // W26(w,y,o1,i) += (    1.00000000) T2(w,c1,o1,v1) V2(v1,c1,y,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x30_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X30_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W26ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 31, [1]
  // W27(y,w,o1,i) += (    1.00000000) T2(y,c1,o1,v1) V2(v1,c1,w,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x31_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X31_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W27ccaa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 32, [2]
  // W28(c1,w,i,v1) += (    1.00000000) D1(i,o1) V2(v1,c1,w,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(y,c1,k,v1) W28(c1,w,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W28cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x32_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X32_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W28cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x32_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X32_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W28cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 33, [2]
  // W29(c1,w,i,v1) += (    1.00000000) D1(i,o1) V2(v1,c1,w,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(y,c1,v1,k) W29(c1,w,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W29cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x33_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X33_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W29cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x33_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X33_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W29cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 34, [2]
  // W30(c1,y,i,v1) += (    1.00000000) D1(i,o1) V2(v1,c1,y,o1) 
  // S2(w,y,i,k) += (   -1.00000000) T2(w,c1,v1,k) W30(c1,y,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W30cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x34_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X34_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W30cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x34_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X34_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W30cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 35, [2]
  // W31(c1,y,i,v1) += (    1.00000000) D1(i,o1) V2(v1,c1,y,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,c1,k,v1) W31(c1,y,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W31cca_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x35_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X35_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W31cca_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x35_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X35_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W31cca_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 36, [1]
  // S2(w,y,i,k) += (    8.00000000) T2(y,c1,k,v1) V2(v1,c1,w,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x36_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X36_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 37, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(y,c1,v1,k) V2(v1,c1,w,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x37_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X37_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 38, [1]
  // S2(w,y,i,k) += (    2.00000000) T2(w,c1,v1,k) V2(v1,c1,y,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x38_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X38_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 39, [1]
  // S2(w,y,i,k) += (   -4.00000000) T2(w,c1,k,v1) V2(v1,c1,y,i) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x39_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X39_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 40, [2]
  // W32(i,o3,k,v1) += (    1.00000000) D3(i,o3,k,o2,o4,o1) V2(v1,o2,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,o3,v1) W32(i,o3,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W32aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x40_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X40_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W32aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x40_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X40_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W32aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 41, [2]
  // W33(i,k,o3,v1) += (    1.00000000) D3(i,o2,k,o3,o1,o4) V2(v1,o2,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,o3,v1) W33(i,k,o3,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W33aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x41_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X41_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W33aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x41_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X41_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W33aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 42, [2]
  // W34(k,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o2,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,y,i,v1) W34(k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    double W34_sigma_ccoo_ccov = 0;
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x42_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X42_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), &W34_sigma_ccoo_ccov, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x42_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X42_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), &W34_sigma_ccoo_ccov, S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 43, [2]
  // W35(k,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o2,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,i,v1) W35(k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    double W35_sigma_ccoo_ccov = 0;
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x43_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X43_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), &W35_sigma_ccoo_ccov, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x43_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X43_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), &W35_sigma_ccoo_ccov, S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 44, [2]
  // W36(k,o2,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o1,i,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,o2,v1) W36(k,o2,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W36aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x44_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X44_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W36aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x44_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X44_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W36aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 45, [2]
  // W37(k,o1,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o2,i,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,o1,v1) W37(k,o1,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W37aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x45_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X45_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W37aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x45_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X45_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W37aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 46, [2]
  // W38(k,o2,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,i,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,o2,v1) W38(k,o2,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W38aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x46_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X46_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W38aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x46_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X46_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W38aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 47, [2]
  // W39(k,o2,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,i,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,w,o2,v1) W39(k,o2,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W39aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x47_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X47_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W39aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x47_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X47_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W39aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 48, [2]
  // W40(i,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,o2,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,w,k,v1) W40(i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W40a_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x48_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X48_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W40a_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x48_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X48_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W40a_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 49, [2]
  // W41(i,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,o2,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,v1,k) W41(i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W41a_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x49_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X49_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W41a_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x49_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X49_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W41a_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 50, [2]
  // W42(i,v1) += (    1.00000000) D1(o1,o2) V2(v1,o2,i,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,w,k,v1) W42(i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W42a_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x50_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X50_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W42a_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x50_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X50_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W42a_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 51, [2]
  // W43(i,v1) += (    1.00000000) D1(o1,o2) V2(v1,o2,i,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,v1,k) W43(i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W43a_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x51_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X51_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W43a_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x51_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X51_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W43a_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 52, [2]
  // W44(i,v1) += (    1.00000000) D1(o1,o2) V2(v1,i,o1,o2) 
  // S2(w,y,i,k) += (    4.00000000) T2(y,w,k,v1) W44(i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W44a_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x52_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X52_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W44a_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x52_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X52_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W44a_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 53, [2]
  // W45(i,v1) += (    1.00000000) D1(o1,o2) V2(v1,i,o1,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,w,v1,k) W45(i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W45a_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ccov_no0_x53_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X53_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W45a_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x53_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X53_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W45a_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 54, [2]
  // W46(i,k,o3,v1) += (    1.00000000) D2(i,o1,k,o2) V2(v1,o1,o2,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,w,o3,v1) W46(i,k,o3,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W46aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x54_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X54_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W46aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x54_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X54_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W46aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 55, [2]
  // W47(k,i,o1,v1) += (    1.00000000) D1(k,o2) V2(v1,i,o1,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,y,o1,v1) W47(k,i,o1,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W47aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x55_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X55_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W47aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x55_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X55_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W47aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 56, [2]
  // W48(k,i,o1,v1) += (    1.00000000) D1(k,o2) V2(v1,i,o1,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,w,o1,v1) W48(k,i,o1,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W48aa_sigma_ccoo_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x56_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X56_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W48aa_sigma_ccoo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x56_type1_eri_v,G_IF_SIGMA_CCOO_CCOV_NO1_X56_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W48aa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_ccoo_ccov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,y,i,k) += (   -1.00000000) D2(i,o2,k,o1) W0(w,y,o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x0_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X0_TYPE2_ERI_V)
      (sk, ik, W0ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,y,i,k) += (   -1.00000000) D2(i,o2,k,o1) W1(y,w,o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x1_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X1_TYPE2_ERI_V)
      (sk, ik, W1ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,y,i,k) += (   -1.00000000) D2(i,o2,k,o1) W2(w,y,o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x2_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X2_TYPE2_ERI_V)
      (sk, ik, W2ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,y,i,k) += (   -1.00000000) D2(i,o2,k,o1) W3(y,w,o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x3_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X3_TYPE2_ERI_V)
      (sk, ik, W3ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,y,i,k) += (   -1.00000000) D1(k,o1) W8(w,y,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x4_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X4_TYPE2_ERI_V)
      (sk, ik, W8ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,y,i,k) += (    2.00000000) D1(k,o1) W9(w,y,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x5_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X5_TYPE2_ERI_V)
      (sk, ik, W9ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,y,i,k) += (   -1.00000000) D1(k,o1) W10(y,w,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x6_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X6_TYPE2_ERI_V)
      (sk, ik, W10ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,y,i,k) += (    2.00000000) D1(k,o1) W11(y,w,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x7_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X7_TYPE2_ERI_V)
      (sk, ik, W11ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [1]
  // S2(w,y,i,k) += (   -1.00000000) D2(i,o2,k,o1) W16(w,y,o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x8_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X8_TYPE2_ERI_V)
      (sk, ik, W16ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [1]
  // S2(w,y,i,k) += (   -1.00000000) D2(i,o2,k,o1) W17(y,w,o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x9_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X9_TYPE2_ERI_V)
      (sk, ik, W17ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [1]
  // S2(w,y,i,k) += (    2.00000000) D2(i,o2,k,o1) W18(w,y,o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x10_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X10_TYPE2_ERI_V)
      (sk, ik, W18ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // S2(w,y,i,k) += (    2.00000000) D2(i,o2,k,o1) W19(y,w,o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x11_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X11_TYPE2_ERI_V)
      (sk, ik, W19ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,y,i,k) += (   -1.00000000) D1(k,o1) W24(w,y,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x12_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X12_TYPE2_ERI_V)
      (sk, ik, W24ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,y,i,k) += (    2.00000000) D1(k,o1) W25(y,w,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x13_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X13_TYPE2_ERI_V)
      (sk, ik, W25ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [1]
  // S2(w,y,i,k) += (    2.00000000) D1(k,o1) W26(w,y,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x14_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X14_TYPE2_ERI_V)
      (sk, ik, W26ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [1]
  // S2(w,y,i,k) += (   -4.00000000) D1(k,o1) W27(y,w,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x15_type2_eri_v,G_IF_SIGMA_CCOO_CCOV_NO0_X15_TYPE2_ERI_V)
      (sk, ik, W27ccaa_sigma_ccoo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccoo_ccov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
