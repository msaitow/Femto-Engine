                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_cooo_cooo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  `7MM"""YMM                         mm               
//    MM    `7                         MM                  
//    MM   d  .gP"Ya `7MMpMMMb.pMMMb.mmMMmm ,pW"Wq.      
//    MM""MM ,M'   Yb  MM    MM    MM  MM  6W'   `Wb   
//    MM   Y 8M""""""  MM    MM    MM  MM  8M     M8 
//    MM     YM.    ,  MM    MM    MM  MM  YA.   ,A9       
//  .JMML.    `Mbmmd'.JMML  JMML  JMML.`Mbmo`Ybmd9'        

//                                   Generated date : Wed Feb 19 15:56:43 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_cooo_cooo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma,
                                  const double Ecas) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [2]
  // W0(c1,i,m,k) += (    1.00000000) D2(i,m,o1,o2) T2(c1,o2,k,o1) 
  // S2(w,i,k,m) += (   -2.00000000) Fc1(c1,w) W0(c1,i,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W0caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x0_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X0_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W0caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x0_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X0_TYPE1_NOERI)
      (sm, im, W0caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [2]
  // W1(c1,i,m,k) += (    1.00000000) D2(i,m,o1,o2) T2(c1,o2,o1,k) 
  // S2(w,i,k,m) += (    1.00000000) Fc1(c1,w) W1(c1,i,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor W1ca_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sk));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x1_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X1_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W1ca_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x1_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X1_TYPE1_NOERI)
        (sk, ik, sm, im, W1ca_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W2(c1,i,k,m) += (    1.00000000) D2(i,k,o1,o2) T2(o2,c1,o1,m) 
  // S2(w,i,k,m) += (    1.00000000) Fc1(c1,w) W2(c1,i,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W2caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x2_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X2_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W2caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x2_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X2_TYPE1_NOERI)
      (sm, im, W2caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [2]
  // W3(c1,i,k,m) += (    1.00000000) D2(i,o1,o2,k) T2(c1,o1,o2,m) 
  // S2(w,i,k,m) += (    1.00000000) Fc1(c1,w) W3(c1,i,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W3caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x3_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X3_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W3caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x3_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X3_TYPE1_NOERI)
      (sm, im, W3caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [2]
  // W4(c1,i,k,m) += (    1.00000000) D1(i,o1) T2(c1,o1,k,m) 
  // S2(w,i,k,m) += (   -2.00000000) Fc1(c1,w) W4(c1,i,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W4caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x4_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X4_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W4caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x4_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X4_TYPE1_NOERI)
      (sm, im, W4caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W5(c1,i,k,m) += (    1.00000000) D1(i,o1) T2(o1,c1,k,m) 
  // S2(w,i,k,m) += (    1.00000000) Fc1(c1,w) W5(c1,i,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W5caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x5_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X5_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W5caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x5_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X5_TYPE1_NOERI)
      (sm, im, W5caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [2]
  // W6(c1,i,m,k) += (    1.00000000) D3(i,m,o1,o2,o3,k) T2(c1,o2,o3,o1) 
  // S2(w,i,k,m) += (    1.00000000) Fc1(c1,w) W6(c1,i,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W6caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x6_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X6_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W6caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x6_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X6_TYPE1_NOERI)
      (sm, im, W6caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [2]
  // W7(i,m,o2,o3) += (    1.00000000) D2(i,m,o1,o2) Fc1(o1,o3) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o2,o3,k) W7(i,m,o2,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W7aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x7_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X7_TYPE1_NOERI)
      (sm, im, W7aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x7_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X7_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W7aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 8, [2]
  // W8(w,i,m,o3) += (    1.00000000) D2(i,m,o1,o2) T2(w,o2,o3,o1) 
  // S2(w,i,k,m) += (    2.00000000) Fc1(k,o3) W8(w,i,m,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W8caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x8_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X8_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W8caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x8_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X8_TYPE1_NOERI)
      (sm, im, W8caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 9, [2]
  // W9(i,o1,k,o3) += (    1.00000000) D2(i,o1,o2,k) Fc1(o2,o3) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o1,o3,m) W9(i,o1,k,o3) 
  double flops = 0; // Flop count
  orz::DTensor W9aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x9_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X9_TYPE1_NOERI)
    (W9aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x9_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X9_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W9aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 10, [2]
  // W10(w,i,k,o3) += (    1.00000000) D2(i,k,o1,o2) T2(w,o2,o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) Fc1(m,o3) W10(w,i,k,o3) 
  double flops = 0; // Flop count
  orz::DTensor W10caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x10_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X10_TYPE1_NOERI)
      (so1, io1, T2b.cptr(), W10caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x10_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X10_TYPE1_NOERI)
      (sm, im, W10caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 11, [2]
  // W11(w,i,o2,k) += (    1.00000000) D1(i,o1) T2(w,o1,o2,k) 
  // S2(w,i,k,m) += (   -1.00000000) Fc1(m,o2) W11(w,i,o2,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    orz::DTensor W11caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x11_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X11_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W11caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x11_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X11_TYPE1_NOERI)
        (sk, ik, sm, im, W11caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 12, [2]
  // W12(w,i,o2,m) += (    1.00000000) D1(i,o1) T2(w,o1,o2,m) 
  // S2(w,i,k,m) += (    2.00000000) Fc1(k,o2) W12(w,i,o2,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W12caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x12_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X12_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W12caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x12_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X12_TYPE1_NOERI)
      (sm, im, W12caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 13, [2]
  // W13(i,m,k,o2,o3,o4) += (    1.00000000) D3(i,m,o1,k,o2,o3) Fc1(o1,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o3,o4,o2) W13(i,m,k,o2,o3,o4) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W13aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so2));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x13_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X13_TYPE1_NOERI)
        (sm, im, so2, io2, W13aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x13_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X13_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W13aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 14, [2]
  // W14(i,m,o2,o3) += (    1.00000000) D2(i,m,o1,o2) Fc1(o1,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,o2,k,o3) W14(i,m,o2,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor W14aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so3));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x14_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X14_TYPE1_NOERI)
        (sm, im, so3, io3, W14aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x14_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X14_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W14aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 15, [2]
  // W15(w,i,m,o3) += (    1.00000000) D2(i,m,o1,o2) T2(w,o2,o1,o3) 
  // S2(w,i,k,m) += (   -1.00000000) Fc1(k,o3) W15(w,i,m,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor W15ca_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^so3));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x15_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X15_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W15ca_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x15_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X15_TYPE1_NOERI)
        (sm, im, so3, io3, W15ca_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 16, [2]
  // W16(i,k,o2,o3) += (    1.00000000) D2(i,k,o1,o2) Fc1(o1,o3) 
  // S2(w,i,k,m) += (   -0.50000000) T2(o2,w,o3,m) W16(i,k,o2,o3) 
  double flops = 0; // Flop count
  orz::DTensor W16aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x16_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X16_TYPE1_NOERI)
    (W16aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x16_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X16_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W16aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 17, [2]
  // W17(w,i,k,o3) += (    1.00000000) D2(i,o1,o2,k) T2(w,o1,o2,o3) 
  // S2(w,i,k,m) += (   -1.00000000) Fc1(m,o3) W17(w,i,k,o3) 
  double flops = 0; // Flop count
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    if(hintmo.iproc_havingimo()[io3] == myrank) {           
    T2b = T2.get_amp2(io3);
    orz::DTensor W17caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so3));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x17_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X17_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W17caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x17_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X17_TYPE1_NOERI)
        (sm, im, so3, io3, W17caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 18, [2]
  // W18(w,i,k,o2) += (    1.00000000) D1(i,o1) T2(w,o1,k,o2) 
  // S2(w,i,k,m) += (    2.00000000) Fc1(m,o2) W18(w,i,k,o2) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    T2b = T2.get_amp2(io2);
    orz::DTensor W18caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so2));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x18_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X18_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W18caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x18_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X18_TYPE1_NOERI)
        (sm, im, so2, io2, W18caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 19, [2]
  // W19(w,i,o2,m) += (    1.00000000) D1(i,o1) T2(o1,w,o2,m) 
  // S2(w,i,k,m) += (   -1.00000000) Fc1(k,o2) W19(w,i,o2,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W19caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x19_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X19_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W19caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x19_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X19_TYPE1_NOERI)
      (sm, im, W19caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 20, [2]
  // W20(i,m,o2,o3,k,o4) += (    1.00000000) D3(i,m,o1,o2,o3,k) Fc1(o1,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o2,o3,o4) W20(i,m,o2,o3,k,o4) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W20aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so4));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x20_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X20_TYPE1_NOERI)
        (sm, im, so4, io4, W20aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x20_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X20_TYPE1_NOERI)
        (sm, im, so4, io4, T2b.cptr(), W20aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 21, [2]
  // W21(i,m,o1,o3) += (    1.00000000) D2(i,m,o1,o2) Fc1(o2,o3) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o3,k,o1) W21(i,m,o1,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W21aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x21_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X21_TYPE1_NOERI)
        (sm, im, so1, io1, W21aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x21_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X21_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W21aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 22, [2]
  // W22(i,m,o1,o3) += (    1.00000000) D2(i,m,o1,o2) Fc1(o2,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o3,o1,k) W22(i,m,o1,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W22aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x22_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X22_TYPE1_NOERI)
      (sm, im, W22aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x22_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X22_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W22aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 23, [2]
  // W23(i,k,o1,o3) += (    1.00000000) D2(i,k,o1,o2) Fc1(o2,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(o3,w,o1,m) W23(i,k,o1,o3) 
  double flops = 0; // Flop count
  orz::DTensor W23aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x23_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X23_TYPE1_NOERI)
    (W23aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x23_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X23_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W23aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 24, [2]
  // W24(i,o2,k,o3) += (    1.00000000) D2(i,o1,o2,k) Fc1(o1,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o3,o2,m) W24(i,o2,k,o3) 
  double flops = 0; // Flop count
  orz::DTensor W24aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x24_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X24_TYPE1_NOERI)
    (W24aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x24_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X24_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W24aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 25, [2]
  // W25(i,o2) += (    1.00000000) D1(i,o1) Fc1(o1,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,k,m) W25(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W25aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x25_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X25_TYPE1_NOERI)
    (W25aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x25_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X25_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W25aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 26, [2]
  // W26(i,o2) += (    1.00000000) D1(i,o1) Fc1(o1,o2) 
  // S2(w,i,k,m) += (    0.50000000) T2(o2,w,k,m) W26(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W26aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x26_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X26_TYPE1_NOERI)
    (W26aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x26_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X26_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W26aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 27, [2]
  // W27(i,m,o1,o3,k,o4) += (    1.00000000) D3(i,m,o1,o2,o3,k) Fc1(o2,o4) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o4,o3,o1) W27(i,m,o1,o3,k,o4) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W27aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x27_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X27_TYPE1_NOERI)
        (sm, im, so1, io1, W27aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x27_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X27_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W27aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 28, [2]
  // W28(i,o2,o3,k) += (    1.00000000) D2(i,o1,o2,o3) Fc1(k,o1) 
  // S2(w,i,k,m) += (   -0.50000000) T2(o3,w,o2,m) W28(i,o2,o3,k) 
  double flops = 0; // Flop count
  orz::DTensor W28aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x28_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X28_TYPE1_NOERI)
    (W28aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x28_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X28_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W28aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 29, [2]
  // W29(i,o1,o2,k) += (    1.00000000) D2(i,o1,o2,o3) Fc1(k,o3) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o1,o2,m) W29(i,o1,o2,k) 
  double flops = 0; // Flop count
  orz::DTensor W29aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x29_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X29_TYPE1_NOERI)
    (W29aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x29_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X29_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W29aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 30, [2]
  // W30(i,m,o1,o2,o3,k) += (    1.00000000) D3(i,m,o1,o2,o3,o4) Fc1(k,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o2,o3,o1) W30(i,m,o1,o2,o3,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W30aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x30_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X30_TYPE1_NOERI)
        (sm, im, so1, io1, W30aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x30_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X30_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W30aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 31, [2]
  // W31(i,o2,o3,m) += (    1.00000000) D2(i,o1,o2,o3) Fc1(m,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,o3,k,o2) W31(i,o2,o3,m) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor W31aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so2^sm));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x31_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X31_TYPE1_NOERI)
        (sm, im, so2, io2, W31aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x31_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X31_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W31aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 32, [2]
  // W32(i,o2,o3,m) += (    1.00000000) D2(i,o1,o2,o3) Fc1(m,o1) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o3,o2,k) W32(i,o2,o3,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W32aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x32_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X32_TYPE1_NOERI)
      (sm, im, W32aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x32_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X32_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W32aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 33, [2]
  // W33(i,o2,o3,o4,k,m) += (    1.00000000) D3(i,o1,o2,o3,o4,k) Fc1(m,o1) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o3,o4,o2) W33(i,o2,o3,o4,k,m) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor W33aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so2^sm));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x33_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X33_TYPE1_NOERI)
        (sm, im, so2, io2, W33aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x33_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X33_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W33aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 34, [2]
  // W34(m,o2,o3,i) += (    1.00000000) D2(m,o1,o2,o3) Fc1(i,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,k,o3) W34(m,o2,o3,i) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor W34aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so3));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x34_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X34_TYPE1_NOERI)
        (sm, im, so3, io3, W34aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x34_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X34_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W34aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 35, [2]
  // W35(k,o2,o3,i) += (    1.00000000) D2(k,o1,o2,o3) Fc1(i,o1) 
  // S2(w,i,k,m) += (    0.50000000) T2(o2,w,o3,m) W35(k,o2,o3,i) 
  double flops = 0; // Flop count
  orz::DTensor W35aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x35_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X35_TYPE1_NOERI)
    (W35aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x35_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X35_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W35aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 36, [2]
  // W36(m,o2,o3,i) += (    1.00000000) D2(m,o1,o2,o3) Fc1(i,o1) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o2,o3,k) W36(m,o2,o3,i) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W36aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x36_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X36_TYPE1_NOERI)
      (sm, im, W36aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x36_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X36_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W36aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 37, [2]
  // W37(k,o1,o2,i) += (    1.00000000) D2(k,o1,o2,o3) Fc1(i,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o2,o1,m) W37(k,o1,o2,i) 
  double flops = 0; // Flop count
  orz::DTensor W37aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x37_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X37_TYPE1_NOERI)
    (W37aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x37_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X37_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W37aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 38, [2]
  // W38(o2,i) += (    1.00000000) D1(o1,o2) Fc1(i,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,k,m) W38(o2,i) 
  double flops = 0; // Flop count
  orz::DTensor W38aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x38_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X38_TYPE1_NOERI)
    (W38aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x38_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X38_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W38aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 39, [2]
  // W39(o1,i) += (    1.00000000) D1(o1,o2) Fc1(i,o2) 
  // S2(w,i,k,m) += (    0.50000000) T2(o1,w,k,m) W39(o1,i) 
  double flops = 0; // Flop count
  orz::DTensor W39aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x39_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X39_TYPE1_NOERI)
    (W39aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x39_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X39_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W39aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 40, [2]
  // W40(k,o1,m,o3,o4,i) += (    1.00000000) D3(k,o1,m,o2,o3,o4) Fc1(i,o2) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o3,o1,o4) W40(k,o1,m,o3,o4,i) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W40aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so4));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x40_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X40_TYPE1_NOERI)
        (sm, im, so4, io4, W40aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x40_type1_noeri,G_IF_SIGMA_COOO_COOO_NO1_X40_TYPE1_NOERI)
        (sm, im, so4, io4, T2b.cptr(), W40aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 41, [1]
  // S2(w,i,k,m) += (   -1.00000000) Ecas D3(i,m,o1,k,o2,o3) T2(w,o3,o1,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x41_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X41_TYPE1_NOERI)
        (sm, im, so2, io2, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 42, [1]
  // S2(w,i,k,m) += (    2.00000000) Ecas D2(i,m,o2,o1) T2(w,o1,k,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x42_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X42_TYPE1_NOERI)
        (sm, im, so2, io2, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 43, [1]
  // S2(w,i,k,m) += (   -1.00000000) Ecas D2(i,m,o2,o1) T2(w,o1,o2,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x43_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X43_TYPE1_NOERI)
        (sk, ik, sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 44, [1]
  // S2(w,i,k,m) += (   -1.00000000) Ecas D2(i,k,o2,o1) T2(o1,w,o2,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x44_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X44_TYPE1_NOERI)
      (sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 45, [1]
  // S2(w,i,k,m) += (   -1.00000000) Ecas D2(i,o2,o1,k) T2(w,o2,o1,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x45_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X45_TYPE1_NOERI)
      (sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 46, [1]
  // S2(w,i,k,m) += (    2.00000000) Ecas D1(i,o1) T2(w,o1,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x46_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X46_TYPE1_NOERI)
      (sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 47, [1]
  // S2(w,i,k,m) += (   -1.00000000) Ecas D1(i,o1) T2(o1,w,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x47_type1_noeri,G_IF_SIGMA_COOO_COOO_NO0_X47_TYPE1_NOERI)
      (sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_cooo_cooo
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W2caaaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaaa(symblockinfo, 0));
  orz::DTensor W11caaaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaaa(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_cooo
  { 
  // No. 0, [2]
  // W0(c1,w,i,m,o4,o2) += (    1.00000000) D3(i,m,o3,o1,o4,o2) V2(c1,w,o1,o3) 
  // S2(w,i,k,m) += (   -2.00000000) T2(c1,o2,k,o4) W0(c1,w,i,m,o4,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W0caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1^sm^so4));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x0_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X0_TYPE1_ERI_C)
        (sc1, ic1, sm, im, so4, io4, V2_sym.cptr(), W0caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x0_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X0_TYPE1_ERI_C)
        (sc1, ic1, sm, im, so4, io4, T2b.cptr(), W0caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,w,i,m,o4,o2) += (    1.00000000) D3(i,m,o3,o1,o4,o2) V2(c1,w,o1,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o2,o4,k) W1(c1,w,i,m,o4,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W1caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sc1^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x1_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X1_TYPE1_ERI_C)
      (sc1, ic1, sm, im, V2_sym.cptr(), W1caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x1_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X1_TYPE1_ERI_C)
        (sc1, ic1, sk, ik, sm, im, T2b.cptr(), W1caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // W2(w,o1,o4,o3,k,o2) += (    1.00000000) T2(c1,o1,o4,o3) V2(c1,w,k,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x2_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X2_TYPE1_ERI_C)
      (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), W2caaaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(c1,w,i,k,o4,o2) += (    1.00000000) D3(i,k,o3,o1,o4,o2) V2(c1,w,o1,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(o2,c1,o4,m) W3(c1,w,i,k,o4,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W3caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x3_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X3_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W3caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x3_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X3_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W3caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [2]
  // W4(c1,w,i,o2,o4,k) += (    1.00000000) D3(i,o2,o3,o1,o4,k) V2(c1,w,o1,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o2,o4,m) W4(c1,w,i,o2,o4,k) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W4caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x4_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X4_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W4caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x4_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X4_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W4caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W5(c1,w,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  // S2(w,i,k,m) += (   -2.00000000) T2(c1,o2,k,m) W5(c1,w,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W5caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x5_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X5_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W5caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x5_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X5_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W5caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [2]
  // W6(c1,w,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(o2,c1,k,m) W6(c1,w,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W6caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x6_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X6_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W6caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x6_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X6_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W6caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [2]
  // W7(c1,w,i,o3,o1,k) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,k,o2) 
  // S2(w,i,k,m) += (    1.00000000) T2(o1,c1,o3,m) W7(c1,w,i,o3,o1,k) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W7caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x7_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X7_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W7caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x7_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X7_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W7caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W8(c1,w,i,o2,o3,k) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,k,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o2,o3,m) W8(c1,w,i,o2,o3,k) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W8caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x8_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X8_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W8caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x8_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X8_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W8caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W9(c1,w,i,m,o4,o2) += (    1.00000000) D3(i,m,o3,o1,o4,o2) V2(c1,o1,w,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o2,k,o4) W9(c1,w,i,m,o4,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W9caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1^sm^so4));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x9_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X9_TYPE1_ERI_C)
        (sc1, ic1, sm, im, so4, io4, V2_sym.cptr(), W9caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x9_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X9_TYPE1_ERI_C)
        (sc1, ic1, sm, im, so4, io4, T2b.cptr(), W9caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W10(c1,w,i,m,o1,o4) += (    1.00000000) D3(i,m,o3,o1,o4,o2) V2(c1,o2,w,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o1,o4,k) W10(c1,w,i,m,o1,o4) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W10caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sc1^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x10_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X10_TYPE1_ERI_C)
      (sc1, ic1, sm, im, V2_sym.cptr(), W10caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x10_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X10_TYPE1_ERI_C)
        (sc1, ic1, sk, ik, sm, im, T2b.cptr(), W10caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // W11(w,o1,o4,o3,o2,k) += (    1.00000000) T2(c1,o1,o4,o3) V2(c1,o2,w,k) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x11_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X11_TYPE1_ERI_C)
      (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), W11caaaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 12, [2]
  // W12(c1,w,i,k,o4,o1) += (    1.00000000) D3(i,o2,o3,k,o4,o1) V2(c1,o2,w,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(o1,c1,o4,m) W12(c1,w,i,k,o4,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W12caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x12_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X12_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W12caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x12_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X12_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W12caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W13(c1,w,i,o2,k,o4) += (    1.00000000) D3(i,o2,o3,k,o4,o1) V2(c1,o1,w,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o2,o4,m) W13(c1,w,i,o2,k,o4) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W13caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x13_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X13_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W13caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x13_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X13_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W13caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [2]
  // W14(c1,w,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o1,w,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o2,k,m) W14(c1,w,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W14caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x14_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X14_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W14caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x14_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X14_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W14caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [2]
  // W15(c1,w,i,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o2,w,o3) 
  // S2(w,i,k,m) += (    1.00000000) T2(o1,c1,k,m) W15(c1,w,i,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W15caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x15_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X15_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W15caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x15_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X15_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W15caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [2]
  // W16(c1,w,i,o3,o1,k) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o2,w,k) 
  // S2(w,i,k,m) += (   -2.00000000) T2(o1,c1,o3,m) W16(c1,w,i,o3,o1,k) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W16caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x16_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X16_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W16caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x16_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X16_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W16caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 17, [2]
  // W17(c1,w,i,o2,o3,k) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o1,w,k) 
  // S2(w,i,k,m) += (   -2.00000000) T2(c1,o2,o3,m) W17(c1,w,i,o2,o3,k) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W17caaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x17_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X17_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W17caaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x17_type1_eri_c,G_IF_SIGMA_COOO_COOO_NO1_X17_TYPE1_ERI_C)
      (sc1, ic1, sm, im, T2b.cptr(), W17caaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_cooo_cooo
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o3,o1,o4,o2) W2(w,o1,o4,o3,k,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x0_type2_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X0_TYPE2_ERI_C)
      (sm, im, W2caaaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,k,m) += (   -2.00000000) D3(i,m,o3,o1,o4,o2) W11(w,o1,o4,o3,o2,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x1_type2_eri_c,G_IF_SIGMA_COOO_COOO_NO0_X1_TYPE2_ERI_C)
      (sm, im, W11caaaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_cooo_cooo
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W1caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W2caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W5caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W6caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W7caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W8caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W9caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W12caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W13caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W18caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W19caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W20caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W23caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W24caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W25caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W26caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W27caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W30caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W31caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W62caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W63caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W68caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_cooo
  { 
  // No. 0, [1]
  // W0(w,o2,k,o3) += (    1.00000000) T2(o2,c1,k,o1) V2(o1,o3,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x0_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X0_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W0caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 1, [1]
  // W1(w,o2,o3,k) += (    1.00000000) T2(o2,c1,o3,o1) V2(o1,k,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x1_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X1_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W1caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 2, [1]
  // W2(w,o2,m,o3) += (    1.00000000) T2(o2,c1,m,o1) V2(o1,o3,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x2_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X2_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W2caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,o2,o3,m) += (    1.00000000) T2(c1,o2,o1,o3) V2(m,o1,c1,w) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,k,o3,o2) W3(w,o2,o3,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W3ca_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so3^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x3_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X3_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), W3ca_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x3_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X3_TYPE1_ERI_O)
      (sm, im, so3, io3, W3ca_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,o2,k,m) += (    1.00000000) T2(c1,o2,o1,k) V2(m,o1,c1,w) 
  // S2(w,i,k,m) += (    1.00000000) D1(i,o2) W4(w,o2,k,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor W4ca_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x4_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X4_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), W4ca_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x4_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X4_TYPE1_ERI_O)
      (sk, ik, sm, im, W4ca_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 5, [1]
  // W5(w,o2,m,k) += (    1.00000000) T2(o2,c1,m,o1) V2(o1,k,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x5_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X5_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W5caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 6, [1]
  // W6(w,o2,o4,o3) += (    1.00000000) T2(o2,c1,o4,o1) V2(o1,o3,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x6_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X6_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W6caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 7, [1]
  // W7(w,o2,k,o3) += (    1.00000000) T2(c1,o2,k,o1) V2(o1,o3,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x7_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X7_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W7caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 8, [1]
  // W8(w,o2,o3,k) += (    1.00000000) T2(c1,o2,o3,o1) V2(o1,k,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x8_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X8_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W8caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 9, [1]
  // W9(w,o2,m,o3) += (    1.00000000) T2(o2,c1,o1,m) V2(o1,o3,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x9_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X9_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W9caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W10(w,o2,o3,m) += (    1.00000000) T2(c1,o2,o3,o1) V2(m,o1,c1,w) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,o2,o3,k) W10(w,o2,o3,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W10caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x10_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X10_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W10caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x10_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X10_TYPE1_ERI_O)
    (sm, im, W10caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o2,k,m) += (    1.00000000) T2(c1,o2,k,o1) V2(m,o1,c1,w) 
  // S2(w,i,k,m) += (   -2.00000000) D1(i,o2) W11(w,o2,k,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W11caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x11_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X11_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W11caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x11_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X11_TYPE1_ERI_O)
    (sm, im, W11caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 12, [1]
  // W12(w,o2,m,k) += (    1.00000000) T2(o2,c1,o1,m) V2(o1,k,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x12_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X12_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W12caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 13, [1]
  // W13(w,o2,o4,o3) += (    1.00000000) T2(c1,o2,o4,o1) V2(o1,o3,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x13_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X13_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W13caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 14, [2]
  // W14(w,o1,o4,o3,m,o2) += (    1.00000000) T2(c1,o1,o4,o3) V2(m,o2,c1,w) 
  // S2(w,i,k,m) += (    1.00000000) D3(i,o2,o3,o1,o4,k) W14(w,o1,o4,o3,m,o2) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W14caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so3^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x14_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X14_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), W14caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x14_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X14_TYPE1_ERI_O)
      (sm, im, so3, io3, W14caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 15, [2]
  // W15(c1,w,i,o3,o1,m) += (    1.00000000) D2(i,o2,o3,o1) V2(m,o2,c1,w) 
  // S2(w,i,k,m) += (   -2.00000000) T2(c1,o1,k,o3) W15(c1,w,i,o3,o1,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W15ccaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so3^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x15_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X15_TYPE1_ERI_O)
      (sm, im, so3, io3, V2_sym.cptr(), W15ccaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x15_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X15_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), W15ccaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 16, [2]
  // W16(c1,w,i,o3,o1,m) += (    1.00000000) D2(i,o2,o3,o1) V2(m,o2,c1,w) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o1,o3,k) W16(c1,w,i,o3,o1,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W16ccaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x16_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X16_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W16ccaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x16_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X16_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W16ccaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 17, [2]
  // W17(w,o2,o5,o4,o1,o3) += (    1.00000000) T2(c1,o2,o5,o4) V2(o1,o3,c1,w) 
  // S2(w,i,k,m) += (    1.00000000) D4(o1,o3,m,i,o2,o4,k,o5) W17(w,o2,o5,o4,o1,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 

    int imoi = amo2imo[io1] - nclosed;                              
    int imoj = amo2imo[io3] - nclosed;                              
                                                                                         
    // Generate D4 by cumulant expansion ....                                            
    if(ctinp.use_d4cum_of()){
    FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
      (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
       rdm4_ij_sliced.cptr(), imoi, imoj);                                               
    rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, io1, so1, io3, so3, rdm4_ij_sliced);    
    flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
    } // End if
    // Slice the already existing 8-index 4-RDM ....                                            
    else{
    const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
    rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, io1, so1, io3, so3, rdm4_ij_sliced);    
    }
    FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, so3, io1, io3, rdm4_sym.cptr(), nir, nsym, psym);  
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor W17caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so4^so1^so3));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x17_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X17_TYPE1_ERI_O)
        (so1, io1, so3, io3, so4, io4, T2b.cptr(), V2_sym.cptr(), W17caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x17_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X17_TYPE1_ERI_O)
          (sm, im, so1, io1, so3, io3, so4, io4, W17caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  } // End scope

  { 
  // No. 18, [1]
  // W18(w,o2,k,o3) += (    1.00000000) T2(o2,c1,k,o1) V2(o1,c1,w,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x18_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X18_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W18caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 19, [1]
  // W19(w,o2,o3,k) += (    1.00000000) T2(o2,c1,o3,o1) V2(o1,c1,w,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x19_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X19_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W19caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 20, [1]
  // W20(w,o2,m,o3) += (    1.00000000) T2(o2,c1,m,o1) V2(o1,c1,w,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x20_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X20_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W20caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 21, [2]
  // W21(w,o2,o3,m) += (    1.00000000) T2(c1,o2,o1,o3) V2(m,w,c1,o1) 
  // S2(w,i,k,m) += (   -2.00000000) D2(i,k,o3,o2) W21(w,o2,o3,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W21ca_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so3^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x21_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X21_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), W21ca_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x21_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X21_TYPE1_ERI_O)
      (sm, im, so3, io3, W21ca_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 22, [2]
  // W22(w,o2,k,m) += (    1.00000000) T2(c1,o2,o1,k) V2(m,w,c1,o1) 
  // S2(w,i,k,m) += (   -2.00000000) D1(i,o2) W22(w,o2,k,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor W22ca_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x22_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X22_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), W22ca_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x22_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X22_TYPE1_ERI_O)
      (sk, ik, sm, im, W22ca_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 23, [1]
  // W23(w,o2,m,k) += (    1.00000000) T2(o2,c1,m,o1) V2(o1,c1,w,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x23_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X23_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W23caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 24, [1]
  // W24(w,o2,o4,o3) += (    1.00000000) T2(o2,c1,o4,o1) V2(o1,c1,w,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x24_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X24_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W24caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 25, [1]
  // W25(w,o2,k,o3) += (    1.00000000) T2(c1,o2,k,o1) V2(o1,c1,w,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x25_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X25_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W25caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 26, [1]
  // W26(w,o2,o3,k) += (    1.00000000) T2(c1,o2,o3,o1) V2(o1,c1,w,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x26_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X26_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W26caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 27, [1]
  // W27(w,o2,m,o3) += (    1.00000000) T2(o2,c1,o1,m) V2(o1,c1,w,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x27_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X27_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W27caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 28, [2]
  // W28(w,o2,o3,m) += (    1.00000000) T2(c1,o2,o3,o1) V2(m,w,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,k,o3,o2) W28(w,o2,o3,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W28caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x28_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X28_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W28caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x28_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X28_TYPE1_ERI_O)
    (sm, im, W28caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 29, [2]
  // W29(w,o2,k,m) += (    1.00000000) T2(c1,o2,k,o1) V2(m,w,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) D1(i,o2) W29(w,o2,k,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W29caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x29_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X29_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W29caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x29_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X29_TYPE1_ERI_O)
    (sm, im, W29caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 30, [1]
  // W30(w,o2,m,k) += (    1.00000000) T2(o2,c1,o1,m) V2(o1,c1,w,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x30_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X30_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W30caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 31, [1]
  // W31(w,o2,o4,o3) += (    1.00000000) T2(c1,o2,o4,o1) V2(o1,c1,w,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x31_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X31_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W31caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 32, [2]
  // W32(w,o1,o4,o3,m,o2) += (    1.00000000) T2(c1,o1,o4,o3) V2(m,w,c1,o2) 
  // S2(w,i,k,m) += (    1.00000000) D3(i,k,o3,o1,o4,o2) W32(w,o1,o4,o3,m,o2) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W32caaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so3^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x32_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X32_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), W32caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x32_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X32_TYPE1_ERI_O)
      (sm, im, so3, io3, W32caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 33, [2]
  // W33(w,c1,i,o3,o1,m) += (    1.00000000) D2(i,o2,o3,o1) V2(m,w,c1,o2) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o1,k,o3) W33(w,c1,i,o3,o1,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W33ccaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so3^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x33_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X33_TYPE1_ERI_O)
      (sm, im, so3, io3, V2_sym.cptr(), W33ccaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x33_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X33_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), W33ccaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 34, [2]
  // W34(w,c1,i,o2,o3,m) += (    1.00000000) D2(i,o2,o3,o1) V2(m,w,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,o2,o3,k) W34(w,c1,i,o2,o3,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W34ccaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x34_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X34_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W34ccaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x34_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X34_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W34ccaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 35, [2]
  // W35(w,o1,o5,o4,o2,o3) += (    1.00000000) T2(c1,o1,o5,o4) V2(o2,c1,w,o3) 
  // S2(w,i,k,m) += (    1.00000000) D4(o2,o5,m,i,k,o3,o1,o4) W35(w,o1,o5,o4,o2,o3) 
  double flops = 0; // Flop count
  int so2(s_eri);
  int io2(i_eri);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 

    int imoi = amo2imo[io2] - nclosed;                              
    int imoj = amo2imo[io5] - nclosed;                              
                                                                                         
    // Generate D4 by cumulant expansion ....                                            
    if(ctinp.use_d4cum_of()){
    FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
      (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
       rdm4_ij_sliced.cptr(), imoi, imoj);                                               
    rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, io2, so2, io5, so5, rdm4_ij_sliced);    
    flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
    } // End if
    // Slice the already existing 8-index 4-RDM ....                                            
    else{
    const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
    rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, io2, so2, io5, so5, rdm4_ij_sliced);    
    }
    FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so2, so5, io2, io5, rdm4_sym.cptr(), nir, nsym, psym);  
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor W35caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so5^so4^so2));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x35_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X35_TYPE1_ERI_O)
        (so2, io2, so4, io4, so5, io5, T2b.cptr(), V2_sym.cptr(), W35caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x35_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X35_TYPE1_ERI_O)
          (sm, im, so2, io2, so4, io4, so5, io5, W35caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  } // End scope

  { 
  // No. 36, [2]
  // W36(i,m,o3,o1) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,o5,o2,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(o3,w,k,o1) W36(i,m,o3,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W36aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x36_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X36_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W36aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x36_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X36_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W36aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 37, [2]
  // W37(i,m,o5,o3,o1,k) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,k,o2,o4) 
  // S2(w,i,k,m) += (    2.00000000) T2(o3,w,o5,o1) W37(i,m,o5,o3,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W37aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x37_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X37_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W37aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x37_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X37_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W37aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 38, [2]
  // W38(i,m,o5,o3,o1,k) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,o4,k,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(o3,w,o5,o1) W38(i,m,o5,o3,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W38aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x38_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X38_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W38aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x38_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X38_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W38aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 39, [2]
  // W39(i,o3,k,o1) += (    1.00000000) D3(i,o3,o4,o2,o5,k) V2(o1,o5,o2,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(o3,w,m,o1) W39(i,o3,k,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W39aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x39_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X39_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W39aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x39_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X39_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W39aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 40, [2]
  // W40(i,k,o5,o3,m,o1) += (    1.00000000) D3(i,k,o4,o2,o5,o3) V2(m,o1,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o3,o1,o5) W40(i,k,o5,o3,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W40aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so5^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x40_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X40_TYPE1_ERI_O)
      (sm, im, so5, io5, V2_sym.cptr(), W40aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x40_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X40_TYPE1_ERI_O)
      (sm, im, so5, io5, T2b.cptr(), W40aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 41, [2]
  // W41(i,k,o5,o2,m,o1) += (    1.00000000) D3(i,o3,o4,k,o5,o2) V2(m,o3,o1,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o1,o5) W41(i,k,o5,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W41aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so5^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x41_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X41_TYPE1_ERI_O)
      (sm, im, so5, io5, V2_sym.cptr(), W41aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x41_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X41_TYPE1_ERI_O)
      (sm, im, so5, io5, T2b.cptr(), W41aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 42, [2]
  // W42(i,o3,m,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o1,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o3,o1,k) W42(i,o3,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W42aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x42_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X42_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W42aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x42_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X42_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W42aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 43, [2]
  // W43(i,o2,m,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o3,o1,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o1,k) W43(i,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W43aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x43_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X43_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W43aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x43_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X43_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W43aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 44, [2]
  // W44(i,o4,o2,m,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o3,k,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o2,o1,o4) W44(i,o4,o2,m,k,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W44aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so4^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x44_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X44_TYPE1_ERI_O)
      (sm, im, so4, io4, V2_sym.cptr(), W44aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x44_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X44_TYPE1_ERI_O)
      (sm, im, so4, io4, T2b.cptr(), W44aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 45, [2]
  // W45(i,o3,o1,k) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,k,o2,o4) 
  // S2(w,i,k,m) += (    2.00000000) T2(o3,w,m,o1) W45(i,o3,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W45aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x45_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X45_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W45aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x45_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X45_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W45aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 46, [2]
  // W46(i,o3,o1,k) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o4,k,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(o3,w,m,o1) W46(i,o3,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W46aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x46_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X46_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W46aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x46_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X46_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W46aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 47, [2]
  // W47(i,o4,o2,m,o1,k) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o1,k,o3) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o1,o4) W47(i,o4,o2,m,o1,k) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W47aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so4^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x47_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X47_TYPE1_ERI_O)
      (sm, im, so4, io4, V2_sym.cptr(), W47aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x47_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X47_TYPE1_ERI_O)
      (sm, im, so4, io4, T2b.cptr(), W47aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 48, [2]
  // W48(k,m,o5,o2,o1,i) += (    1.00000000) D3(k,o4,m,o3,o5,o2) V2(o1,o4,i,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(o5,w,o2,o1) W48(k,m,o5,o2,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W48aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x48_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X48_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W48aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x48_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X48_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W48aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 49, [2]
  // W49(i,m,o3,o1) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,o5,o2,o4) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,o3,k,o1) W49(i,m,o3,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W49aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x49_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X49_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W49aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x49_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X49_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W49aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 50, [2]
  // W50(i,m,o5,o3,o1,k) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,k,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o3,o5,o1) W50(i,m,o5,o3,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W50aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x50_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X50_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W50aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x50_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X50_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W50aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 51, [2]
  // W51(i,m,o2,o5,o1,k) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,o4,k,o3) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o5,o1) W51(i,m,o2,o5,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W51aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x51_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X51_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W51aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x51_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X51_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W51aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 52, [2]
  // W52(i,k,o3,o1) += (    1.00000000) D3(i,k,o4,o2,o5,o3) V2(o1,o5,o2,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(o3,w,o1,m) W52(i,k,o3,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W52aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x52_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X52_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W52aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x52_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X52_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W52aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 53, [2]
  // W53(i,o3,o5,k,m,o1) += (    1.00000000) D3(i,o3,o4,o2,o5,k) V2(m,o1,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o3,o5,o1) W53(i,o3,o5,k,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W53aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x53_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X53_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W53aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x53_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X53_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W53aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 54, [2]
  // W54(i,o2,o5,k,m,o1) += (    1.00000000) D3(i,o3,o4,o2,o5,k) V2(m,o3,o1,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o5,o1) W54(i,o2,o5,k,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W54aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x54_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X54_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W54aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x54_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X54_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W54aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 55, [2]
  // W55(i,o3,m,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o1,o2,o4) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o3,k,o1) W55(i,o3,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W55aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x55_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X55_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W55aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x55_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X55_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W55aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 56, [2]
  // W56(i,o2,m,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o3,o1,o4) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o2,k,o1) W56(i,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W56aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x56_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X56_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W56aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x56_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X56_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W56aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 57, [2]
  // W57(i,o4,o2,m,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o3,k,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o4,o1) W57(i,o4,o2,m,k,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W57aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x57_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X57_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W57aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x57_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X57_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W57aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 58, [2]
  // W58(i,o3,o1,k) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,k,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(o3,w,o1,m) W58(i,o3,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W58aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x58_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X58_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W58aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x58_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X58_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W58aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 59, [2]
  // W59(i,o2,o1,k) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o4,k,o3) 
  // S2(w,i,k,m) += (   -1.00000000) T2(o2,w,o1,m) W59(i,o2,o1,k) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W59aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x59_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X59_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W59aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x59_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X59_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W59aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 60, [2]
  // W60(i,o3,o4,m,o1,k) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o1,k,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o3,o4,o1) W60(i,o3,o4,m,o1,k) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W60aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x60_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X60_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W60aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x60_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X60_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W60aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 61, [2]
  // W61(k,o4,m,o5,o1,i) += (    1.00000000) D3(k,o4,m,o3,o5,o2) V2(o1,o2,i,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o5,o4,o1) W61(k,o4,m,o5,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W61aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x61_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X61_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W61aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x61_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X61_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W61aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 62, [1]
  // W62(w,o3,k,o4) += (    1.00000000) T2(o3,w,o1,o2) V2(o2,k,o1,o4) 
  double flops = 0; // Flop count
  int so2(s_eri);
  int io2(i_eri);
  T2b = T2.get_amp2(io2);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x62_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X62_TYPE1_ERI_O)
    (so2, io2, T2b.cptr(), V2_sym.cptr(), W62caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 63, [1]
  // W63(w,o3,k,o4) += (    1.00000000) T2(w,o3,o2,o1) V2(o1,k,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x63_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X63_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W63caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 64, [2]
  // W64(w,o3,m,o4) += (    1.00000000) T2(w,o3,o2,o1) V2(m,o2,o1,o4) 
  // S2(w,i,k,m) += (   -1.00000000) D2(i,k,o4,o3) W64(w,o3,m,o4) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W64caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x64_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X64_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W64caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x64_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X64_TYPE1_ERI_O)
    (sm, im, W64caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 65, [2]
  // W65(w,o3,m,o4) += (    1.00000000) T2(w,o3,o2,o1) V2(m,o1,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) D2(i,o3,o4,k) W65(w,o3,m,o4) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W65caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x65_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X65_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W65caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x65_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X65_TYPE1_ERI_O)
    (sm, im, W65caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 66, [2]
  // W66(w,o1,m,k) += (    1.00000000) T2(w,o1,o2,o3) V2(m,o3,k,o2) 
  // S2(w,i,k,m) += (    2.00000000) D1(i,o1) W66(w,o1,m,k) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W66caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x66_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X66_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), W66caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x66_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X66_TYPE1_ERI_O)
    (sm, im, W66caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 67, [2]
  // W67(w,o1,m,k) += (    1.00000000) T2(w,o1,o2,o3) V2(m,o2,k,o3) 
  // S2(w,i,k,m) += (   -1.00000000) D1(i,o1) W67(w,o1,m,k) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W67caa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x67_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X67_TYPE1_ERI_O)
      (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), W67caa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_cooo_no1_x67_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X67_TYPE1_ERI_O)
    (sm, im, W67caa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 68, [1]
  // W68(w,o3,o4,o5) += (    1.00000000) T2(w,o3,o2,o1) V2(o1,o4,o2,o5) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x68_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X68_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W68caaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 69, [2]
  // W69(i,m,o5,o1) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,o3,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,k,o5) W69(i,m,o5,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      orz::DTensor W69a_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sm^so5^so1));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x69_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X69_TYPE1_ERI_O)
        (sm, im, so1, io1, so5, io5, V2_sym.cptr(), W69a_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io5);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x69_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X69_TYPE1_ERI_O)
        (sm, im, so1, io1, so5, io5, T2b.cptr(), W69a_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 70, [2]
  // W70(i,m,o5,o1) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(o1,o3,o2,o4) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o1,o5,k) W70(i,m,o5,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W70aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x70_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X70_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W70aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x70_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X70_TYPE1_ERI_O)
        (sk, ik, sm, im, so1, io1, T2b.cptr(), W70aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 71, [2]
  // W71(i,m,o4,o5,k,o1) += (    1.00000000) D3(i,m,o4,o2,o5,o3) V2(k,o3,o1,o2) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o1,o5,o4) W71(i,m,o4,o5,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W71aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm^so4^sk));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x71_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X71_TYPE1_ERI_O)
        (sk, ik, sm, im, so4, io4, V2_sym.cptr(), W71aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x71_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X71_TYPE1_ERI_O)
        (sk, ik, sm, im, so4, io4, T2b.cptr(), W71aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 72, [2]
  // W72(i,k,o5,o1) += (    1.00000000) D3(i,k,o4,o2,o5,o3) V2(o1,o3,o2,o4) 
  // S2(w,i,k,m) += (    0.50000000) T2(o1,w,o5,m) W72(i,k,o5,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W72aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x72_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X72_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W72aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x72_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X72_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W72aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 73, [2]
  // W73(i,o5,k,o1) += (    1.00000000) D3(i,o3,o4,o2,o5,k) V2(o1,o3,o2,o4) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o1,o5,m) W73(i,o5,k,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W73aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x73_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X73_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W73aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x73_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X73_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W73aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 74, [2]
  // W74(i,o4,o5,k,m,o1) += (    1.00000000) D3(i,o3,o4,o2,o5,k) V2(m,o3,o1,o2) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o1,o5,o4) W74(i,o4,o5,k,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W74aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so4^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x74_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X74_TYPE1_ERI_O)
      (sm, im, so4, io4, V2_sym.cptr(), W74aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x74_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X74_TYPE1_ERI_O)
      (sm, im, so4, io4, T2b.cptr(), W74aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 75, [2]
  // W75(i,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,k,m) W75(i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W75a_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x75_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X75_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W75a_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x75_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X75_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W75a_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 76, [2]
  // W76(i,o4,m,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o3,o1,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,k,o4) W76(i,o4,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W76aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so4^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x76_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X76_TYPE1_ERI_O)
      (sm, im, so4, io4, V2_sym.cptr(), W76aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x76_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X76_TYPE1_ERI_O)
      (sm, im, so4, io4, T2b.cptr(), W76aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 77, [2]
  // W77(i,o4,m,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(m,o3,o1,o2) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o1,o4,k) W77(i,o4,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W77aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x77_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X77_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W77aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x77_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X77_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W77aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 78, [2]
  // W78(i,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  // S2(w,i,k,m) += (    0.50000000) T2(o1,w,k,m) W78(i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W78a_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x78_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X78_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W78a_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x78_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X78_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W78a_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 79, [2]
  // W79(i,o4,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,o3,o1,o2) 
  // S2(w,i,k,m) += (    0.50000000) T2(o1,w,o4,m) W79(i,o4,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  orz::DTensor W79aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x79_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X79_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W79aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x79_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X79_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W79aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 80, [2]
  // W80(i,o4,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,o2,o1,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o1,o4,m) W80(i,o4,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  orz::DTensor W80aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x80_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X80_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W80aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x80_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X80_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W80aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 81, [2]
  // W81(i,o5,o2,k) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(k,o3,o1,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(o2,w,o5,m) W81(i,o5,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  orz::DTensor W81aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x81_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X81_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W81aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x81_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X81_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W81aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 82, [2]
  // W82(i,o3,o5,k) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(k,o2,o1,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o3,o5,m) W82(i,o3,o5,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  orz::DTensor W82aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x82_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X82_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W82aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x82_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X82_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W82aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 83, [2]
  // W83(i,o5,o2,m) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(m,o3,o1,o4) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,o2,k,o5) W83(i,o5,o2,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W83aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so5^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x83_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X83_TYPE1_ERI_O)
      (sm, im, so5, io5, V2_sym.cptr(), W83aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x83_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X83_TYPE1_ERI_O)
      (sm, im, so5, io5, T2b.cptr(), W83aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 84, [2]
  // W84(i,o5,o2,m) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(m,o3,o1,o4) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o2,o5,k) W84(i,o5,o2,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W84aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x84_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X84_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W84aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x84_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X84_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W84aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 85, [2]
  // W85(i,o4,o1,o5,m,k) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(m,o3,k,o2) 
  // S2(w,i,k,m) += (   -0.50000000) T2(w,o1,o5,o4) W85(i,o4,o1,o5,m,k) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W85aaaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so4^sm));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x85_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X85_TYPE1_ERI_O)
      (sm, im, so4, io4, V2_sym.cptr(), W85aaaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x85_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X85_TYPE1_ERI_O)
      (sm, im, so4, io4, T2b.cptr(), W85aaaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 86, [2]
  // W86(m,o5,o2,i) += (    1.00000000) D3(m,o3,o4,o1,o5,o2) V2(i,o3,o1,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o5,k,o2) W86(m,o5,o2,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W86a_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sm^so2^si));
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x86_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X86_TYPE1_ERI_O)
        (si, ii, sm, im, so2, io2, V2_sym.cptr(), W86a_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x86_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X86_TYPE1_ERI_O)
        (si, ii, sm, im, so2, io2, T2b.cptr(), W86a_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 87, [2]
  // W87(k,o5,o2,i) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(i,o3,o1,o4) 
  // S2(w,i,k,m) += (    0.50000000) T2(o5,w,o2,m) W87(k,o5,o2,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  orz::DTensor W87aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, si));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x87_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X87_TYPE1_ERI_O)
    (si, ii, V2_sym.cptr(), W87aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x87_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X87_TYPE1_ERI_O)
      (si, ii, sm, im, T2b.cptr(), W87aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 88, [2]
  // W88(m,o5,o2,i) += (    1.00000000) D3(m,o3,o4,o1,o5,o2) V2(i,o3,o1,o4) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o5,o2,k) W88(m,o5,o2,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W88aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^si));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x88_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X88_TYPE1_ERI_O)
      (si, ii, sm, im, V2_sym.cptr(), W88aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x88_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X88_TYPE1_ERI_O)
        (si, ii, sk, ik, sm, im, T2b.cptr(), W88aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 89, [2]
  // W89(k,o3,o1,i) += (    1.00000000) D3(k,o3,o1,o4,o2,o5) V2(i,o4,o2,o5) 
  // S2(w,i,k,m) += (    0.50000000) T2(w,o1,o3,m) W89(k,o3,o1,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  orz::DTensor W89aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, si));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x89_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X89_TYPE1_ERI_O)
    (si, ii, V2_sym.cptr(), W89aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x89_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X89_TYPE1_ERI_O)
      (si, ii, sm, im, T2b.cptr(), W89aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 90, [2]
  // W90(o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(i,o2,o1,o3) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o4,k,m) W90(o4,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  orz::DTensor W90a_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, si));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x90_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X90_TYPE1_ERI_O)
    (si, ii, V2_sym.cptr(), W90a_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x90_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X90_TYPE1_ERI_O)
      (si, ii, sm, im, T2b.cptr(), W90a_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 91, [2]
  // W91(m,o4,o1,i) += (    1.00000000) D2(m,o3,o4,o2) V2(o1,o2,i,o3) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o4,k,o1) W91(m,o4,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W91aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x91_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X91_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W91aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x91_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X91_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W91aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 92, [2]
  // W92(k,o4,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o2,i,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(o4,w,o1,m) W92(k,o4,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W92aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x92_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X92_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W92aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x92_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X92_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W92aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 93, [2]
  // W93(o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(i,o2,o1,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(o4,w,k,m) W93(o4,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  orz::DTensor W93a_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, si));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x93_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X93_TYPE1_ERI_O)
    (si, ii, V2_sym.cptr(), W93a_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x93_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X93_TYPE1_ERI_O)
      (si, ii, sm, im, T2b.cptr(), W93a_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 94, [2]
  // W94(m,o4,o1,i) += (    1.00000000) D2(m,o3,o4,o2) V2(o1,o2,i,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(o4,w,k,o1) W94(m,o4,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W94aa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x94_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X94_TYPE1_ERI_O)
      (sm, im, so1, io1, V2_sym.cptr(), W94aa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x94_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X94_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), W94aa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 95, [2]
  // W95(k,o1,o4,i) += (    1.00000000) D2(k,o2,o1,o3) V2(o4,o2,i,o3) 
  // S2(w,i,k,m) += (    0.50000000) T2(o1,w,m,o4) W95(k,o1,o4,i) 
  double flops = 0; // Flop count
  int so4(s_eri);
  int io4(i_eri);
  orz::DTensor W95aaa_sigma_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so4));
  FC_FUNC(g_if_sigma_cooo_cooo_no0_x95_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X95_TYPE1_ERI_O)
    (so4, io4, V2_sym.cptr(), W95aaa_sigma_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io4);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x95_type1_eri_o,G_IF_SIGMA_COOO_COOO_NO1_X95_TYPE1_ERI_O)
      (sm, im, so4, io4, T2b.cptr(), W95aaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_cooo_cooo
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o3,o2) W0(w,o2,k,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x0_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X0_TYPE2_ERI_O)
      (sm, im, W0caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o3,o2) W1(w,o2,o3,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x1_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X1_TYPE2_ERI_O)
      (sm, im, W1caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,o2,o3,k) W2(w,o2,m,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x2_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X2_TYPE2_ERI_O)
      (sm, im, W2caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,i,k,m) += (   -2.00000000) D1(i,o2) W5(w,o2,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x3_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X3_TYPE2_ERI_O)
      (sm, im, W5caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o3,k,o4,o2) W6(w,o2,o4,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x4_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X4_TYPE2_ERI_O)
      (sm, im, W6caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o3,o2) W7(w,o2,k,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x5_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X5_TYPE2_ERI_O)
      (sm, im, W7caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o3,o2) W8(w,o2,o3,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x6_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X6_TYPE2_ERI_O)
      (sm, im, W8caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,k,o3,o2) W9(w,o2,m,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x7_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X7_TYPE2_ERI_O)
      (sm, im, W9caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [1]
  // S2(w,i,k,m) += (    1.00000000) D1(i,o2) W12(w,o2,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x8_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X8_TYPE2_ERI_O)
      (sm, im, W12caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o3,o2,o4,k) W13(w,o2,o4,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x9_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X9_TYPE2_ERI_O)
      (sm, im, W13caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o3,o2) W18(w,o2,k,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x10_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X10_TYPE2_ERI_O)
      (sm, im, W18caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // S2(w,i,k,m) += (    4.00000000) D2(i,m,o3,o2) W19(w,o2,o3,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x11_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X11_TYPE2_ERI_O)
      (sm, im, W19caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,o2,o3,k) W20(w,o2,m,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x12_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X12_TYPE2_ERI_O)
      (sm, im, W20caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,i,k,m) += (    4.00000000) D1(i,o2) W23(w,o2,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x13_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X13_TYPE2_ERI_O)
      (sm, im, W23caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [1]
  // S2(w,i,k,m) += (   -2.00000000) D3(i,m,o3,k,o4,o2) W24(w,o2,o4,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x14_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X14_TYPE2_ERI_O)
      (sm, im, W24caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o3,o2) W25(w,o2,k,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x15_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X15_TYPE2_ERI_O)
      (sm, im, W25caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o3,o2) W26(w,o2,o3,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x16_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X16_TYPE2_ERI_O)
      (sm, im, W26caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 17, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,o2,o3,k) W27(w,o2,m,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x17_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X17_TYPE2_ERI_O)
      (sm, im, W27caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 18, [1]
  // S2(w,i,k,m) += (   -2.00000000) D1(i,o2) W30(w,o2,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x18_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X18_TYPE2_ERI_O)
      (sm, im, W30caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 19, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o3,k,o4,o2) W31(w,o2,o4,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x19_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X19_TYPE2_ERI_O)
      (sm, im, W31caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 20, [1]
  // S2(w,i,k,m) += (    2.00000000) D2(i,m,o4,o3) W62(w,o3,k,o4) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x20_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X20_TYPE2_ERI_O)
      (sm, im, W62caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 21, [1]
  // S2(w,i,k,m) += (   -1.00000000) D2(i,m,o4,o3) W63(w,o3,k,o4) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x21_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X21_TYPE2_ERI_O)
      (sm, im, W63caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 22, [1]
  // S2(w,i,k,m) += (   -0.50000000) D3(i,m,o4,o3,o5,k) W68(w,o3,o4,o5) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x22_type2_eri_o,G_IF_SIGMA_COOO_COOO_NO0_X22_TYPE2_ERI_O)
      (sm, im, W68caaa_sigma_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@loadD4C(a,begin)
  //*-- FEMTO begins --//*
  // Label : d4c_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  orz::DTensor C5;
  orz::LoadBin(ctinp.dir()/(format("D4C_g[%d]")%i_eri).str()) >> C5;

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_cooo
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (   -0.50000000) C5(m,i,o3,o6,k,o1) T2(w,o3,o1,o6) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so6 = 0;so6 < nir;++so6){ 
    for(int io6 = symblockinfo.psym()(so6,I_O,I_BEGIN);io6 <= symblockinfo.psym()(so6,I_O,I_END);++io6){ 
      T2b = T2.get_amp2(io6);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x0_type1_d4c_o,G_IF_SIGMA_COOO_COOO_NO0_X0_TYPE1_D4C_O)
        (sm, im, so1, io1, so6, io6, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,k,m) += (   -0.50000000) C5(m,i,k,o6,o3,o1) T2(w,o3,o6,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x1_type1_d4c_o,G_IF_SIGMA_COOO_COOO_NO0_X1_TYPE1_D4C_O)
      (sm, im, so1, io1, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,i,k,m) += (    0.50000000) C5(i,m,o6,k,o5,o1) T2(w,o1,o6,o5) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x2_type1_d4c_o,G_IF_SIGMA_COOO_COOO_NO0_X2_TYPE1_D4C_O)
        (sm, im, so1, io1, so5, io5, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,i,k,m) += (   -0.50000000) C5(i,m,o5,o2,o6,k) T2(w,o2,o6,o5) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x3_type1_d4c_o,G_IF_SIGMA_COOO_COOO_NO0_X3_TYPE1_D4C_O)
        (sk, ik, sm, im, so5, io5, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,i,k,m) += (   -0.50000000) C5(o5,o2,o6,k,i,m) T2(w,o2,o6,o5) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x4_type1_d4c_o,G_IF_SIGMA_COOO_COOO_NO0_X4_TYPE1_D4C_O)
      (sm, im, so5, io5, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,i,k,m) += (    0.50000000) C5(k,o3,o1,o5,m,i) T2(w,o1,o3,o5) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x5_type1_d4c_o,G_IF_SIGMA_COOO_COOO_NO0_X5_TYPE1_D4C_O)
        (si, ii, sm, im, so5, io5, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadD4C(a,end)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_cooo_cooo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
