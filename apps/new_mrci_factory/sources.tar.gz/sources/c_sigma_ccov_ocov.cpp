                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccov_ocov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  __/\\\\\\\\\\\\\\\____________________________________________________________________                                   
//   _\/\\\///////////_____________________________________________________________________                                             
//    _\/\\\_______________________________________________________/\\\_____________________                                         
//     _\/\\\\\\\\\\\__________/\\\\\\\\______/\\\\\__/\\\\\_____/\\\\\\\\\\\______/\\\\\____ 
//      _\/\\\///////_________/\\\/////\\\___/\\\///\\\\\///\\\__\////\\\////_____/\\\///\\\__               
//       _\/\\\_______________/\\\\\\\\\\\___\/\\\_\//\\\__\/\\\_____\/\\\________/\\\__\//\\\_       
//        _\/\\\______________\//\\///////____\/\\\__\/\\\__\/\\\_____\/\\\_/\\___\//\\\__/\\\__            
//         _\/\\\_______________\//\\\\\\\\\\__\/\\\__\/\\\__\/\\\_____\//\\\\\_____\///\\\\\/___    
//          _\///_________________\//////////___\///___\///___\///_______\/////________\/////_____                                   

//                                   Generated date : Wed Feb 19 15:56:08 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccov_ocov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  if(myrank == 0){
  { 
  // No. 0, [2]
  // W0(y,i,o2,o3) += (    1.00000000) D2(i,o1,o2,o3) Fc1(y,o1) 
  // S2(w,y,i,a) += (    1.00000000) T2(o2,w,o3,a) W0(y,i,o2,o3) 
  double flops = 0; // Flop count
  orz::DTensor W0caaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x0_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO0_X0_TYPE1_NOERI)
    (W0caaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x0_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO1_X0_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W0caaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 1, [2]
  // W1(w,i,o2,o3) += (    1.00000000) D2(i,o1,o2,o3) Fc1(w,o1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o2,y,o3,a) W1(w,i,o2,o3) 
  double flops = 0; // Flop count
  orz::DTensor W1caaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x1_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO0_X1_TYPE1_NOERI)
    (W1caaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x1_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO1_X1_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W1caaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 2, [2]
  // W2(y,o2) += (    1.00000000) D1(o1,o2) Fc1(y,o1) 
  // S2(w,y,i,a) += (    1.00000000) T2(o2,w,i,a) W2(y,o2) 
  double flops = 0; // Flop count
  orz::DTensor W2ca_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x2_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO0_X2_TYPE1_NOERI)
    (W2ca_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x2_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO1_X2_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W2ca_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 3, [2]
  // W3(w,o2) += (    1.00000000) D1(o1,o2) Fc1(w,o1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o2,y,i,a) W3(w,o2) 
  double flops = 0; // Flop count
  orz::DTensor W3ca_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x3_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO0_X3_TYPE1_NOERI)
    (W3ca_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x3_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO1_X3_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W3ca_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 4, [2]
  // W4(y,a) += (    1.00000000) D1(o1,o2) T2(o1,y,o2,a) 
  // S2(w,y,i,a) += (    4.00000000) Fc1(w,i) W4(y,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W4c_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xc(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x4_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO0_X4_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W4c_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x4_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO1_X4_TYPE1_NOERI)
      (sa, ia, W4c_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W5(w,a) += (    1.00000000) D1(o1,o2) T2(o2,w,o1,a) 
  // S2(w,y,i,a) += (   -2.00000000) Fc1(y,i) W5(w,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W5c_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xc(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x5_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO0_X5_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W5c_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x5_type1_noeri,G_IF_SIGMA_CCOV_OCOV_NO1_X5_TYPE1_NOERI)
      (sa, ia, W5c_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ocov
  { 
  // No. 0, [2]
  // W0(c1,y,w,i,o3,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,y,w,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(o3,c1,o1,a) W0(c1,y,w,i,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W0ccaaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x0_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X0_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W0ccaaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x0_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X0_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W0ccaaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,w,y,i,o3,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,y,o2) 
  // S2(w,y,i,a) += (   -1.00000000) T2(o3,c1,o1,a) W1(c1,w,y,i,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W1ccaaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x1_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X1_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W1ccaaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x1_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X1_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W1ccaaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W2(c1,y,w,o2) += (    1.00000000) D1(o1,o2) V2(c1,y,w,o1) 
  // S2(w,y,i,a) += (    2.00000000) T2(o2,c1,i,a) W2(c1,y,w,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W2cca_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x2_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X2_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W2cca_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x2_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X2_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W2cca_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(c1,w,y,o2) += (    1.00000000) D1(o1,o2) V2(c1,w,y,o1) 
  // S2(w,y,i,a) += (   -1.00000000) T2(o2,c1,i,a) W3(c1,w,y,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W3cca_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x3_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X3_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W3cca_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x3_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X3_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W3cca_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [2]
  // W4(c1,y,w,o1,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,y,w,i) 
  // S2(w,y,i,a) += (   -4.00000000) T2(o2,c1,o1,a) W4(c1,y,w,o1,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W4ccaaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x4_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X4_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W4ccaaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x4_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X4_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W4ccaaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W5(c1,w,y,o1,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,w,y,i) 
  // S2(w,y,i,a) += (    2.00000000) T2(o2,c1,o1,a) W5(c1,w,y,o1,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W5ccaaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x5_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X5_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W5ccaaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x5_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X5_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W5ccaaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [2]
  // W6(w,i,o5,o2) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(w,o3,o1,o4) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o5,y,o2,a) W6(w,i,o5,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W6aaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x6_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X6_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W6aaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x6_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X6_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W6aaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [2]
  // W7(y,i,o1,o4) += (    1.00000000) D3(i,o3,o1,o4,o2,o5) V2(y,o3,o2,o5) 
  // S2(w,y,i,a) += (    1.00000000) T2(o1,w,o4,a) W7(y,i,o1,o4) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W7aaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x7_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X7_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W7aaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x7_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X7_TYPE1_ERI_C)
      (sa, ia, sy, iy, T2b.cptr(), W7aaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W8(w,o4) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o2,o1,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o4,y,i,a) W8(w,o4) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W8a_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x8_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X8_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W8a_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x8_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X8_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W8a_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W9(y,o4) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,o2,o1,o3) 
  // S2(w,y,i,a) += (    1.00000000) T2(o4,w,i,a) W9(y,o4) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W9a_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x9_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X9_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W9a_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x9_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X9_TYPE1_ERI_C)
      (sa, ia, sy, iy, T2b.cptr(), W9a_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W10(w,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,i,o1,o3) 
  // S2(w,y,i,a) += (    4.00000000) T2(o4,y,o2,a) W10(w,o2,o4,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W10aaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x10_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X10_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W10aaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x10_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X10_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W10aaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [2]
  // W11(y,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,i,o1,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o4,w,o2,a) W11(y,o2,o4,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W11aaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x11_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X11_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W11aaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x11_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X11_TYPE1_ERI_C)
      (sa, ia, sy, iy, T2b.cptr(), W11aaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [2]
  // W12(w,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o1,i,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o4,y,o2,a) W12(w,o2,o4,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W12aaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x12_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X12_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W12aaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x12_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X12_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W12aaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W13(y,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,o1,i,o3) 
  // S2(w,y,i,a) += (    1.00000000) T2(o4,w,o2,a) W13(y,o2,o4,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W13aaa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x13_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO0_X13_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W13aaa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x13_type1_eri_c,G_IF_SIGMA_CCOV_OCOV_NO1_X13_TYPE1_ERI_C)
      (sa, ia, sy, iy, T2b.cptr(), W13aaa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ocov
  { 
  // No. 0, [2]
  // W0(w,i,o4,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o2,w,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o4,y,o1,a) W0(w,i,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W0caa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x0_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO0_X0_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W0caa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x0_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO1_X0_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W0caa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [2]
  // W1(y,i,o4,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o2,y,o3) 
  // S2(w,y,i,a) += (    1.00000000) T2(o4,w,o1,a) W1(y,i,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W1caa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x1_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO0_X1_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W1caa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x1_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO1_X1_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W1caa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,o2,w,i) 
  // S2(w,y,i,a) += (    4.00000000) T2(o3,y,o1,a) W2(w,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W2caa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x2_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO0_X2_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W2caa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x2_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO1_X2_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W2caa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(y,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,o2,y,i) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o3,w,o1,a) W3(y,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W3caa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x3_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO0_X3_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W3caa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x3_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO1_X3_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W3caa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,i,w,o2) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o3,y,o1,a) W4(w,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W4caa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x4_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO0_X4_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W4caa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x4_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO1_X4_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W4caa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W5(y,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,i,y,o2) 
  // S2(w,y,i,a) += (    1.00000000) T2(o3,w,o1,a) W5(y,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W5caa_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x5_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO0_X5_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W5caa_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x5_type1_eri_o,G_IF_SIGMA_CCOV_OCOV_NO1_X5_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W5caa_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ocov
  { 
  // No. 0, [2]
  // W0(w,i,o3,o1,a,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(a,v1,w,o2) 
  // S2(w,y,i,a) += (   -2.00000000) T2(y,o3,v1,o1) W0(w,i,o3,o1,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W0caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x0_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X0_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W0caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x0_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X0_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W0caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(y,i,o1,o3,a,v1) += (    1.00000000) D2(i,o2,o1,o3) V2(a,v1,y,o2) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,o1,v1,o3) W1(y,i,o1,o3,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W1caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x1_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X1_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W1caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x1_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X1_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W1caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,o2,a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,w,o1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(y,o2,v1,i) W2(w,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W2cav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x2_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X2_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W2cav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x2_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X2_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W2cav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(y,o2,a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,y,o1) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,o2,v1,i) W3(y,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W3cav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x3_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X3_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W3cav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x3_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X3_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W3cav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,o1,o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,w,i) 
  // S2(w,y,i,a) += (    4.00000000) T2(y,o2,v1,o1) W4(w,o1,o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W4caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x4_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X4_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W4caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x4_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X4_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W4caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(y,o1,o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,y,i) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,o1,v1,o2) W5(y,o1,o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W5caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x5_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X5_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W5caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x5_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X5_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W5caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(w,i,o3,o1,a,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(a,w,o2,v1) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,o3,v1,o1) W6(w,i,o3,o1,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W6caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x6_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X6_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W6caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x6_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X6_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W6caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(y,i,o1,o3,a,v1) += (    1.00000000) D2(i,o2,o1,o3) V2(a,y,o2,v1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,o1,v1,o3) W7(y,i,o1,o3,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W7caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x7_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X7_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W7caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x7_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X7_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W7caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W8(w,o2,a,v1) += (    1.00000000) D1(o1,o2) V2(a,w,o1,v1) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,o2,v1,i) W8(w,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W8cav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x8_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X8_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W8cav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x8_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X8_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W8cav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(y,o2,a,v1) += (    1.00000000) D1(o1,o2) V2(a,y,o1,v1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,o2,v1,i) W9(y,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W9cav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ocov_no0_x9_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X9_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W9cav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x9_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X9_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W9cav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W10(y,o1,o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,y,i,v1) 
  // S2(w,y,i,a) += (    4.00000000) T2(w,o2,v1,o1) W10(y,o1,o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W10caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x10_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X10_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W10caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x10_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X10_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W10caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o1,o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,w,i,v1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(y,o1,v1,o2) W11(w,o1,o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W11caav_sigma_ccov_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ocov_no0_x11_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO0_X11_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W11caav_sigma_ccov_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ocov_no1_x11_type1_eri_v,G_IF_SIGMA_CCOV_OCOV_NO1_X11_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W11caav_sigma_ccov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccov_ocov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
