                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_fock_d_ccoo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

//                                   Generated date : Wed Feb 19 15:54:49 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::fock_d_ccoo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const orz::DTensor &CFock,                                                 
                                  const int alloc_type,                                                      
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "Hdiag" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor Hdiagb; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) h6_int D2(i,i,k,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x0_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X0_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [1]
  // Hdiag(w,w,i,k) += (    2.00000000) h6_int D2(i,k,k,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x1_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X1_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [1]
  // Hdiag(w,y,i,k) += (   -1.00000000) D2(i,i,k,k) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x2_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X2_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [1]
  // Hdiag(w,w,i,k) += (   -2.00000000) D2(i,k,k,i) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x3_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X3_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [1]
  // Hdiag(w,y,i,k) += (   -1.00000000) D2(i,i,k,k) P1(y,y) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x4_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X4_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [1]
  // Hdiag(w,y,i,k) += (   -4.00000000) h6_int D1(k,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x5_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X5_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [1]
  // Hdiag(w,w,i,k) += (    2.00000000) h6_int D1(k,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x6_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X6_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) D1(k,k) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x7_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X7_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 8, [1]
  // Hdiag(w,w,i,k) += (   -2.00000000) D1(k,k) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x8_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X8_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 9, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) D1(k,k) P1(y,y) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x9_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X9_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 10, [1]
  // Hdiag(w,w,i,i) += (   -8.00000000) h6_int D1(i,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x10_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X10_TYPE1_NOERI)
      (si, ii, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 11, [1]
  // Hdiag(w,y,i,i) += (    4.00000000) h6_int D1(i,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x11_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X11_TYPE1_NOERI)
      (si, ii, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 12, [1]
  // Hdiag(w,w,i,i) += (    8.00000000) D1(i,i) P1(w,w) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x12_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X12_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 13, [1]
  // Hdiag(w,y,i,i) += (   -2.00000000) D1(i,i) P1(w,w) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x13_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X13_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 14, [1]
  // Hdiag(w,y,i,i) += (   -2.00000000) D1(i,i) P1(y,y) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x14_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X14_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 15, [1]
  // Hdiag(w,w,i,k) += (    2.00000000) h6_int D1(i,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x15_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X15_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 16, [1]
  // Hdiag(w,y,i,k) += (   -4.00000000) h6_int D1(i,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x16_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X16_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 17, [1]
  // Hdiag(w,w,i,k) += (   -2.00000000) D1(i,i) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x17_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X17_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 18, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) D1(i,i) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x18_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X18_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 19, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) D1(i,i) P1(y,y) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x19_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X19_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 20, [1]
  // Hdiag(w,y,i,k) += (    8.00000000) h6_int 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x20_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X20_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 21, [1]
  // Hdiag(w,w,i,k) += (   -4.00000000) h6_int 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x21_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X21_TYPE1_NOERI)
      (sk, ik, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 22, [1]
  // Hdiag(w,y,i,k) += (   -4.00000000) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x22_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X22_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 23, [1]
  // Hdiag(w,w,i,k) += (    4.00000000) P1(w,w) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x23_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X23_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 24, [1]
  // Hdiag(w,y,i,k) += (   -4.00000000) P1(y,y) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x24_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X24_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 25, [1]
  // Hdiag(w,w,i,i) += (    8.00000000) h6_int 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x25_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X25_TYPE1_NOERI)
      (si, ii, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 26, [1]
  // Hdiag(w,y,i,i) += (   -4.00000000) h6_int 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x26_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X26_TYPE1_NOERI)
      (si, ii, &h6_int, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 27, [1]
  // Hdiag(w,w,i,i) += (   -8.00000000) P1(w,w) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x27_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X27_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 28, [1]
  // Hdiag(w,y,i,i) += (    2.00000000) P1(w,w) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x28_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X28_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 29, [1]
  // Hdiag(w,y,i,i) += (    2.00000000) P1(y,y) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x29_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X29_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 30, [1]
  // Hdiag(w,y,i,k) += (    1.00000000) D3(i,i,k,k,o1,o2) P1(o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x30_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X30_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 31, [1]
  // Hdiag(w,w,i,k) += (    1.00000000) D3(i,k,k,i,o1,o2) P1(o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x31_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X31_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 32, [1]
  // Hdiag(w,y,i,k) += (   -2.00000000) D2(k,k,o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x32_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X32_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 33, [1]
  // Hdiag(w,w,i,k) += (    1.00000000) D2(k,k,o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x33_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X33_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 34, [1]
  // Hdiag(w,w,i,i) += (   -4.00000000) D2(i,i,o1,o2) P1(o1,o2) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x34_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X34_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 35, [1]
  // Hdiag(w,y,i,i) += (    2.00000000) D2(i,i,o2,o1) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x35_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X35_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 36, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) D2(i,o1,k,k) P1(i,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x36_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X36_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 37, [1]
  // Hdiag(w,w,i,k) += (    2.00000000) D2(i,k,k,o1) P1(i,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x37_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X37_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 38, [1]
  // Hdiag(w,w,i,k) += (    1.00000000) D2(i,i,o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x38_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X38_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 39, [1]
  // Hdiag(w,y,i,k) += (   -2.00000000) D2(i,i,o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x39_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X39_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 40, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) D2(i,i,k,o1) P1(k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x40_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X40_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 41, [1]
  // Hdiag(w,w,i,k) += (    2.00000000) D2(i,k,o1,i) P1(k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x41_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X41_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 42, [1]
  // Hdiag(w,y,i,k) += (    4.00000000) D1(o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x42_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X42_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 43, [1]
  // Hdiag(w,w,i,k) += (   -2.00000000) D1(o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x43_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X43_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 44, [1]
  // Hdiag(w,y,i,k) += (   -4.00000000) D1(k,o1) P1(k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x44_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X44_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 45, [1]
  // Hdiag(w,w,i,k) += (    2.00000000) D1(k,o1) P1(k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x45_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X45_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 46, [1]
  // Hdiag(w,w,i,i) += (   -4.00000000) D1(i,o1) P1(i,o1) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x46_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X46_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 47, [1]
  // Hdiag(w,y,i,i) += (    2.00000000) D1(i,o1) P1(i,o1) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x47_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X47_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 48, [1]
  // Hdiag(w,w,i,i) += (    4.00000000) D1(o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x48_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X48_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 49, [1]
  // Hdiag(w,y,i,i) += (   -2.00000000) D1(o1,o2) P1(o2,o1) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x49_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X49_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 50, [1]
  // Hdiag(w,y,i,i) += (    2.00000000) D1(i,o1) P1(i,o1) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x50_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X50_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 51, [1]
  // Hdiag(w,w,i,i) += (   -4.00000000) D1(i,o1) P1(i,o1) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x51_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X51_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 52, [1]
  // Hdiag(w,w,i,k) += (    2.00000000) D1(i,o1) P1(i,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x52_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X52_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 53, [1]
  // Hdiag(w,y,i,k) += (   -4.00000000) D1(i,o1) P1(i,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x53_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X53_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 54, [1]
  // Hdiag(w,y,i,k) += (   -2.00000000) D1(k,k) P1(i,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x54_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X54_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 55, [1]
  // Hdiag(w,w,i,k) += (    1.00000000) D1(k,k) P1(i,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x55_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X55_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 56, [1]
  // Hdiag(w,w,i,k) += (   -4.00000000) D1(i,k) P1(i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x56_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X56_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 57, [1]
  // Hdiag(w,y,i,k) += (    2.00000000) D1(i,k) P1(i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x57_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X57_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 58, [1]
  // Hdiag(w,w,i,i) += (    8.00000000) P1(i,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x58_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X58_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 59, [1]
  // Hdiag(w,y,i,i) += (   -4.00000000) P1(i,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ii]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x59_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X59_TYPE1_NOERI)
      (si, ii, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ii, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 60, [1]
  // Hdiag(w,y,i,k) += (    4.00000000) P1(i,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x60_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X60_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 61, [1]
  // Hdiag(w,w,i,k) += (   -2.00000000) P1(i,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x61_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X61_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 62, [1]
  // Hdiag(w,w,i,k) += (    1.00000000) D1(i,i) P1(k,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x62_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X62_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 63, [1]
  // Hdiag(w,y,i,k) += (   -2.00000000) D1(i,i) P1(k,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x63_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X63_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 64, [1]
  // Hdiag(w,y,i,k) += (    4.00000000) P1(k,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x64_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X64_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 65, [1]
  // Hdiag(w,w,i,k) += (   -2.00000000) P1(k,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_d_ccoo_no0_x65_type1_noeri,G_IF_FOCK_D_CCOO_NO0_X65_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("fock_d_ccoo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
