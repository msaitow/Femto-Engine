                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_diag_coov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//      ______                  __           
//     / ____/___   ____ ___   / /_ ____     
//    / /_   / _ \ / __ `__ \ / __// __ \ 
//   / __/  /  __// / / / / // /_ / /_/ /    
//  /_/     \___//_/ /_/ /_/ \__/ \____/  

//                                   Generated date : Wed Feb 19 15:55:10 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::diag_coov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "Hdiag" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor Hdiagb; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [1]
  // Hdiag(w,i,k,a) += (   -1.00000000) Fc0 D2(i,i,k,k) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x0_type1_noeri,G_IF_DIAG_COOV_NO0_X0_TYPE1_NOERI)
      (sa, ia, &Fc0, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D2(i,i,k,k) Fc1(w,w) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x1_type1_noeri,G_IF_DIAG_COOV_NO0_X1_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) Fc0 D1(i,i) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x2_type1_noeri,G_IF_DIAG_COOV_NO0_X2_TYPE1_NOERI)
      (sa, ia, &Fc0, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D1(i,i) Fc1(w,w) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x3_type1_noeri,G_IF_DIAG_COOV_NO0_X3_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [1]
  // Hdiag(w,i,k,a) += (   -1.00000000) D3(i,i,k,k,o1,o2) Fc1(o1,o2) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x4_type1_noeri,G_IF_DIAG_COOV_NO0_X4_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D2(i,i,o1,o2) Fc1(o1,o2) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x5_type1_noeri,G_IF_DIAG_COOV_NO0_X5_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D2(i,i,k,o1) Fc1(k,o1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x6_type1_noeri,G_IF_DIAG_COOV_NO0_X6_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D1(i,i) Fc1(k,k) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x7_type1_noeri,G_IF_DIAG_COOV_NO0_X7_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 8, [1]
  // Hdiag(w,i,k,a) += (   -1.00000000) D2(i,i,k,k) Fc1(a,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x8_type1_noeri,G_IF_DIAG_COOV_NO0_X8_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 9, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D1(i,i) Fc1(a,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x9_type1_noeri,G_IF_DIAG_COOV_NO0_X9_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : diag_coov
  { 
  // No. 0, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D3(i,i,k,k,o1,o2) V2(w,w,o1,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x0_type1_eri_c,G_IF_DIAG_COOV_NO0_X0_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D2(i,i,o1,o2) V2(w,w,o1,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x1_type1_eri_c,G_IF_DIAG_COOV_NO0_X1_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D2(i,i,k,o1) V2(w,w,k,o1) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x2_type1_eri_c,G_IF_DIAG_COOV_NO0_X2_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D1(i,i) V2(w,w,k,k) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x3_type1_eri_c,G_IF_DIAG_COOV_NO0_X3_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D3(i,i,k,o1,o2,k) V2(w,o1,w,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x4_type1_eri_c,G_IF_DIAG_COOV_NO0_X4_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D2(i,i,o1,o2) V2(w,o1,w,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x5_type1_eri_c,G_IF_DIAG_COOV_NO0_X5_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // Hdiag(w,i,k,a) += (   -4.00000000) D2(i,i,k,o1) V2(w,k,w,o1) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x6_type1_eri_c,G_IF_DIAG_COOV_NO0_X6_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // Hdiag(w,i,k,a) += (    4.00000000) D1(i,i) V2(w,k,w,k) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x7_type1_eri_c,G_IF_DIAG_COOV_NO0_X7_TYPE1_ERI_C)
      (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : diag_coov
  { 
  // No. 0, [1]
  // Hdiag(w,i,k,a) += (   -0.50000000) D4(o1,o3,i,i,k,k,o2,o4) V2(o1,o3,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 

      int imoi = amo2imo[io1] - nclosed;                              
      int imoj = amo2imo[io3] - nclosed;                              
                                                                                           
      // Generate D4 by cumulant expansion ....                                            
      if(ctinp.use_d4cum_of()){
      FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
        (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
         rdm4_ij_sliced.cptr(), imoi, imoj);                                               
      rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, io1, so1, io3, so3, rdm4_ij_sliced);    
      flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
      } // End if
      // Slice the already existing 8-index 4-RDM ....                                            
      else{
      const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
      rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, io1, so1, io3, so3, rdm4_ij_sliced);    
      }
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, so3, io1, io3, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_diag_coov_no0_x0_type1_eri_o,G_IF_DIAG_COOV_NO0_X0_TYPE1_ERI_O)
        (sa, ia, so1, io1, so3, io3, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D3(i,i,o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x1_type1_eri_o,G_IF_DIAG_COOV_NO0_X1_TYPE1_ERI_O)
      (sa, ia, so1, io1, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D3(i,i,k,o2,o3,o1) V2(k,o2,o1,o3) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x2_type1_eri_o,G_IF_DIAG_COOV_NO0_X2_TYPE1_ERI_O)
      (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D2(i,i,o1,o2) V2(k,k,o1,o2) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x3_type1_eri_o,G_IF_DIAG_COOV_NO0_X3_TYPE1_ERI_O)
      (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // Hdiag(w,i,k,a) += (   -1.00000000) D2(i,i,o1,o2) V2(k,o1,k,o2) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x4_type1_eri_o,G_IF_DIAG_COOV_NO0_X4_TYPE1_ERI_O)
      (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : diag_coov
  { 
  // No. 0, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D2(i,i,k,k) V2(a,a,w,w) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x0_type1_eri_v,G_IF_DIAG_COOV_NO0_X0_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 1, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D1(i,i) V2(a,a,w,w) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x1_type1_eri_v,G_IF_DIAG_COOV_NO0_X1_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 2, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D2(i,k,k,i) V2(a,w,w,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x2_type1_eri_v,G_IF_DIAG_COOV_NO0_X2_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 3, [1]
  // Hdiag(w,i,k,a) += (    1.00000000) D1(i,i) V2(a,w,w,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x3_type1_eri_v,G_IF_DIAG_COOV_NO0_X3_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 4, [1]
  // Hdiag(w,i,k,a) += (   -1.00000000) D3(i,i,k,k,o1,o2) V2(a,a,o1,o2) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x4_type1_eri_v,G_IF_DIAG_COOV_NO0_X4_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 5, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D2(i,i,o1,o2) V2(a,a,o1,o2) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x5_type1_eri_v,G_IF_DIAG_COOV_NO0_X5_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 6, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D2(i,i,k,o1) V2(a,a,k,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x6_type1_eri_v,G_IF_DIAG_COOV_NO0_X6_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 7, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D1(i,i) V2(a,a,k,k) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x7_type1_eri_v,G_IF_DIAG_COOV_NO0_X7_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 8, [1]
  // Hdiag(w,i,k,a) += (   -1.00000000) D3(i,o1,k,k,o2,i) V2(a,o1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x8_type1_eri_v,G_IF_DIAG_COOV_NO0_X8_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 9, [1]
  // Hdiag(w,i,k,a) += (    2.00000000) D2(i,o1,o2,i) V2(a,o1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x9_type1_eri_v,G_IF_DIAG_COOV_NO0_X9_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 10, [1]
  // Hdiag(w,i,k,a) += (   -2.00000000) D2(i,k,o1,i) V2(a,k,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x10_type1_eri_v,G_IF_DIAG_COOV_NO0_X10_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 11, [1]
  // Hdiag(w,i,k,a) += (   -1.00000000) D1(i,i) V2(a,k,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_coov_no0_x11_type1_eri_v,G_IF_DIAG_COOV_NO0_X11_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("diag_coov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
