                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_covv_ocov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//      _/_/_/_/                            _/             
//     _/        _/_/    _/_/_/  _/_/    _/_/_/_/    _/_/  
//    _/_/_/  _/_/_/_/  _/    _/    _/    _/      _/    _/ 
//   _/      _/        _/    _/    _/    _/      _/    _/  
//  _/        _/_/_/  _/    _/    _/      _/_/    _/_/     

//                                   Generated date : Wed Feb 19 15:55:37 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_covv_ocov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  if(myrank == 0){
  { 
  // No. 0, [2]
  // W0(w,i,o1,a) += (    1.00000000) D2(i,o1,o2,o3) T2(w,o3,a,o2) 
  // S2(w,i,a,c) += (    2.00000000) Fc1(o1,c) W0(w,i,o1,a) 
  double flops = 0; // Flop count
  orz::DTensor W0caav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x0_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO0_X0_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W0caav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x0_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO1_X0_TYPE1_NOERI)
      (sc, ic, W0caav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 1, [2]
  // W1(w,i,o1,c) += (    1.00000000) D2(i,o1,o2,o3) T2(o3,w,o2,c) 
  // S2(w,i,a,c) += (   -1.00000000) Fc1(o1,a) W1(w,i,o1,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    if(hintmo.iproc_havingimo()[ic] == myrank) {           
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    orz::DTensor W1caa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x1_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO0_X1_TYPE1_NOERI)
      (sc, ic, T2b.cptr(), W1caa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x1_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO1_X1_TYPE1_NOERI)
      (sc, ic, W1caa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W2(w,i,o2,a) += (    1.00000000) D1(i,o1) T2(w,o1,a,o2) 
  // S2(w,i,a,c) += (    2.00000000) Fc1(o2,c) W2(w,i,o2,a) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    T2b = T2.get_amp2(io2);
    orz::DTensor W2cav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, so2));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x2_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO0_X2_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W2cav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    for(int sc = 0;sc < nir;++sc){ 
    for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
      S2b = orz::DTensor(retval.namps_iamp()[ic]);
      FC_FUNC(g_if_sigma_covv_ocov_no1_x2_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO1_X2_TYPE1_NOERI)
        (sc, ic, so2, io2, W2cav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ic, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [2]
  // W3(w,i,o2,c) += (    1.00000000) D1(i,o1) T2(o1,w,o2,c) 
  // S2(w,i,a,c) += (   -1.00000000) Fc1(o2,a) W3(w,i,o2,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    if(hintmo.iproc_havingimo()[ic] == myrank) {           
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    orz::DTensor W3caa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x3_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO0_X3_TYPE1_NOERI)
      (sc, ic, T2b.cptr(), W3caa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x3_type1_noeri,G_IF_SIGMA_COVV_OCOV_NO1_X3_TYPE1_NOERI)
      (sc, ic, W3caa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_covv_ocov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0cavv_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcavv(symblockinfo, 0));
  orz::DTensor W1cavv_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcavv(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_covv_ocov
  { 
  // No. 0, [1]
  // W0(w,o2,c,a) += (    1.00000000) T2(o2,c1,o1,c) V2(o1,a,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x0_type1_eri_o,G_IF_SIGMA_COVV_OCOV_NO0_X0_TYPE1_ERI_O)
      (sc, ic, so1, io1, T2b.cptr(), V2_sym.cptr(), W0cavv_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // W1(w,o2,c,a) += (    1.00000000) T2(o2,c1,o1,c) V2(o1,c1,w,a) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x1_type1_eri_o,G_IF_SIGMA_COVV_OCOV_NO0_X1_TYPE1_ERI_O)
      (sc, ic, so1, io1, T2b.cptr(), V2_sym.cptr(), W1cavv_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W2(i,o2,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o4,o3,a) 
  // S2(w,i,a,c) += (   -1.00000000) T2(o2,w,o1,c) W2(i,o2,o1,a) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W2aav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaav(symblockinfo, so1));
  FC_FUNC(g_if_sigma_covv_ocov_no0_x2_type1_eri_o,G_IF_SIGMA_COVV_OCOV_NO0_X2_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W2aav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x2_type1_eri_o,G_IF_SIGMA_COVV_OCOV_NO1_X2_TYPE1_ERI_O)
      (sc, ic, so1, io1, T2b.cptr(), W2aav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(i,o3,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,a,o2,o4) 
  // S2(w,i,a,c) += (   -1.00000000) T2(o3,w,o1,c) W3(i,o3,o1,a) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W3aav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaav(symblockinfo, so1));
  FC_FUNC(g_if_sigma_covv_ocov_no0_x3_type1_eri_o,G_IF_SIGMA_COVV_OCOV_NO0_X3_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W3aav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x3_type1_eri_o,G_IF_SIGMA_COVV_OCOV_NO1_X3_TYPE1_ERI_O)
      (sc, ic, so1, io1, T2b.cptr(), W3aav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_covv_ocov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,a,c) += (    1.00000000) D1(i,o2) W0(w,o2,c,a) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x0_type2_eri_o,G_IF_SIGMA_COVV_OCOV_NO0_X0_TYPE2_ERI_O)
      (sc, ic, W0cavv_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,a,c) += (   -2.00000000) D1(i,o2) W1(w,o2,c,a) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x1_type2_eri_o,G_IF_SIGMA_COVV_OCOV_NO0_X1_TYPE2_ERI_O)
      (sc, ic, W1cavv_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_covv_ocov
  { 
  // No. 0, [2]
  // W0(c1,w,i,o3,o1,c) += (    1.00000000) D2(i,o2,o3,o1) V2(c,o2,c1,w) 
  // S2(w,i,a,c) += (   -2.00000000) T2(c1,o1,a,o3) W0(c1,w,i,o3,o1,c) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W0ccaa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so3^sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x0_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X0_TYPE1_ERI_V)
      (sc, ic, so3, io3, V2_sym.cptr(), W0ccaa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x0_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X0_TYPE1_ERI_V)
      (sc, ic, so3, io3, T2b.cptr(), W0ccaa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,w,i,o3,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,o2,c1,w) 
  // S2(w,i,a,c) += (    1.00000000) T2(o1,c1,o3,c) W1(c1,w,i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  orz::DTensor W1ccaaa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_covv_ocov_no0_x1_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X1_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W1ccaaa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x1_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X1_TYPE1_ERI_V)
      (sa, ia, sc, ic, T2b.cptr(), W1ccaaa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,o2,a,c) += (    1.00000000) T2(c1,o2,a,o1) V2(c,o1,c1,w) 
  // S2(w,i,a,c) += (   -2.00000000) D1(i,o2) W2(w,o2,a,c) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  orz::DTensor W2cav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sc));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x2_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X2_TYPE1_ERI_V)
      (sc, ic, so1, io1, T2b.cptr(), V2_sym.cptr(), W2cav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_covv_ocov_no1_x2_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X2_TYPE1_ERI_V)
    (sc, ic, W2cav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,c1,i,o3,o1,c) += (    1.00000000) D2(i,o2,o3,o1) V2(c,w,c1,o2) 
  // S2(w,i,a,c) += (    1.00000000) T2(c1,o1,a,o3) W3(w,c1,i,o3,o1,c) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W3ccaa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so3^sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x3_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X3_TYPE1_ERI_V)
      (sc, ic, so3, io3, V2_sym.cptr(), W3ccaa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x3_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X3_TYPE1_ERI_V)
      (sc, ic, so3, io3, T2b.cptr(), W3ccaa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,c1,i,o3,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,w,c1,o2) 
  // S2(w,i,a,c) += (   -2.00000000) T2(o1,c1,o3,c) W4(w,c1,i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  orz::DTensor W4ccaaa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_covv_ocov_no0_x4_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X4_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W4ccaaa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x4_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X4_TYPE1_ERI_V)
      (sa, ia, sc, ic, T2b.cptr(), W4ccaaa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W5(w,o2,a,c) += (    1.00000000) T2(c1,o2,a,o1) V2(c,w,c1,o1) 
  // S2(w,i,a,c) += (    1.00000000) D1(i,o2) W5(w,o2,a,c) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  orz::DTensor W5cav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sc));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x5_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X5_TYPE1_ERI_V)
      (sc, ic, so1, io1, T2b.cptr(), V2_sym.cptr(), W5cav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_covv_ocov_no1_x5_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X5_TYPE1_ERI_V)
    (sc, ic, W5cav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(i,o5,o2,c) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(c,o3,o1,o4) 
  // S2(w,i,a,c) += (    2.00000000) T2(w,o2,a,o5) W6(i,o5,o2,c) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W6aa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaa(symblockinfo, so5^sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x6_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X6_TYPE1_ERI_V)
      (sc, ic, so5, io5, V2_sym.cptr(), W6aa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x6_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X6_TYPE1_ERI_V)
      (sc, ic, so5, io5, T2b.cptr(), W6aa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(i,o1,o4,a) += (    1.00000000) D3(i,o3,o1,o4,o2,o5) V2(a,o3,o2,o5) 
  // S2(w,i,a,c) += (   -1.00000000) T2(o4,w,o1,c) W7(i,o1,o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  orz::DTensor W7aaa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_covv_ocov_no0_x7_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X7_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W7aaa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x7_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X7_TYPE1_ERI_V)
      (sa, ia, sc, ic, T2b.cptr(), W7aaa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W8(i,o2,o1,c) += (    1.00000000) D2(i,o3,o4,o2) V2(c,o3,o1,o4) 
  // S2(w,i,a,c) += (    2.00000000) T2(w,o2,a,o1) W8(i,o2,o1,c) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W8aa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x8_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X8_TYPE1_ERI_V)
      (sc, ic, so1, io1, V2_sym.cptr(), W8aa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x8_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X8_TYPE1_ERI_V)
      (sc, ic, so1, io1, T2b.cptr(), W8aa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(i,o3,o1,c) += (    1.00000000) D2(i,o3,o4,o2) V2(c,o1,o2,o4) 
  // S2(w,i,a,c) += (    2.00000000) T2(w,o3,a,o1) W9(i,o3,o1,c) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W9aa_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x9_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X9_TYPE1_ERI_V)
      (sc, ic, so1, io1, V2_sym.cptr(), W9aa_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x9_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X9_TYPE1_ERI_V)
      (sc, ic, so1, io1, T2b.cptr(), W9aa_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W10(i,o1,o3,c,v1,a) += (    1.00000000) D2(i,o2,o1,o3) V2(c,v1,o2,a) 
  // S2(w,i,a,c) += (   -1.00000000) T2(w,o3,v1,o1) W10(i,o1,o3,c,v1,a) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W10aavv_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaavv(symblockinfo, so1^sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x10_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X10_TYPE1_ERI_V)
      (sc, ic, so1, io1, V2_sym.cptr(), W10aavv_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x10_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X10_TYPE1_ERI_V)
      (sc, ic, so1, io1, T2b.cptr(), W10aavv_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(i,o1,o3,c,a,v1) += (    1.00000000) D2(i,o2,o1,o3) V2(c,o2,a,v1) 
  // S2(w,i,a,c) += (    2.00000000) T2(w,o3,v1,o1) W11(i,o1,o3,c,a,v1) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W11aavv_sigma_covv_ocov(orz::mr::sizeof_sympack_Xaavv(symblockinfo, so1^sc));
    FC_FUNC(g_if_sigma_covv_ocov_no0_x11_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X11_TYPE1_ERI_V)
      (sc, ic, so1, io1, V2_sym.cptr(), W11aavv_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_covv_ocov_no1_x11_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X11_TYPE1_ERI_V)
      (sc, ic, so1, io1, T2b.cptr(), W11aavv_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 12, [2]
  // W12(w,o1,c,a) += (    1.00000000) T2(w,o1,v1,o2) V2(c,v1,o2,a) 
  // S2(w,i,a,c) += (   -1.00000000) D1(i,o1) W12(w,o1,c,a) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  orz::DTensor W12cav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sc));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x12_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X12_TYPE1_ERI_V)
      (sc, ic, so2, io2, T2b.cptr(), V2_sym.cptr(), W12cav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_covv_ocov_no1_x12_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X12_TYPE1_ERI_V)
    (sc, ic, W12cav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ic, S2b);
  } // End scope

  { 
  // No. 13, [2]
  // W13(w,o1,c,a) += (    1.00000000) T2(w,o1,v1,o2) V2(c,o2,a,v1) 
  // S2(w,i,a,c) += (    2.00000000) D1(i,o1) W13(w,o1,c,a) 
  double flops = 0; // Flop count
  int sc(s_eri);
  int ic(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ic]);
  orz::DTensor W13cav_sigma_covv_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sc));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_covv_ocov_no0_x13_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO0_X13_TYPE1_ERI_V)
      (sc, ic, so2, io2, T2b.cptr(), V2_sym.cptr(), W13cav_sigma_covv_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_covv_ocov_no1_x13_type1_eri_v,G_IF_SIGMA_COVV_OCOV_NO1_X13_TYPE1_ERI_V)
    (sc, ic, W13cav_sigma_covv_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ic, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_covv_ocov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
