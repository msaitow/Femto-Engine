                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_cooo_ccov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  8 8888888888   8 8888888888            ,8.       ,8.    8888888 8888888888 ,o888888o.     
//  8 8888         8 8888                 ,888.     ,888.         8 8888    . 8888     `88.   
//  8 8888         8 8888                .`8888.   .`8888.        8 8888   ,8 8888       `8b  
//  8 8888         8 8888               ,8.`8888. ,8.`8888.       8 8888   88 8888        `8b 
//  8 888888888888 8 888888888888      ,8'8.`8888,8^8.`8888.      8 8888   88 8888         88 
//  8 8888         8 8888             ,8' `8.`8888' `8.`8888.     8 8888   88 8888         88 
//  8 8888         8 8888            ,8'   `8.`88'   `8.`8888.    8 8888   88 8888        ,8P 
//  8 8888         8 8888           ,8'     `8.`'     `8.`8888.   8 8888   `8 8888       ,8P  
//  8 8888         8 8888          ,8'       `8        `8.`8888.  8 8888    ` 8888     ,88'   
//  8 8888         8 888888888888 ,8'         `         `8.`8888. 8 8888       `8888888P'     

//                                   Generated date : Wed Feb 19 15:56:12 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_cooo_ccov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [2]
  // W0(w,o1) += (    1.00000000) Fc1(c1,v1) T2(c1,w,v1,o1) 
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o1,k) W0(w,o1) 
  double flops = 0; // Flop count
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    if(hintmo.iproc_havingimo()[io1] == myrank) {           
    T2b = T2.get_amp2(io1);
    orz::DTensor W0c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, so1));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x0_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO0_X0_TYPE1_NOERI)
      (so1, io1, T2b.cptr(), W0c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_ccov_no1_x0_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO1_X0_TYPE1_NOERI)
        (sm, im, so1, io1, W0c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 1, [2]
  // W1(w,o1) += (    1.00000000) Fc1(c1,v1) T2(c1,w,o1,v1) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o1,k) W1(w,o1) 
  double flops = 0; // Flop count
  orz::DTensor W1ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x1_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO0_X1_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W1ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x1_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO1_X1_TYPE1_NOERI)
      (sm, im, W1ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 2, [2]
  // W2(w,k) += (    1.00000000) Fc1(c1,v1) T2(c1,w,v1,k) 
  // S2(w,i,k,m) += (    4.00000000) D1(i,m) W2(w,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    orz::DTensor W2c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x2_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO0_X2_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W2c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_ccov_no1_x2_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO1_X2_TYPE1_NOERI)
        (sk, ik, sm, im, W2c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 3, [2]
  // W3(w,k) += (    1.00000000) Fc1(c1,v1) T2(c1,w,k,v1) 
  // S2(w,i,k,m) += (   -2.00000000) D1(i,m) W3(w,k) 
  double flops = 0; // Flop count
  orz::DTensor W3ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x3_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO0_X3_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W3ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x3_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO1_X3_TYPE1_NOERI)
      (sm, im, W3ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 4, [2]
  // W4(w,m) += (    1.00000000) Fc1(c1,v1) T2(c1,w,v1,m) 
  // S2(w,i,k,m) += (   -2.00000000) D1(i,k) W4(w,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W4c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x4_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO0_X4_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W4c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x4_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO1_X4_TYPE1_NOERI)
      (sm, im, W4c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W5(w,m) += (    1.00000000) Fc1(c1,v1) T2(w,c1,v1,m) 
  // S2(w,i,k,m) += (    1.00000000) D1(i,k) W5(w,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W5c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x5_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO0_X5_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W5c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x5_type1_noeri,G_IF_SIGMA_COOO_CCOV_NO1_X5_TYPE1_NOERI)
      (sm, im, W5c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_cooo_ccov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W4ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W5ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W6ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W7ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_ccov
  { 
  // No. 0, [2]
  // W0(w,o2,m,o1) += (    1.00000000) T2(c1,w,v1,o2) V2(m,v1,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,o1,o2,k) W0(w,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor W0ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, so2^sm));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x0_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X0_TYPE1_ERI_O)
      (sm, im, so2, io2, T2b.cptr(), V2_sym.cptr(), W0ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x0_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X0_TYPE1_ERI_O)
      (sm, im, so2, io2, W0ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(w,o2,m,o1) += (    1.00000000) T2(c1,w,o2,v1) V2(m,v1,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,k,o2,o1) W1(w,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W1caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x1_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X1_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_ccov_no1_x1_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X1_TYPE1_ERI_O)
    (sm, im, W1caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(c1,i,m,v1) += (    1.00000000) D1(i,o1) V2(m,v1,c1,o1) 
  // S2(w,i,k,m) += (   -2.00000000) T2(c1,w,v1,k) W2(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W2cav_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x2_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X2_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W2cav_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x2_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X2_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W2cav_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(c1,i,m,v1) += (    1.00000000) D1(i,o1) V2(m,v1,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,w,k,v1) W3(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W3ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x3_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X3_TYPE1_ERI_O)
      (sm, im, sv1, iv1, V2_sym.cptr(), W3ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x3_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X3_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), W3ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 4, [1]
  // W4(w,o2) += (    1.00000000) T2(w,c1,v1,o1) V2(o1,c1,o2,v1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x4_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X4_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W4ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 5, [1]
  // W5(w,o1) += (    1.00000000) T2(c1,w,v1,o2) V2(o2,c1,o1,v1) 
  double flops = 0; // Flop count
  int so2(s_eri);
  int io2(i_eri);
  T2b = T2.get_amp2(io2);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x5_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X5_TYPE1_ERI_O)
    (so2, io2, T2b.cptr(), V2_sym.cptr(), W5ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 6, [1]
  // W6(w,k) += (    1.00000000) T2(w,c1,v1,o1) V2(o1,c1,k,v1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x6_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X6_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W6ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 7, [1]
  // W7(w,k) += (    1.00000000) T2(c1,w,v1,o1) V2(o1,c1,k,v1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x7_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X7_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W7ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 8, [2]
  // W8(w,m) += (    1.00000000) T2(c1,w,o1,v1) V2(m,v1,c1,o1) 
  // S2(w,i,k,m) += (   -2.00000000) D1(i,k) W8(w,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W8c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x8_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X8_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W8c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_ccov_no1_x8_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X8_TYPE1_ERI_O)
    (sm, im, W8c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(w,m) += (    1.00000000) T2(c1,w,v1,o1) V2(m,v1,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) D1(i,k) W9(w,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W9c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x9_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X9_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W9c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_ccov_no1_x9_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X9_TYPE1_ERI_O)
    (sm, im, W9c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W10(w,o2,m,o1) += (    1.00000000) T2(c1,w,o2,v1) V2(m,o1,c1,v1) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,o1,o2,k) W10(w,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W10caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x10_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X10_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W10caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_ccov_no1_x10_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X10_TYPE1_ERI_O)
    (sm, im, W10caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o2,m,o1) += (    1.00000000) T2(c1,w,v1,o2) V2(m,o1,c1,v1) 
  // S2(w,i,k,m) += (   -2.00000000) D2(i,o1,o2,k) W11(w,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor W11ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, so2^sm));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x11_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X11_TYPE1_ERI_O)
      (sm, im, so2, io2, T2b.cptr(), V2_sym.cptr(), W11ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x11_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X11_TYPE1_ERI_O)
      (sm, im, so2, io2, W11ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 12, [2]
  // W12(c1,i,m,v1) += (    1.00000000) D1(i,o1) V2(m,o1,c1,v1) 
  // S2(w,i,k,m) += (    4.00000000) T2(c1,w,v1,k) W12(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W12cav_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sm));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x12_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X12_TYPE1_ERI_O)
    (sm, im, V2_sym.cptr(), W12cav_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x12_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X12_TYPE1_ERI_O)
      (sk, ik, sm, im, T2b.cptr(), W12cav_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 13, [2]
  // W13(c1,i,m,v1) += (    1.00000000) D1(i,o1) V2(m,o1,c1,v1) 
  // S2(w,i,k,m) += (   -2.00000000) T2(c1,w,k,v1) W13(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W13ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x13_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X13_TYPE1_ERI_O)
      (sm, im, sv1, iv1, V2_sym.cptr(), W13ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x13_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X13_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), W13ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 14, [2]
  // W14(w,m) += (    1.00000000) T2(c1,w,o1,v1) V2(m,o1,c1,v1) 
  // S2(w,i,k,m) += (    1.00000000) D1(i,k) W14(w,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W14c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x14_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X14_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W14c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_ccov_no1_x14_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X14_TYPE1_ERI_O)
    (sm, im, W14c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 15, [2]
  // W15(w,m) += (    1.00000000) T2(c1,w,v1,o1) V2(m,o1,c1,v1) 
  // S2(w,i,k,m) += (   -2.00000000) D1(i,k) W15(w,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W15c_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x15_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X15_TYPE1_ERI_O)
      (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), W15c_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_ccov_no1_x15_type1_eri_o,G_IF_SIGMA_COOO_CCOV_NO1_X15_TYPE1_ERI_O)
    (sm, im, W15c_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_cooo_ccov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o2,k) W4(w,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x0_type2_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X0_TYPE2_ERI_O)
      (sm, im, W4ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o1,k) W5(w,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x1_type2_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X1_TYPE2_ERI_O)
      (sm, im, W5ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,i,k,m) += (    4.00000000) D1(i,m) W6(w,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x2_type2_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X2_TYPE2_ERI_O)
      (sm, im, W6ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,i,k,m) += (   -2.00000000) D1(i,m) W7(w,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x3_type2_eri_o,G_IF_SIGMA_COOO_CCOV_NO0_X3_TYPE2_ERI_O)
      (sm, im, W7ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_cooo_ccov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W1ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W2ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W3ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W4ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W5ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W6caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W7caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W10caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W11caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W16caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W17caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W20caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W21caaa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W26ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W27ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W28ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  orz::DTensor W29ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_ccov
  { 
  // No. 0, [1]
  // W0(w,o1) += (    1.00000000) T2(c2,c1,o1,v1) V2(v1,c2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x0_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X0_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W0ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 1, [1]
  // W1(w,o1) += (    1.00000000) T2(c2,c1,o1,v1) V2(v1,c1,c2,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x1_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X1_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 2, [1]
  // W2(w,k) += (    1.00000000) T2(c2,c1,k,v1) V2(v1,c2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x2_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X2_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W2ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 3, [1]
  // W3(w,k) += (    1.00000000) T2(c2,c1,k,v1) V2(v1,c1,c2,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x3_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X3_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W3ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 4, [1]
  // W4(w,m) += (    1.00000000) T2(c1,c2,v1,m) V2(v1,c2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x4_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X4_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W4ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // W5(w,m) += (    1.00000000) T2(c1,c2,v1,m) V2(v1,c1,c2,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x5_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X5_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W5ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // W6(w,o3,o2,o1) += (    1.00000000) T2(w,c1,o3,v1) V2(v1,o2,c1,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x6_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X6_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W6caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 7, [1]
  // W7(w,o1,o2,o3) += (    1.00000000) T2(c1,w,o1,v1) V2(v1,o2,c1,o3) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x7_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X7_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W7caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 8, [2]
  // W8(c1,i,m,v1) += (    1.00000000) D2(i,m,o2,o1) V2(v1,o2,c1,o1) 
  // S2(w,i,k,m) += (   -2.00000000) T2(w,c1,k,v1) W8(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W8ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x8_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X8_TYPE1_ERI_V)
      (sm, im, sv1, iv1, V2_sym.cptr(), W8ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x8_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X8_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W8ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W9(c1,i,m,v1) += (    1.00000000) D2(i,m,o2,o1) V2(v1,o2,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(c1,w,k,v1) W9(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W9ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x9_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X9_TYPE1_ERI_V)
      (sm, im, sv1, iv1, V2_sym.cptr(), W9ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x9_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X9_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W9ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [1]
  // W10(w,o2,k,o1) += (    1.00000000) T2(w,c1,o2,v1) V2(v1,k,c1,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x10_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X10_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W10caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 11, [1]
  // W11(w,o2,k,o1) += (    1.00000000) T2(c1,w,o2,v1) V2(v1,k,c1,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x11_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X11_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W11caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 12, [2]
  // W12(c1,i,k,v1) += (    1.00000000) D2(i,k,o2,o1) V2(v1,o2,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,c1,m,v1) W12(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W12caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x12_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X12_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W12caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x12_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X12_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W12caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W13(c1,i,k,v1) += (    1.00000000) D2(i,o1,o2,k) V2(v1,o2,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,c1,v1,m) W13(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W13caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x13_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X13_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W13caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x13_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X13_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W13caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [2]
  // W14(c1,i,k,v1) += (    1.00000000) D1(i,o1) V2(v1,k,c1,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,c1,m,v1) W14(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W14caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x14_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X14_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W14caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x14_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X14_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W14caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [2]
  // W15(c1,i,k,v1) += (    1.00000000) D1(i,o1) V2(v1,k,c1,o1) 
  // S2(w,i,k,m) += (   -2.00000000) T2(w,c1,v1,m) W15(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W15caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x15_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X15_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W15caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x15_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X15_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W15caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [1]
  // W16(w,o3,o1,o2) += (    1.00000000) T2(c1,w,o3,v1) V2(v1,c1,o1,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x16_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X16_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W16caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 17, [1]
  // W17(w,o1,o2,o3) += (    1.00000000) T2(w,c1,o1,v1) V2(v1,c1,o2,o3) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x17_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X17_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W17caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 18, [2]
  // W18(c1,i,m,v1) += (    1.00000000) D2(i,m,o2,o1) V2(v1,c1,o1,o2) 
  // S2(w,i,k,m) += (    4.00000000) T2(w,c1,k,v1) W18(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W18ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x18_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X18_TYPE1_ERI_V)
      (sm, im, sv1, iv1, V2_sym.cptr(), W18ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x18_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X18_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W18ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 19, [2]
  // W19(c1,i,m,v1) += (    1.00000000) D2(i,m,o2,o1) V2(v1,c1,o1,o2) 
  // S2(w,i,k,m) += (   -2.00000000) T2(c1,w,k,v1) W19(c1,i,m,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W19ca_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x19_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X19_TYPE1_ERI_V)
      (sm, im, sv1, iv1, V2_sym.cptr(), W19ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x19_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X19_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W19ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 20, [1]
  // W20(w,o2,k,o1) += (    1.00000000) T2(c1,w,o2,v1) V2(v1,c1,k,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x20_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X20_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W20caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 21, [1]
  // W21(w,o2,k,o1) += (    1.00000000) T2(w,c1,o2,v1) V2(v1,c1,k,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x21_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X21_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W21caaa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 22, [2]
  // W22(c1,i,k,v1) += (    1.00000000) D2(i,k,o2,o1) V2(v1,c1,o1,o2) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,c1,v1,m) W22(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W22caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x22_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X22_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W22caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x22_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X22_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W22caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 23, [2]
  // W23(c1,i,k,v1) += (    1.00000000) D2(i,k,o2,o1) V2(v1,c1,o1,o2) 
  // S2(w,i,k,m) += (   -2.00000000) T2(w,c1,m,v1) W23(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W23caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x23_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X23_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W23caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x23_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X23_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W23caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 24, [2]
  // W24(c1,i,k,v1) += (    1.00000000) D1(i,o1) V2(v1,c1,k,o1) 
  // S2(w,i,k,m) += (    1.00000000) T2(w,c1,v1,m) W24(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W24caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x24_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X24_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W24caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x24_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X24_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W24caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 25, [2]
  // W25(c1,i,k,v1) += (    1.00000000) D1(i,o1) V2(v1,c1,k,o1) 
  // S2(w,i,k,m) += (   -2.00000000) T2(w,c1,m,v1) W25(c1,i,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W25caa_sigma_cooo_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x25_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X25_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W25caa_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no1_x25_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO1_X25_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W25caa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 26, [1]
  // W26(w,o2) += (    1.00000000) T2(c1,w,o1,v1) V2(v1,c1,o1,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x26_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X26_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W26ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 27, [1]
  // W27(w,o1) += (    1.00000000) T2(w,c1,o2,v1) V2(v1,c1,o1,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x27_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X27_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W27ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 28, [1]
  // W28(w,k) += (    1.00000000) T2(w,c1,o1,v1) V2(v1,c1,k,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x28_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X28_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W28ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 29, [1]
  // W29(w,k) += (    1.00000000) T2(c1,w,o1,v1) V2(v1,c1,k,o1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_ccov_no0_x29_type1_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X29_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W29ca_sigma_cooo_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_cooo_ccov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (   -1.00000000) D2(i,m,o1,k) W0(w,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x0_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X0_TYPE2_ERI_V)
      (sm, im, W0ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,k,m) += (    2.00000000) D2(i,m,o1,k) W1(w,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x1_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X1_TYPE2_ERI_V)
      (sm, im, W1ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,i,k,m) += (    2.00000000) D1(i,m) W2(w,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x2_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X2_TYPE2_ERI_V)
      (sm, im, W2ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,i,k,m) += (   -4.00000000) D1(i,m) W3(w,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x3_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X3_TYPE2_ERI_V)
      (sm, im, W3ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,i,k,m) += (   -1.00000000) D1(i,k) W4(w,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x4_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X4_TYPE2_ERI_V)
      (sm, im, W4ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,i,k,m) += (    2.00000000) D1(i,k) W5(w,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x5_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X5_TYPE2_ERI_V)
      (sm, im, W5ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o2,o1,o3,k) W6(w,o3,o2,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x6_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X6_TYPE2_ERI_V)
      (sm, im, W6caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o1,o3,o2,k) W7(w,o1,o2,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x7_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X7_TYPE2_ERI_V)
      (sm, im, W7caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o2,o1) W10(w,o2,k,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x8_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X8_TYPE2_ERI_V)
      (sm, im, W10caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o2,o1) W11(w,o2,k,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x9_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X9_TYPE2_ERI_V)
      (sm, im, W11caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o2,o1,o3,k) W16(w,o3,o1,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x10_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X10_TYPE2_ERI_V)
      (sm, im, W16caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // S2(w,i,k,m) += (   -2.00000000) D3(i,m,o1,k,o2,o3) W17(w,o1,o2,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x11_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X11_TYPE2_ERI_V)
      (sm, im, W17caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o2,o1) W20(w,o2,k,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x12_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X12_TYPE2_ERI_V)
      (sm, im, W20caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o2,o1) W21(w,o2,k,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x13_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X13_TYPE2_ERI_V)
      (sm, im, W21caaa_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o2,k) W26(w,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x14_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X14_TYPE2_ERI_V)
      (sm, im, W26ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o1,k) W27(w,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x15_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X15_TYPE2_ERI_V)
      (sm, im, W27ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [1]
  // S2(w,i,k,m) += (    4.00000000) D1(i,m) W28(w,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x16_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X16_TYPE2_ERI_V)
      (sm, im, W28ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 17, [1]
  // S2(w,i,k,m) += (   -2.00000000) D1(i,m) W29(w,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ccov_no0_x17_type2_eri_v,G_IF_SIGMA_COOO_CCOV_NO0_X17_TYPE2_ERI_V)
      (sm, im, W29ca_sigma_cooo_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_cooo_ccov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
