

#ifndef C_SIGMA_CCOV_CCOO_H
#define C_SIGMA_CCOV_CCOO_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//      ______                  __           
//     / ____/___   ____ ___   / /_ ____     
//    / /_   / _ \ / __ `__ \ / __// __ \ 
//   / __/  /  __// / / / / // /_ / /_/ /    
//  /_/     \___//_/ /_/ /_/ \__/ \____/  

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x0_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X0_TYPE1_NOERI)
  (const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x0_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x1_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x1_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x2_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X2_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x2_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X2_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x3_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X3_TYPE1_NOERI)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x3_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X3_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x4_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X4_TYPE1_NOERI)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x4_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X4_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x5_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X5_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x6_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X6_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x0_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X0_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x0_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X0_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x1_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X1_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x1_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X1_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x2_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X2_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x2_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X2_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x3_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X3_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x3_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X3_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x4_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X4_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x4_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X4_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x5_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X5_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x5_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X5_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x6_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X6_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x6_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X6_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x7_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X7_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x7_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X7_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x8_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X8_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x8_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X8_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x9_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X9_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x9_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X9_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W9, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x10_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X10_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x11_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X11_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x12_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X12_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x13_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X13_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x14_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X14_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x14_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X14_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W10, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x15_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X15_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x15_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X15_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W11, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x16_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X16_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x16_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X16_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W12, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x17_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X17_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x17_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X17_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W13, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x18_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X18_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x18_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X18_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W14, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x19_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X19_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x19_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X19_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W15, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x20_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X20_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W16, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x20_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X20_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const W16, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x21_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X21_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W17, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x21_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X21_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const W17, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x22_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X22_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W18, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x22_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X22_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W18, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x23_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X23_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W19, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x23_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X23_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W19, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x24_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X24_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x25_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X25_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x26_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X26_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x27_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X27_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x28_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X28_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so4, const FC_INT &io4, 
   const double * const V2, const double * const W20, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x28_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X28_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const W20, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x29_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X29_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so4, const FC_INT &io4, 
   const double * const V2, const double * const W21, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x29_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X29_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const W21, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x30_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X30_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W22, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x30_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X30_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W22, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x31_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X31_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W23, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x31_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X31_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W23, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x32_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X32_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W24, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x32_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X32_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W24, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x33_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X33_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W25, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x33_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X33_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W25, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x34_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X34_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W26, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x34_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X34_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W26, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x35_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X35_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W27, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x35_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X35_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W27, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x36_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X36_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W28, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x36_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X36_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W28, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x37_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X37_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W29, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x37_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X37_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W29, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x38_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X38_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so4, const FC_INT &io4, 
   const double * const V2, const double * const W30, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x38_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X38_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const W30, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x39_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X39_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W31, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x39_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X39_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W31, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x40_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X40_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W32, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x40_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X40_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W32, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x41_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X41_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W33, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x41_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X41_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W33, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x42_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X42_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W34, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x42_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X42_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W34, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x43_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X43_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W35, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x43_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X43_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W35, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x44_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X44_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W36, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x44_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X44_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W36, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x45_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X45_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W37, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no1_x45_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X45_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W37, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x46_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X46_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccov_ccoo_no0_x47_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X47_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 