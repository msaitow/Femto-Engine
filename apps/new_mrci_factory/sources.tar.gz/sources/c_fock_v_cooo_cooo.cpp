                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_fock_v_cooo_cooo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  8888888888                     888                  
//  888                            888                  
//  888                            888                  
//  8888888  .d88b.  88888b.d88b.  888888  .d88b.       
//  888     d8P  Y8b 888 "888 "88b 888    d88""88b  
//  888     88888888 888  888  888 888    888  888      
//  888     Y8b.     888  888  888 Y88b.  Y88..88P      
//  888      "Y8888  888  888  888  "Y888  "Y88P"   

//                                   Generated date : Wed Feb 19 15:54:47 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::fock_v_cooo_cooo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const orz::DTensor &CFock,                                                 
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (   -2.00000000) h6_int D3(i,m,o1,o2,o3,k) T2(w,o2,o3,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x0_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X0_TYPE1_NOERI)
        (sm, im, so1, io1, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [2]
  // W0(c1,i,m,k) += (    1.00000000) D3(i,m,o2,o1,o3,k) T2(c1,o1,o3,o2) 
  // S2(w,i,k,m) += (    1.00000000) P1(c1,w) W0(c1,i,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W0caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x1_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X1_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W0caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x1_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X1_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W0caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [1]
  // S2(w,i,k,m) += (    4.00000000) h6_int D2(i,m,o1,o2) T2(w,o2,k,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x2_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X2_TYPE1_NOERI)
        (sm, im, so1, io1, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [2]
  // W1(c1,i,m,k) += (    1.00000000) D2(i,m,o2,o1) T2(c1,o1,k,o2) 
  // S2(w,i,k,m) += (   -2.00000000) P1(c1,w) W1(c1,i,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W1caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x3_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X3_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W1caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x3_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X3_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W1caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [1]
  // S2(w,i,k,m) += (   -2.00000000) h6_int D2(i,m,o1,o2) T2(w,o2,o1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x4_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X4_TYPE1_NOERI)
        (sk, ik, sm, im, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W2(c1,i,m,k) += (    1.00000000) D2(i,m,o2,o1) T2(c1,o1,o2,k) 
  // S2(w,i,k,m) += (    1.00000000) P1(c1,w) W2(c1,i,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor W2ca_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sk));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x5_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X5_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W2ca_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x5_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X5_TYPE1_NOERI)
        (sk, ik, sm, im, CFock.cptr(), W2ca_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [1]
  // S2(w,i,k,m) += (   -2.00000000) h6_int D2(i,k,o1,o2) T2(w,o2,m,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x6_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X6_TYPE1_NOERI)
        (sm, im, so1, io1, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [2]
  // W3(c1,i,k,m) += (    1.00000000) D2(i,k,o2,o1) T2(c1,o1,m,o2) 
  // S2(w,i,k,m) += (    1.00000000) P1(c1,w) W3(c1,i,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W3caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x7_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X7_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W3caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x7_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X7_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W3caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 8, [1]
  // S2(w,i,k,m) += (   -2.00000000) h6_int D2(i,o1,o2,k) T2(w,o1,o2,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x8_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X8_TYPE1_NOERI)
      (sm, im, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 9, [2]
  // W4(c1,i,k,m) += (    1.00000000) D2(i,o1,o2,k) T2(c1,o1,o2,m) 
  // S2(w,i,k,m) += (    1.00000000) P1(c1,w) W4(c1,i,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W4caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x9_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X9_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W4caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x9_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X9_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W4caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 10, [1]
  // S2(w,i,k,m) += (    4.00000000) h6_int D1(i,o1) T2(w,o1,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x10_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X10_TYPE1_NOERI)
      (sm, im, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 11, [2]
  // W5(c1,i,k,m) += (    1.00000000) D1(i,o1) T2(c1,o1,k,m) 
  // S2(w,i,k,m) += (   -2.00000000) P1(c1,w) W5(c1,i,k,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W5caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x11_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X11_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W5caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x11_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X11_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W5caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 12, [1]
  // S2(w,i,k,m) += (   -2.00000000) h6_int D1(i,o1) T2(w,o1,m,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x12_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X12_TYPE1_NOERI)
        (sk, ik, sm, im, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 13, [2]
  // W6(c1,i,m,k) += (    1.00000000) D1(i,o1) T2(c1,o1,m,k) 
  // S2(w,i,k,m) += (    1.00000000) P1(c1,w) W6(c1,i,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor W6ca_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^sk));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x13_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X13_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W6ca_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x13_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X13_TYPE1_NOERI)
        (sk, ik, sm, im, CFock.cptr(), W6ca_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 14, [1]
  // S2(w,i,k,m) += (   -1.00000000) C6(i,m,o1,k,o2,o4) T2(w,o4,o1,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x14_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X14_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 15, [2]
  // W7(i,m,o4,o2) += (    1.00000000) D3(i,m,o3,o1,o4,o2) P1(o3,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o2,k,o4) W7(i,m,o4,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W7aa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so4));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x15_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X15_TYPE1_NOERI)
        (sm, im, so4, io4, CFock.cptr(), W7aa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x15_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X15_TYPE1_NOERI)
        (sm, im, so4, io4, T2b.cptr(), W7aa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 16, [2]
  // W8(i,m,o4,o2) += (    1.00000000) D3(i,m,o3,o1,o4,o2) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o4,k) W8(i,m,o4,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W8aaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x16_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X16_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W8aaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x16_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X16_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W8aaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 17, [2]
  // W9(i,m,o3,o1,o4,k) += (    1.00000000) D3(i,m,o3,o1,o4,o2) P1(k,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,o4,o3) W9(i,m,o3,o1,o4,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor W9aaaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so3));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x17_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X17_TYPE1_NOERI)
        (sm, im, so3, io3, CFock.cptr(), W9aaaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x17_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X17_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W9aaaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 18, [2]
  // W10(i,k,o4,o2) += (    1.00000000) D3(i,k,o3,o1,o4,o2) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,m,o4) W10(i,k,o4,o2) 
  double flops = 0; // Flop count
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    if(hintmo.iproc_havingimo()[io4] == myrank) {           
    orz::DTensor W10aaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so4));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x18_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X18_TYPE1_NOERI)
      (so4, io4, CFock.cptr(), W10aaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x18_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X18_TYPE1_NOERI)
        (sm, im, so4, io4, T2b.cptr(), W10aaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 19, [2]
  // W11(i,o2,o4,k) += (    1.00000000) D3(i,o2,o3,o1,o4,k) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o4,m) W11(i,o2,o4,k) 
  double flops = 0; // Flop count
  orz::DTensor W11aaaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_cooo_no0_x19_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X19_TYPE1_NOERI)
    (CFock.cptr(), W11aaaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x19_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X19_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W11aaaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 20, [2]
  // W12(i,o3,o1,o4,k,m) += (    1.00000000) D3(i,o2,o3,o1,o4,k) P1(m,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,o4,o3) W12(i,o3,o1,o4,k,m) 
  double flops = 0; // Flop count
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    if(hintmo.iproc_havingimo()[io3] == myrank) {           
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor W12aaaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so3^sm));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x20_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X20_TYPE1_NOERI)
        (sm, im, so3, io3, CFock.cptr(), W12aaaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x20_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X20_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W12aaaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 21, [2]
  // W13(i,o2) += (    1.00000000) D2(i,o2,o3,o1) P1(o3,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o2,k,m) W13(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W13aa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_cooo_no0_x21_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X21_TYPE1_NOERI)
    (CFock.cptr(), W13aa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x21_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X21_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W13aa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 22, [2]
  // W14(i,o3,o1,m) += (    1.00000000) D2(i,o2,o3,o1) P1(m,o2) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o1,k,o3) W14(i,o3,o1,m) 
  double flops = 0; // Flop count
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    if(hintmo.iproc_havingimo()[io3] == myrank) {           
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor W14aa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so3^sm));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x22_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X22_TYPE1_NOERI)
        (sm, im, so3, io3, CFock.cptr(), W14aa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x22_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X22_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W14aa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 23, [2]
  // W15(i,o3,o1,m) += (    1.00000000) D2(i,o2,o3,o1) P1(m,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,o3,k) W15(i,o3,o1,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W15aaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x23_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X23_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W15aaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x23_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X23_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W15aaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 24, [2]
  // W16(i,o2) += (    1.00000000) D2(i,o2,o3,o1) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,m,k) W16(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W16aa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_cooo_no0_x24_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X24_TYPE1_NOERI)
    (CFock.cptr(), W16aa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x24_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X24_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W16aa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 25, [2]
  // W17(i,o3,o1,k) += (    1.00000000) D2(i,o2,o3,o1) P1(k,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,m,o3) W17(i,o3,o1,k) 
  double flops = 0; // Flop count
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    if(hintmo.iproc_havingimo()[io3] == myrank) {           
    orz::DTensor W17aaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so3));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x25_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X25_TYPE1_NOERI)
      (so3, io3, CFock.cptr(), W17aaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x25_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X25_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W17aaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 26, [2]
  // W18(i,o2,o3,k) += (    1.00000000) D2(i,o2,o3,o1) P1(k,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o3,m) W18(i,o2,o3,k) 
  double flops = 0; // Flop count
  orz::DTensor W18aaaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_cooo_no0_x26_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X26_TYPE1_NOERI)
    (CFock.cptr(), W18aaaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x26_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X26_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W18aaaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 27, [2]
  // W19(i,m,k,o4,o2,o1) += (    1.00000000) D3(i,m,o3,k,o4,o2) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o1,o4) W19(i,m,k,o4,o2,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W19aaaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so4));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x27_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X27_TYPE1_NOERI)
        (sm, im, so4, io4, CFock.cptr(), W19aaaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x27_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X27_TYPE1_NOERI)
        (sm, im, so4, io4, T2b.cptr(), W19aaaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 28, [2]
  // W20(i,m,o2,o1) += (    1.00000000) D2(i,m,o3,o2) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o1,k) W20(i,m,o2,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W20aaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x28_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X28_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W20aaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x28_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X28_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W20aaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 29, [2]
  // W21(w,i,m,o1) += (    1.00000000) D2(i,m,o3,o2) T2(w,o2,o1,o3) 
  // S2(w,i,k,m) += (    2.00000000) P1(k,o1) W21(w,i,m,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W21caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x29_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X29_TYPE1_NOERI)
        (sm, im, so3, io3, T2b.cptr(), W21caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x29_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X29_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W21caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 30, [2]
  // W22(i,o2,k,o1) += (    1.00000000) D2(i,o2,o3,k) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o1,m) W22(i,o2,k,o1) 
  double flops = 0; // Flop count
  orz::DTensor W22aaaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_cooo_no0_x30_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X30_TYPE1_NOERI)
    (CFock.cptr(), W22aaaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x30_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X30_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W22aaaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 31, [2]
  // W23(w,i,k,o1) += (    1.00000000) D2(i,k,o3,o2) T2(w,o2,o1,o3) 
  // S2(w,i,k,m) += (   -1.00000000) P1(m,o1) W23(w,i,k,o1) 
  double flops = 0; // Flop count
  orz::DTensor W23caaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x31_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X31_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W23caaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x31_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X31_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W23caaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 32, [2]
  // W24(w,i,o1,k) += (    1.00000000) D1(i,o2) T2(w,o2,o1,k) 
  // S2(w,i,k,m) += (   -1.00000000) P1(m,o1) W24(w,i,o1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    orz::DTensor W24caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x32_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X32_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W24caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x32_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X32_TYPE1_NOERI)
        (sk, ik, sm, im, CFock.cptr(), W24caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 33, [2]
  // W25(w,i,o1,m) += (    1.00000000) D1(i,o2) T2(w,o2,o1,m) 
  // S2(w,i,k,m) += (    2.00000000) P1(k,o1) W25(w,i,o1,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W25caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x33_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X33_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W25caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_cooo_cooo_no1_x33_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X33_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W25caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 34, [2]
  // W26(i,m,o1,k,o3,o4) += (    1.00000000) D3(i,m,o1,k,o2,o3) P1(o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o3,o1,o4) W26(i,m,o1,k,o3,o4) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W26aaaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^so4));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x34_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X34_TYPE1_NOERI)
        (sm, im, so4, io4, CFock.cptr(), W26aaaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x34_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X34_TYPE1_NOERI)
        (sm, im, so4, io4, T2b.cptr(), W26aaaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 35, [2]
  // W27(i,m,o2,o1) += (    1.00000000) D2(i,m,o3,o2) P1(o3,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o2,k,o1) W27(i,m,o2,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W27aa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^so1));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x35_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X35_TYPE1_NOERI)
        (sm, im, so1, io1, CFock.cptr(), W27aa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x35_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X35_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W27aa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 36, [2]
  // W28(w,i,m,o1) += (    1.00000000) D2(i,m,o3,o2) T2(w,o2,o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) P1(k,o1) W28(w,i,m,o1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor W28ca_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^so1));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x36_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X36_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W28ca_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x36_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X36_TYPE1_NOERI)
        (sm, im, so1, io1, CFock.cptr(), W28ca_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 37, [2]
  // W29(i,k,o2,o1) += (    1.00000000) D2(i,k,o3,o2) P1(o3,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,m,o1) W29(i,k,o2,o1) 
  double flops = 0; // Flop count
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    if(hintmo.iproc_havingimo()[io1] == myrank) {           
    orz::DTensor W29aaa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, so1));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x37_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X37_TYPE1_NOERI)
      (so1, io1, CFock.cptr(), W29aaa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x37_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X37_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W29aaa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 38, [2]
  // W30(w,i,k,o3) += (    1.00000000) D2(i,o2,o1,k) T2(w,o2,o1,o3) 
  // S2(w,i,k,m) += (   -1.00000000) P1(m,o3) W30(w,i,k,o3) 
  double flops = 0; // Flop count
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    if(hintmo.iproc_havingimo()[io3] == myrank) {           
    T2b = T2.get_amp2(io3);
    orz::DTensor W30caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so3));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x38_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X38_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W30caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x38_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X38_TYPE1_NOERI)
        (sm, im, so3, io3, CFock.cptr(), W30caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 39, [2]
  // W31(w,i,k,o1) += (    1.00000000) D1(i,o2) T2(w,o2,k,o1) 
  // S2(w,i,k,m) += (    2.00000000) P1(m,o1) W31(w,i,k,o1) 
  double flops = 0; // Flop count
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    if(hintmo.iproc_havingimo()[io1] == myrank) {           
    T2b = T2.get_amp2(io1);
    orz::DTensor W31caa_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
    FC_FUNC(g_if_fock_v_cooo_cooo_no0_x39_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X39_TYPE1_NOERI)
      (so1, io1, T2b.cptr(), W31caa_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x39_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X39_TYPE1_NOERI)
        (sm, im, so1, io1, CFock.cptr(), W31caa_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 40, [2]
  // W32(w,i,m,o2) += (    1.00000000) D1(i,o1) T2(w,o1,m,o2) 
  // S2(w,i,k,m) += (   -1.00000000) P1(k,o2) W32(w,i,m,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor W32ca_fock_v_cooo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^so2));
      FC_FUNC(g_if_fock_v_cooo_cooo_no0_x40_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO0_X40_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W32ca_fock_v_cooo_cooo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_fock_v_cooo_cooo_no1_x40_type1_noeri,G_IF_FOCK_V_COOO_COOO_NO1_X40_TYPE1_NOERI)
        (sm, im, so2, io2, CFock.cptr(), W32ca_fock_v_cooo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("fock_v_cooo_cooo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
