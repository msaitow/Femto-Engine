

#ifndef C_DIAG_OOOV_H
#define C_DIAG_OOOV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//  ___________                __               
//  \_   _____/____    _____ _/  |_  ____      
//   |    __)_/ __ \  /     \\   __\/  _ \ 
//   |     \ \  ___/ |  Y Y  \|  | (  <_> )  
//   \___  /  \___  >|__|_|  /|__|  \____/   
//       \/       \/       \/                

void FC_FUNC(g_if_diag_ooov_no0_x0_type1_noeri,G_IF_DIAG_OOOV_NO0_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x1_type1_noeri,G_IF_DIAG_OOOV_NO0_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x2_type1_noeri,G_IF_DIAG_OOOV_NO0_X2_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x3_type1_noeri,G_IF_DIAG_OOOV_NO0_X3_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x4_type1_noeri,G_IF_DIAG_OOOV_NO0_X4_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x5_type1_noeri,G_IF_DIAG_OOOV_NO0_X5_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x6_type1_noeri,G_IF_DIAG_OOOV_NO0_X6_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x7_type1_noeri,G_IF_DIAG_OOOV_NO0_X7_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x8_type1_noeri,G_IF_DIAG_OOOV_NO0_X8_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Ecas, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x9_type1_noeri,G_IF_DIAG_OOOV_NO0_X9_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Ecas, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x0_type1_eri_o,G_IF_DIAG_OOOV_NO0_X0_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, const FC_INT &sm, const FC_INT &im, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x1_type1_eri_o,G_IF_DIAG_OOOV_NO0_X1_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sm, const FC_INT &im, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x2_type1_eri_o,G_IF_DIAG_OOOV_NO0_X2_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sm, const FC_INT &im, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x3_type1_eri_o,G_IF_DIAG_OOOV_NO0_X3_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, const FC_INT &sm, const FC_INT &im, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x4_type1_eri_o,G_IF_DIAG_OOOV_NO0_X4_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x5_type1_eri_o,G_IF_DIAG_OOOV_NO0_X5_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x6_type1_eri_o,G_IF_DIAG_OOOV_NO0_X6_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x7_type1_eri_o,G_IF_DIAG_OOOV_NO0_X7_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x8_type1_eri_o,G_IF_DIAG_OOOV_NO0_X8_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x9_type1_eri_o,G_IF_DIAG_OOOV_NO0_X9_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x10_type1_eri_o,G_IF_DIAG_OOOV_NO0_X10_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x11_type1_eri_o,G_IF_DIAG_OOOV_NO0_X11_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x12_type1_eri_o,G_IF_DIAG_OOOV_NO0_X12_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x0_type1_eri_v,G_IF_DIAG_OOOV_NO0_X0_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x1_type1_eri_v,G_IF_DIAG_OOOV_NO0_X1_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x2_type1_eri_v,G_IF_DIAG_OOOV_NO0_X2_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x3_type1_eri_v,G_IF_DIAG_OOOV_NO0_X3_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x4_type1_eri_v,G_IF_DIAG_OOOV_NO0_X4_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ooov_no0_x5_type1_eri_v,G_IF_DIAG_OOOV_NO0_X5_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 