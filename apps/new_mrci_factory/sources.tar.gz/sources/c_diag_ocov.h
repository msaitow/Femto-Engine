

#ifndef C_DIAG_OCOV_H
#define C_DIAG_OCOV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//      _/_/_/_/                            _/             
//     _/        _/_/    _/_/_/  _/_/    _/_/_/_/    _/_/  
//    _/_/_/  _/_/_/_/  _/    _/    _/    _/      _/    _/ 
//   _/      _/        _/    _/    _/    _/      _/    _/  
//  _/        _/_/_/  _/    _/    _/      _/_/    _/_/     

void FC_FUNC(g_if_diag_ocov_no0_x0_type1_noeri,G_IF_DIAG_OCOV_NO0_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Fc0, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x1_type1_noeri,G_IF_DIAG_OCOV_NO0_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x2_type1_noeri,G_IF_DIAG_OCOV_NO0_X2_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Fc0, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x3_type1_noeri,G_IF_DIAG_OCOV_NO0_X3_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x4_type1_noeri,G_IF_DIAG_OCOV_NO0_X4_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x5_type1_noeri,G_IF_DIAG_OCOV_NO0_X5_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x6_type1_noeri,G_IF_DIAG_OCOV_NO0_X6_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x7_type1_noeri,G_IF_DIAG_OCOV_NO0_X7_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x8_type1_noeri,G_IF_DIAG_OCOV_NO0_X8_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x9_type1_noeri,G_IF_DIAG_OCOV_NO0_X9_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x0_type1_eri_c,G_IF_DIAG_OCOV_NO0_X0_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x1_type1_eri_c,G_IF_DIAG_OCOV_NO0_X1_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x2_type1_eri_c,G_IF_DIAG_OCOV_NO0_X2_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x3_type1_eri_c,G_IF_DIAG_OCOV_NO0_X3_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x4_type1_eri_c,G_IF_DIAG_OCOV_NO0_X4_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x5_type1_eri_c,G_IF_DIAG_OCOV_NO0_X5_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x6_type1_eri_c,G_IF_DIAG_OCOV_NO0_X6_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x7_type1_eri_c,G_IF_DIAG_OCOV_NO0_X7_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x0_type1_eri_o,G_IF_DIAG_OCOV_NO0_X0_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x1_type1_eri_o,G_IF_DIAG_OCOV_NO0_X1_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x2_type1_eri_o,G_IF_DIAG_OCOV_NO0_X2_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x3_type1_eri_o,G_IF_DIAG_OCOV_NO0_X3_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x4_type1_eri_o,G_IF_DIAG_OCOV_NO0_X4_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x0_type1_eri_v,G_IF_DIAG_OCOV_NO0_X0_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x1_type1_eri_v,G_IF_DIAG_OCOV_NO0_X1_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x2_type1_eri_v,G_IF_DIAG_OCOV_NO0_X2_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x3_type1_eri_v,G_IF_DIAG_OCOV_NO0_X3_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x4_type1_eri_v,G_IF_DIAG_OCOV_NO0_X4_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x5_type1_eri_v,G_IF_DIAG_OCOV_NO0_X5_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x6_type1_eri_v,G_IF_DIAG_OCOV_NO0_X6_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x7_type1_eri_v,G_IF_DIAG_OCOV_NO0_X7_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x8_type1_eri_v,G_IF_DIAG_OCOV_NO0_X8_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x9_type1_eri_v,G_IF_DIAG_OCOV_NO0_X9_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x10_type1_eri_v,G_IF_DIAG_OCOV_NO0_X10_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_diag_ocov_no0_x11_type1_eri_v,G_IF_DIAG_OCOV_NO0_X11_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 