                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_coov_covv.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//       #                #########      #     #   # 
//  ########## ##########         #   #######  #   # 
//      #    #         #          #    # #     #   # 
//      #    #        #   ########     # #     #   # 
//     #     #     # #           #  ##########    #  
//    #   # #       #            #       #       #   
//   #     #         #    ########       #     ##    

//                                   Generated date : Wed Feb 19 15:56:49 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_coov_covv(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [2]
  // W0(w,o2,o1,a) += (    1.00000000) Fc1(o2,v1) T2(w,o1,v1,a) 
  // S2(w,i,k,a) += (   -1.00000000) D2(i,o1,o2,k) W0(w,o2,o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W0caa_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
    FC_FUNC(g_if_sigma_coov_covv_no0_x0_type1_noeri,G_IF_SIGMA_COOV_COVV_NO0_X0_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W0caa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_covv_no1_x0_type1_noeri,G_IF_SIGMA_COOV_COVV_NO1_X0_TYPE1_NOERI)
      (sa, ia, W0caa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [2]
  // W1(w,i,v1,a) += (    1.00000000) D1(i,o1) T2(w,o1,v1,a) 
  // S2(w,i,k,a) += (    2.00000000) Fc1(k,v1) W1(w,i,v1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W1cav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcav(symblockinfo, sa));
    FC_FUNC(g_if_sigma_coov_covv_no0_x1_type1_noeri,G_IF_SIGMA_COOV_COVV_NO0_X1_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W1cav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_covv_no1_x1_type1_noeri,G_IF_SIGMA_COOV_COVV_NO1_X1_TYPE1_NOERI)
      (sa, ia, W1cav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W2(w,o1,o2,a) += (    1.00000000) Fc1(o1,v1) T2(o2,w,v1,a) 
  // S2(w,i,k,a) += (   -1.00000000) D2(i,k,o1,o2) W2(w,o1,o2,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W2caa_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
    FC_FUNC(g_if_sigma_coov_covv_no0_x2_type1_noeri,G_IF_SIGMA_COOV_COVV_NO0_X2_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W2caa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_covv_no1_x2_type1_noeri,G_IF_SIGMA_COOV_COVV_NO1_X2_TYPE1_NOERI)
      (sa, ia, W2caa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [2]
  // W3(w,i,v1,a) += (    1.00000000) D1(i,o1) T2(o1,w,v1,a) 
  // S2(w,i,k,a) += (   -1.00000000) Fc1(k,v1) W3(w,i,v1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W3cav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcav(symblockinfo, sa));
    FC_FUNC(g_if_sigma_coov_covv_no0_x3_type1_noeri,G_IF_SIGMA_COOV_COVV_NO0_X3_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W3cav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_covv_no1_x3_type1_noeri,G_IF_SIGMA_COOV_COVV_NO1_X3_TYPE1_NOERI)
      (sa, ia, W3cav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_coov_covv
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  orz::DTensor W1caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  orz::DTensor W2caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  orz::DTensor W3caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  orz::DTensor W4caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  orz::DTensor W5caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  orz::DTensor W6caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
  orz::DTensor W7caav_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaav(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_coov_covv
  { 
  // No. 0, [1]
  // W0(w,o1,o2,a) += (    1.00000000) T2(o1,c1,a,v1) V2(v1,o2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_coov_covv_no0_x0_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X0_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W0caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 1, [1]
  // W1(w,o1,k,a) += (    1.00000000) T2(o1,c1,a,v1) V2(v1,k,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_coov_covv_no0_x1_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X1_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 2, [1]
  // W2(w,o1,o2,a) += (    1.00000000) T2(o1,c1,v1,a) V2(v1,o2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_covv_no0_x2_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X2_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W2caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // W3(w,o1,k,a) += (    1.00000000) T2(o1,c1,v1,a) V2(v1,k,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_covv_no0_x3_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X3_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W3caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // W4(w,o1,o2,a) += (    1.00000000) T2(o1,c1,a,v1) V2(v1,c1,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_coov_covv_no0_x4_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X4_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W4caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 5, [1]
  // W5(w,o1,k,a) += (    1.00000000) T2(o1,c1,a,v1) V2(v1,c1,w,k) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_coov_covv_no0_x5_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X5_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W5caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 6, [1]
  // W6(w,o1,o2,a) += (    1.00000000) T2(o1,c1,v1,a) V2(v1,c1,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_covv_no0_x6_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X6_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W6caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // W7(w,o1,k,a) += (    1.00000000) T2(o1,c1,v1,a) V2(v1,c1,w,k) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_covv_no0_x7_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X7_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W7caav_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W8(i,o2,k,v1) += (    1.00000000) D3(i,o2,o3,k,o4,o1) V2(v1,o3,o1,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(o2,w,a,v1) W8(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W8aaa_sigma_coov_covv(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_coov_covv_no0_x8_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X8_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W8aaa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no1_x8_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X8_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W8aaa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W9(i,o2,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,o3,k,o1) 
  // S2(w,i,k,a) += (   -1.00000000) T2(o2,w,a,v1) W9(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W9aaa_sigma_coov_covv(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_coov_covv_no0_x9_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X9_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W9aaa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no1_x9_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X9_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W9aaa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W10(i,o2,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,k,o1,o3) 
  // S2(w,i,k,a) += (    2.00000000) T2(o2,w,a,v1) W10(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W10aaa_sigma_coov_covv(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_coov_covv_no0_x10_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X10_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W10aaa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no1_x10_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X10_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W10aaa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [2]
  // W11(i,k,o3,v1) += (    1.00000000) D3(i,k,o1,o3,o2,o4) V2(v1,o1,o2,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(o3,w,v1,a) W11(i,k,o3,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W11aaa_sigma_coov_covv(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_coov_covv_no0_x11_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X11_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W11aaa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no1_x11_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X11_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W11aaa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [2]
  // W12(i,o1,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,o3,k,o2) 
  // S2(w,i,k,a) += (   -1.00000000) T2(o1,w,v1,a) W12(i,o1,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W12aaa_sigma_coov_covv(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_coov_covv_no0_x12_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X12_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W12aaa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no1_x12_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X12_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W12aaa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W13(i,o2,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,k,o1,o3) 
  // S2(w,i,k,a) += (   -1.00000000) T2(o2,w,v1,a) W13(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W13aaa_sigma_coov_covv(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_coov_covv_no0_x13_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X13_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W13aaa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no1_x13_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X13_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W13aaa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [2]
  // W14(w,o1,o2,a) += (    1.00000000) T2(w,o1,v2,v1) V2(a,v1,o2,v2) 
  // S2(w,i,k,a) += (   -1.00000000) D2(i,o1,o2,k) W14(w,o1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W14caa_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_coov_covv_no0_x14_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X14_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W14caa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_covv_no1_x14_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X14_TYPE1_ERI_V)
    (sa, ia, W14caa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 15, [2]
  // W15(w,o1,k,a) += (    1.00000000) T2(w,o1,v2,v1) V2(a,v1,k,v2) 
  // S2(w,i,k,a) += (    2.00000000) D1(i,o1) W15(w,o1,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W15caa_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_coov_covv_no0_x15_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X15_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W15caa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_covv_no1_x15_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X15_TYPE1_ERI_V)
    (sa, ia, W15caa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 16, [2]
  // W16(w,o2,o1,a) += (    1.00000000) T2(w,o2,v1,v2) V2(a,v1,o1,v2) 
  // S2(w,i,k,a) += (   -1.00000000) D2(i,k,o1,o2) W16(w,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W16caa_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int sv2 = 0;sv2 < nir;++sv2){ 
  for(int iv2 = symblockinfo.psym()(sv2,I_V,I_BEGIN);iv2 <= symblockinfo.psym()(sv2,I_V,I_END);++iv2){ 
    T2b = T2.get_amp2(iv2);
    FC_FUNC(g_if_sigma_coov_covv_no0_x16_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X16_TYPE1_ERI_V)
      (sa, ia, sv2, iv2, T2b.cptr(), V2_sym.cptr(), W16caa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_covv_no1_x16_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X16_TYPE1_ERI_V)
    (sa, ia, W16caa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 17, [2]
  // W17(w,o1,k,a) += (    1.00000000) T2(w,o1,v1,v2) V2(a,v1,k,v2) 
  // S2(w,i,k,a) += (   -1.00000000) D1(i,o1) W17(w,o1,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W17caa_sigma_coov_covv(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int sv2 = 0;sv2 < nir;++sv2){ 
  for(int iv2 = symblockinfo.psym()(sv2,I_V,I_BEGIN);iv2 <= symblockinfo.psym()(sv2,I_V,I_END);++iv2){ 
    T2b = T2.get_amp2(iv2);
    FC_FUNC(g_if_sigma_coov_covv_no0_x17_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X17_TYPE1_ERI_V)
      (sa, ia, sv2, iv2, T2b.cptr(), V2_sym.cptr(), W17caa_sigma_coov_covv.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_covv_no1_x17_type1_eri_v,G_IF_SIGMA_COOV_COVV_NO1_X17_TYPE1_ERI_V)
    (sa, ia, W17caa_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_coov_covv
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,a) += (    1.00000000) D2(i,o1,o2,k) W0(w,o1,o2,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x0_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X0_TYPE2_ERI_V)
      (sa, ia, W0caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,k,a) += (   -2.00000000) D1(i,o1) W1(w,o1,k,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x1_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X1_TYPE2_ERI_V)
      (sa, ia, W1caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,i,k,a) += (    1.00000000) D2(i,k,o2,o1) W2(w,o1,o2,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x2_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X2_TYPE2_ERI_V)
      (sa, ia, W2caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,i,k,a) += (    1.00000000) D1(i,o1) W3(w,o1,k,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x3_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X3_TYPE2_ERI_V)
      (sa, ia, W3caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,i,k,a) += (   -2.00000000) D2(i,o1,o2,k) W4(w,o1,o2,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x4_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X4_TYPE2_ERI_V)
      (sa, ia, W4caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,i,k,a) += (    4.00000000) D1(i,o1) W5(w,o1,k,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x5_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X5_TYPE2_ERI_V)
      (sa, ia, W5caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,i,k,a) += (    1.00000000) D2(i,o1,o2,k) W6(w,o1,o2,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x6_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X6_TYPE2_ERI_V)
      (sa, ia, W6caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,i,k,a) += (   -2.00000000) D1(i,o1) W7(w,o1,k,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_covv_no0_x7_type2_eri_v,G_IF_SIGMA_COOV_COVV_NO0_X7_TYPE2_ERI_V)
      (sa, ia, W7caav_sigma_coov_covv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_coov_covv", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
