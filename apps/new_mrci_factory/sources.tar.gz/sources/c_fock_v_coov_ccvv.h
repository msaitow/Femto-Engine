

#ifndef C_FOCK_V_COOV_CCVV_H
#define C_FOCK_V_COOV_CCVV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//        :::::::::: ::::::::::   :::   ::: ::::::::::: :::::::: 
//       :+:        :+:         :+:+: :+:+:    :+:    :+:    :+: 
//      +:+        +:+        +:+ +:+:+ +:+   +:+    +:+    +:+  
//     :#::+::#   +#++:++#   +#+  +:+  +#+   +#+    +#+    +:+   
//    +#+        +#+        +#+       +#+   +#+    +#+    +#+    
//   #+#        #+#        #+#       #+#   #+#    #+#    #+#     
//  ###        ########## ###       ###   ###     ########       

void FC_FUNC(g_if_fock_v_coov_ccvv_no0_x0_type1_noeri,G_IF_FOCK_V_COOV_CCVV_NO0_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const T2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ccvv_no1_x0_type1_noeri,G_IF_FOCK_V_COOV_CCVV_NO1_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ccvv_no0_x1_type1_noeri,G_IF_FOCK_V_COOV_CCVV_NO0_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const T2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ccvv_no1_x1_type1_noeri,G_IF_FOCK_V_COOV_CCVV_NO1_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 