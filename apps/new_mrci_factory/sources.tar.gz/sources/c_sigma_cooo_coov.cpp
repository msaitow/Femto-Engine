                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_cooo_coov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

//                                   Generated date : Wed Feb 19 15:56:46 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_cooo_coov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  if(myrank == 0){
  { 
  // No. 0, [2]
  // W0(w,o2,o3,o1) += (    1.00000000) Fc1(o2,v1) T2(w,o3,o1,v1) 
  // S2(w,i,k,m) += (   -1.00000000) D3(i,m,o1,k,o2,o3) W0(w,o2,o3,o1) 
  double flops = 0; // Flop count
  orz::DTensor W0caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x0_type1_noeri,G_IF_SIGMA_COOO_COOV_NO0_X0_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W0caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x0_type1_noeri,G_IF_SIGMA_COOO_COOV_NO1_X0_TYPE1_NOERI)
      (sm, im, W0caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 1, [2]
  // W1(w,o1,o2,k) += (    1.00000000) Fc1(o1,v1) T2(w,o2,k,v1) 
  // S2(w,i,k,m) += (    2.00000000) D2(i,m,o1,o2) W1(w,o1,o2,k) 
  double flops = 0; // Flop count
  orz::DTensor W1caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x1_type1_noeri,G_IF_SIGMA_COOO_COOV_NO0_X1_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W1caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x1_type1_noeri,G_IF_SIGMA_COOO_COOV_NO1_X1_TYPE1_NOERI)
      (sm, im, W1caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 2, [2]
  // W2(w,k,o2,o1) += (    1.00000000) Fc1(k,v1) T2(w,o2,o1,v1) 
  // S2(w,i,k,m) += (   -1.00000000) D2(i,m,o1,o2) W2(w,k,o2,o1) 
  double flops = 0; // Flop count
  orz::DTensor W2caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x2_type1_noeri,G_IF_SIGMA_COOO_COOV_NO0_X2_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W2caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x2_type1_noeri,G_IF_SIGMA_COOO_COOV_NO1_X2_TYPE1_NOERI)
      (sm, im, W2caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 3, [2]
  // W3(w,o1,o2,m) += (    1.00000000) Fc1(o1,v1) T2(o2,w,v1,m) 
  // S2(w,i,k,m) += (   -1.00000000) D2(i,k,o1,o2) W3(w,o1,o2,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W3caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x3_type1_noeri,G_IF_SIGMA_COOO_COOV_NO0_X3_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W3caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x3_type1_noeri,G_IF_SIGMA_COOO_COOV_NO1_X3_TYPE1_NOERI)
      (sm, im, W3caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [2]
  // W4(w,m,o1,o2) += (    1.00000000) Fc1(m,v1) T2(w,o1,o2,v1) 
  // S2(w,i,k,m) += (   -1.00000000) D2(i,o1,o2,k) W4(w,m,o1,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W4caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_coov_no0_x4_type1_noeri,G_IF_SIGMA_COOO_COOV_NO0_X4_TYPE1_NOERI)
        (sm, im, sv1, iv1, T2b.cptr(), W4caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_sigma_cooo_coov_no1_x4_type1_noeri,G_IF_SIGMA_COOO_COOV_NO1_X4_TYPE1_NOERI)
      (sm, im, W4caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W5(w,i,k,v1) += (    1.00000000) D1(i,o1) T2(w,o1,k,v1) 
  // S2(w,i,k,m) += (    2.00000000) Fc1(m,v1) W5(w,i,k,v1) 
  double flops = 0; // Flop count
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    if(hintmo.iproc_havingimo()[iv1] == myrank) {           
    T2b = T2.get_amp2(iv1);
    orz::DTensor W5caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x5_type1_noeri,G_IF_SIGMA_COOO_COOV_NO0_X5_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W5caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_coov_no1_x5_type1_noeri,G_IF_SIGMA_COOO_COOV_NO1_X5_TYPE1_NOERI)
        (sm, im, sv1, iv1, W5caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [2]
  // W6(w,i,m,v1) += (    1.00000000) D1(i,o1) T2(o1,w,v1,m) 
  // S2(w,i,k,m) += (   -1.00000000) Fc1(k,v1) W6(w,i,m,v1) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W6cav_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sm));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x6_type1_noeri,G_IF_SIGMA_COOO_COOV_NO0_X6_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W6cav_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x6_type1_noeri,G_IF_SIGMA_COOO_COOV_NO1_X6_TYPE1_NOERI)
      (sm, im, W6cav_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_cooo_coov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W10caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_coov
  { 
  // No. 0, [2]
  // W0(w,o1,o2,m) += (    1.00000000) T2(c1,o1,o2,v1) V2(m,v1,c1,w) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,o1,o2,k) W0(w,o1,o2,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W0caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x0_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X0_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W0caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x0_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X0_TYPE1_ERI_O)
    (sm, im, W0caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(w,o1,k,m) += (    1.00000000) T2(c1,o1,k,v1) V2(m,v1,c1,w) 
  // S2(w,i,k,m) += (   -2.00000000) D1(i,o1) W1(w,o1,k,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W1caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x1_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X1_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x1_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X1_TYPE1_ERI_O)
    (sm, im, W1caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,o1,o2,m) += (    1.00000000) T2(c1,o1,o2,v1) V2(m,w,c1,v1) 
  // S2(w,i,k,m) += (    1.00000000) D2(i,k,o2,o1) W2(w,o1,o2,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W2caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x2_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X2_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W2caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x2_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X2_TYPE1_ERI_O)
    (sm, im, W2caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,o1,k,m) += (    1.00000000) T2(c1,o1,k,v1) V2(m,w,c1,v1) 
  // S2(w,i,k,m) += (    1.00000000) D1(i,o1) W3(w,o1,k,m) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W3caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x3_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X3_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W3caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x3_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X3_TYPE1_ERI_O)
    (sm, im, W3caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,o1,o4,m,o2,o3) += (    1.00000000) T2(w,o1,o4,v1) V2(m,o2,o3,v1) 
  // S2(w,i,k,m) += (   -1.00000000) D3(i,o2,o3,o1,o4,k) W4(w,o1,o4,m,o2,o3) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W4caaaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x4_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X4_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W4caaaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x4_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X4_TYPE1_ERI_O)
    (sm, im, W4caaaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(w,o2,o4,m,o1,o3) += (    1.00000000) T2(w,o2,o4,v1) V2(m,v1,o1,o3) 
  // S2(w,i,k,m) += (   -1.00000000) D3(i,o2,o3,o1,o4,k) W5(w,o2,o4,m,o1,o3) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W5caaaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x5_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X5_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W5caaaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x5_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X5_TYPE1_ERI_O)
    (sm, im, W5caaaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(i,o1,m,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(m,o2,o3,v1) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o1,k,v1) W6(i,o1,m,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W6aa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x6_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X6_TYPE1_ERI_O)
      (sm, im, sv1, iv1, V2_sym.cptr(), W6aa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x6_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X6_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), W6aa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(i,o2,m,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(m,v1,o1,o3) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o2,k,v1) W7(i,o2,m,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W7aa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x7_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X7_TYPE1_ERI_O)
      (sm, im, sv1, iv1, V2_sym.cptr(), W7aa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x7_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X7_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), W7aa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W8(i,o2,o3,m,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(m,v1,k,o1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o2,o3,v1) W8(i,o2,o3,m,k,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W8aaaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x8_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X8_TYPE1_ERI_O)
      (sm, im, sv1, iv1, V2_sym.cptr(), W8aaaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x8_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X8_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), W8aaaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(i,o3,o1,m,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(m,o2,k,v1) 
  // S2(w,i,k,m) += (   -1.00000000) T2(w,o1,o3,v1) W9(i,o3,o1,m,k,v1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W9aaaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x9_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X9_TYPE1_ERI_O)
      (sm, im, sv1, iv1, V2_sym.cptr(), W9aaaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x9_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X9_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), W9aaaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 10, [1]
  // W10(w,o2,k,o3) += (    1.00000000) T2(o2,w,v1,o1) V2(o1,k,o3,v1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x10_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X10_TYPE1_ERI_O)
    (so1, io1, T2b.cptr(), V2_sym.cptr(), W10caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o2,m,o1) += (    1.00000000) T2(w,o2,o3,v1) V2(m,o3,o1,v1) 
  // S2(w,i,k,m) += (   -1.00000000) D2(i,k,o1,o2) W11(w,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W11caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x11_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X11_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W11caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x11_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X11_TYPE1_ERI_O)
    (sm, im, W11caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 12, [2]
  // W12(w,o2,m,o1) += (    1.00000000) T2(w,o2,o3,v1) V2(m,v1,o1,o3) 
  // S2(w,i,k,m) += (   -1.00000000) D2(i,o2,o1,k) W12(w,o2,m,o1) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W12caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x12_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X12_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W12caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x12_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X12_TYPE1_ERI_O)
    (sm, im, W12caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 13, [2]
  // W13(w,o1,m,k) += (    1.00000000) T2(w,o1,o2,v1) V2(m,v1,k,o2) 
  // S2(w,i,k,m) += (    2.00000000) D1(i,o1) W13(w,o1,m,k) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W13caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x13_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X13_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W13caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x13_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X13_TYPE1_ERI_O)
    (sm, im, W13caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

  { 
  // No. 14, [2]
  // W14(w,o1,m,k) += (    1.00000000) T2(w,o1,o2,v1) V2(m,o2,k,v1) 
  // S2(w,i,k,m) += (   -1.00000000) D1(i,o1) W14(w,o1,m,k) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[im]);
  orz::DTensor W14caa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x14_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X14_TYPE1_ERI_O)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W14caa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_cooo_coov_no1_x14_type1_eri_o,G_IF_SIGMA_COOO_COOV_NO1_X14_TYPE1_ERI_O)
    (sm, im, W14caa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(im, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_cooo_coov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (    2.00000000) D2(i,m,o3,o2) W10(w,o2,k,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x0_type2_eri_o,G_IF_SIGMA_COOO_COOV_NO0_X0_TYPE2_ERI_O)
      (sm, im, W10caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_cooo_coov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W1caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W2caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W3caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W4caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W5caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W6caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W7caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W8caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W9caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W11caaaaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaaaa(symblockinfo, 0));
  orz::DTensor W12caaaaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaaaa(symblockinfo, 0));
  orz::DTensor W16caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  orz::DTensor W17caaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_coov
  { 
  // No. 0, [1]
  // W0(w,o1,o3,o2) += (    1.00000000) T2(c1,o1,o3,v1) V2(v1,o2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x0_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X0_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W0caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 1, [1]
  // W1(w,o1,k,o2) += (    1.00000000) T2(c1,o1,k,v1) V2(v1,o2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x1_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X1_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 2, [1]
  // W2(w,o1,o2,k) += (    1.00000000) T2(c1,o1,o2,v1) V2(v1,k,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x2_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X2_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W2caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 3, [1]
  // W3(w,o1,m,o2) += (    1.00000000) T2(o1,c1,v1,m) V2(v1,o2,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x3_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X3_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W3caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // W4(w,o1,m,k) += (    1.00000000) T2(o1,c1,v1,m) V2(v1,k,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x4_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X4_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W4caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // W5(w,o1,o3,o2) += (    1.00000000) T2(c1,o1,o3,v1) V2(v1,c1,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x5_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X5_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W5caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 6, [1]
  // W6(w,o1,k,o2) += (    1.00000000) T2(c1,o1,k,v1) V2(v1,c1,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x6_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X6_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W6caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 7, [1]
  // W7(w,o1,o2,k) += (    1.00000000) T2(c1,o1,o2,v1) V2(v1,c1,w,k) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x7_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X7_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W7caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 8, [1]
  // W8(w,o1,m,o2) += (    1.00000000) T2(o1,c1,v1,m) V2(v1,c1,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x8_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X8_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W8caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 9, [1]
  // W9(w,o1,m,k) += (    1.00000000) T2(o1,c1,v1,m) V2(v1,c1,w,k) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x9_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X9_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W9caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W10(i,m,o1,v1) += (    1.00000000) D3(i,m,o3,o1,o4,o2) V2(v1,o3,o2,o4) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,o1,k,v1) W10(i,m,o1,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W10aa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^sv1));
    FC_FUNC(g_if_sigma_cooo_coov_no0_x10_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X10_TYPE1_ERI_V)
      (sm, im, sv1, iv1, V2_sym.cptr(), W10aa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x10_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO1_X10_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W10aa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // W11(w,o1,o4,o3,k,o2) += (    1.00000000) T2(w,o1,o4,v1) V2(v1,o3,k,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x11_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X11_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W11caaaaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 12, [1]
  // W12(w,o2,o4,k,o1,o3) += (    1.00000000) T2(w,o2,o4,v1) V2(v1,k,o1,o3) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x12_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X12_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W12caaaaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 13, [2]
  // W13(i,k,o1,v1) += (    1.00000000) D3(i,k,o3,o1,o4,o2) V2(v1,o3,o2,o4) 
  // S2(w,i,k,m) += (   -1.00000000) T2(o1,w,v1,m) W13(i,k,o1,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W13aaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_coov_no0_x13_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X13_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W13aaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x13_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO1_X13_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W13aaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [2]
  // W14(i,o1,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,o3,k,o2) 
  // S2(w,i,k,m) += (   -1.00000000) T2(o1,w,v1,m) W14(i,o1,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W14aaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_coov_no0_x14_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X14_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W14aaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x14_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO1_X14_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W14aaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [2]
  // W15(i,o2,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,k,o1,o3) 
  // S2(w,i,k,m) += (   -1.00000000) T2(o2,w,v1,m) W15(i,o2,k,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W15aaa_sigma_cooo_coov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_cooo_coov_no0_x15_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X15_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W15aaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no1_x15_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO1_X15_TYPE1_ERI_V)
      (sm, im, sv1, iv1, T2b.cptr(), W15aaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [1]
  // W16(w,o3,o1,o2) += (    1.00000000) T2(w,o3,o4,v1) V2(v1,o1,o2,o4) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x16_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X16_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W16caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 17, [1]
  // W17(w,o2,k,o3) += (    1.00000000) T2(w,o2,o1,v1) V2(v1,k,o1,o3) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_cooo_coov_no0_x17_type1_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X17_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W17caaa_sigma_cooo_coov.cptr(), nir, nsym, psym, &flops);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_cooo_coov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o2,o1,o3,k) W0(w,o1,o3,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x0_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X0_TYPE2_ERI_V)
      (sm, im, W0caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o2,o1) W1(w,o1,k,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x1_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X1_TYPE2_ERI_V)
      (sm, im, W1caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o2,o1) W2(w,o1,o2,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x2_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X2_TYPE2_ERI_V)
      (sm, im, W2caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,k,o2,o1) W3(w,o1,m,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x3_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X3_TYPE2_ERI_V)
      (sm, im, W3caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,i,k,m) += (    1.00000000) D1(i,o1) W4(w,o1,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x4_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X4_TYPE2_ERI_V)
      (sm, im, W4caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,i,k,m) += (    1.00000000) D3(i,m,o2,k,o3,o1) W5(w,o1,o3,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x5_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X5_TYPE2_ERI_V)
      (sm, im, W5caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,m,o2,o1) W6(w,o1,k,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x6_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X6_TYPE2_ERI_V)
      (sm, im, W6caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,i,k,m) += (   -2.00000000) D2(i,m,o2,o1) W7(w,o1,o2,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x7_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X7_TYPE2_ERI_V)
      (sm, im, W7caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [1]
  // S2(w,i,k,m) += (    1.00000000) D2(i,o1,o2,k) W8(w,o1,m,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x8_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X8_TYPE2_ERI_V)
      (sm, im, W8caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [1]
  // S2(w,i,k,m) += (   -2.00000000) D1(i,o1) W9(w,o1,m,k) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x9_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X9_TYPE2_ERI_V)
      (sm, im, W9caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [1]
  // S2(w,i,k,m) += (   -1.00000000) D3(i,m,o3,o1,o4,o2) W11(w,o1,o4,o3,k,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x10_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X10_TYPE2_ERI_V)
      (sm, im, W11caaaaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // S2(w,i,k,m) += (   -1.00000000) D3(i,m,o3,o1,o4,o2) W12(w,o2,o4,k,o1,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x11_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X11_TYPE2_ERI_V)
      (sm, im, W12caaaaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,i,k,m) += (   -1.00000000) D3(i,m,o1,o3,o2,k) W16(w,o3,o1,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x12_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X12_TYPE2_ERI_V)
      (sm, im, W16caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,i,k,m) += (   -1.00000000) D2(i,m,o3,o2) W17(w,o2,k,o3) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x13_type2_eri_v,G_IF_SIGMA_COOO_COOV_NO0_X13_TYPE2_ERI_V)
      (sm, im, W17caaa_sigma_cooo_coov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@loadD4C(v,begin)
  //*-- FEMTO begins --//*
  // Label : d4c_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  orz::DTensor C5;
  orz::LoadBin(ctinp.dir()/(format("D4C_g[%d]")%i_eri).str()) >> C5;

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_cooo_coov
  { 
  // No. 0, [1]
  // S2(w,i,k,m) += (   -1.00000000) C5(m,i,k,o1,o4,v1) T2(w,o4,o1,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_coov_no0_x0_type1_d4c_v,G_IF_SIGMA_COOO_COOV_NO0_X0_TYPE1_D4C_V)
      (sm, im, sv1, iv1, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadD4C(v,end)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_cooo_coov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
