                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccov_ooov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//    o__ __o__/_                            o                         
//   <|    v                                <|>                        
//   < >                                    < >                        
//    |         o__  __o   \o__ __o__ __o    |        o__ __o         
//    o__/_    /v      |>   |     |     |>   o__/_   /v     v\        
//    |       />      //   / \   / \   / \   |      />       <\    
//   <o>      \o    o/     \o/   \o/   \o/   |      \         /   
//    |        v\  /v __o   |     |     |    o       o       o        
//   / \        <\/> __/>  / \   / \   / \   <\__    <\__ __/>  

//                                   Generated date : Wed Feb 19 15:56:01 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccov_ooov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ooov
  { 
  // No. 0, [2]
  // W0(w,y,i,o1,o4,o2) += (    1.00000000) D3(i,o3,o1,o4,o2,o5) V2(w,o3,y,o5) 
  // S2(w,y,i,a) += (    1.00000000) T2(o1,o2,o4,a) W0(w,y,i,o1,o4,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W0caaaa_sigma_ccov_ooov(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ooov_no0_x0_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO0_X0_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W0caaaa_sigma_ccov_ooov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ooov_no1_x0_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO1_X0_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W0caaaa_sigma_ccov_ooov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [2]
  // W1(w,y,o3,o4) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o2,y,o1) 
  // S2(w,y,i,a) += (    1.00000000) T2(o4,o3,i,a) W1(w,y,o3,o4) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W1caa_sigma_ccov_ooov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ooov_no0_x1_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO0_X1_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W1caa_sigma_ccov_ooov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ooov_no1_x1_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO1_X1_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W1caa_sigma_ccov_ooov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,y,o1,o3,o2,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,i,y,o4) 
  // S2(w,y,i,a) += (   -2.00000000) T2(o1,o2,o3,a) W2(w,y,o1,o3,o2,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W2caaaa_sigma_ccov_ooov(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ooov_no0_x2_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO0_X2_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W2caaaa_sigma_ccov_ooov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ooov_no1_x2_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO1_X2_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W2caaaa_sigma_ccov_ooov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,y,o1,o3,o2,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o4,y,i) 
  // S2(w,y,i,a) += (    1.00000000) T2(o1,o2,o3,a) W3(w,y,o1,o3,o2,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W3caaaa_sigma_ccov_ooov(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccov_ooov_no0_x3_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO0_X3_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W3caaaa_sigma_ccov_ooov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ooov_no1_x3_type1_eri_c,G_IF_SIGMA_CCOV_OOOV_NO1_X3_TYPE1_ERI_C)
      (sa, ia, sw, iw, T2b.cptr(), W3caaaa_sigma_ccov_ooov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccov_ooov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
