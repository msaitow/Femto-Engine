                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_fock_v_ccoo_ccoo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  `7MM"""YMM                         mm               
//    MM    `7                         MM                  
//    MM   d  .gP"Ya `7MMpMMMb.pMMMb.mmMMmm ,pW"Wq.      
//    MM""MM ,M'   Yb  MM    MM    MM  MM  6W'   `Wb   
//    MM   Y 8M""""""  MM    MM    MM  MM  8M     M8 
//    MM     YM.    ,  MM    MM    MM  MM  YA.   ,A9       
//  .JMML.    `Mbmmd'.JMML  JMML  JMML.`Mbmo`Ybmd9'        

//                                   Generated date : Wed Feb 19 15:54:46 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::fock_v_ccoo_ccoo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const orz::DTensor &CFock,                                                 
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,y,i,k) += (    4.00000000) h6_int D2(i,o1,k,o2) T2(w,y,o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x0_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X0_TYPE1_NOERI)
        (sk, ik, so2, io2, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [2]
  // W0(c1,y,i,k) += (    1.00000000) D2(i,o2,k,o1) T2(c1,y,o2,o1) 
  // S2(w,y,i,k) += (   -2.00000000) P1(c1,w) W0(c1,y,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W0cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x1_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X1_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), W0cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x1_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X1_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W0cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W1(c1,w,i,k) += (    1.00000000) D2(i,o2,k,o1) T2(c1,w,o1,o2) 
  // S2(w,y,i,k) += (   -2.00000000) P1(c1,y) W1(c1,w,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W1cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x2_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X2_TYPE1_NOERI)
        (sk, ik, so2, io2, T2b.cptr(), W1cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x2_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X2_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W1cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [1]
  // S2(w,y,i,k) += (   -8.00000000) h6_int D1(k,o1) T2(w,y,i,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x3_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X3_TYPE1_NOERI)
        (sk, ik, so1, io1, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [1]
  // S2(w,y,i,k) += (    4.00000000) h6_int D1(k,o1) T2(w,y,o1,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    T2b = T2.get_amp2(ii);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x4_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X4_TYPE1_NOERI)
        (si, ii, sk, ik, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W2(c1,y,k,i) += (    1.00000000) D1(k,o1) T2(c1,y,i,o1) 
  // S2(w,y,i,k) += (    4.00000000) P1(c1,w) W2(c1,y,k,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W2cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x5_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X5_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), W2cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x5_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X5_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W2cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [2]
  // W3(c1,y,k,i) += (    1.00000000) D1(k,o1) T2(c1,y,o1,i) 
  // S2(w,y,i,k) += (   -2.00000000) P1(c1,w) W3(c1,y,k,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      orz::DTensor W3cc_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^si));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x6_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X6_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W3cc_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x6_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X6_TYPE1_NOERI)
        (si, ii, sk, ik, CFock.cptr(), W3cc_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [2]
  // W4(c1,w,k,i) += (    1.00000000) D1(k,o1) T2(c1,w,i,o1) 
  // S2(w,y,i,k) += (   -2.00000000) P1(c1,y) W4(c1,w,k,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W4cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x7_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X7_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), W4cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x7_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X7_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W4cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 8, [2]
  // W5(c1,w,k,i) += (    1.00000000) D1(k,o1) T2(c1,w,o1,i) 
  // S2(w,y,i,k) += (    4.00000000) P1(c1,y) W5(c1,w,k,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      orz::DTensor W5cc_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^si));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x8_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X8_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W5cc_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x8_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X8_TYPE1_NOERI)
        (si, ii, sk, ik, CFock.cptr(), W5cc_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 9, [1]
  // S2(w,y,i,k) += (    4.00000000) h6_int D1(i,o1) T2(y,w,o1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x9_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X9_TYPE1_NOERI)
      (sk, ik, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 10, [1]
  // S2(w,y,i,k) += (   -8.00000000) h6_int D1(i,o1) T2(w,y,o1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x10_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X10_TYPE1_NOERI)
      (sk, ik, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 11, [2]
  // W6(y,c1,i,k) += (    1.00000000) D1(i,o1) T2(y,c1,o1,k) 
  // S2(w,y,i,k) += (   -2.00000000) P1(c1,w) W6(y,c1,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W6cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x11_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X11_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W6cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x11_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X11_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W6cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 12, [2]
  // W7(c1,y,i,k) += (    1.00000000) D1(i,o1) T2(c1,y,o1,k) 
  // S2(w,y,i,k) += (    4.00000000) P1(c1,w) W7(c1,y,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W7cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x12_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X12_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W7cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x12_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X12_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W7cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 13, [2]
  // W8(w,c1,i,k) += (    1.00000000) D1(i,o1) T2(w,c1,o1,k) 
  // S2(w,y,i,k) += (    4.00000000) P1(c1,y) W8(w,c1,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W8cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x13_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X13_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W8cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x13_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X13_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W8cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 14, [2]
  // W9(c1,w,i,k) += (    1.00000000) D1(i,o1) T2(c1,w,o1,k) 
  // S2(w,y,i,k) += (   -2.00000000) P1(c1,y) W9(c1,w,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W9cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x14_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X14_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W9cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x14_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X14_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W9cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 15, [1]
  // S2(w,y,i,k) += (   16.00000000) h6_int T2(w,y,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x15_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X15_TYPE1_NOERI)
      (sk, ik, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 16, [1]
  // S2(w,y,i,k) += (   -8.00000000) h6_int T2(y,w,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x16_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X16_TYPE1_NOERI)
      (sk, ik, &h6_int, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 17, [1]
  // S2(w,y,i,k) += (   -8.00000000) P1(c1,w) T2(c1,y,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x17_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X17_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 18, [1]
  // S2(w,y,i,k) += (    4.00000000) P1(c1,w) T2(y,c1,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x18_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X18_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 19, [1]
  // S2(w,y,i,k) += (    4.00000000) P1(c1,y) T2(c1,w,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x19_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X19_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 20, [1]
  // S2(w,y,i,k) += (   -8.00000000) P1(c1,y) T2(w,c1,i,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x20_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X20_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 21, [2]
  // W10(i,o2,k,o3) += (    1.00000000) D3(i,o2,k,o3,o1,o4) P1(o1,o4) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o2,o3) W10(i,o2,k,o3) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor W10aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^so3));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x21_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X21_TYPE1_NOERI)
        (sk, ik, so3, io3, CFock.cptr(), W10aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x21_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X21_TYPE1_NOERI)
        (sk, ik, so3, io3, T2b.cptr(), W10aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 22, [2]
  // W11(k,o2) += (    1.00000000) D2(k,o2,o3,o1) P1(o3,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(w,y,i,o2) W11(k,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      double W11_fock_v_ccoo_ccoo = 0;
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x22_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X22_TYPE1_NOERI)
        (sk, ik, so2, io2, CFock.cptr(), &W11_fock_v_ccoo_ccoo, nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x22_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X22_TYPE1_NOERI)
        (sk, ik, so2, io2, T2b.cptr(), &W11_fock_v_ccoo_ccoo, S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 23, [2]
  // W12(k,o2) += (    1.00000000) D2(k,o2,o3,o1) P1(o3,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o2,i) W12(k,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W12a_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xa(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x23_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X23_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W12a_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x23_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X23_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W12a_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 24, [2]
  // W13(k,o2,o3,i) += (    1.00000000) D2(k,o2,o1,o3) P1(i,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o3,o2) W13(k,o2,o3,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W13aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^so2));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x24_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X24_TYPE1_NOERI)
        (sk, ik, so2, io2, CFock.cptr(), W13aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x24_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X24_TYPE1_NOERI)
        (sk, ik, so2, io2, T2b.cptr(), W13aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 25, [2]
  // W14(i,o2) += (    1.00000000) D2(i,o2,o3,o1) P1(o3,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(y,w,o2,k) W14(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W14aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x25_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X25_TYPE1_NOERI)
    (CFock.cptr(), W14aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x25_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X25_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W14aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 26, [2]
  // W15(i,o2) += (    1.00000000) D2(i,o2,o3,o1) P1(o3,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(w,y,o2,k) W15(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W15aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x26_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X26_TYPE1_NOERI)
    (CFock.cptr(), W15aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x26_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X26_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W15aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 27, [2]
  // W16(i,o2,o1,k) += (    1.00000000) D2(i,o2,o3,o1) P1(k,o3) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o2,o1) W16(i,o2,o1,k) 
  double flops = 0; // Flop count
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    if(hintmo.iproc_havingimo()[io1] == myrank) {           
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor W16aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sk));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x27_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X27_TYPE1_NOERI)
        (sk, ik, so1, io1, CFock.cptr(), W16aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x27_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X27_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), W16aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 28, [2]
  // W17() += (    1.00000000) D1(o1,o2) P1(o2,o1) 
  // S2(w,y,i,k) += (    8.00000000) W17 T2(w,y,i,k) 
  double flops = 0; // Flop count
  double W17_fock_v_ccoo_ccoo = 0;
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x28_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X28_TYPE1_NOERI)
    (CFock.cptr(), &W17_fock_v_ccoo_ccoo, nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x28_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X28_TYPE1_NOERI)
      (sk, ik, &W17_fock_v_ccoo_ccoo, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 29, [2]
  // W18() += (    1.00000000) D1(o1,o2) P1(o2,o1) 
  // S2(w,y,i,k) += (   -4.00000000) W18 T2(y,w,i,k) 
  double flops = 0; // Flop count
  double W18_fock_v_ccoo_ccoo = 0;
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x29_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X29_TYPE1_NOERI)
    (CFock.cptr(), &W18_fock_v_ccoo_ccoo, nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x29_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X29_TYPE1_NOERI)
      (sk, ik, &W18_fock_v_ccoo_ccoo, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 30, [2]
  // W19(o2,k) += (    1.00000000) D1(o1,o2) P1(k,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(w,y,i,o2) W19(o2,k) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      double W19_fock_v_ccoo_ccoo = 0;
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x30_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X30_TYPE1_NOERI)
        (sk, ik, so2, io2, CFock.cptr(), &W19_fock_v_ccoo_ccoo, nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x30_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X30_TYPE1_NOERI)
        (sk, ik, so2, io2, T2b.cptr(), &W19_fock_v_ccoo_ccoo, S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 31, [2]
  // W20(o2,k) += (    1.00000000) D1(o1,o2) P1(k,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o2,i) W20(o2,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W20a_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xa(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x31_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X31_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W20a_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x31_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X31_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W20a_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 32, [2]
  // W21(o2,i) += (    1.00000000) D1(o1,o2) P1(i,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(y,w,o2,k) W21(o2,i) 
  double flops = 0; // Flop count
  orz::DTensor W21aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x32_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X32_TYPE1_NOERI)
    (CFock.cptr(), W21aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x32_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X32_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W21aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 33, [2]
  // W22(o2,i) += (    1.00000000) D1(o1,o2) P1(i,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(w,y,o2,k) W22(o2,i) 
  double flops = 0; // Flop count
  orz::DTensor W22aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x33_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X33_TYPE1_NOERI)
    (CFock.cptr(), W22aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x33_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X33_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W22aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 34, [2]
  // W23(i,o3,k,o1) += (    1.00000000) D2(i,o3,k,o2) P1(o2,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o3,o1) W23(i,o3,k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W23aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^so1));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x34_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X34_TYPE1_NOERI)
        (sk, ik, so1, io1, CFock.cptr(), W23aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x34_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X34_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), W23aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 35, [2]
  // W24(i,k,o2,o3) += (    1.00000000) D2(i,o1,k,o2) P1(o1,o3) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o3,o2) W24(i,k,o2,o3) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W24aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sk^so2));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x35_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X35_TYPE1_NOERI)
        (sk, ik, so2, io2, CFock.cptr(), W24aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x35_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X35_TYPE1_NOERI)
        (sk, ik, so2, io2, T2b.cptr(), W24aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 36, [2]
  // W25(k,o1) += (    1.00000000) D1(k,o2) P1(o2,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(w,y,i,o1) W25(k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      double W25_fock_v_ccoo_ccoo = 0;
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x36_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X36_TYPE1_NOERI)
        (sk, ik, so1, io1, CFock.cptr(), &W25_fock_v_ccoo_ccoo, nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x36_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X36_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), &W25_fock_v_ccoo_ccoo, S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 37, [2]
  // W26(k,o1) += (    1.00000000) D1(k,o2) P1(o2,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(w,y,o1,i) W26(k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W26a_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xa(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x37_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X37_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W26a_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x37_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X37_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W26a_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 38, [2]
  // W27(w,y,k,o1) += (    1.00000000) D1(k,o2) T2(w,y,o1,o2) 
  // S2(w,y,i,k) += (   -4.00000000) P1(i,o1) W27(w,y,k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W27cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sk));
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x38_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X38_TYPE1_NOERI)
        (sk, ik, so2, io2, T2b.cptr(), W27cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x38_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X38_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W27cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 39, [2]
  // W28(w,y,k,o1) += (    1.00000000) D1(k,o2) T2(w,y,o2,o1) 
  // S2(w,y,i,k) += (    2.00000000) P1(i,o1) W28(w,y,k,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor W28cc_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, sk^so1));
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x39_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X39_TYPE1_NOERI)
        (sk, ik, so1, io1, T2b.cptr(), W28cc_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x39_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X39_TYPE1_NOERI)
        (sk, ik, so1, io1, CFock.cptr(), W28cc_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 40, [2]
  // W29(i,o1) += (    1.00000000) D1(i,o2) P1(o2,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(y,w,o1,k) W29(i,o1) 
  double flops = 0; // Flop count
  orz::DTensor W29aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x40_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X40_TYPE1_NOERI)
    (CFock.cptr(), W29aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x40_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X40_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W29aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 41, [2]
  // W30(i,o1) += (    1.00000000) D1(i,o2) P1(o2,o1) 
  // S2(w,y,i,k) += (   -4.00000000) T2(w,y,o1,k) W30(i,o1) 
  double flops = 0; // Flop count
  orz::DTensor W30aa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x41_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X41_TYPE1_NOERI)
    (CFock.cptr(), W30aa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x41_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X41_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W30aa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 42, [2]
  // W31(w,y,i,o1) += (    1.00000000) D1(i,o2) T2(w,y,o1,o2) 
  // S2(w,y,i,k) += (    2.00000000) P1(k,o1) W31(w,y,i,o1) 
  double flops = 0; // Flop count
  orz::DTensor W31ccaa_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x42_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X42_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W31ccaa_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x42_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X42_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), W31ccaa_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 43, [2]
  // W32(w,y,i,o2) += (    1.00000000) D1(i,o1) T2(w,y,o1,o2) 
  // S2(w,y,i,k) += (   -4.00000000) P1(k,o2) W32(w,y,i,o2) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    T2b = T2.get_amp2(io2);
    orz::DTensor W32cca_fock_v_ccoo_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, so2));
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x43_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X43_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W32cca_fock_v_ccoo_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no1_x43_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO1_X43_TYPE1_NOERI)
        (sk, ik, so2, io2, CFock.cptr(), W32cca_fock_v_ccoo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 44, [1]
  // S2(w,y,i,k) += (    8.00000000) P1(k,o1) T2(w,y,i,o1) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x44_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X44_TYPE1_NOERI)
        (sk, ik, so1, io1, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 45, [1]
  // S2(w,y,i,k) += (   -4.00000000) P1(k,o1) T2(w,y,o1,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    T2b = T2.get_amp2(ii);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x45_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X45_TYPE1_NOERI)
        (si, ii, sk, ik, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 46, [1]
  // S2(w,y,i,k) += (    8.00000000) P1(i,o1) T2(w,y,o1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x46_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X46_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 47, [1]
  // S2(w,y,i,k) += (   -4.00000000) P1(i,o1) T2(y,w,o1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_fock_v_ccoo_ccoo_no0_x47_type1_noeri,G_IF_FOCK_V_CCOO_CCOO_NO0_X47_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("fock_v_ccoo_ccoo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
