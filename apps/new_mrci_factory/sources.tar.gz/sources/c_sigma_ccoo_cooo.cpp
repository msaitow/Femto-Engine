                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccoo_cooo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  8 8888888888   8 8888888888            ,8.       ,8.    8888888 8888888888 ,o888888o.     
//  8 8888         8 8888                 ,888.     ,888.         8 8888    . 8888     `88.   
//  8 8888         8 8888                .`8888.   .`8888.        8 8888   ,8 8888       `8b  
//  8 8888         8 8888               ,8.`8888. ,8.`8888.       8 8888   88 8888        `8b 
//  8 888888888888 8 888888888888      ,8'8.`8888,8^8.`8888.      8 8888   88 8888         88 
//  8 8888         8 8888             ,8' `8.`8888' `8.`8888.     8 8888   88 8888         88 
//  8 8888         8 8888            ,8'   `8.`88'   `8.`8888.    8 8888   88 8888        ,8P 
//  8 8888         8 8888           ,8'     `8.`'     `8.`8888.   8 8888   `8 8888       ,8P  
//  8 8888         8 8888          ,8'       `8        `8.`8888.  8 8888    ` 8888     ,88'   
//  8 8888         8 888888888888 ,8'         `         `8.`8888. 8 8888       `8888888P'     

//                                   Generated date : Wed Feb 19 15:55:59 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccoo_cooo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [2]
  // W0(w,i,k,o2,o3,o4) += (    1.00000000) D3(i,o1,k,o2,o3,o4) Fc1(w,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o3,o2,o4) W0(w,i,k,o2,o3,o4) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W0caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so4));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x0_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X0_TYPE1_NOERI)
        (sk, ik, so4, io4, W0caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x0_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X0_TYPE1_NOERI)
        (sk, ik, so4, io4, T2b.cptr(), W0caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [2]
  // W1(y,i,o1,k,o3,o4) += (    1.00000000) D3(i,o1,k,o2,o3,o4) Fc1(y,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o3,o1,o4) W1(y,i,o1,k,o3,o4) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor W1caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so4));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x1_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X1_TYPE1_NOERI)
        (sk, ik, so4, io4, W1caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x1_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X1_TYPE1_NOERI)
        (sk, ik, so4, io4, T2b.cptr(), W1caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W2(w,k,o2,o3) += (    1.00000000) D2(k,o1,o2,o3) Fc1(w,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o2,i,o3) W2(w,k,o2,o3) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor W2ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so3));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x2_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X2_TYPE1_NOERI)
        (sk, ik, so3, io3, W2ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x2_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X2_TYPE1_NOERI)
        (sk, ik, so3, io3, T2b.cptr(), W2ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [2]
  // W3(y,k,o2,o3) += (    1.00000000) D2(k,o1,o2,o3) Fc1(y,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o2,i,o3) W3(y,k,o2,o3) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor W3ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so3));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x3_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X3_TYPE1_NOERI)
        (sk, ik, so3, io3, W3ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x3_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X3_TYPE1_NOERI)
        (sk, ik, so3, io3, T2b.cptr(), W3ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [2]
  // W4(y,k,o2,o3) += (    1.00000000) D2(k,o1,o2,o3) Fc1(y,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o2,o3,i) W4(y,k,o2,o3) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W4caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x4_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X4_TYPE1_NOERI)
      (sk, ik, W4caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x4_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X4_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W4caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W5(w,k,o1,o2) += (    1.00000000) D2(k,o1,o2,o3) Fc1(w,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o2,o1,i) W5(w,k,o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W5caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x5_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X5_TYPE1_NOERI)
      (sk, ik, W5caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x5_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X5_TYPE1_NOERI)
        (si, ii, sk, ik, T2b.cptr(), W5caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [2]
  // W6(y,k) += (    1.00000000) D2(k,o1,o2,o3) T2(y,o2,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(w,i) W6(y,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W6c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x6_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X6_TYPE1_NOERI)
        (sk, ik, so3, io3, T2b.cptr(), W6c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x6_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X6_TYPE1_NOERI)
      (sk, ik, W6c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [2]
  // W7(w,k) += (    1.00000000) D2(k,o1,o2,o3) T2(w,o2,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) Fc1(y,i) W7(w,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W7c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x7_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X7_TYPE1_NOERI)
        (sk, ik, so3, io3, T2b.cptr(), W7c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x7_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X7_TYPE1_NOERI)
      (sk, ik, W7c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 8, [2]
  // W8(y,i,o2,o3) += (    1.00000000) D2(i,o1,o2,o3) Fc1(y,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(o2,w,o3,k) W8(y,i,o2,o3) 
  double flops = 0; // Flop count
  orz::DTensor W8caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x8_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X8_TYPE1_NOERI)
    (W8caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x8_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X8_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W8caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 9, [2]
  // W9(w,i,o2,o3) += (    1.00000000) D2(i,o1,o2,o3) Fc1(w,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o2,y,o3,k) W9(w,i,o2,o3) 
  double flops = 0; // Flop count
  orz::DTensor W9caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x9_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X9_TYPE1_NOERI)
    (W9caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x9_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X9_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W9caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 10, [2]
  // W10(w,i,o2,o3) += (    1.00000000) D2(i,o1,o2,o3) Fc1(w,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o2,o3,k) W10(w,i,o2,o3) 
  double flops = 0; // Flop count
  orz::DTensor W10caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x10_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X10_TYPE1_NOERI)
    (W10caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x10_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X10_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W10caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 11, [2]
  // W11(y,i,o1,o2) += (    1.00000000) D2(i,o1,o2,o3) Fc1(y,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o2,o1,k) W11(y,i,o1,o2) 
  double flops = 0; // Flop count
  orz::DTensor W11caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x11_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X11_TYPE1_NOERI)
    (W11caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x11_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X11_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W11caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 12, [2]
  // W12(w,i) += (    1.00000000) D2(i,o1,o2,o3) T2(w,o2,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(y,k) W12(w,i) 
  double flops = 0; // Flop count
  orz::DTensor W12ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x12_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X12_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W12ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x12_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X12_TYPE1_NOERI)
      (sk, ik, W12ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 13, [2]
  // W13(y,i) += (    1.00000000) D2(i,o1,o2,o3) T2(y,o2,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) Fc1(w,k) W13(y,i) 
  double flops = 0; // Flop count
  orz::DTensor W13ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x13_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X13_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W13ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x13_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X13_TYPE1_NOERI)
      (sk, ik, W13ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 14, [2]
  // W14(w,o2) += (    1.00000000) D1(o1,o2) Fc1(w,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o2,i,k) W14(w,o2) 
  double flops = 0; // Flop count
  orz::DTensor W14ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x14_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X14_TYPE1_NOERI)
    (W14ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x14_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X14_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W14ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 15, [2]
  // W15(y,o2) += (    1.00000000) D1(o1,o2) Fc1(y,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o2,i,k) W15(y,o2) 
  double flops = 0; // Flop count
  orz::DTensor W15ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x15_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X15_TYPE1_NOERI)
    (W15ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x15_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X15_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W15ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 16, [2]
  // W16(w,i) += (    1.00000000) D1(o1,o2) T2(w,o1,i,o2) 
  // S2(w,y,i,k) += (    4.00000000) Fc1(y,k) W16(w,i) 
  double flops = 0; // Flop count
  orz::DTensor W16ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x16_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X16_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W16ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x16_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X16_TYPE1_NOERI)
      (sk, ik, W16ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 17, [2]
  // W17(y,i) += (    1.00000000) D1(o1,o2) T2(y,o1,i,o2) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(w,k) W17(y,i) 
  double flops = 0; // Flop count
  orz::DTensor W17ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x17_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X17_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W17ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x17_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X17_TYPE1_NOERI)
      (sk, ik, W17ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 18, [2]
  // W18(w,i) += (    1.00000000) D1(o1,o2) T2(w,o1,o2,i) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(y,k) W18(w,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    T2b = T2.get_amp2(ii);
    orz::DTensor W18c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, si));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x18_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X18_TYPE1_NOERI)
      (si, ii, T2b.cptr(), W18c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x18_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X18_TYPE1_NOERI)
        (si, ii, sk, ik, W18c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 19, [2]
  // W19(y,i) += (    1.00000000) D1(o1,o2) T2(y,o1,o2,i) 
  // S2(w,y,i,k) += (    1.00000000) Fc1(w,k) W19(y,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    T2b = T2.get_amp2(ii);
    orz::DTensor W19c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, si));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x19_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X19_TYPE1_NOERI)
      (si, ii, T2b.cptr(), W19c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x19_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X19_TYPE1_NOERI)
        (si, ii, sk, ik, W19c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ik, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 20, [2]
  // W20(y,o2) += (    1.00000000) D1(o1,o2) Fc1(y,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(o2,w,i,k) W20(y,o2) 
  double flops = 0; // Flop count
  orz::DTensor W20ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x20_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X20_TYPE1_NOERI)
    (W20ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x20_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X20_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W20ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 21, [2]
  // W21(w,o2) += (    1.00000000) D1(o1,o2) Fc1(w,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o2,y,i,k) W21(w,o2) 
  double flops = 0; // Flop count
  orz::DTensor W21ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x21_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X21_TYPE1_NOERI)
    (W21ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x21_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X21_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W21ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 22, [2]
  // W22(y,k) += (    1.00000000) D1(o1,o2) T2(o1,y,o2,k) 
  // S2(w,y,i,k) += (    4.00000000) Fc1(w,i) W22(y,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W22c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x22_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X22_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W22c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x22_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X22_TYPE1_NOERI)
      (sk, ik, W22c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 23, [2]
  // W23(w,k) += (    1.00000000) D1(o1,o2) T2(o1,w,o2,k) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(y,i) W23(w,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W23c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x23_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X23_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W23c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x23_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X23_TYPE1_NOERI)
      (sk, ik, W23c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 24, [2]
  // W24(y,k) += (    1.00000000) D1(o1,o2) T2(y,o1,o2,k) 
  // S2(w,y,i,k) += (   -2.00000000) Fc1(w,i) W24(y,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W24c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x24_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X24_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W24c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x24_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X24_TYPE1_NOERI)
      (sk, ik, W24c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 25, [2]
  // W25(w,k) += (    1.00000000) D1(o1,o2) T2(w,o2,o1,k) 
  // S2(w,y,i,k) += (    1.00000000) Fc1(y,i) W25(w,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W25c_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x25_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO0_X25_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W25c_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x25_type1_noeri,G_IF_SIGMA_CCOO_COOO_NO1_X25_TYPE1_NOERI)
      (sk, ik, W25c_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_ccoo_cooo
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0ccaaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaaa(symblockinfo, 0));
  orz::DTensor W1ccaaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaaa(symblockinfo, 0));
  orz::DTensor W6ccaaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaaa(symblockinfo, 0));
  orz::DTensor W7ccaaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaaa(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccoo_cooo
  { 
  // No. 0, [1]
  // W0(w,y,o4,o3,o1,o2) += (    1.00000000) T2(c1,o4,o3,o1) V2(c1,w,y,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x0_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X0_TYPE1_ERI_C)
      (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), W0ccaaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // W1(y,w,o4,o2,o1,o3) += (    1.00000000) T2(c1,o4,o2,o1) V2(c1,y,w,o3) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x1_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X1_TYPE1_ERI_C)
      (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), W1ccaaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W2(c1,w,y,k,o3,o1) += (    1.00000000) D2(k,o2,o3,o1) V2(c1,w,y,o2) 
  // S2(w,y,i,k) += (    2.00000000) T2(c1,o3,i,o1) W2(c1,w,y,k,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W2cca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1^sk^so1));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x2_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X2_TYPE1_ERI_C)
        (sc1, ic1, sk, ik, so1, io1, V2_sym.cptr(), W2cca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x2_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X2_TYPE1_ERI_C)
        (sc1, ic1, sk, ik, so1, io1, T2b.cptr(), W2cca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(c1,y,w,k,o3,o1) += (    1.00000000) D2(k,o2,o3,o1) V2(c1,y,w,o2) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o3,i,o1) W3(c1,y,w,k,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W3cca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1^sk^so1));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x3_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X3_TYPE1_ERI_C)
        (sc1, ic1, sk, ik, so1, io1, V2_sym.cptr(), W3cca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x3_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X3_TYPE1_ERI_C)
        (sc1, ic1, sk, ik, so1, io1, T2b.cptr(), W3cca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [2]
  // W4(c1,y,w,k,o2,o3) += (    1.00000000) D2(k,o2,o3,o1) V2(c1,y,w,o1) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o3,o2,i) W4(c1,y,w,k,o2,o3) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W4ccaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, sc1^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x4_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X4_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, V2_sym.cptr(), W4ccaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x4_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X4_TYPE1_ERI_C)
        (sc1, ic1, si, ii, sk, ik, T2b.cptr(), W4ccaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W5(c1,w,y,k,o3,o1) += (    1.00000000) D2(k,o2,o3,o1) V2(c1,w,y,o2) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o3,o1,i) W5(c1,w,y,k,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W5ccaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, sc1^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x5_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X5_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, V2_sym.cptr(), W5ccaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x5_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X5_TYPE1_ERI_C)
        (sc1, ic1, si, ii, sk, ik, T2b.cptr(), W5ccaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // W6(w,y,o3,o2,o1,i) += (    1.00000000) T2(c1,o3,o2,o1) V2(c1,w,y,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x6_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X6_TYPE1_ERI_C)
      (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), W6ccaaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // W7(y,w,o3,o2,o1,i) += (    1.00000000) T2(c1,o3,o2,o1) V2(c1,y,w,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x7_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X7_TYPE1_ERI_C)
      (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), W7ccaaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W8(c1,y,w,i,o3,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,y,w,o2) 
  // S2(w,y,i,k) += (    2.00000000) T2(o3,c1,o1,k) W8(c1,y,w,i,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W8ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x8_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X8_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W8ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x8_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X8_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W8ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W9(c1,w,y,i,o3,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,y,o2) 
  // S2(w,y,i,k) += (   -1.00000000) T2(o3,c1,o1,k) W9(c1,w,y,i,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W9ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x9_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X9_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W9ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x9_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X9_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W9ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W10(c1,w,y,i,o2,o3) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,y,o1) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o3,o2,k) W10(c1,w,y,i,o2,o3) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W10ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x10_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X10_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W10ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x10_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X10_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W10ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [2]
  // W11(c1,y,w,i,o3,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,y,w,o2) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o3,o1,k) W11(c1,y,w,i,o3,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W11ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x11_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X11_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W11ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x11_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X11_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W11ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [2]
  // W12(c1,w,y,o2) += (    1.00000000) D1(o1,o2) V2(c1,w,y,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(c1,o2,i,k) W12(c1,w,y,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W12cca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x12_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X12_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W12cca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x12_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X12_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W12cca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W13(c1,y,w,o2) += (    1.00000000) D1(o1,o2) V2(c1,y,w,o1) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o2,i,k) W13(c1,y,w,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W13cca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x13_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X13_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W13cca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x13_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X13_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W13cca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [2]
  // W14(c1,y,w,o2) += (    1.00000000) D1(o1,o2) V2(c1,y,w,o1) 
  // S2(w,y,i,k) += (    2.00000000) T2(o2,c1,i,k) W14(c1,y,w,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W14cca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x14_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X14_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W14cca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x14_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X14_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W14cca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [2]
  // W15(c1,w,y,o2) += (    1.00000000) D1(o1,o2) V2(c1,w,y,o1) 
  // S2(w,y,i,k) += (   -1.00000000) T2(o2,c1,i,k) W15(c1,w,y,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W15cca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x15_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X15_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W15cca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x15_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X15_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W15cca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [2]
  // W16(c1,y,w,o1,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,y,w,i) 
  // S2(w,y,i,k) += (   -4.00000000) T2(o2,c1,o1,k) W16(c1,y,w,o1,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W16ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x16_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X16_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W16ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x16_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X16_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W16ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 17, [2]
  // W17(c1,w,y,o1,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,w,y,i) 
  // S2(w,y,i,k) += (    2.00000000) T2(o2,c1,o1,k) W17(c1,w,y,o1,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W17ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x17_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X17_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W17ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x17_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X17_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W17ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 18, [2]
  // W18(c1,w,y,o1,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,w,y,i) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o2,o1,k) W18(c1,w,y,o1,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W18ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x18_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X18_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W18ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x18_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X18_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W18ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 19, [2]
  // W19(c1,y,w,o1,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,y,w,i) 
  // S2(w,y,i,k) += (    2.00000000) T2(c1,o2,o1,k) W19(c1,y,w,o1,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W19ccaaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x19_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X19_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W19ccaaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x19_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X19_TYPE1_ERI_C)
      (sc1, ic1, sk, ik, T2b.cptr(), W19ccaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 20, [2]
  // W20(y,k,o5,o2) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(y,o3,o1,o4) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o5,i,o2) W20(y,k,o5,o2) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W20a_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sy^sk^so2));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x20_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X20_TYPE1_ERI_C)
        (sk, ik, so2, io2, sy, iy, V2_sym.cptr(), W20a_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x20_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X20_TYPE1_ERI_C)
        (sk, ik, so2, io2, sy, iy, T2b.cptr(), W20a_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 21, [2]
  // W21(w,k,o5,o2) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(w,o3,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o5,i,o2) W21(w,k,o5,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W21a_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sw^sk^so2));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x21_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X21_TYPE1_ERI_C)
        (sk, ik, so2, io2, sw, iw, V2_sym.cptr(), W21a_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x21_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X21_TYPE1_ERI_C)
        (sk, ik, so2, io2, sw, iw, T2b.cptr(), W21a_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 22, [2]
  // W22(w,k,o3,o5) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(w,o2,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o5,o3,i) W22(w,k,o3,o5) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W22aa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sw^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x22_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X22_TYPE1_ERI_C)
      (sk, ik, sw, iw, V2_sym.cptr(), W22aa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x22_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X22_TYPE1_ERI_C)
        (si, ii, sk, ik, sw, iw, T2b.cptr(), W22aa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 23, [2]
  // W23(y,k,o5,o2) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(y,o3,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o5,o2,i) W23(y,k,o5,o2) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W23aa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sy^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x23_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X23_TYPE1_ERI_C)
      (sk, ik, sy, iy, V2_sym.cptr(), W23aa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x23_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X23_TYPE1_ERI_C)
        (si, ii, sk, ik, sy, iy, T2b.cptr(), W23aa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 24, [2]
  // W24(y,k,o3,o5,o2,i) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(y,i,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o5,o3,o2) W24(y,k,o3,o5,o2,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W24aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy^sk^so2));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x24_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X24_TYPE1_ERI_C)
        (sk, ik, so2, io2, sy, iy, V2_sym.cptr(), W24aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x24_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X24_TYPE1_ERI_C)
        (sk, ik, so2, io2, sy, iy, T2b.cptr(), W24aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 25, [2]
  // W25(w,k,o3,o5,o2,i) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(w,i,o1,o4) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o5,o3,o2) W25(w,k,o3,o5,o2,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W25aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw^sk^so2));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x25_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X25_TYPE1_ERI_C)
        (sk, ik, so2, io2, sw, iw, V2_sym.cptr(), W25aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x25_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X25_TYPE1_ERI_C)
        (sk, ik, so2, io2, sw, iw, T2b.cptr(), W25aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 26, [2]
  // W26(w,k,o3,o5,o2,i) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(w,o1,i,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o5,o3,o2) W26(w,k,o3,o5,o2,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W26aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw^sk^so2));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x26_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X26_TYPE1_ERI_C)
        (sk, ik, so2, io2, sw, iw, V2_sym.cptr(), W26aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x26_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X26_TYPE1_ERI_C)
        (sk, ik, so2, io2, sw, iw, T2b.cptr(), W26aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 27, [2]
  // W27(y,k,o1,o5,o2,i) += (    1.00000000) D3(k,o3,o4,o1,o5,o2) V2(y,o3,i,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o5,o1,o2) W27(y,k,o1,o5,o2,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W27aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy^sk^so2));
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x27_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X27_TYPE1_ERI_C)
        (sk, ik, so2, io2, sy, iy, V2_sym.cptr(), W27aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x27_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X27_TYPE1_ERI_C)
        (sk, ik, so2, io2, sy, iy, T2b.cptr(), W27aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 28, [2]
  // W28(w,i,o5,o2) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(w,o3,o1,o4) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o5,y,o2,k) W28(w,i,o5,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W28aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x28_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X28_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W28aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x28_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X28_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W28aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 29, [2]
  // W29(y,i,o5,o2) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(y,o3,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(o5,w,o2,k) W29(y,i,o5,o2) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W29aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x29_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X29_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W29aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x29_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X29_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W29aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 30, [2]
  // W30(y,i,o3,o5) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(y,o2,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o5,o3,k) W30(y,i,o3,o5) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W30aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x30_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X30_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W30aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x30_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X30_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W30aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 31, [2]
  // W31(w,i,o5,o2) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(w,o3,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o5,o2,k) W31(w,i,o5,o2) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W31aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x31_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X31_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W31aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x31_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X31_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W31aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 32, [2]
  // W32(y,o4) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,o2,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o4,i,k) W32(y,o4) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W32a_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x32_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X32_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W32a_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x32_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X32_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W32a_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 33, [2]
  // W33(w,o4) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o2,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,i,k) W33(w,o4) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W33a_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x33_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X33_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W33a_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x33_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X33_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W33a_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 34, [2]
  // W34(w,o4) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o2,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o4,y,i,k) W34(w,o4) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W34a_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x34_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X34_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W34a_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x34_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X34_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W34a_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 35, [2]
  // W35(y,o4) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,o2,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,w,i,k) W35(y,o4) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W35a_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x35_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X35_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W35a_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x35_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X35_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W35a_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 36, [2]
  // W36(w,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,i,o1,o3) 
  // S2(w,y,i,k) += (    4.00000000) T2(o4,y,o2,k) W36(w,o2,o4,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W36aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x36_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X36_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W36aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x36_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X36_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W36aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 37, [2]
  // W37(y,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,i,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o4,w,o2,k) W37(y,o2,o4,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W37aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x37_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X37_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W37aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x37_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X37_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W37aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 38, [2]
  // W38(w,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o1,i,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o4,y,o2,k) W38(w,o2,o4,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W38aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x38_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X38_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W38aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x38_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X38_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W38aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 39, [2]
  // W39(y,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,o1,i,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,w,o2,k) W39(y,o2,o4,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W39aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x39_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X39_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W39aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x39_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X39_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W39aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 40, [2]
  // W40(y,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,i,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o2,k) W40(y,o2,o4,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W40aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x40_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X40_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W40aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x40_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X40_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W40aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 41, [2]
  // W41(w,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,i,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o4,o2,k) W41(w,o2,o4,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W41aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x41_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X41_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W41aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x41_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X41_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W41aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 42, [2]
  // W42(w,o2,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(w,o1,i,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,o2,k) W42(w,o2,o4,i) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  orz::DTensor W42aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sw));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x42_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X42_TYPE1_ERI_C)
    (sw, iw, V2_sym.cptr(), W42aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x42_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X42_TYPE1_ERI_C)
      (sk, ik, sw, iw, T2b.cptr(), W42aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 43, [2]
  // W43(y,o1,o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(y,o2,i,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o1,k) W43(y,o1,o4,i) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  orz::DTensor W43aaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sy));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x43_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X43_TYPE1_ERI_C)
    (sy, iy, V2_sym.cptr(), W43aaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x43_type1_eri_c,G_IF_SIGMA_CCOO_COOO_NO1_X43_TYPE1_ERI_C)
      (sk, ik, sy, iy, T2b.cptr(), W43aaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_ccoo_cooo
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,y,i,k) += (   -1.00000000) D3(i,o3,k,o2,o4,o1) W0(w,y,o4,o3,o1,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x0_type2_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X0_TYPE2_ERI_C)
      (sk, ik, W0ccaaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,y,i,k) += (   -1.00000000) D3(i,o3,k,o2,o4,o1) W1(y,w,o4,o2,o1,o3) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x1_type2_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X1_TYPE2_ERI_C)
      (sk, ik, W1ccaaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,y,i,k) += (   -1.00000000) D2(k,o2,o3,o1) W6(w,y,o3,o2,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x2_type2_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X2_TYPE2_ERI_C)
      (sk, ik, W6ccaaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,y,i,k) += (    2.00000000) D2(k,o2,o3,o1) W7(y,w,o3,o2,o1,i) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x3_type2_eri_c,G_IF_SIGMA_CCOO_COOO_NO0_X3_TYPE2_ERI_C)
      (sk, ik, W7ccaaaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccoo_cooo
  { 
  // No. 0, [2]
  // W0(w,y,o3,o2,o1,k) += (    1.00000000) T2(c1,o3,o2,o1) V2(k,w,c1,y) 
  // S2(w,y,i,k) += (   -1.00000000) D2(i,o2,o3,o1) W0(w,y,o3,o2,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W0ccaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x0_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X0_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), W0ccaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x0_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X0_TYPE1_ERI_O)
      (sk, ik, so1, io1, W0ccaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(y,w,o3,o2,o1,k) += (    1.00000000) T2(c1,o3,o2,o1) V2(k,y,c1,w) 
  // S2(w,y,i,k) += (    2.00000000) D2(i,o2,o3,o1) W1(y,w,o3,o2,o1,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W1ccaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x1_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X1_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), W1ccaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x1_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X1_TYPE1_ERI_O)
      (sk, ik, so1, io1, W1ccaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(y,c1,w,o1,o2,k) += (    1.00000000) D1(o1,o2) V2(k,y,c1,w) 
  // S2(w,y,i,k) += (   -4.00000000) T2(c1,o2,i,o1) W2(y,c1,w,o1,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W2ccca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccca(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x2_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X2_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W2ccca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x2_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X2_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W2ccca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,c1,y,o1,o2,k) += (    1.00000000) D1(o1,o2) V2(k,w,c1,y) 
  // S2(w,y,i,k) += (    2.00000000) T2(c1,o2,i,o1) W3(w,c1,y,o1,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W3ccca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xccca(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x3_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X3_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W3ccca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x3_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X3_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W3ccca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,c1,y,o1,o2,k) += (    1.00000000) D1(o1,o2) V2(k,w,c1,y) 
  // S2(w,y,i,k) += (   -1.00000000) T2(c1,o2,o1,i) W4(w,c1,y,o1,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W4cccaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcccaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x4_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X4_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W4cccaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x4_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X4_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W4cccaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(y,c1,w,o1,o2,k) += (    1.00000000) D1(o1,o2) V2(k,y,c1,w) 
  // S2(w,y,i,k) += (    2.00000000) T2(c1,o2,o1,i) W5(y,c1,w,o1,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W5cccaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcccaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x5_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X5_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W5cccaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x5_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X5_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W5cccaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(w,i,o3,o5,o2,k) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(k,w,o1,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o5,o3,o2) W6(w,i,o3,o5,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W6caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x6_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X6_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W6caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x6_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X6_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W6caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(y,i,o3,o5,o2,k) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(k,y,o1,o4) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o5,o3,o2) W7(y,i,o3,o5,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W7caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x7_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X7_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W7caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x7_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X7_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W7caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W8(y,i,o3,o5,o2,k) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(k,o4,y,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o5,o3,o2) W8(y,i,o3,o5,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W8caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x8_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X8_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W8caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x8_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X8_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W8caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(w,i,o1,o5,o2,k) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(k,o4,w,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o5,o1,o2) W9(w,i,o1,o5,o2,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W9caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x9_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X9_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W9caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x9_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X9_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W9caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W10(y,o2,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,y,o1,o3) 
  // S2(w,y,i,k) += (    4.00000000) T2(w,o4,i,o2) W10(y,o2,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W10ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x10_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X10_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W10ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x10_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X10_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W10ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o2,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,w,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o4,i,o2) W11(w,o2,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W11ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x11_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X11_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W11ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x11_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X11_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W11ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 12, [2]
  // W12(y,o2,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,o3,y,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o4,i,o2) W12(y,o2,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W12ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x12_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X12_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W12ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x12_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X12_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W12ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 13, [2]
  // W13(w,o2,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,o3,w,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,i,o2) W13(w,o2,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W13ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x13_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X13_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W13ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x13_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X13_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W13ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 14, [2]
  // W14(w,o2,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,w,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,o2,i) W14(w,o2,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W14caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x14_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X14_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W14caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x14_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X14_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W14caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 15, [2]
  // W15(y,o2,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,y,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o4,o2,i) W15(y,o2,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W15caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x15_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X15_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W15caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x15_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X15_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W15caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 16, [2]
  // W16(y,o2,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,o3,y,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o2,i) W16(y,o2,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W16caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x16_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X16_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W16caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x16_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X16_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W16caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 17, [2]
  // W17(w,o1,o4,k) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,o3,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,o1,i) W17(w,o1,o4,k) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W17caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x17_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X17_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W17caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x17_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X17_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W17caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 18, [2]
  // W18(y,o1,o2,o4,k,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,o3,y,i) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o1,o2) W18(y,o1,o2,o4,k,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W18caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x18_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X18_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W18caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x18_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X18_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W18caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 19, [2]
  // W19(w,o1,o2,o4,k,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,o3,w,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o4,o1,o2) W19(w,o1,o2,o4,k,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W19caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x19_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X19_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W19caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x19_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X19_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W19caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 20, [2]
  // W20(w,o1,o2,o4,k,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,w,i,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,o1,o2) W20(w,o1,o2,o4,k,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W20caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x20_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X20_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W20caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x20_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X20_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W20caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 21, [2]
  // W21(y,o1,o2,o4,k,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(k,y,i,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o4,o1,o2) W21(y,o1,o2,o4,k,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W21caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x21_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X21_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W21caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x21_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X21_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W21caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 22, [2]
  // W22(y,i,k,o5,o2,o1) += (    1.00000000) D3(i,o4,k,o3,o5,o2) V2(o1,o4,y,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(o5,w,o2,o1) W22(y,i,k,o5,o2,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W22caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x22_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X22_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W22caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x22_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X22_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W22caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 23, [2]
  // W23(w,i,k,o5,o2,o1) += (    1.00000000) D3(i,o4,k,o3,o5,o2) V2(o1,o3,w,o4) 
  // S2(w,y,i,k) += (    1.00000000) T2(o5,y,o2,o1) W23(w,i,k,o5,o2,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W23caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x23_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X23_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W23caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x23_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X23_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W23caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 24, [2]
  // W24(w,k,o4,o1) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o3,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,y,i,o1) W24(w,k,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W24ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x24_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X24_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W24ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x24_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X24_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W24ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 25, [2]
  // W25(y,k,o4,o1) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o2,y,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,w,i,o1) W25(y,k,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W25ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x25_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X25_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W25ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x25_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X25_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W25ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 26, [2]
  // W26(y,k,o4,o2,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o3,y,i) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,w,o2,o1) W26(y,k,o4,o2,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W26caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x26_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X26_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W26caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x26_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X26_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W26caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 27, [2]
  // W27(w,k,o4,o2,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o3,w,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o4,y,o2,o1) W27(w,k,o4,o2,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W27caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x27_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X27_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W27caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x27_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X27_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W27caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 28, [2]
  // W28(y,k,o4,o2,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,i,y,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o4,w,o2,o1) W28(y,k,o4,o2,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W28caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x28_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X28_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W28caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x28_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X28_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W28caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 29, [2]
  // W29(w,k,o4,o2,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,i,w,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,y,o2,o1) W29(w,k,o4,o2,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W29caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x29_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X29_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W29caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x29_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X29_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W29caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 30, [2]
  // W30(y,i,o4,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o3,y,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,w,k,o1) W30(y,i,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W30caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x30_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X30_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W30caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x30_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X30_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W30caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 31, [2]
  // W31(w,i,o4,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o2,w,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,y,k,o1) W31(w,i,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W31caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x31_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X31_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W31caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x31_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X31_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W31caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 32, [2]
  // W32(w,i,o4,o2,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,w,o1,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,o1,o2) W32(w,i,o4,o2,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W32caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x32_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X32_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W32caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x32_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X32_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W32caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 33, [2]
  // W33(y,i,o4,o2,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,y,o1,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o4,o1,o2) W33(y,i,o4,o2,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W33caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x33_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X33_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W33caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x33_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X33_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W33caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 34, [2]
  // W34(w,i,o4,o2,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,o1,w,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o4,o1,o2) W34(w,i,o4,o2,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W34caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x34_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X34_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W34caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x34_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X34_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W34caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 35, [2]
  // W35(y,i,o4,o2,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,o1,y,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o1,o2) W35(y,i,o4,o2,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W35caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x35_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X35_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W35caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x35_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X35_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W35caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 36, [2]
  // W36(w,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,w,o1,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o3,o1,i) W36(w,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W36caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x36_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X36_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W36caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x36_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X36_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W36caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 37, [2]
  // W37(y,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,y,o1,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o3,o1,i) W37(y,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W37caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x37_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X37_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W37caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x37_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X37_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W37caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 38, [2]
  // W38(w,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,o1,w,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o3,o1,i) W38(w,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W38caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x38_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X38_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W38caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x38_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X38_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W38caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 39, [2]
  // W39(y,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,o1,y,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o3,o1,i) W39(y,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W39caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x39_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X39_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W39caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x39_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X39_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W39caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 40, [2]
  // W40(w,o2,o3,k,o1,i) += (    1.00000000) D1(o2,o3) V2(k,o1,w,i) 
  // S2(w,y,i,k) += (    4.00000000) T2(y,o3,o1,o2) W40(w,o2,o3,k,o1,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W40caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x40_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X40_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W40caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x40_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X40_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W40caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 41, [2]
  // W41(y,o2,o3,k,o1,i) += (    1.00000000) D1(o2,o3) V2(k,o1,y,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o3,o1,o2) W41(y,o2,o3,k,o1,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W41caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x41_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X41_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W41caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x41_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X41_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W41caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 42, [2]
  // W42(y,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,o2,y,i) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,w,k,o1) W42(y,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W42caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x42_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X42_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W42caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x42_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X42_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W42caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 43, [2]
  // W43(w,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,o2,w,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o3,y,k,o1) W43(w,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W43caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x43_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X43_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W43caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x43_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X43_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W43caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 44, [2]
  // W44(y,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,i,y,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o3,w,k,o1) W44(y,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W44caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x44_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X44_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W44caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x44_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X44_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W44caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 45, [2]
  // W45(w,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,i,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,y,k,o1) W45(w,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W45caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x45_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X45_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W45caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x45_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X45_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W45caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 46, [2]
  // W46(y,o2,o3,k,i,o1) += (    1.00000000) D1(o2,o3) V2(k,y,i,o1) 
  // S2(w,y,i,k) += (    4.00000000) T2(w,o3,o1,o2) W46(y,o2,o3,k,i,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W46caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x46_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X46_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W46caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x46_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X46_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W46caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 47, [2]
  // W47(w,o2,o3,k,i,o1) += (    1.00000000) D1(o2,o3) V2(k,w,i,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o3,o1,o2) W47(w,o2,o3,k,i,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W47caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x47_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X47_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W47caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x47_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X47_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W47caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 48, [2]
  // W48(y,i,o4,k,o5,o1) += (    1.00000000) D3(i,o4,k,o3,o5,o2) V2(o1,o2,y,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o5,o4,o1) W48(y,i,o4,k,o5,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W48caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x48_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X48_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W48caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x48_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X48_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W48caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 49, [2]
  // W49(w,i,k,o3,o1,o5) += (    1.00000000) D3(i,o2,k,o3,o1,o4) V2(o5,o4,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o1,o3,o5) W49(w,i,k,o3,o1,o5) 
  double flops = 0; // Flop count
  int so5(s_eri);
  int io5(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W49caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so5));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x49_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X49_TYPE1_ERI_O)
      (sk, ik, so5, io5, V2_sym.cptr(), W49caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x49_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X49_TYPE1_ERI_O)
      (sk, ik, so5, io5, T2b.cptr(), W49caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 50, [2]
  // W50(y,k,o4,o1) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o2,y,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o4,i,o1) W50(y,k,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W50ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x50_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X50_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W50ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x50_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X50_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W50ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 51, [2]
  // W51(w,k,o4,o1) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o2,w,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,i,o1) W51(w,k,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W51ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x51_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X51_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W51ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x51_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X51_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W51ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 52, [2]
  // W52(y,k,o3,o4,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o2,y,i) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o3,o1) W52(y,k,o3,o4,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W52caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x52_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X52_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W52caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x52_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X52_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W52caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 53, [2]
  // W53(w,k,o3,o4,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,o2,w,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o4,o3,o1) W53(w,k,o3,o4,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W53caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x53_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X53_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W53caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x53_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X53_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W53caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 54, [2]
  // W54(w,k,o3,o4,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,i,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,o3,o1) W54(w,k,o3,o4,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W54caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x54_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X54_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W54caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x54_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X54_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W54caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 55, [2]
  // W55(y,k,o4,o2,o1,i) += (    1.00000000) D2(k,o3,o4,o2) V2(o1,i,y,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o2,o1) W55(y,k,o4,o2,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W55caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x55_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X55_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W55caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x55_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X55_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W55caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 56, [2]
  // W56(w,i,o4,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o2,w,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o4,y,o1,k) W56(w,i,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W56caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x56_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X56_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W56caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x56_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X56_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W56caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 57, [2]
  // W57(y,i,o4,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o2,y,o3) 
  // S2(w,y,i,k) += (    1.00000000) T2(o4,w,o1,k) W57(y,i,o4,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W57caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x57_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X57_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W57caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x57_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X57_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W57caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 58, [2]
  // W58(w,i,o3,o4,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,w,o1,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o4,o3,o1) W58(w,i,o3,o4,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W58caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x58_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X58_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W58caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x58_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X58_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W58caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 59, [2]
  // W59(y,i,o2,o1,k,o4) += (    1.00000000) D2(i,o2,o1,o3) V2(k,y,o3,o4) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o1,o2,o4) W59(y,i,o2,o1,k,o4) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W59caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so4));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x59_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X59_TYPE1_ERI_O)
      (sk, ik, so4, io4, V2_sym.cptr(), W59caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x59_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X59_TYPE1_ERI_O)
      (sk, ik, so4, io4, T2b.cptr(), W59caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 60, [2]
  // W60(y,i,o3,o4,k,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(k,o1,y,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o4,o3,o1) W60(y,i,o3,o4,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W60caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x60_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X60_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W60caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x60_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X60_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W60caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 61, [2]
  // W61(w,i,o1,o3,k,o4) += (    1.00000000) D2(i,o2,o1,o3) V2(k,o4,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o1,o3,o4) W61(w,i,o1,o3,k,o4) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W61caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so4));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x61_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X61_TYPE1_ERI_O)
      (sk, ik, so4, io4, V2_sym.cptr(), W61caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x61_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X61_TYPE1_ERI_O)
      (sk, ik, so4, io4, T2b.cptr(), W61caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 62, [2]
  // W62(y,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,y,o1,o2) 
  // S2(w,y,i,k) += (    4.00000000) T2(w,o3,i,o1) W62(y,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W62ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x62_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X62_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W62ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x62_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X62_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W62ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 63, [2]
  // W63(w,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,w,o1,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o3,i,o1) W63(w,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W63ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x63_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X63_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W63ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x63_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X63_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W63ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 64, [2]
  // W64(y,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,o1,y,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o3,i,o1) W64(y,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W64ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x64_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X64_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W64ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x64_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X64_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W64ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 65, [2]
  // W65(w,o3,k,o1) += (    1.00000000) D1(o2,o3) V2(k,o1,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o3,i,o1) W65(w,o3,k,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W65ca_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x65_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X65_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W65ca_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x65_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X65_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W65ca_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 66, [2]
  // W66(y,o2,o3,k,o1,i) += (    1.00000000) D1(o2,o3) V2(k,o1,y,i) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o3,o2,o1) W66(y,o2,o3,k,o1,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W66caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x66_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X66_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W66caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x66_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X66_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W66caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 67, [2]
  // W67(w,o1,o2,k,o3,i) += (    1.00000000) D1(o1,o2) V2(k,o3,w,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o1,o2,o3) W67(w,o1,o2,k,o3,i) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W67caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so3));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x67_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X67_TYPE1_ERI_O)
      (sk, ik, so3, io3, V2_sym.cptr(), W67caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x67_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X67_TYPE1_ERI_O)
      (sk, ik, so3, io3, T2b.cptr(), W67caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 68, [2]
  // W68(w,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,o2,w,i) 
  // S2(w,y,i,k) += (    4.00000000) T2(o3,y,o1,k) W68(w,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W68caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x68_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X68_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W68caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x68_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X68_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W68caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 69, [2]
  // W69(y,o1,o3,i) += (    1.00000000) D1(o1,o2) V2(o3,o2,y,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o1,w,o3,k) W69(y,o1,o3,i) 
  double flops = 0; // Flop count
  int so3(s_eri);
  int io3(i_eri);
  orz::DTensor W69caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so3));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x69_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X69_TYPE1_ERI_O)
    (so3, io3, V2_sym.cptr(), W69caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x69_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X69_TYPE1_ERI_O)
      (sk, ik, so3, io3, T2b.cptr(), W69caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 70, [2]
  // W70(w,o3,o1,i) += (    1.00000000) D1(o2,o3) V2(o1,i,w,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o3,y,o1,k) W70(w,o3,o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W70caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x70_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X70_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W70caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x70_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X70_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W70caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 71, [2]
  // W71(y,o1,o3,i) += (    1.00000000) D1(o1,o2) V2(o3,i,y,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o1,w,o3,k) W71(y,o1,o3,i) 
  double flops = 0; // Flop count
  int so3(s_eri);
  int io3(i_eri);
  orz::DTensor W71caa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so3));
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x71_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X71_TYPE1_ERI_O)
    (so3, io3, V2_sym.cptr(), W71caa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x71_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X71_TYPE1_ERI_O)
      (sk, ik, so3, io3, T2b.cptr(), W71caa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 72, [2]
  // W72(w,o2,o3,k,i,o1) += (    1.00000000) D1(o2,o3) V2(k,w,i,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o3,o2,o1) W72(w,o2,o3,k,i,o1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W72caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so1));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x72_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X72_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W72caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x72_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X72_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W72caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 73, [2]
  // W73(y,o1,o2,k,i,o3) += (    1.00000000) D1(o1,o2) V2(k,y,i,o3) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o1,o2,o3) W73(y,o1,o2,k,i,o3) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W73caaa_sigma_ccoo_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^so3));
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x73_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO0_X73_TYPE1_ERI_O)
      (sk, ik, so3, io3, V2_sym.cptr(), W73caaa_sigma_ccoo_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x73_type1_eri_o,G_IF_SIGMA_CCOO_COOO_NO1_X73_TYPE1_ERI_O)
      (sk, ik, so3, io3, T2b.cptr(), W73caaa_sigma_ccoo_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@loadD4C(c,begin)
  //*-- FEMTO begins --//*
  // Label : d4c_c
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  orz::DTensor C5;
  orz::LoadBin(ctinp.dir()/(format("D4C_g[%d]")%i_eri).str()) >> C5;

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccoo_cooo
  { 
  // No. 0, [1]
  // S2(w,y,i,k) += (    1.00000000) C5(i,o4,o6,o2,k,y) T2(w,o6,o4,o2) 
  double flops = 0; // Flop count
  int sy(s_eri);
  int iy(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x0_type1_d4c_c,G_IF_SIGMA_CCOO_COOO_NO0_X0_TYPE1_D4C_C)
        (sk, ik, so2, io2, sy, iy, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,y,i,k) += (    1.00000000) C5(k,o4,o1,o5,i,w) T2(y,o1,o4,o5) 
  double flops = 0; // Flop count
  int sw(s_eri);
  int iw(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x1_type1_d4c_c,G_IF_SIGMA_CCOO_COOO_NO0_X1_TYPE1_D4C_C)
        (sk, ik, so5, io5, sw, iw, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadD4C(c,end)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccoo_cooo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
