

#ifndef C_SIGMA_OCOV_CCOV_H
#define C_SIGMA_OCOV_CCOV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//  8888888888                     888                  
//  888                            888                  
//  888                            888                  
//  8888888  .d88b.  88888b.d88b.  888888  .d88b.       
//  888     d8P  Y8b 888 "888 "88b 888    d88""88b  
//  888     88888888 888  888  888 888    888  888      
//  888     Y8b.     888  888  888 Y88b.  Y88..88P      
//  888      "Y8888  888  888  888  "Y888  "Y88P"   

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x0_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO0_X0_TYPE1_NOERI)
  (const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x0_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO1_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x1_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO0_X1_TYPE1_NOERI)
  (const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x1_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO1_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x2_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO0_X2_TYPE1_NOERI)
  (const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x2_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO1_X2_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x3_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO0_X3_TYPE1_NOERI)
  (const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x3_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO1_X3_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x4_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO0_X4_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x4_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO1_X4_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x5_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO0_X5_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x5_type1_noeri,G_IF_SIGMA_OCOV_CCOV_NO1_X5_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x0_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X0_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const V2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x1_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X1_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const V2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x2_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X2_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x2_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X2_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x3_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X3_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x3_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X3_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x4_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X4_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x4_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X4_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x5_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X5_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x5_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X5_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x6_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X6_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x6_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X6_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x7_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X7_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x7_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X7_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x8_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X8_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x8_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X8_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x9_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X9_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x9_type1_eri_c,G_IF_SIGMA_OCOV_CCOV_NO1_X9_TYPE1_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc1, const FC_INT &ic1, 
   const double * const T2, const double * const W9, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x0_type2_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X0_TYPE2_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x1_type2_eri_c,G_IF_SIGMA_OCOV_CCOV_NO0_X1_TYPE2_ERI_C)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x0_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X0_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x1_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X1_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x2_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X2_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x2_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X2_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x3_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X3_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x3_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X3_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x4_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X4_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x4_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X4_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x5_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X5_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x5_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X5_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x6_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X6_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x6_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X6_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x7_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X7_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x7_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X7_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x8_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X8_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x8_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X8_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x9_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X9_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x9_type1_eri_o,G_IF_SIGMA_OCOV_CCOV_NO1_X9_TYPE1_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W9, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x0_type2_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X0_TYPE2_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x1_type2_eri_o,G_IF_SIGMA_OCOV_CCOV_NO0_X1_TYPE2_ERI_O)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x0_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X0_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x0_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X0_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so2, const FC_INT &io2, 
   const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x1_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X1_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x1_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X1_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x2_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X2_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x2_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X2_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x3_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X3_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x3_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X3_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x4_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X4_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x4_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X4_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x5_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X5_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x5_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X5_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x6_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X6_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x6_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X6_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x7_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X7_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x7_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X7_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x8_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X8_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x8_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X8_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x9_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X9_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const W9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x9_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X9_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W9, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x10_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X10_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x10_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X10_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W10, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no0_x11_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO0_X11_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const W11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ocov_ccov_no1_x11_type1_eri_v,G_IF_SIGMA_OCOV_CCOV_NO1_X11_TYPE1_ERI_V)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const W11, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 