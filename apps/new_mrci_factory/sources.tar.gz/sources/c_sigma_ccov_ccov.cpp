                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccov_ccov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  `7MM"""YMM                         mm               
//    MM    `7                         MM                  
//    MM   d  .gP"Ya `7MMpMMMb.pMMMb.mmMMmm ,pW"Wq.      
//    MM""MM ,M'   Yb  MM    MM    MM  MM  6W'   `Wb   
//    MM   Y 8M""""""  MM    MM    MM  MM  8M     M8 
//    MM     YM.    ,  MM    MM    MM  MM  YA.   ,A9       
//  .JMML.    `Mbmmd'.JMML  JMML  JMML.`Mbmo`Ybmd9'        

//                                   Generated date : Wed Feb 19 15:56:04 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccov_ccov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,y,i,a) += (    1.00000000) Fc0 D1(i,o1) T2(y,w,o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x0_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X0_TYPE1_NOERI)
      (sa, ia, &Fc0, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [1]
  // S2(w,y,i,a) += (   -2.00000000) Fc0 D1(i,o1) T2(w,y,o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x1_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X1_TYPE1_NOERI)
      (sa, ia, &Fc0, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W0(y,c1,i,a) += (    1.00000000) D1(i,o1) T2(y,c1,o1,a) 
  // S2(w,y,i,a) += (   -1.00000000) Fc1(c1,w) W0(y,c1,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W0cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x2_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X2_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W0cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x2_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X2_TYPE1_NOERI)
      (sa, ia, W0cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [2]
  // W1(c1,y,i,a) += (    1.00000000) D1(i,o1) T2(c1,y,o1,a) 
  // S2(w,y,i,a) += (    2.00000000) Fc1(c1,w) W1(c1,y,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W1cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x3_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X3_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W1cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x3_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X3_TYPE1_NOERI)
      (sa, ia, W1cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [2]
  // W2(w,c1,i,a) += (    1.00000000) D1(i,o1) T2(w,c1,o1,a) 
  // S2(w,y,i,a) += (    2.00000000) Fc1(c1,y) W2(w,c1,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W2cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x4_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X4_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W2cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x4_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X4_TYPE1_NOERI)
      (sa, ia, W2cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W3(c1,w,i,a) += (    1.00000000) D1(i,o1) T2(c1,w,o1,a) 
  // S2(w,y,i,a) += (   -1.00000000) Fc1(c1,y) W3(c1,w,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W3cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x5_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X5_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W3cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x5_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X5_TYPE1_NOERI)
      (sa, ia, W3cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [1]
  // S2(w,y,i,a) += (    4.00000000) Fc0 T2(w,y,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x6_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X6_TYPE1_NOERI)
      (sa, ia, &Fc0, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [1]
  // S2(w,y,i,a) += (   -2.00000000) Fc0 T2(y,w,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x7_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X7_TYPE1_NOERI)
      (sa, ia, &Fc0, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 8, [1]
  // S2(w,y,i,a) += (   -4.00000000) Fc1(c1,w) T2(c1,y,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x8_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X8_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 9, [1]
  // S2(w,y,i,a) += (    2.00000000) Fc1(c1,w) T2(y,c1,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x9_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X9_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 10, [1]
  // S2(w,y,i,a) += (    2.00000000) Fc1(c1,y) T2(c1,w,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x10_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X10_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 11, [1]
  // S2(w,y,i,a) += (   -4.00000000) Fc1(c1,y) T2(w,c1,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x11_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X11_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 12, [2]
  // W4(i,o1) += (    1.00000000) D2(i,o1,o2,o3) Fc1(o2,o3) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,w,o1,a) W4(i,o1) 
  double flops = 0; // Flop count
  orz::DTensor W4aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x12_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X12_TYPE1_NOERI)
    (W4aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x12_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X12_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W4aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 13, [2]
  // W5(i,o1) += (    1.00000000) D2(i,o1,o2,o3) Fc1(o2,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o1,a) W5(i,o1) 
  double flops = 0; // Flop count
  orz::DTensor W5aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x13_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X13_TYPE1_NOERI)
    (W5aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x13_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X13_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W5aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 14, [2]
  // W6() += (    1.00000000) D1(o1,o2) Fc1(o1,o2) 
  // S2(w,y,i,a) += (    4.00000000) W6 T2(w,y,i,a) 
  double flops = 0; // Flop count
  double W6_sigma_ccov_ccov = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x14_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X14_TYPE1_NOERI)
    (&W6_sigma_ccov_ccov, nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x14_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X14_TYPE1_NOERI)
      (sa, ia, &W6_sigma_ccov_ccov, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 15, [2]
  // W7() += (    1.00000000) D1(o1,o2) Fc1(o1,o2) 
  // S2(w,y,i,a) += (   -2.00000000) W7 T2(y,w,i,a) 
  double flops = 0; // Flop count
  double W7_sigma_ccov_ccov = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x15_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X15_TYPE1_NOERI)
    (&W7_sigma_ccov_ccov, nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x15_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X15_TYPE1_NOERI)
      (sa, ia, &W7_sigma_ccov_ccov, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 16, [2]
  // W8(o2,i) += (    1.00000000) D1(o1,o2) Fc1(i,o1) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,w,o2,a) W8(o2,i) 
  double flops = 0; // Flop count
  orz::DTensor W8aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x16_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X16_TYPE1_NOERI)
    (W8aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x16_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X16_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W8aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 17, [2]
  // W9(o2,i) += (    1.00000000) D1(o1,o2) Fc1(i,o1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o2,a) W9(o2,i) 
  double flops = 0; // Flop count
  orz::DTensor W9aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x17_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X17_TYPE1_NOERI)
    (W9aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x17_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X17_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W9aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 18, [2]
  // W10(i,o2) += (    1.00000000) D1(i,o1) Fc1(o1,o2) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,w,o2,a) W10(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W10aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x18_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X18_TYPE1_NOERI)
    (W10aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x18_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X18_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W10aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 19, [2]
  // W11(i,o2) += (    1.00000000) D1(i,o1) Fc1(o1,o2) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o2,a) W11(i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W11aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x19_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X19_TYPE1_NOERI)
    (W11aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x19_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X19_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W11aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 20, [1]
  // S2(w,y,i,a) += (    4.00000000) Fc1(i,o1) T2(w,y,o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x20_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X20_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 21, [1]
  // S2(w,y,i,a) += (   -2.00000000) Fc1(i,o1) T2(y,w,o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x21_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X21_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 22, [2]
  // W12(w,y,i,v1) += (    1.00000000) D1(i,o1) T2(w,y,v1,o1) 
  // S2(w,y,i,a) += (    1.00000000) Fc1(a,v1) W12(w,y,i,v1) 
  double flops = 0; // Flop count
  orz::DTensor W12ccav_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xccav(symblockinfo, 0));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x22_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X22_TYPE1_NOERI)
      (so1, io1, T2b.cptr(), W12ccav_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x22_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X22_TYPE1_NOERI)
      (sa, ia, W12ccav_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 23, [2]
  // W13(w,y,i,v1) += (    1.00000000) D1(i,o1) T2(w,y,o1,v1) 
  // S2(w,y,i,a) += (   -2.00000000) Fc1(a,v1) W13(w,y,i,v1) 
  double flops = 0; // Flop count
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    if(hintmo.iproc_havingimo()[iv1] == myrank) {           
    T2b = T2.get_amp2(iv1);
    orz::DTensor W13cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sv1));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x23_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X23_TYPE1_NOERI)
      (sv1, iv1, T2b.cptr(), W13cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x23_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO1_X23_TYPE1_NOERI)
        (sa, ia, sv1, iv1, W13cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 24, [1]
  // S2(w,y,i,a) += (    4.00000000) Fc1(a,v1) T2(w,y,i,v1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x24_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X24_TYPE1_NOERI)
        (sa, ia, sv1, iv1, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 25, [1]
  // S2(w,y,i,a) += (   -2.00000000) Fc1(a,v1) T2(w,y,v1,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x25_type1_noeri,G_IF_SIGMA_CCOV_CCOV_NO0_X25_TYPE1_NOERI)
        (sa, ia, si, ii, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_ccov_ccov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0ccav_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xccav(symblockinfo, 0));
  orz::DTensor W1ccav_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xccav(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ccov
  { 
  // No. 0, [1]
  // W0(w,y,o1,a) += (    1.00000000) T2(c2,c1,o1,a) V2(c1,w,c2,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x0_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X0_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), W0ccav_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // W1(y,w,o1,a) += (    1.00000000) T2(c2,c1,o1,a) V2(c1,y,c2,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x1_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X1_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), W1ccav_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,y,i,a) += (    4.00000000) T2(c2,c1,i,a) V2(c1,y,c2,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x2_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X2_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,y,i,a) += (   -2.00000000) T2(c2,c1,i,a) V2(c1,w,c2,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x3_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X3_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [2]
  // W2(c1,w,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  // S2(w,y,i,a) += (   -1.00000000) T2(y,c1,o2,a) W2(c1,w,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W2caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x4_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X4_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W2caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x4_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X4_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W2caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W3(c1,w,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) T2(c1,y,o2,a) W3(c1,w,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W3caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x5_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X5_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W3caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x5_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X5_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W3caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [2]
  // W4(c1,y,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,y,o1,o3) 
  // S2(w,y,i,a) += (   -1.00000000) T2(c1,w,o2,a) W4(c1,y,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W4caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x6_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X6_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W4caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x6_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X6_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W4caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [2]
  // W5(c1,y,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,y,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,c1,o2,a) W5(c1,y,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W5caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x7_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X7_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W5caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x7_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X7_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W5caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W6(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,y,o1,o2) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,c1,i,a) W6(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W6c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x8_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X8_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W6c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x8_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X8_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W6c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W7(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,y,o1,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(c1,w,i,a) W7(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W7c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x9_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X9_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W7c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x9_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X9_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W7c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W8(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,w,o1,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(y,c1,i,a) W8(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W8c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x10_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X10_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W8c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x10_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X10_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W8c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [2]
  // W9(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,w,o1,o2) 
  // S2(w,y,i,a) += (   -4.00000000) T2(c1,y,i,a) W9(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W9c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x11_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X11_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W9c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x11_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X11_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W9c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [2]
  // W10(c1,w,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,w,i,o1) 
  // S2(w,y,i,a) += (   -1.00000000) T2(y,c1,o2,a) W10(c1,w,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W10caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x12_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X12_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W10caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x12_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X12_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W10caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W11(c1,w,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,w,i,o1) 
  // S2(w,y,i,a) += (    2.00000000) T2(c1,y,o2,a) W11(c1,w,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W11caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x13_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X13_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W11caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x13_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X13_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W11caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [2]
  // W12(c1,y,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,y,i,o1) 
  // S2(w,y,i,a) += (   -1.00000000) T2(c1,w,o2,a) W12(c1,y,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W12caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x14_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X14_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W12caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x14_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X14_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W12caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [2]
  // W13(c1,y,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,y,i,o1) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,c1,o2,a) W13(c1,y,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W13caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x15_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X15_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W13caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x15_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X15_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W13caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [2]
  // W14(c1,w,i,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o3,w,o2) 
  // S2(w,y,i,a) += (   -1.00000000) T2(y,c1,o1,a) W14(c1,w,i,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W14caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x16_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X16_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W14caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x16_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X16_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W14caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 17, [2]
  // W15(c1,w,i,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o3,w,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(c1,y,o1,a) W15(c1,w,i,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W15caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x17_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X17_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W15caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x17_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X17_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W15caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 18, [2]
  // W16(c1,y,i,o2) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o3,y,o1) 
  // S2(w,y,i,a) += (   -1.00000000) T2(w,c1,o2,a) W16(c1,y,i,o2) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W16caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x18_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X18_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W16caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x18_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X18_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W16caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 19, [2]
  // W17(c1,y,i,o1) += (    1.00000000) D2(i,o2,o3,o1) V2(c1,o3,y,o2) 
  // S2(w,y,i,a) += (   -1.00000000) T2(c1,w,o1,a) W17(c1,y,i,o1) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W17caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x19_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X19_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W17caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x19_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X19_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W17caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 20, [2]
  // W18(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,o1,y,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,c1,i,a) W18(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W18c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x20_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X20_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W18c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x20_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X20_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W18c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 21, [2]
  // W19(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,o1,y,o2) 
  // S2(w,y,i,a) += (   -1.00000000) T2(c1,w,i,a) W19(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W19c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x21_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X21_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W19c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x21_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X21_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W19c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 22, [2]
  // W20(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,o1,w,o2) 
  // S2(w,y,i,a) += (   -1.00000000) T2(y,c1,i,a) W20(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W20c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x22_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X22_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W20c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x22_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X22_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W20c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 23, [2]
  // W21(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,o1,w,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(c1,y,i,a) W21(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W21c_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x23_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X23_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W21c_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x23_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X23_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W21c_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 24, [2]
  // W22(c1,w,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,o1,w,i) 
  // S2(w,y,i,a) += (    2.00000000) T2(y,c1,o2,a) W22(c1,w,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W22caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x24_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X24_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W22caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x24_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X24_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W22caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 25, [2]
  // W23(c1,w,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,o1,w,i) 
  // S2(w,y,i,a) += (   -4.00000000) T2(c1,y,o2,a) W23(c1,w,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W23caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x25_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X25_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W23caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x25_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X25_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W23caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 26, [2]
  // W24(c1,y,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,o1,y,i) 
  // S2(w,y,i,a) += (   -1.00000000) T2(w,c1,o2,a) W24(c1,y,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W24caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x26_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X26_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W24caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x26_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X26_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W24caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 27, [2]
  // W25(c1,y,o2,i) += (    1.00000000) D1(o1,o2) V2(c1,o1,y,i) 
  // S2(w,y,i,a) += (    2.00000000) T2(c1,w,o2,a) W25(c1,y,o2,i) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W25caa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x27_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X27_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W25caa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x27_type1_eri_c,G_IF_SIGMA_CCOV_CCOV_NO1_X27_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W25caa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_ccov_ccov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,y,i,a) += (    1.00000000) D1(i,o1) W0(w,y,o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x0_type2_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X0_TYPE2_ERI_C)
      (sa, ia, W0ccav_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,y,i,a) += (   -2.00000000) D1(i,o1) W1(y,w,o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x1_type2_eri_c,G_IF_SIGMA_CCOV_CCOV_NO0_X1_TYPE2_ERI_C)
      (sa, ia, W1ccav_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_ccov_ccov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W8aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  orz::DTensor W9aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, 0));
  double W10_sigma_ccov_ccov = 0;
  double W11_sigma_ccov_ccov = 0;
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ccov
  { 
  // No. 0, [2]
  // W0(c1,w,i,o1) += (    1.00000000) D1(i,o2) V2(o1,o2,c1,w) 
  // S2(w,y,i,a) += (   -1.00000000) T2(y,c1,o1,a) W0(c1,w,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W0cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x0_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X0_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W0cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x0_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X0_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W0cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,w,i,o1) += (    1.00000000) D1(i,o2) V2(o1,o2,c1,w) 
  // S2(w,y,i,a) += (    2.00000000) T2(y,c1,a,o1) W1(c1,w,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W1cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x1_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X1_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W1cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x1_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X1_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W1cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W2(c1,y,i,o1) += (    1.00000000) D1(i,o2) V2(o1,o2,c1,y) 
  // S2(w,y,i,a) += (   -1.00000000) T2(w,c1,a,o1) W2(c1,y,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W2cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x2_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X2_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W2cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x2_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X2_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W2cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(c1,y,i,o1) += (    1.00000000) D1(i,o2) V2(o1,o2,c1,y) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,c1,o1,a) W3(c1,y,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W3cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x3_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X3_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W3cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x3_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X3_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W3cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(w,c1,o1,a) V2(o1,i,c1,y) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x4_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X4_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,y,i,a) += (    2.00000000) T2(w,c1,a,o1) V2(o1,i,c1,y) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x5_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X5_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,y,i,a) += (    2.00000000) T2(y,c1,o1,a) V2(o1,i,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x6_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X6_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(y,c1,a,o1) V2(o1,i,c1,w) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x7_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X7_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W4(c1,w,i,o1) += (    1.00000000) D1(i,o2) V2(o1,c1,w,o2) 
  // S2(w,y,i,a) += (   -4.00000000) T2(y,c1,a,o1) W4(c1,w,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W4cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x8_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X8_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W4cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x8_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X8_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W4cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W5(c1,y,i,o1) += (    1.00000000) D1(i,o2) V2(o1,c1,y,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,c1,a,o1) W5(c1,y,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W5cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x9_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X9_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W5cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x9_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X9_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W5cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W6(c1,w,i,o1) += (    1.00000000) D1(i,o2) V2(o1,c1,w,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(y,c1,o1,a) W6(c1,w,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W6cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x10_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X10_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W6cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x10_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X10_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W6cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [2]
  // W7(c1,y,i,o1) += (    1.00000000) D1(i,o2) V2(o1,c1,y,o2) 
  // S2(w,y,i,a) += (   -1.00000000) T2(w,c1,o1,a) W7(c1,y,i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W7cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x11_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X11_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W7cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x11_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X11_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W7cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,y,i,a) += (    8.00000000) T2(y,c1,a,o1) V2(o1,c1,w,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x12_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X12_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(w,c1,a,o1) V2(o1,c1,y,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x13_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X13_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(y,c1,o1,a) V2(o1,c1,w,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x14_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X14_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [1]
  // S2(w,y,i,a) += (    2.00000000) T2(w,c1,o1,a) V2(o1,c1,y,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x15_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X15_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [1]
  // W8(i,o3) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(o1,o4,o2,o5) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x16_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X16_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W8aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 17, [1]
  // W9(i,o3) += (    1.00000000) D3(i,o3,o1,o4,o2,o5) V2(o1,o4,o2,o5) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x17_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X17_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W9aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 18, [1]
  // W10() += (    1.00000000) D2(o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x18_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X18_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), &W10_sigma_ccov_ccov, nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 19, [1]
  // W11() += (    1.00000000) D2(o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x19_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X19_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), &W11_sigma_ccov_ccov, nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 20, [2]
  // W12(o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(i,o2,o1,o3) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,w,o4,a) W12(o4,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  orz::DTensor W12a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, si));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x20_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X20_TYPE1_ERI_O)
    (si, ii, V2_sym.cptr(), W12a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x20_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X20_TYPE1_ERI_O)
      (sa, ia, si, ii, T2b.cptr(), W12a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 21, [2]
  // W13(o4,i) += (    1.00000000) D2(o1,o3,o2,o4) V2(i,o2,o1,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o4,a) W13(o4,i) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  orz::DTensor W13a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, si));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x21_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X21_TYPE1_ERI_O)
    (si, ii, V2_sym.cptr(), W13a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x21_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X21_TYPE1_ERI_O)
      (sa, ia, si, ii, T2b.cptr(), W13a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 22, [2]
  // W14(i,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,w,o1,a) W14(i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W14a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x22_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X22_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W14a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x22_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X22_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W14a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 23, [2]
  // W15(i,o1) += (    1.00000000) D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  // S2(w,y,i,a) += (   -2.00000000) T2(y,w,a,o1) W15(i,o1) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W15a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x23_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X23_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W15a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x23_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X23_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W15a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 24, [2]
  // W16(o1,i) += (    1.00000000) D1(o2,o3) V2(o1,i,o2,o3) 
  // S2(w,y,i,a) += (    4.00000000) T2(y,w,a,o1) W16(o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W16a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x24_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X24_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W16a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x24_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X24_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W16a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 25, [2]
  // W17(o1,i) += (    1.00000000) D1(o2,o3) V2(o1,i,o2,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(y,w,o1,a) W17(o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W17a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x25_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X25_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W17a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x25_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X25_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W17a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 26, [2]
  // W18(o1,i) += (    1.00000000) D1(o2,o3) V2(o1,o3,i,o2) 
  // S2(w,y,i,a) += (    1.00000000) T2(y,w,o1,a) W18(o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W18a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x26_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X26_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W18a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x26_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X26_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W18a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 27, [2]
  // W19(o1,i) += (    1.00000000) D1(o2,o3) V2(o1,o3,i,o2) 
  // S2(w,y,i,a) += (   -2.00000000) T2(y,w,a,o1) W19(o1,i) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  orz::DTensor W19a_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xa(symblockinfo, so1));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x27_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X27_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), W19a_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(io1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x27_type1_eri_o,G_IF_SIGMA_CCOV_CCOV_NO1_X27_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), W19a_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_ccov_ccov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,y,i,a) += (    0.50000000) T2(y,w,o3,a) W8(i,o3) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x0_type2_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X0_TYPE2_ERI_O)
      (sa, ia, T2b.cptr(), W8aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,y,i,a) += (   -1.00000000) T2(w,y,o3,a) W9(i,o3) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x1_type2_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X1_TYPE2_ERI_O)
      (sa, ia, T2b.cptr(), W9aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(w,y,i,a) += (    2.00000000) W10 T2(w,y,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x2_type2_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X2_TYPE2_ERI_O)
      (sa, ia, &W10_sigma_ccov_ccov, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(w,y,i,a) += (   -1.00000000) W11 T2(y,w,i,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x3_type2_eri_o,G_IF_SIGMA_CCOV_CCOV_NO0_X3_TYPE2_ERI_O)
      (sa, ia, &W11_sigma_ccov_ccov, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ccov
  { 
  // No. 0, [2]
  // W0(y,w,o1,a) += (    1.00000000) T2(c1,y,v1,o1) V2(a,v1,c1,w) 
  // S2(w,y,i,a) += (   -1.00000000) D1(i,o1) W0(y,w,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W0cc_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x0_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X0_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W0cc_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x0_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X0_TYPE1_ERI_V)
      (sa, ia, so1, io1, W0cc_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(y,w,o1,a) += (    1.00000000) T2(c1,y,o1,v1) V2(a,v1,c1,w) 
  // S2(w,y,i,a) += (    2.00000000) D1(i,o1) W1(y,w,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W1cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x1_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X1_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccov_no1_x1_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X1_TYPE1_ERI_V)
    (sa, ia, W1cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,y,o1,a) += (    1.00000000) T2(c1,w,o1,v1) V2(a,v1,c1,y) 
  // S2(w,y,i,a) += (   -1.00000000) D1(i,o1) W2(w,y,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W2cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x2_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X2_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W2cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccov_no1_x2_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X2_TYPE1_ERI_V)
    (sa, ia, W2cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,y,o1,a) += (    1.00000000) T2(c1,w,v1,o1) V2(a,v1,c1,y) 
  // S2(w,y,i,a) += (    2.00000000) D1(i,o1) W3(w,y,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W3cc_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x3_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X3_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W3cc_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x3_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X3_TYPE1_ERI_V)
      (sa, ia, so1, io1, W3cc_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(c1,w,v1,i) V2(a,v1,c1,y) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x4_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X4_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,y,i,a) += (    2.00000000) T2(c1,w,i,v1) V2(a,v1,c1,y) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x5_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X5_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,y,i,a) += (    2.00000000) T2(c1,y,v1,i) V2(a,v1,c1,w) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x6_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X6_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(c1,y,i,v1) V2(a,v1,c1,w) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x7_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X7_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W4(y,w,o1,a) += (    1.00000000) T2(c1,y,o1,v1) V2(a,w,c1,v1) 
  // S2(w,y,i,a) += (   -1.00000000) D1(i,o1) W4(y,w,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W4cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x8_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X8_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W4cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccov_no1_x8_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X8_TYPE1_ERI_V)
    (sa, ia, W4cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W5(w,y,o1,a) += (    1.00000000) T2(c1,w,o1,v1) V2(a,y,c1,v1) 
  // S2(w,y,i,a) += (    2.00000000) D1(i,o1) W5(w,y,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W5cca_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x9_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X9_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), W5cca_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccov_no1_x9_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X9_TYPE1_ERI_V)
    (sa, ia, W5cca_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W6(y,w,o1,a) += (    1.00000000) T2(c1,y,v1,o1) V2(a,w,c1,v1) 
  // S2(w,y,i,a) += (    2.00000000) D1(i,o1) W6(y,w,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W6cc_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x10_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X10_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W6cc_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x10_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X10_TYPE1_ERI_V)
      (sa, ia, so1, io1, W6cc_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W7(w,y,o1,a) += (    1.00000000) T2(c1,w,v1,o1) V2(a,y,c1,v1) 
  // S2(w,y,i,a) += (   -4.00000000) D1(i,o1) W7(w,y,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W7cc_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xcc(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x11_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X11_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W7cc_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x11_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X11_TYPE1_ERI_V)
      (sa, ia, so1, io1, W7cc_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,y,i,a) += (    8.00000000) T2(c1,w,v1,i) V2(a,y,c1,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x12_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X12_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(c1,w,i,v1) V2(a,y,c1,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x13_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X13_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 14, [1]
  // S2(w,y,i,a) += (    2.00000000) T2(c1,y,i,v1) V2(a,w,c1,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x14_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X14_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 15, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(c1,y,v1,i) V2(a,w,c1,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x15_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X15_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 16, [2]
  // W8(i,o2,a,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(a,v1,o1,o3) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,v1,o2) W8(i,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W8av_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x16_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X16_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W8av_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x16_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X16_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W8av_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 17, [2]
  // W9(i,o2,a,v1) += (    1.00000000) D2(i,o2,o1,o3) V2(a,v1,o1,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o2,v1) W9(i,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W9aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sa^sv1));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x17_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X17_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), W9aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x17_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X17_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W9aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 18, [2]
  // W10(a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,o1,o2) 
  // S2(w,y,i,a) += (    4.00000000) T2(w,y,i,v1) W10(a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    double W10_sigma_ccov_ccov = 0;
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x18_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X18_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), &W10_sigma_ccov_ccov, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x18_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X18_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), &W10_sigma_ccov_ccov, S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 19, [2]
  // W11(a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,o1,o2) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,v1,i) W11(a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W11v_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xv(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x19_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X19_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W11v_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x19_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X19_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W11v_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 20, [2]
  // W12(o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,i,o1) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,v1,o2) W12(o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W12av_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x20_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X20_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W12av_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x20_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X20_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W12av_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 21, [2]
  // W13(o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,v1,i,o1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o2,v1) W13(o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W13aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sa^sv1));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x21_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X21_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), W13aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x21_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X21_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W13aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 22, [2]
  // W14(i,o1,a,v1) += (    1.00000000) D1(i,o2) V2(a,v1,o1,o2) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,v1,o1) W14(i,o1,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W14av_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x22_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X22_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W14av_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x22_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X22_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W14av_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 23, [2]
  // W15(i,o2,a,v1) += (    1.00000000) D1(i,o1) V2(a,v1,o1,o2) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o2,v1) W15(i,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W15aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sa^sv1));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x23_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X23_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), W15aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x23_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X23_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W15aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 24, [1]
  // S2(w,y,i,a) += (    4.00000000) T2(w,y,o1,v1) V2(a,v1,i,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x24_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X24_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 25, [1]
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,v1,o1) V2(a,v1,i,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x25_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X25_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 26, [2]
  // W16(i,o2,a,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(a,o3,o1,v1) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,o2,v1) W16(i,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W16aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sa^sv1));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x26_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X26_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), W16aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x26_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X26_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W16aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 27, [2]
  // W17(i,o3,a,v1) += (    1.00000000) D2(i,o2,o1,o3) V2(a,o1,o2,v1) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,v1,o3) W17(i,o3,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W17av_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x27_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X27_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W17av_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x27_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X27_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W17av_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 28, [2]
  // W18(a,v1) += (    1.00000000) D1(o1,o2) V2(a,o1,o2,v1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,i,v1) W18(a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    double W18_sigma_ccov_ccov = 0;
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x28_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X28_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), &W18_sigma_ccov_ccov, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x28_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X28_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), &W18_sigma_ccov_ccov, S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 29, [2]
  // W19(a,v1) += (    1.00000000) D1(o1,o2) V2(a,o1,o2,v1) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,v1,i) W19(a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W19v_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xv(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x29_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X29_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W19v_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x29_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X29_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W19v_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 30, [2]
  // W20(o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,o1,i,v1) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,o2,v1) W20(o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W20aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sa^sv1));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x30_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X30_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), W20aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x30_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X30_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W20aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 31, [2]
  // W21(o2,i,a,v1) += (    1.00000000) D1(o1,o2) V2(a,o1,i,v1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,v1,o2) W21(o2,i,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W21av_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x31_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X31_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W21av_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x31_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X31_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W21av_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 32, [2]
  // W22(i,o1,a,v1) += (    1.00000000) D1(i,o2) V2(a,o1,o2,v1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,v1,o1) W22(i,o1,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W22av_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xav(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x32_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X32_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W22av_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x32_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X32_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W22av_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 33, [2]
  // W23(i,o2,a,v1) += (    1.00000000) D1(i,o1) V2(a,o2,o1,v1) 
  // S2(w,y,i,a) += (    1.00000000) T2(w,y,o2,v1) W23(i,o2,a,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    orz::DTensor W23aa_sigma_ccov_ccov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sa^sv1));
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x33_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X33_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, V2_sym.cptr(), W23aa_sigma_ccov_ccov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x33_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO1_X33_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W23aa_sigma_ccov_ccov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 34, [1]
  // S2(w,y,i,a) += (    4.00000000) T2(w,y,v1,o1) V2(a,o1,i,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x34_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X34_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 35, [1]
  // S2(w,y,i,a) += (   -2.00000000) T2(w,y,o1,v1) V2(a,o1,i,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x35_type1_eri_v,G_IF_SIGMA_CCOV_CCOV_NO0_X35_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccov_ccov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
