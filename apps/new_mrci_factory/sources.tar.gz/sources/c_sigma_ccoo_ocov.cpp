                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccoo_ocov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//    o__ __o__/_                            o                         
//   <|    v                                <|>                        
//   < >                                    < >                        
//    |         o__  __o   \o__ __o__ __o    |        o__ __o         
//    o__/_    /v      |>   |     |     |>   o__/_   /v     v\        
//    |       />      //   / \   / \   / \   |      />       <\    
//   <o>      \o    o/     \o/   \o/   \o/   |      \         /   
//    |        v\  /v __o   |     |     |    o       o       o        
//   / \        <\/> __/>  / \   / \   / \   <\__    <\__ __/>  

//                                   Generated date : Wed Feb 19 15:56:01 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccoo_ocov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
//-@ERI.contractions(begin)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccoo_ocov
  { 
  // No. 0, [2]
  // W0(w,i,o3,o1,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(k,w,o2,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o3,v1,o1) W0(w,i,o3,o1,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W0caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x0_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X0_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W0caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x0_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X0_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W0caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(y,i,o1,o3,k,v1) += (    1.00000000) D2(i,o2,o1,o3) V2(k,y,o2,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o1,v1,o3) W1(y,i,o1,o3,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W1caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so3^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x1_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X1_TYPE1_ERI_O)
      (sk, ik, so3, io3, V2_sym.cptr(), W1caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x1_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X1_TYPE1_ERI_O)
      (sk, ik, so3, io3, T2b.cptr(), W1caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,i,o3,o1,k,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(k,v1,w,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o3,v1,o1) W2(w,i,o3,o1,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W2caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x2_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X2_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W2caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x2_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X2_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W2caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(y,i,o1,o3,k,v1) += (    1.00000000) D2(i,o2,o1,o3) V2(k,v1,y,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o1,v1,o3) W3(y,i,o1,o3,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W3caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so3^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x3_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X3_TYPE1_ERI_O)
      (sk, ik, so3, io3, V2_sym.cptr(), W3caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x3_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X3_TYPE1_ERI_O)
      (sk, ik, so3, io3, T2b.cptr(), W3caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,o2,k,v1) += (    1.00000000) D1(o1,o2) V2(k,w,o1,v1) 
  // S2(w,y,i,k) += (    1.00000000) T2(y,o2,v1,i) W4(w,o2,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W4cav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x4_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X4_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W4cav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x4_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X4_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W4cav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(y,o2,k,v1) += (    1.00000000) D1(o1,o2) V2(k,y,o1,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o2,v1,i) W5(y,o2,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W5cav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x5_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X5_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W5cav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x5_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X5_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W5cav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(w,o2,k,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,w,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o2,v1,i) W6(w,o2,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W6cav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x6_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X6_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W6cav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x6_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X6_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W6cav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(y,o2,k,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,y,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(w,o2,v1,i) W7(y,o2,k,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  orz::DTensor W7cav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcav(symblockinfo, sk));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x7_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X7_TYPE1_ERI_O)
    (sk, ik, V2_sym.cptr(), W7cav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x7_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X7_TYPE1_ERI_O)
      (si, ii, sk, ik, T2b.cptr(), W7cav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W8(w,o1,o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,w,i) 
  // S2(w,y,i,k) += (    4.00000000) T2(y,o2,v1,o1) W8(w,o1,o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W8caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x8_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X8_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W8caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x8_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X8_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W8caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(y,o1,o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,v1,y,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(w,o1,v1,o2) W9(y,o1,o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W9caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x9_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X9_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W9caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x9_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X9_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W9caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W10(y,o1,o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,y,i,v1) 
  // S2(w,y,i,k) += (    4.00000000) T2(w,o2,v1,o1) W10(y,o1,o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W10caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so1^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x10_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X10_TYPE1_ERI_O)
      (sk, ik, so1, io1, V2_sym.cptr(), W10caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x10_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X10_TYPE1_ERI_O)
      (sk, ik, so1, io1, T2b.cptr(), W10caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o1,o2,k,i,v1) += (    1.00000000) D1(o1,o2) V2(k,w,i,v1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(y,o1,v1,o2) W11(w,o1,o2,k,i,v1) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ik]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W11caav_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaav(symblockinfo, so2^sk));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x11_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO0_X11_TYPE1_ERI_O)
      (sk, ik, so2, io2, V2_sym.cptr(), W11caav_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x11_type1_eri_o,G_IF_SIGMA_CCOO_OCOV_NO1_X11_TYPE1_ERI_O)
      (sk, ik, so2, io2, T2b.cptr(), W11caav_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ik, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_ccoo_ocov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0ccaaaa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xccaaaa(symblockinfo, 0));
  orz::DTensor W1ccaaaa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xccaaaa(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccoo_ocov
  { 
  // No. 0, [1]
  // W0(w,y,o4,o1,o3,o2) += (    1.00000000) T2(o4,w,o1,v1) V2(v1,o3,y,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x0_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X0_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W0ccaaaa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 1, [1]
  // W1(y,w,o1,o4,o3,o2) += (    1.00000000) T2(o1,y,o4,v1) V2(v1,o3,w,o2) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x1_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X1_TYPE1_ERI_V)
    (sv1, iv1, T2b.cptr(), V2_sym.cptr(), W1ccaaaa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 2, [2]
  // W2(w,k,o3,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o2,w,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,y,i,v1) W2(w,k,o3,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W2ca_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x2_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X2_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W2ca_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x2_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X2_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W2ca_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W3(y,k,o3,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o1,y,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,w,i,v1) W3(y,k,o3,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W3ca_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x3_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X3_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W3ca_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x3_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X3_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W3ca_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [2]
  // W4(y,k,o3,o1,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o2,y,i) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,w,o1,v1) W4(y,k,o3,o1,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W4caaa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x4_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X4_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W4caaa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x4_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X4_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W4caaa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W5(w,k,o3,o1,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,o2,w,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o3,y,o1,v1) W5(w,k,o3,o1,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W5caaa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x5_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X5_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W5caaa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x5_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X5_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W5caaa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [2]
  // W6(y,k,o3,o1,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,i,y,o2) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o3,w,o1,v1) W6(y,k,o3,o1,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W6caaa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x6_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X6_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W6caaa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x6_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X6_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W6caaa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [2]
  // W7(w,k,o3,o1,i,v1) += (    1.00000000) D2(k,o2,o3,o1) V2(v1,i,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,y,o1,v1) W7(w,k,o3,o1,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor W7caaa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sk^sv1));
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x7_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X7_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, V2_sym.cptr(), W7caaa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x7_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X7_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W7caaa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W8(y,i,o3,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,o2,y,o1) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,w,k,v1) W8(y,i,o3,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W8caa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x8_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X8_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W8caa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x8_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X8_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W8caa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W9(w,i,o3,v1) += (    1.00000000) D2(i,o2,o3,o1) V2(v1,o1,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o3,y,k,v1) W9(w,i,o3,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W9caa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x9_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X9_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W9caa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x9_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X9_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W9caa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [2]
  // W10(y,o2,i,v1) += (    1.00000000) D1(o1,o2) V2(v1,o1,y,i) 
  // S2(w,y,i,k) += (    1.00000000) T2(o2,w,k,v1) W10(y,o2,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W10caa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x10_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X10_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W10caa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x10_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X10_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W10caa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o1,i,v1) += (    1.00000000) D1(o1,o2) V2(v1,o2,w,i) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o1,y,k,v1) W11(w,o1,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W11caa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x11_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X11_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W11caa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x11_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X11_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W11caa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [2]
  // W12(y,o2,i,v1) += (    1.00000000) D1(o1,o2) V2(v1,i,y,o1) 
  // S2(w,y,i,k) += (   -2.00000000) T2(o2,w,k,v1) W12(y,o2,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W12caa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x12_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X12_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W12caa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x12_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X12_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W12caa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [2]
  // W13(w,o1,i,v1) += (    1.00000000) D1(o1,o2) V2(v1,i,w,o2) 
  // S2(w,y,i,k) += (    1.00000000) T2(o1,y,k,v1) W13(w,o1,i,v1) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W13caa_sigma_ccoo_ocov(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccoo_ocov_no0_x13_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X13_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W13caa_sigma_ccoo_ocov.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no1_x13_type1_eri_v,G_IF_SIGMA_CCOO_OCOV_NO1_X13_TYPE1_ERI_V)
      (sk, ik, sv1, iv1, T2b.cptr(), W13caa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_ccoo_ocov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(w,y,i,k) += (    1.00000000) D3(i,o3,k,o2,o4,o1) W0(w,y,o4,o1,o3,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x0_type2_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X0_TYPE2_ERI_V)
      (sk, ik, W0ccaaaa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,y,i,k) += (    1.00000000) D3(i,o2,k,o3,o1,o4) W1(y,w,o1,o4,o3,o2) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ocov_no0_x1_type2_eri_v,G_IF_SIGMA_CCOO_OCOV_NO0_X1_TYPE2_ERI_V)
      (sk, ik, W1ccaaaa_sigma_ccoo_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ik, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccoo_ocov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
