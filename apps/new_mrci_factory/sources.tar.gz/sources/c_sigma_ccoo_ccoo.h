

#ifndef C_SIGMA_CCOO_CCOO_H
#define C_SIGMA_CCOO_CCOO_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//                                                              
//   _______________                                  ______    
//  |          |                 .'. .`. `````|`````.~      ~.  
//  |______    |______         .'   `   `.    |    |          | 
//  |          |             .'           `.  |    |          | 
//  |          |___________.'               `.|     `.______.'  
//                                                              

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x0_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X0_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Fc0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x1_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X1_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x1_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X1_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x2_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X2_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x2_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X2_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x3_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X3_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Fc0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x4_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X4_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Fc0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x5_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X5_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x5_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X5_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x6_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X6_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x6_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X6_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x7_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X7_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x7_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X7_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x8_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X8_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x8_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X8_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x9_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X9_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Fc0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x10_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X10_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Fc0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x11_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X11_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x11_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X11_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x12_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X12_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x12_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X12_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x13_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X13_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x13_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X13_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x14_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X14_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x14_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X14_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W9, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x15_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X15_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Fc0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x16_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X16_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Fc0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x17_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X17_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x18_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X18_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x19_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X19_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x20_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X20_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x21_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X21_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x21_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X21_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W10, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x22_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X22_TYPE1_NOERI)
  (const double * const W11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x22_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X22_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W11, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x23_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X23_TYPE1_NOERI)
  (const double * const W12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x23_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X23_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W12, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x24_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X24_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const W13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x24_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X24_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W13, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x25_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X25_TYPE1_NOERI)
  (const double * const W14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x25_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X25_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W14, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x26_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X26_TYPE1_NOERI)
  (const double * const W15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x26_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X26_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W15, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x27_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X27_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const W16, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x27_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X27_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W16, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x28_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X28_TYPE1_NOERI)
  (const double * const W17, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x28_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X28_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W17, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x29_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X29_TYPE1_NOERI)
  (const double * const W18, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x29_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X29_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W18, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x30_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X30_TYPE1_NOERI)
  (const double * const W19, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x30_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X30_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W19, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x31_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X31_TYPE1_NOERI)
  (const double * const W20, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x31_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X31_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W20, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x32_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X32_TYPE1_NOERI)
  (const double * const W21, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x32_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X32_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W21, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x33_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X33_TYPE1_NOERI)
  (const double * const W22, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x33_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X33_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W22, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x34_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X34_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const W23, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x34_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X34_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W23, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x35_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X35_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W24, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x35_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X35_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W24, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x36_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X36_TYPE1_NOERI)
  (const double * const W25, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x36_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X36_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W25, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x37_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X37_TYPE1_NOERI)
  (const double * const W26, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x37_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X37_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W26, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x38_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X38_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W27, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x38_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X38_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W27, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x39_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X39_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W28, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x39_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X39_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W28, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x40_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X40_TYPE1_NOERI)
  (const double * const W29, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x40_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X40_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W29, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x41_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X41_TYPE1_NOERI)
  (const double * const W30, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x41_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X41_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W30, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x42_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X42_TYPE1_NOERI)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W31, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x42_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X42_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W31, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x43_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X43_TYPE1_NOERI)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W32, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x43_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO1_X43_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W32, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x44_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X44_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x45_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X45_TYPE1_NOERI)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x46_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X46_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x47_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X47_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x48_type1_noeri,G_IF_SIGMA_CCOO_CCOO_NO0_X48_TYPE1_NOERI)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x0_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X0_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x1_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X1_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x2_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X2_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x3_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X3_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x4_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X4_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x5_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X5_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x6_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X6_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x7_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X7_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x7_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X7_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x8_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X8_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x8_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X8_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x9_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X9_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x9_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X9_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x10_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X10_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x10_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X10_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x11_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X11_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x11_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X11_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W9, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x12_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X12_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x12_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X12_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W10, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x13_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X13_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x13_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X13_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W11, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x14_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X14_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x14_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X14_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W12, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x15_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X15_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x15_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X15_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W13, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x16_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X16_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x16_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X16_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W14, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x17_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X17_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x17_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X17_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W15, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x18_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X18_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W16, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x18_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X18_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W16, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x19_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X19_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W17, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x19_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X19_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W17, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x20_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X20_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W18, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x20_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X20_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W18, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x21_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X21_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W19, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x21_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X21_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W19, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x22_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X22_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W20, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x22_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X22_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W20, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x23_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X23_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W21, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x23_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X23_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W21, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x24_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X24_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W22, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x24_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X24_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W22, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x25_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X25_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W23, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x25_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X25_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W23, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x26_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X26_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W24, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x26_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X26_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W24, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x27_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X27_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W25, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x27_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X27_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W25, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x28_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X28_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W26, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x28_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X28_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W26, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x29_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X29_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W27, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x29_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X29_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W27, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x30_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X30_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W28, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x30_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X30_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W28, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x31_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X31_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W29, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x31_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X31_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W29, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x32_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X32_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W30, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x32_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X32_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W30, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x33_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X33_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W31, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x33_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X33_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W31, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x34_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X34_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W32, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x34_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X34_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W32, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x35_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X35_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W33, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x35_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X35_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W33, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x36_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X36_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W34, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x36_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X36_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W34, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x37_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X37_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W35, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x37_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X37_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W35, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x38_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X38_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W36, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x38_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X38_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W36, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x39_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X39_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W37, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x39_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X39_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W37, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x40_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X40_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W38, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x40_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X40_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W38, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x41_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X41_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W39, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x41_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X41_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W39, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x42_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X42_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W40, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x42_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X42_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W40, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x43_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X43_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W41, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x43_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X43_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W41, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x44_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X44_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W42, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x44_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X44_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W42, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x45_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X45_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W43, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x45_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X45_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W43, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x46_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X46_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W44, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x46_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X46_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W44, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x47_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X47_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W45, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x47_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X47_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W45, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x48_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X48_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W46, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x48_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X48_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W46, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x49_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X49_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W47, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x49_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X49_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W47, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x50_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X50_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const W48, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x50_type1_eri_c,G_IF_SIGMA_CCOO_CCOO_NO1_X50_TYPE1_ERI_C)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W48, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x0_type2_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X0_TYPE2_ERI_C)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x1_type2_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X1_TYPE2_ERI_C)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x2_type2_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X2_TYPE2_ERI_C)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x3_type2_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X3_TYPE2_ERI_C)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x4_type2_eri_c,G_IF_SIGMA_CCOO_CCOO_NO0_X4_TYPE2_ERI_C)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x0_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X0_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x0_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X0_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x1_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X1_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x1_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X1_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x2_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X2_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x2_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X2_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x3_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X3_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x3_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X3_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x4_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X4_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x5_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X5_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x6_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X6_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x7_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X7_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x8_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X8_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x8_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X8_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x9_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X9_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x9_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X9_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W9, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x10_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X10_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x10_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X10_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W10, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x11_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X11_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x11_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X11_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W11, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x12_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X12_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x12_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X12_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W12, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x13_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X13_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x13_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X13_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const W13, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x14_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X14_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x14_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X14_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const W14, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x15_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X15_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x15_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X15_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W15, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x16_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X16_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W16, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x16_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X16_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W16, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x17_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X17_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W17, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x17_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X17_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W17, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x18_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X18_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W18, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x18_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X18_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W18, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x19_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X19_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W19, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x19_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X19_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W19, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x20_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X20_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W20, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x20_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X20_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W20, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x21_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X21_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W21, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x21_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X21_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W21, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x22_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X22_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W22, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x22_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X22_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W22, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x23_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X23_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W23, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x23_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X23_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W23, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x24_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X24_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x25_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X25_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x26_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X26_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x27_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X27_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x28_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X28_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x29_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X29_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x30_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X30_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x31_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X31_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x32_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X32_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W24, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x32_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X32_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W24, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x33_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X33_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W25, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x33_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X33_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W25, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x34_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X34_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W26, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x34_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X34_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W26, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x35_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X35_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W27, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x35_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X35_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W27, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x36_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X36_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W28, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x37_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X37_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W29, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x38_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X38_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W30, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x39_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X39_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W31, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x40_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X40_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W32, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x40_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X40_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W32, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x41_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X41_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W33, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x41_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X41_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W33, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x42_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X42_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W34, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x42_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X42_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W34, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x43_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X43_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W35, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x43_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X43_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W35, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x44_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X44_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W36, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x44_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X44_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const W36, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x45_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X45_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W37, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x45_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X45_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const W37, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x46_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X46_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W38, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x46_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X46_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W38, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x47_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X47_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W39, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x47_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X47_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W39, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x48_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X48_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W40, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x48_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X48_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W40, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x49_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X49_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W41, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x49_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X49_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W41, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x50_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X50_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W42, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x50_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X50_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W42, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x51_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X51_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W43, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x51_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X51_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W43, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x52_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X52_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W44, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x52_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X52_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W44, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x53_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X53_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const W45, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x53_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X53_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const W45, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x54_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X54_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W46, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x54_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X54_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W46, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x55_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X55_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const W47, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x55_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X55_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W47, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x56_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X56_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x57_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X57_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x58_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X58_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x59_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X59_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x60_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X60_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x61_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X61_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x62_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X62_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x63_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X63_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x64_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X64_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W48, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x65_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X65_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W49, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x66_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X66_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W50, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x66_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X66_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W50, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x67_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X67_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W51, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x68_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X68_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W52, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x69_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X69_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W53, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x69_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X69_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W53, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x70_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X70_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W54, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x71_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X71_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W55, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x72_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X72_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const W56, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x72_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X72_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W56, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x73_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X73_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const W57, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x73_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X73_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W57, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x74_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X74_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W58, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x74_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X74_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W58, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x75_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X75_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const W59, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x75_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X75_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W59, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x76_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X76_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const W60, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x76_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X76_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W60, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x77_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X77_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so5, const FC_INT &io5, 
   const double * const V2, const double * const W61, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x77_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X77_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so5, const FC_INT &io5, 
   const double * const T2, const double * const W61, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x78_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X78_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so5, const FC_INT &io5, 
   const double * const V2, const double * const W62, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x78_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X78_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so5, const FC_INT &io5, 
   const double * const T2, const double * const W62, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x79_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X79_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W63, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x79_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X79_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W63, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x80_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X80_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W64, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x80_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X80_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W64, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x81_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X81_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W65, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x81_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X81_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W65, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x82_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X82_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W66, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x82_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X82_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W66, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x83_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X83_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W67, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x83_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X83_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W67, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x84_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X84_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W68, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x84_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X84_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W68, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x85_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X85_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W69, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x85_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X85_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W69, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x86_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X86_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W70, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x86_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X86_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W70, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x87_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X87_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W71, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x87_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X87_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W71, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x88_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X88_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W72, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x88_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X88_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W72, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x89_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X89_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W73, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x89_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X89_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W73, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x90_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X90_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W74, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x90_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X90_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W74, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x91_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X91_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W75, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x91_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X91_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W75, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x92_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X92_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W76, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x92_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X92_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W76, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x93_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X93_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W77, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x93_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X93_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W77, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x94_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X94_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W78, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x94_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X94_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W78, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x95_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X95_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W79, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x95_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X95_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W79, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x96_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X96_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W80, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x96_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X96_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W80, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x97_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X97_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W81, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x97_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X97_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W81, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x98_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X98_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W82, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x98_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X98_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W82, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x99_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X99_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W83, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x99_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X99_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W83, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x100_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X100_TYPE1_ERI_O)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W84, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x100_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X100_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W84, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x101_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X101_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W85, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x101_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X101_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W85, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x102_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X102_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W86, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x102_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X102_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W86, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x103_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X103_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so4, const FC_INT &io4, 
   const double * const V2, const double * const W87, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x103_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X103_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const W87, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x104_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X104_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const W88, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x104_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X104_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const W88, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x105_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X105_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W89, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x105_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X105_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W89, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x106_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X106_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const W90, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x106_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X106_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const W90, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x107_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X107_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const W91, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x107_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO1_X107_TYPE1_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const W91, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x108_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X108_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x109_type1_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X109_TYPE1_ERI_O)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x0_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X0_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x1_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X1_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x2_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X2_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x3_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X3_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x4_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X4_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W28, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x5_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X5_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W29, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x6_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X6_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W30, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x7_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X7_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W31, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x8_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X8_TYPE2_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W48, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x9_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X9_TYPE2_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const W49, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x10_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X10_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W51, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x11_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X11_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const W52, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x12_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X12_TYPE2_ERI_O)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const W54, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x13_type2_eri_o,G_IF_SIGMA_CCOO_CCOO_NO0_X13_TYPE2_ERI_O)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const W55, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 