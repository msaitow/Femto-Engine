                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ooov_cooo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

//                                   Generated date : Wed Feb 19 15:55:28 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ooov_cooo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
//-@ERI.contractions(begin)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ooov_cooo
  { 
  // No. 0, [2]
  // W0(o5,o1,o2,o4,o3,a) += (    1.00000000) T2(c1,o5,o1,o2) V2(o4,c1,o3,a) 
  // S2(i,k,m,a) += (   -1.00000000) D4(o4,o1,m,i,o3,k,o5,o2) W0(o5,o1,o2,o4,o3,a) 
  double flops = 0; // Flop count
  int so4(s_eri);
  int io4(i_eri);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 

    int imoi = amo2imo[io4] - nclosed;                              
    int imoj = amo2imo[io1] - nclosed;                              
                                                                                         
    // Generate D4 by cumulant expansion ....                                            
    if(ctinp.use_d4cum_of()){
    FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
      (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
       rdm4_ij_sliced.cptr(), imoi, imoj);                                               
    rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, io4, so4, io1, so1, rdm4_ij_sliced);    
    flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
    } // End if
    // Slice the already existing 8-index 4-RDM ....                                            
    else{
    const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
    rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, io4, so4, io1, so1, rdm4_ij_sliced);    
    }
    FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so4, so1, io4, io1, rdm4_sym.cptr(), nir, nsym, psym);  
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      for(int sa = 0;sa < nir;++sa){ 
      for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
        S2b = orz::DTensor(retval.namps_iamp()[ia]);
        orz::DTensor W0aa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^so2^so4^sa));
        FC_FUNC(g_if_sigma_ooov_cooo_no0_x0_type1_eri_o,G_IF_SIGMA_OOOV_COOO_NO0_X0_TYPE1_ERI_O)
          (sa, ia, so1, io1, so2, io2, so4, io4, T2b.cptr(), V2_sym.cptr(), W0aa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
        FC_FUNC(g_if_sigma_ooov_cooo_no1_x0_type1_eri_o,G_IF_SIGMA_OOOV_COOO_NO1_X0_TYPE1_ERI_O)
          (sa, ia, so1, io1, so2, io2, so4, io4, W0aa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
        retval.acc_amp2(ia, S2b);
      }
      }
    }
    }
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ooov_cooo
  { 
  // No. 0, [2]
  // W0(c1,i,k,o4,o1,a) += (    1.00000000) D3(i,o3,k,o2,o4,o1) V2(a,o2,c1,o3) 
  // S2(i,k,m,a) += (   -1.00000000) T2(c1,o1,m,o4) W0(c1,i,k,o4,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W0caaa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x0_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X0_TYPE1_ERI_V)
      (sa, ia, so4, io4, V2_sym.cptr(), W0caaa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_ooov_cooo_no1_x0_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X0_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), W0caaa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,i,o3,k,o4,a) += (    1.00000000) D3(i,o3,k,o2,o4,o1) V2(a,o2,c1,o1) 
  // S2(i,k,m,a) += (   -1.00000000) T2(c1,o3,o4,m) W1(c1,i,o3,k,o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W1caaaa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xcaaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ooov_cooo_no0_x1_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X1_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W1caaaa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_ooov_cooo_no1_x1_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X1_TYPE1_ERI_V)
      (sa, ia, sm, im, T2b.cptr(), W1caaaa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(o2,o4,o3,a) += (    1.00000000) T2(c1,o2,o1,o4) V2(a,o3,c1,o1) 
  // S2(i,k,m,a) += (    2.00000000) D3(i,m,k,o3,o4,o2) W2(o2,o4,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor W2aa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x2_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X2_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), W2aa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_cooo_no1_x2_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X2_TYPE1_ERI_V)
      (sa, ia, so4, io4, W2aa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(o3,m,o2,a) += (    1.00000000) T2(c1,o3,o1,m) V2(a,o2,c1,o1) 
  // S2(i,k,m,a) += (    2.00000000) D2(i,o3,k,o2) W3(o3,m,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    orz::DTensor W3aa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^sa));
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x3_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X3_TYPE1_ERI_V)
      (sa, ia, sm, im, T2b.cptr(), V2_sym.cptr(), W3aa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_cooo_no1_x3_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X3_TYPE1_ERI_V)
      (sa, ia, sm, im, W3aa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(o2,o4,o3,a) += (    1.00000000) T2(c1,o2,o4,o1) V2(a,o3,c1,o1) 
  // S2(i,k,m,a) += (   -1.00000000) D3(i,m,k,o3,o4,o2) W4(o2,o4,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W4aaa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x4_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X4_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W4aaa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_cooo_no1_x4_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X4_TYPE1_ERI_V)
    (sa, ia, W4aaa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(o3,m,o2,a) += (    1.00000000) T2(c1,o3,m,o1) V2(a,o2,c1,o1) 
  // S2(i,k,m,a) += (   -1.00000000) D2(i,o3,k,o2) W5(o3,m,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W5aaa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x5_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X5_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W5aaa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_cooo_no1_x5_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X5_TYPE1_ERI_V)
    (sa, ia, W5aaa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(o2,o4,o3,a) += (    1.00000000) T2(c1,o2,o1,o4) V2(a,o1,c1,o3) 
  // S2(i,k,m,a) += (   -1.00000000) D3(i,m,k,o3,o4,o2) W6(o2,o4,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor W6aa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x6_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X6_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), W6aa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_cooo_no1_x6_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X6_TYPE1_ERI_V)
      (sa, ia, so4, io4, W6aa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(o3,m,o2,a) += (    1.00000000) T2(c1,o3,o1,m) V2(a,o1,c1,o2) 
  // S2(i,k,m,a) += (   -1.00000000) D2(i,o3,k,o2) W7(o3,m,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    orz::DTensor W7aa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^sa));
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x7_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X7_TYPE1_ERI_V)
      (sa, ia, sm, im, T2b.cptr(), V2_sym.cptr(), W7aa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_cooo_no1_x7_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X7_TYPE1_ERI_V)
      (sa, ia, sm, im, W7aa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W8(o2,o1,o3,a) += (    1.00000000) T2(c1,o2,o1,o4) V2(a,o4,c1,o3) 
  // S2(i,k,m,a) += (   -1.00000000) D3(i,m,k,o2,o1,o3) W8(o2,o1,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W8aaa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x8_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X8_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), W8aaa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_cooo_no1_x8_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X8_TYPE1_ERI_V)
    (sa, ia, W8aaa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(o2,m,o3,a) += (    1.00000000) T2(c1,o2,m,o1) V2(a,o1,c1,o3) 
  // S2(i,k,m,a) += (   -1.00000000) D2(i,o3,k,o2) W9(o2,m,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W9aaa_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x9_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X9_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W9aaa_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_cooo_no1_x9_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X9_TYPE1_ERI_V)
    (sa, ia, W9aaa_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W10(o3,a) += (    1.00000000) T2(c1,o3,o2,o1) V2(a,o1,c1,o2) 
  // S2(i,k,m,a) += (    2.00000000) D2(i,m,k,o3) W10(o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W10a_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x10_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X10_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W10a_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_cooo_no1_x10_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X10_TYPE1_ERI_V)
    (sa, ia, W10a_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(o1,a) += (    1.00000000) T2(c1,o1,o2,o3) V2(a,o2,c1,o3) 
  // S2(i,k,m,a) += (   -1.00000000) D2(i,m,k,o1) W11(o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W11a_sigma_ooov_cooo(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ooov_cooo_no0_x11_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO0_X11_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), W11a_sigma_ooov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_cooo_no1_x11_type1_eri_v,G_IF_SIGMA_OOOV_COOO_NO1_X11_TYPE1_ERI_V)
    (sa, ia, W11a_sigma_ooov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ooov_cooo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
