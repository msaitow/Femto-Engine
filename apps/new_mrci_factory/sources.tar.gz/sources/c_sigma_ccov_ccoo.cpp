                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccov_ccoo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//      ______                  __           
//     / ____/___   ____ ___   / /_ ____     
//    / /_   / _ \ / __ `__ \ / __// __ \ 
//   / __/  /  __// / / / / // /_ / /_/ /    
//  /_/     \___//_/ /_/ /_/ \__/ \____/  

//                                   Generated date : Wed Feb 19 15:56:02 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccov_ccoo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  if(myrank == 0){
  { 
  // No. 0, [2]
  // W0(w,y,i,o2) += (    1.00000000) D2(i,o1,o2,o3) T2(w,y,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) Fc1(o2,a) W0(w,y,i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W0ccaa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x0_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X0_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W0ccaa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x0_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X0_TYPE1_NOERI)
      (sa, ia, W0ccaa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 1, [2]
  // W1(o2,a) += (    1.00000000) D1(o1,o2) Fc1(o1,a) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,i,o2) W1(o2,a) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      double W1_sigma_ccov_ccoo = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x1_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X1_TYPE1_NOERI)
        (sa, ia, so2, io2, &W1_sigma_ccov_ccoo, nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x1_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X1_TYPE1_NOERI)
        (sa, ia, so2, io2, T2b.cptr(), &W1_sigma_ccov_ccoo, S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W2(o2,a) += (    1.00000000) D1(o1,o2) Fc1(o1,a) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o2,i) W2(o2,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W2a_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x2_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X2_TYPE1_NOERI)
      (sa, ia, W2a_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x2_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X2_TYPE1_NOERI)
        (sa, ia, si, ii, T2b.cptr(), W2a_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 3, [2]
  // W3(w,y,i,o2) += (    1.00000000) D1(i,o1) T2(w,y,o2,o1) 
  // S2(w,y,i,a) += (    2.00000000) Fc1(o2,a) W3(w,y,i,o2) 
  double flops = 0; // Flop count
  orz::DTensor W3ccaa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, 0));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x3_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X3_TYPE1_NOERI)
      (so1, io1, T2b.cptr(), W3ccaa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x3_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X3_TYPE1_NOERI)
      (sa, ia, W3ccaa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 4, [2]
  // W4(w,y,i,o2) += (    1.00000000) D1(i,o1) T2(w,y,o1,o2) 
  // S2(w,y,i,a) += (   -4.00000000) Fc1(o2,a) W4(w,y,i,o2) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    T2b = T2.get_amp2(io2);
    orz::DTensor W4cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, so2));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x4_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X4_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W4cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x4_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO1_X4_TYPE1_NOERI)
        (sa, ia, so2, io2, W4cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [1]
  // S2(w,y,i,a) += (    8.00000000) Fc1(o1,a) T2(w,y,i,o1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x5_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X5_TYPE1_NOERI)
        (sa, ia, so1, io1, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [1]
  // S2(w,y,i,a) += (   -4.00000000) Fc1(o1,a) T2(w,y,o1,i) 
  double flops = 0; // Flop count
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    if(hintmo.iproc_havingimo()[ii] == myrank) {           
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x6_type1_noeri,G_IF_SIGMA_CCOV_CCOO_NO0_X6_TYPE1_NOERI)
        (sa, ia, si, ii, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccov_ccoo
  { 
  // No. 0, [2]
  // W0(c1,y,i,o2,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,o3,c1,y) 
  // S2(w,y,i,a) += (   -2.00000000) T2(c1,w,o1,o2) W0(c1,y,i,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W0ccaa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x0_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X0_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W0ccaa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x0_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X0_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W0ccaa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,w,i,o2,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,o3,c1,w) 
  // S2(w,y,i,a) += (   -2.00000000) T2(c1,y,o2,o1) W1(c1,w,i,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W1ccaa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x1_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X1_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W1ccaa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x1_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X1_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W1ccaa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(c1,y,o2,a) += (    1.00000000) D1(o1,o2) V2(a,o1,c1,y) 
  // S2(w,y,i,a) += (    4.00000000) T2(c1,w,o2,i) W2(c1,y,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W2cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccoo_no0_x2_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X2_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W2cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x2_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X2_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W2cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(c1,y,o2,a) += (    1.00000000) D1(o1,o2) V2(a,o1,c1,y) 
  // S2(w,y,i,a) += (   -2.00000000) T2(c1,w,i,o2) W3(c1,y,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W3cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x3_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X3_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W3cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x3_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X3_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W3cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(c1,w,o2,a) += (    1.00000000) D1(o1,o2) V2(a,o1,c1,w) 
  // S2(w,y,i,a) += (    4.00000000) T2(c1,y,i,o2) W4(c1,w,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W4cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x4_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X4_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W4cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x4_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X4_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W4cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(c1,w,o2,a) += (    1.00000000) D1(o1,o2) V2(a,o1,c1,w) 
  // S2(w,y,i,a) += (   -2.00000000) T2(c1,y,o2,i) W5(c1,w,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W5cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccoo_no0_x5_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X5_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W5cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x5_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X5_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W5cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(y,w,o2,a) += (    1.00000000) T2(c1,y,o2,o1) V2(a,o1,c1,w) 
  // S2(w,y,i,a) += (    4.00000000) D1(i,o2) W6(y,w,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W6cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x6_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X6_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W6cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccoo_no1_x6_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X6_TYPE1_ERI_V)
    (sa, ia, W6cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(y,w,o2,a) += (    1.00000000) T2(c1,y,o1,o2) V2(a,o1,c1,w) 
  // S2(w,y,i,a) += (   -2.00000000) D1(i,o2) W7(y,w,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor W7cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x7_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X7_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), W7cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x7_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X7_TYPE1_ERI_V)
      (sa, ia, so2, io2, W7cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W8(w,y,o2,a) += (    1.00000000) T2(c1,w,o1,o2) V2(a,o1,c1,y) 
  // S2(w,y,i,a) += (    4.00000000) D1(i,o2) W8(w,y,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor W8cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x8_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X8_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), W8cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x8_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X8_TYPE1_ERI_V)
      (sa, ia, so2, io2, W8cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(w,y,o2,a) += (    1.00000000) T2(c1,w,o2,o1) V2(a,o1,c1,y) 
  // S2(w,y,i,a) += (   -2.00000000) D1(i,o2) W9(w,y,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W9cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x9_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X9_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W9cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccoo_no1_x9_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X9_TYPE1_ERI_V)
    (sa, ia, W9cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 10, [1]
  // S2(w,y,i,a) += (   -8.00000000) T2(c1,y,i,o1) V2(a,o1,c1,w) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x10_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X10_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 11, [1]
  // S2(w,y,i,a) += (    4.00000000) T2(c1,y,o1,i) V2(a,o1,c1,w) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x11_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X11_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,y,i,a) += (    4.00000000) T2(c1,w,i,o1) V2(a,o1,c1,y) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x12_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X12_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,y,i,a) += (   -8.00000000) T2(c1,w,o1,i) V2(a,o1,c1,y) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x13_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X13_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 14, [2]
  // W10(w,c1,i,o2,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,w,c1,o3) 
  // S2(w,y,i,a) += (   -2.00000000) T2(c1,y,o1,o2) W10(w,c1,i,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W10ccaa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x14_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X14_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W10ccaa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x14_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X14_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W10ccaa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 15, [2]
  // W11(y,c1,i,o2,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,y,c1,o3) 
  // S2(w,y,i,a) += (    4.00000000) T2(c1,w,o1,o2) W11(y,c1,i,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W11ccaa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x15_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X15_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W11ccaa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x15_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X15_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W11ccaa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 16, [2]
  // W12(y,c1,o2,a) += (    1.00000000) D1(o1,o2) V2(a,y,c1,o1) 
  // S2(w,y,i,a) += (   -8.00000000) T2(c1,w,o2,i) W12(y,c1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W12cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccoo_no0_x16_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X16_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W12cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x16_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X16_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W12cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 17, [2]
  // W13(y,c1,o2,a) += (    1.00000000) D1(o1,o2) V2(a,y,c1,o1) 
  // S2(w,y,i,a) += (    4.00000000) T2(c1,w,i,o2) W13(y,c1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W13cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x17_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X17_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W13cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x17_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X17_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W13cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 18, [2]
  // W14(w,c1,o2,a) += (    1.00000000) D1(o1,o2) V2(a,w,c1,o1) 
  // S2(w,y,i,a) += (    4.00000000) T2(c1,y,o2,i) W14(w,c1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W14cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccoo_no0_x18_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X18_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W14cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x18_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X18_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W14cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 19, [2]
  // W15(w,c1,o2,a) += (    1.00000000) D1(o1,o2) V2(a,w,c1,o1) 
  // S2(w,y,i,a) += (   -2.00000000) T2(c1,y,i,o2) W15(w,c1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W15cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x19_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X19_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W15cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x19_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X19_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W15cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 20, [2]
  // W16(y,w,o2,a) += (    1.00000000) T2(c1,y,o1,o2) V2(a,w,c1,o1) 
  // S2(w,y,i,a) += (    4.00000000) D1(i,o2) W16(y,w,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor W16cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x20_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X20_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), W16cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x20_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X20_TYPE1_ERI_V)
      (sa, ia, so2, io2, W16cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 21, [2]
  // W17(w,y,o2,a) += (    1.00000000) T2(c1,w,o1,o2) V2(a,y,c1,o1) 
  // S2(w,y,i,a) += (   -8.00000000) D1(i,o2) W17(w,y,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor W17cc_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcc(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x21_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X21_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), W17cc_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x21_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X21_TYPE1_ERI_V)
      (sa, ia, so2, io2, W17cc_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 22, [2]
  // W18(y,w,o2,a) += (    1.00000000) T2(c1,y,o2,o1) V2(a,w,c1,o1) 
  // S2(w,y,i,a) += (   -2.00000000) D1(i,o2) W18(y,w,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W18cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x22_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X22_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W18cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccoo_no1_x22_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X22_TYPE1_ERI_V)
    (sa, ia, W18cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 23, [2]
  // W19(w,y,o2,a) += (    1.00000000) T2(c1,w,o2,o1) V2(a,y,c1,o1) 
  // S2(w,y,i,a) += (    4.00000000) D1(i,o2) W19(w,y,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W19cca_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xcca(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x23_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X23_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W19cca_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ccov_ccoo_no1_x23_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X23_TYPE1_ERI_V)
    (sa, ia, W19cca_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 24, [1]
  // S2(w,y,i,a) += (   16.00000000) T2(c1,w,o1,i) V2(a,y,c1,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x24_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X24_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 25, [1]
  // S2(w,y,i,a) += (   -8.00000000) T2(c1,y,o1,i) V2(a,w,c1,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x25_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X25_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 26, [1]
  // S2(w,y,i,a) += (   -8.00000000) T2(c1,w,i,o1) V2(a,y,c1,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x26_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X26_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 27, [1]
  // S2(w,y,i,a) += (    4.00000000) T2(c1,y,i,o1) V2(a,w,c1,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x27_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X27_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 28, [2]
  // W20(i,o3,o4,a) += (    1.00000000) D3(i,o3,o1,o4,o2,o5) V2(a,o1,o2,o5) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o3,o4) W20(i,o3,o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W20aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x28_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X28_TYPE1_ERI_V)
      (sa, ia, so4, io4, V2_sym.cptr(), W20aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x28_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X28_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), W20aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 29, [2]
  // W21(o4,a) += (    1.00000000) D2(o1,o3,o2,o4) V2(a,o2,o1,o3) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,i,o4) W21(o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    double W21_sigma_ccov_ccoo = 0;
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x29_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X29_TYPE1_ERI_V)
      (sa, ia, so4, io4, V2_sym.cptr(), &W21_sigma_ccov_ccoo, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x29_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X29_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), &W21_sigma_ccov_ccoo, S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 30, [2]
  // W22(o4,a) += (    1.00000000) D2(o1,o3,o2,o4) V2(a,o2,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o4,i) W22(o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W22a_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccoo_no0_x30_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X30_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W22a_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x30_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X30_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W22a_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 31, [2]
  // W23(o3,o4,i,a) += (    1.00000000) D2(o1,o3,o2,o4) V2(a,o1,i,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o4,o3) W23(o3,o4,i,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W23aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x31_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X31_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W23aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x31_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X31_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W23aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 32, [2]
  // W24(i,o2,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o4,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o1,o2) W24(i,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W24aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x32_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X32_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W24aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x32_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X32_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W24aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 33, [2]
  // W25(i,o3,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o4,o1,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o3,o1) W25(i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W25aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x33_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X33_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W25aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x33_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X33_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W25aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 34, [2]
  // W26(o1,a) += (    1.00000000) D1(o2,o3) V2(a,o2,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o1,i) W26(o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W26a_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccoo_no0_x34_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X34_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W26a_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x34_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X34_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W26a_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 35, [2]
  // W27(o1,a) += (    1.00000000) D1(o2,o3) V2(a,o2,o1,o3) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,i,o1) W27(o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    double W27_sigma_ccov_ccoo = 0;
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x35_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X35_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), &W27_sigma_ccov_ccoo, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x35_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X35_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), &W27_sigma_ccov_ccoo, S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 36, [2]
  // W28(o3,i,o1,a) += (    1.00000000) D1(o2,o3) V2(a,o2,i,o1) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,o1,o3) W28(o3,i,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W28aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x36_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X36_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W28aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x36_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X36_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W28aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 37, [2]
  // W29(o3,i,o1,a) += (    1.00000000) D1(o2,o3) V2(a,o2,i,o1) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o3,o1) W29(o3,i,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W29aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x37_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X37_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W29aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x37_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X37_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W29aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 38, [2]
  // W30(i,o2,o4,a) += (    1.00000000) D2(i,o2,o1,o3) V2(a,o4,o1,o3) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,o2,o4) W30(i,o2,o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W30aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x38_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X38_TYPE1_ERI_V)
      (sa, ia, so4, io4, V2_sym.cptr(), W30aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x38_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X38_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), W30aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 39, [2]
  // W31(i,o2,o4,a) += (    1.00000000) D2(i,o2,o1,o3) V2(a,o4,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o4,o2) W31(i,o2,o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W31aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x39_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X39_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W31aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x39_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X39_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W31aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 40, [2]
  // W32(o1,a) += (    1.00000000) D1(o2,o3) V2(a,o1,o2,o3) 
  // S2(w,y,i,a) += (    8.00000000) T2(w,y,i,o1) W32(o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    double W32_sigma_ccov_ccoo = 0;
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x40_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X40_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), &W32_sigma_ccov_ccoo, nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x40_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X40_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), &W32_sigma_ccov_ccoo, S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 41, [2]
  // W33(o1,a) += (    1.00000000) D1(o2,o3) V2(a,o1,o2,o3) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,o1,i) W33(o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W33a_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_ccov_ccoo_no0_x41_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X41_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W33a_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x41_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X41_TYPE1_ERI_V)
      (sa, ia, si, ii, T2b.cptr(), W33a_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 42, [2]
  // W34(o3,o1,i,a) += (    1.00000000) D1(o2,o3) V2(a,o1,i,o2) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,o3,o1) W34(o3,o1,i,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W34aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x42_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X42_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W34aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x42_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X42_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W34aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 43, [2]
  // W35(o3,o1,i,a) += (    1.00000000) D1(o2,o3) V2(a,o1,i,o2) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o1,o3) W35(o3,o1,i,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W35aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x43_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X43_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W35aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x43_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X43_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W35aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 44, [2]
  // W36(i,o2,o3,a) += (    1.00000000) D1(i,o1) V2(a,o2,o1,o3) 
  // S2(w,y,i,a) += (    2.00000000) T2(w,y,o2,o3) W36(i,o2,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W36aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x44_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X44_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W36aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x44_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X44_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W36aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 45, [2]
  // W37(i,o2,o3,a) += (    1.00000000) D1(i,o1) V2(a,o2,o1,o3) 
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,o3,o2) W37(i,o2,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    orz::DTensor W37aa_sigma_ccov_ccoo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so2^sa));
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x45_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X45_TYPE1_ERI_V)
      (sa, ia, so2, io2, V2_sym.cptr(), W37aa_sigma_ccov_ccoo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x45_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO1_X45_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), W37aa_sigma_ccov_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 46, [1]
  // S2(w,y,i,a) += (    8.00000000) T2(w,y,o2,o1) V2(a,o1,i,o2) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x46_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X46_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 47, [1]
  // S2(w,y,i,a) += (   -4.00000000) T2(w,y,o1,o2) V2(a,o1,i,o2) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x47_type1_eri_v,G_IF_SIGMA_CCOV_CCOO_NO0_X47_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccov_ccoo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
