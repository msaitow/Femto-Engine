

#ifndef C_FOCK_D_OOOV_H
#define C_FOCK_D_OOOV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

void FC_FUNC(g_if_fock_d_ooov_no0_x0_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const h6_int, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_d_ooov_no0_x1_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const h6_int, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_d_ooov_no0_x2_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X2_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_d_ooov_no0_x3_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X3_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_d_ooov_no0_x4_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X4_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_d_ooov_no0_x5_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X5_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_d_ooov_no0_x6_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X6_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_d_ooov_no0_x7_type1_noeri,G_IF_FOCK_D_OOOV_NO0_X7_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 