                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_fock_v_cooo_ccoo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  8888888888                     888                  
//  888                            888                  
//  888                            888                  
//  8888888  .d88b.  88888b.d88b.  888888  .d88b.       
//  888     d8P  Y8b 888 "888 "88b 888    d88""88b  
//  888     88888888 888  888  888 888    888  888      
//  888     Y8b.     888  888  888 Y88b.  Y88..88P      
//  888      "Y8888  888  888  888  "Y888  "Y88P"   

//                                   Generated date : Wed Feb 19 15:54:47 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::fock_v_cooo_ccoo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const orz::DTensor &CFock,                                                 
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [2]
  // W0(c1,i,m,o1,k,o2) += (    1.00000000) D3(i,m,o1,k,o2,o3) P1(c1,o3) 
  // S2(w,i,k,m) += (    2.00000000) T2(c1,w,o2,o1) W0(c1,i,m,o1,k,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor W0caaa_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, sm^so1));
      FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x0_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X0_TYPE1_NOERI)
        (sm, im, so1, io1, CFock.cptr(), W0caaa_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x0_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X0_TYPE1_NOERI)
        (sm, im, so1, io1, T2b.cptr(), W0caaa_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [2]
  // W1(c1,i,m,o2) += (    1.00000000) D2(i,m,o2,o1) P1(c1,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(c1,w,k,o2) W1(c1,i,m,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor W1ca_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xca(symblockinfo, sm^so2));
      FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x1_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X1_TYPE1_NOERI)
        (sm, im, so2, io2, CFock.cptr(), W1ca_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x1_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X1_TYPE1_NOERI)
        (sm, im, so2, io2, T2b.cptr(), W1ca_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [2]
  // W2(c1,i,m,o2) += (    1.00000000) D2(i,m,o2,o1) P1(c1,o1) 
  // S2(w,i,k,m) += (   -4.00000000) T2(c1,w,o2,k) W2(c1,i,m,o2) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W2caa_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x2_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X2_TYPE1_NOERI)
      (sm, im, CFock.cptr(), W2caa_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x2_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X2_TYPE1_NOERI)
        (sk, ik, sm, im, T2b.cptr(), W2caa_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    }
    }
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 3, [2]
  // W3(c1,i,o2,k) += (    1.00000000) D2(i,o1,o2,k) P1(c1,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(w,c1,o2,m) W3(c1,i,o2,k) 
  double flops = 0; // Flop count
  orz::DTensor W3caaa_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x3_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X3_TYPE1_NOERI)
    (CFock.cptr(), W3caaa_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x3_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X3_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W3caaa_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 4, [2]
  // W4(c1,i,k,o2) += (    1.00000000) D2(i,k,o2,o1) P1(c1,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(c1,w,o2,m) W4(c1,i,k,o2) 
  double flops = 0; // Flop count
  orz::DTensor W4caaa_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x4_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X4_TYPE1_NOERI)
    (CFock.cptr(), W4caaa_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x4_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X4_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W4caaa_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 5, [2]
  // W5(c1,i) += (    1.00000000) D1(i,o1) P1(c1,o1) 
  // S2(w,i,k,m) += (    2.00000000) T2(c1,w,k,m) W5(c1,i) 
  double flops = 0; // Flop count
  orz::DTensor W5ca_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x5_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X5_TYPE1_NOERI)
    (CFock.cptr(), W5ca_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x5_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X5_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W5ca_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 6, [2]
  // W6(c1,i) += (    1.00000000) D1(i,o1) P1(c1,o1) 
  // S2(w,i,k,m) += (   -4.00000000) T2(w,c1,k,m) W6(c1,i) 
  double flops = 0; // Flop count
  orz::DTensor W6ca_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x6_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X6_TYPE1_NOERI)
    (CFock.cptr(), W6ca_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x6_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X6_TYPE1_NOERI)
      (sm, im, T2b.cptr(), W6ca_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 7, [2]
  // W7(w,o2) += (    1.00000000) P1(c1,o1) T2(c1,w,o1,o2) 
  // S2(w,i,k,m) += (   -4.00000000) D2(i,m,o2,k) W7(w,o2) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    T2b = T2.get_amp2(io2);
    orz::DTensor W7c_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xc(symblockinfo, so2));
    FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x7_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X7_TYPE1_NOERI)
      (so2, io2, CFock.cptr(), T2b.cptr(), W7c_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x7_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X7_TYPE1_NOERI)
        (sm, im, so2, io2, W7c_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 8, [2]
  // W8(w,o1) += (    1.00000000) P1(c1,o2) T2(c1,w,o1,o2) 
  // S2(w,i,k,m) += (    2.00000000) D2(i,m,o1,k) W8(w,o1) 
  double flops = 0; // Flop count
  orz::DTensor W8ca_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x8_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X8_TYPE1_NOERI)
      (so2, io2, CFock.cptr(), T2b.cptr(), W8ca_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x8_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X8_TYPE1_NOERI)
      (sm, im, W8ca_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 9, [2]
  // W9(w,k) += (    1.00000000) P1(c1,o1) T2(c1,w,o1,k) 
  // S2(w,i,k,m) += (    8.00000000) D1(i,m) W9(w,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    orz::DTensor W9c_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xc(symblockinfo, sk));
    FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x9_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X9_TYPE1_NOERI)
      (sk, ik, CFock.cptr(), T2b.cptr(), W9c_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x9_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X9_TYPE1_NOERI)
        (sk, ik, sm, im, W9c_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(im, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 10, [2]
  // W10(w,k) += (    1.00000000) P1(c1,o1) T2(c1,w,k,o1) 
  // S2(w,i,k,m) += (   -4.00000000) D1(i,m) W10(w,k) 
  double flops = 0; // Flop count
  orz::DTensor W10ca_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xca(symblockinfo, 0));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x10_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X10_TYPE1_NOERI)
      (so1, io1, CFock.cptr(), T2b.cptr(), W10ca_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x10_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X10_TYPE1_NOERI)
      (sm, im, W10ca_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 11, [2]
  // W11(w,m) += (    1.00000000) P1(c1,o1) T2(c1,w,o1,m) 
  // S2(w,i,k,m) += (   -4.00000000) D1(i,k) W11(w,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W11c_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x11_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X11_TYPE1_NOERI)
      (sm, im, CFock.cptr(), T2b.cptr(), W11c_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x11_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X11_TYPE1_NOERI)
      (sm, im, W11c_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 12, [2]
  // W12(w,m) += (    1.00000000) P1(c1,o1) T2(w,c1,o1,m) 
  // S2(w,i,k,m) += (    2.00000000) D1(i,k) W12(w,m) 
  double flops = 0; // Flop count
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    if(hintmo.iproc_havingimo()[im] == myrank) {           
    T2b = T2.get_amp2(im);
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor W12c_fock_v_cooo_ccoo(orz::mr::sizeof_sympack_Xc(symblockinfo, sm));
    FC_FUNC(g_if_fock_v_cooo_ccoo_no0_x12_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO0_X12_TYPE1_NOERI)
      (sm, im, CFock.cptr(), T2b.cptr(), W12c_fock_v_cooo_ccoo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_fock_v_cooo_ccoo_no1_x12_type1_noeri,G_IF_FOCK_V_COOO_CCOO_NO1_X12_TYPE1_NOERI)
      (sm, im, W12c_fock_v_cooo_ccoo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(im, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("fock_v_cooo_ccoo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
