                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_coov_cooo.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  8 8888888888   8 8888888888            ,8.       ,8.    8888888 8888888888 ,o888888o.     
//  8 8888         8 8888                 ,888.     ,888.         8 8888    . 8888     `88.   
//  8 8888         8 8888                .`8888.   .`8888.        8 8888   ,8 8888       `8b  
//  8 8888         8 8888               ,8.`8888. ,8.`8888.       8 8888   88 8888        `8b 
//  8 888888888888 8 888888888888      ,8'8.`8888,8^8.`8888.      8 8888   88 8888         88 
//  8 8888         8 8888             ,8' `8.`8888' `8.`8888.     8 8888   88 8888         88 
//  8 8888         8 8888            ,8'   `8.`88'   `8.`8888.    8 8888   88 8888        ,8P 
//  8 8888         8 8888           ,8'     `8.`'     `8.`8888.   8 8888   `8 8888       ,8P  
//  8 8888         8 8888          ,8'       `8        `8.`8888.  8 8888    ` 8888     ,88'   
//  8 8888         8 888888888888 ,8'         `         `8.`8888. 8 8888       `8888888P'     

//                                   Generated date : Wed Feb 19 15:56:51 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_coov_cooo(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  if(myrank == 0){
  { 
  // No. 0, [2]
  // W0(w,i,o1,k) += (    1.00000000) D3(i,o1,o2,k,o3,o4) T2(w,o4,o2,o3) 
  // S2(w,i,k,a) += (   -1.00000000) Fc1(o1,a) W0(w,i,o1,k) 
  double flops = 0; // Flop count
  orz::DTensor W0caaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x0_type1_noeri,G_IF_SIGMA_COOV_COOO_NO0_X0_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W0caaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x0_type1_noeri,G_IF_SIGMA_COOV_COOO_NO1_X0_TYPE1_NOERI)
      (sa, ia, W0caaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 1, [2]
  // W1(w,i,o1,k) += (    1.00000000) D2(i,o1,o2,o3) T2(w,o3,k,o2) 
  // S2(w,i,k,a) += (    2.00000000) Fc1(o1,a) W1(w,i,o1,k) 
  double flops = 0; // Flop count
  orz::DTensor W1caaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x1_type1_noeri,G_IF_SIGMA_COOV_COOO_NO0_X1_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W1caaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x1_type1_noeri,G_IF_SIGMA_COOV_COOO_NO1_X1_TYPE1_NOERI)
      (sa, ia, W1caaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 2, [2]
  // W2(w,i,o1,k) += (    1.00000000) D2(i,o1,o2,o3) T2(w,o3,o2,k) 
  // S2(w,i,k,a) += (   -1.00000000) Fc1(o1,a) W2(w,i,o1,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    orz::DTensor W2caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x2_type1_noeri,G_IF_SIGMA_COOV_COOO_NO0_X2_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W2caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x2_type1_noeri,G_IF_SIGMA_COOV_COOO_NO1_X2_TYPE1_NOERI)
        (sa, ia, sk, ik, W2caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 3, [2]
  // W3(w,i,k,o3) += (    1.00000000) D2(i,k,o1,o2) T2(w,o2,o3,o1) 
  // S2(w,i,k,a) += (   -1.00000000) Fc1(o3,a) W3(w,i,k,o3) 
  double flops = 0; // Flop count
  orz::DTensor W3caaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x3_type1_noeri,G_IF_SIGMA_COOV_COOO_NO0_X3_TYPE1_NOERI)
      (so1, io1, T2b.cptr(), W3caaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x3_type1_noeri,G_IF_SIGMA_COOV_COOO_NO1_X3_TYPE1_NOERI)
      (sa, ia, W3caaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 4, [2]
  // W4(w,i,o2,k) += (    1.00000000) D1(i,o1) T2(w,o1,o2,k) 
  // S2(w,i,k,a) += (   -1.00000000) Fc1(o2,a) W4(w,i,o2,k) 
  double flops = 0; // Flop count
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    if(hintmo.iproc_havingimo()[ik] == myrank) {           
    T2b = T2.get_amp2(ik);
    orz::DTensor W4caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sk));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x4_type1_noeri,G_IF_SIGMA_COOV_COOO_NO0_X4_TYPE1_NOERI)
      (sk, ik, T2b.cptr(), W4caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x4_type1_noeri,G_IF_SIGMA_COOV_COOO_NO1_X4_TYPE1_NOERI)
        (sa, ia, sk, ik, W4caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [2]
  // W5(w,i,k,o3) += (    1.00000000) D2(i,o1,o2,k) T2(w,o1,o2,o3) 
  // S2(w,i,k,a) += (   -1.00000000) Fc1(o3,a) W5(w,i,k,o3) 
  double flops = 0; // Flop count
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    if(hintmo.iproc_havingimo()[io3] == myrank) {           
    T2b = T2.get_amp2(io3);
    orz::DTensor W5caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so3));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x5_type1_noeri,G_IF_SIGMA_COOV_COOO_NO0_X5_TYPE1_NOERI)
      (so3, io3, T2b.cptr(), W5caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x5_type1_noeri,G_IF_SIGMA_COOV_COOO_NO1_X5_TYPE1_NOERI)
        (sa, ia, so3, io3, W5caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [2]
  // W6(w,i,k,o2) += (    1.00000000) D1(i,o1) T2(w,o1,k,o2) 
  // S2(w,i,k,a) += (    2.00000000) Fc1(o2,a) W6(w,i,k,o2) 
  double flops = 0; // Flop count
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    if(hintmo.iproc_havingimo()[io2] == myrank) {           
    T2b = T2.get_amp2(io2);
    orz::DTensor W6caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, so2));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x6_type1_noeri,G_IF_SIGMA_COOV_COOO_NO0_X6_TYPE1_NOERI)
      (so2, io2, T2b.cptr(), W6caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x6_type1_noeri,G_IF_SIGMA_COOV_COOO_NO1_X6_TYPE1_NOERI)
        (sa, ia, so2, io2, W6caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, S2b);
    }
    }
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_coov_cooo
  { 
  // No. 0, [2]
  // W0(w,o1,o4,o3,o2,a) += (    1.00000000) T2(c1,o1,o4,o3) V2(a,o2,c1,w) 
  // S2(w,i,k,a) += (    1.00000000) D3(i,o2,o3,o1,o4,k) W0(w,o1,o4,o3,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W0caaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x0_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X0_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), W0caaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x0_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X0_TYPE1_ERI_V)
      (sa, ia, so3, io3, W0caaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,w,i,o3,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,o2,c1,w) 
  // S2(w,i,k,a) += (   -2.00000000) T2(c1,o1,k,o3) W1(c1,w,i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W1ccaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x1_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X1_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W1ccaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x1_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X1_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W1ccaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(c1,w,i,o3,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,o2,c1,w) 
  // S2(w,i,k,a) += (    1.00000000) T2(c1,o1,o3,k) W2(c1,w,i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W2ccaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_coov_cooo_no0_x2_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X2_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W2ccaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x2_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X2_TYPE1_ERI_V)
      (sa, ia, sk, ik, T2b.cptr(), W2ccaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(w,o2,o3,a) += (    1.00000000) T2(c1,o2,o1,o3) V2(a,o1,c1,w) 
  // S2(w,i,k,a) += (    1.00000000) D2(i,k,o3,o2) W3(w,o2,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W3ca_sigma_coov_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x3_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X3_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), W3ca_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x3_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X3_TYPE1_ERI_V)
      (sa, ia, so3, io3, W3ca_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(w,o2,k,a) += (    1.00000000) T2(c1,o2,o1,k) V2(a,o1,c1,w) 
  // S2(w,i,k,a) += (    1.00000000) D1(i,o2) W4(w,o2,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor W4ca_sigma_coov_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x4_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X4_TYPE1_ERI_V)
      (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), W4ca_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x4_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X4_TYPE1_ERI_V)
      (sa, ia, sk, ik, W4ca_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(w,o2,o3,a) += (    1.00000000) T2(c1,o2,o3,o1) V2(a,o1,c1,w) 
  // S2(w,i,k,a) += (    1.00000000) D2(i,o2,o3,k) W5(w,o2,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W5caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x5_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X5_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W5caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x5_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X5_TYPE1_ERI_V)
    (sa, ia, W5caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 6, [2]
  // W6(w,o2,k,a) += (    1.00000000) T2(c1,o2,k,o1) V2(a,o1,c1,w) 
  // S2(w,i,k,a) += (   -2.00000000) D1(i,o2) W6(w,o2,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W6caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x6_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X6_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W6caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x6_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X6_TYPE1_ERI_V)
    (sa, ia, W6caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 7, [2]
  // W7(w,o1,o4,o3,o2,a) += (    1.00000000) T2(c1,o1,o4,o3) V2(a,w,c1,o2) 
  // S2(w,i,k,a) += (    1.00000000) D3(i,k,o3,o1,o4,o2) W7(w,o1,o4,o3,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W7caaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x7_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X7_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), W7caaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x7_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X7_TYPE1_ERI_V)
      (sa, ia, so3, io3, W7caaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 8, [2]
  // W8(w,c1,i,o3,o1,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,w,c1,o2) 
  // S2(w,i,k,a) += (    1.00000000) T2(c1,o1,k,o3) W8(w,c1,i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    orz::DTensor W8ccaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xccaa(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x8_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X8_TYPE1_ERI_V)
      (sa, ia, so3, io3, V2_sym.cptr(), W8ccaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x8_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X8_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), W8ccaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 9, [2]
  // W9(w,c1,i,o2,o3,a) += (    1.00000000) D2(i,o2,o3,o1) V2(a,w,c1,o1) 
  // S2(w,i,k,a) += (    1.00000000) T2(c1,o2,o3,k) W9(w,c1,i,o2,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W9ccaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xccaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_coov_cooo_no0_x9_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X9_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W9ccaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x9_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X9_TYPE1_ERI_V)
      (sa, ia, sk, ik, T2b.cptr(), W9ccaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 10, [2]
  // W10(w,o2,o3,a) += (    1.00000000) T2(c1,o2,o1,o3) V2(a,w,c1,o1) 
  // S2(w,i,k,a) += (   -2.00000000) D2(i,k,o3,o2) W10(w,o2,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor W10ca_sigma_coov_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, so3^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x10_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X10_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), W10ca_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x10_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X10_TYPE1_ERI_V)
      (sa, ia, so3, io3, W10ca_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 11, [2]
  // W11(w,o2,k,a) += (    1.00000000) T2(c1,o2,o1,k) V2(a,w,c1,o1) 
  // S2(w,i,k,a) += (   -2.00000000) D1(i,o2) W11(w,o2,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor W11ca_sigma_coov_cooo(orz::mr::sizeof_sympack_Xca(symblockinfo, sk^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x11_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X11_TYPE1_ERI_V)
      (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), W11ca_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x11_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X11_TYPE1_ERI_V)
      (sa, ia, sk, ik, W11ca_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 12, [2]
  // W12(w,o2,o3,a) += (    1.00000000) T2(c1,o2,o3,o1) V2(a,w,c1,o1) 
  // S2(w,i,k,a) += (    1.00000000) D2(i,k,o3,o2) W12(w,o2,o3,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W12caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x12_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X12_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W12caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x12_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X12_TYPE1_ERI_V)
    (sa, ia, W12caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 13, [2]
  // W13(w,o2,k,a) += (    1.00000000) T2(c1,o2,k,o1) V2(a,w,c1,o1) 
  // S2(w,i,k,a) += (    1.00000000) D1(i,o2) W13(w,o2,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W13caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x13_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X13_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W13caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x13_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X13_TYPE1_ERI_V)
    (sa, ia, W13caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 14, [2]
  // W14(i,o5,o2,a) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(a,o3,o1,o4) 
  // S2(w,i,k,a) += (    2.00000000) T2(w,o2,k,o5) W14(i,o5,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W14aa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so5^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x14_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X14_TYPE1_ERI_V)
      (sa, ia, so5, io5, V2_sym.cptr(), W14aa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x14_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X14_TYPE1_ERI_V)
      (sa, ia, so5, io5, T2b.cptr(), W14aa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 15, [2]
  // W15(i,o5,o2,a) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(a,o3,o1,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o2,o5,k) W15(i,o5,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W15aaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_coov_cooo_no0_x15_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X15_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W15aaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x15_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X15_TYPE1_ERI_V)
      (sa, ia, sk, ik, T2b.cptr(), W15aaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 16, [2]
  // W16(i,o4,o1,o5,k,a) += (    1.00000000) D3(i,o3,o4,o1,o5,o2) V2(a,o3,k,o2) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o1,o5,o4) W16(i,o4,o1,o5,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W16aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x16_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X16_TYPE1_ERI_V)
      (sa, ia, so4, io4, V2_sym.cptr(), W16aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x16_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X16_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), W16aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 17, [2]
  // W17(i,k,o5,o2,o1,a) += (    1.00000000) D3(i,o3,o4,k,o5,o2) V2(a,o3,o1,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o2,o1,o5) W17(i,k,o5,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W17aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so5^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x17_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X17_TYPE1_ERI_V)
      (sa, ia, so5, io5, V2_sym.cptr(), W17aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x17_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X17_TYPE1_ERI_V)
      (sa, ia, so5, io5, T2b.cptr(), W17aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 18, [2]
  // W18(i,o2,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o3,o1,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o2,o1,k) W18(i,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W18aaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_coov_cooo_no0_x18_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X18_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W18aaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x18_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X18_TYPE1_ERI_V)
      (sa, ia, sk, ik, T2b.cptr(), W18aaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 19, [2]
  // W19(i,o4,o2,k,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o3,k,o1) 
  // S2(w,i,k,a) += (    2.00000000) T2(w,o2,o1,o4) W19(i,o4,o2,k,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W19aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x19_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X19_TYPE1_ERI_V)
      (sa, ia, so4, io4, V2_sym.cptr(), W19aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x19_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X19_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), W19aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 20, [2]
  // W20(i,o2,o5,k,o1,a) += (    1.00000000) D3(i,o3,o4,o2,o5,k) V2(a,o3,o1,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o2,o5,o1) W20(i,o2,o5,k,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W20aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x20_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X20_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W20aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x20_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X20_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W20aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 21, [2]
  // W21(i,o2,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o3,o1,o4) 
  // S2(w,i,k,a) += (    2.00000000) T2(w,o2,k,o1) W21(i,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W21aa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x21_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X21_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W21aa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x21_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X21_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W21aa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 22, [2]
  // W22(i,o4,o2,k,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o3,k,o1) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o2,o4,o1) W22(i,o4,o2,k,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W22aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x22_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X22_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W22aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x22_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X22_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W22aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 23, [2]
  // W23(i,k,o5,o3,o1,a) += (    1.00000000) D3(i,k,o4,o2,o5,o3) V2(a,o1,o2,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o3,o1,o5) W23(i,k,o5,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W23aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so5^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x23_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X23_TYPE1_ERI_V)
      (sa, ia, so5, io5, V2_sym.cptr(), W23aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x23_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X23_TYPE1_ERI_V)
      (sa, ia, so5, io5, T2b.cptr(), W23aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 24, [2]
  // W24(i,o3,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o1,o2,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o3,o1,k) W24(i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W24aaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sa));
  FC_FUNC(g_if_sigma_coov_cooo_no0_x24_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X24_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), W24aaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x24_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X24_TYPE1_ERI_V)
      (sa, ia, sk, ik, T2b.cptr(), W24aaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 25, [2]
  // W25(i,o4,o2,o1,k,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o1,k,o3) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o2,o1,o4) W25(i,o4,o2,o1,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    orz::DTensor W25aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so4^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x25_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X25_TYPE1_ERI_V)
      (sa, ia, so4, io4, V2_sym.cptr(), W25aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x25_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X25_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), W25aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 26, [2]
  // W26(i,o3,o1,k,o5,a) += (    1.00000000) D3(i,o3,o1,k,o2,o4) V2(a,o5,o2,o4) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o3,o1,o5) W26(i,o3,o1,k,o5,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    orz::DTensor W26aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so5^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x26_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X26_TYPE1_ERI_V)
      (sa, ia, so5, io5, V2_sym.cptr(), W26aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x26_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X26_TYPE1_ERI_V)
      (sa, ia, so5, io5, T2b.cptr(), W26aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 27, [2]
  // W27(i,o3,o1,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o1,o2,o4) 
  // S2(w,i,k,a) += (    2.00000000) T2(w,o3,k,o1) W27(i,o3,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W27aa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x27_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X27_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W27aa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x27_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X27_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W27aa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 28, [2]
  // W28(i,o3,o4,o1,k,a) += (    1.00000000) D2(i,o3,o4,o2) V2(a,o1,k,o2) 
  // S2(w,i,k,a) += (   -1.00000000) T2(w,o3,o4,o1) W28(i,o3,o4,o1,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor W28aaaa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xaaaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_coov_cooo_no0_x28_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X28_TYPE1_ERI_V)
      (sa, ia, so1, io1, V2_sym.cptr(), W28aaaa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x28_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X28_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), W28aaaa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 29, [2]
  // W29(w,o3,o4,a) += (    1.00000000) T2(w,o3,o2,o1) V2(a,o1,o2,o4) 
  // S2(w,i,k,a) += (   -1.00000000) D2(i,o3,o4,k) W29(w,o3,o4,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W29caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x29_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X29_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W29caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x29_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X29_TYPE1_ERI_V)
    (sa, ia, W29caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 30, [2]
  // W30(w,o3,k,a) += (    1.00000000) T2(w,o3,o2,o1) V2(a,o1,k,o2) 
  // S2(w,i,k,a) += (    2.00000000) D1(i,o3) W30(w,o3,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W30caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x30_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X30_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W30caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x30_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X30_TYPE1_ERI_V)
    (sa, ia, W30caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 31, [2]
  // W31(w,o2,o1,a) += (    1.00000000) T2(w,o2,o3,o4) V2(a,o3,o1,o4) 
  // S2(w,i,k,a) += (   -1.00000000) D2(i,k,o1,o2) W31(w,o2,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W31caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x31_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X31_TYPE1_ERI_V)
      (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), W31caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x31_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X31_TYPE1_ERI_V)
    (sa, ia, W31caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 32, [2]
  // W32(w,o1,k,a) += (    1.00000000) T2(w,o1,o2,o3) V2(a,o2,k,o3) 
  // S2(w,i,k,a) += (   -1.00000000) D1(i,o1) W32(w,o1,k,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W32caa_sigma_coov_cooo(orz::mr::sizeof_sympack_Xcaa(symblockinfo, sa));
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x32_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO0_X32_TYPE1_ERI_V)
      (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), W32caa_sigma_coov_cooo.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_coov_cooo_no1_x32_type1_eri_v,G_IF_SIGMA_COOV_COOO_NO1_X32_TYPE1_ERI_V)
    (sa, ia, W32caa_sigma_coov_cooo.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@loadD4C(v,begin)
  //*-- FEMTO begins --//*
  // Label : d4c_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  orz::DTensor C5;
  orz::LoadBin(ctinp.dir()/(format("D4C_g[%d]")%i_eri).str()) >> C5;

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_coov_cooo
  { 
  // No. 0, [1]
  // S2(w,i,k,a) += (   -1.00000000) C5(o1,k,o2,o5,i,a) T2(w,o5,o1,o2) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x0_type1_d4c_v,G_IF_SIGMA_COOV_COOO_NO0_X0_TYPE1_D4C_V)
      (sa, ia, so2, io2, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadD4C(v,end)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_coov_cooo", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
