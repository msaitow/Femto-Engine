                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ccvv_ccvv.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//       #                #########      #     #   # 
//  ########## ##########         #   #######  #   # 
//      #    #         #          #    # #     #   # 
//      #    #        #   ########     # #     #   # 
//     #     #     # #           #  ##########    #  
//    #   # #       #            #       #       #   
//   #     #         #    ########       #     ##    

//                                   Generated date : Wed Feb 19 15:55:31 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ccvv_ccvv(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [1]
  // S2(y,w,c,a) += (    8.00000000) Fc0 T2(y,w,c,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x0_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X0_TYPE1_NOERI)
      (sa, ia, &Fc0, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [1]
  // S2(w,y,a,c) += (   -4.00000000) Fc0 T2(y,w,a,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    if(hintmo.iproc_havingimo()[ic] == myrank) {           
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x1_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X1_TYPE1_NOERI)
      (sc, ic, &Fc0, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [1]
  // S2(y,w,c,a) += (   -8.00000000) Fc1(c1,w) T2(y,c1,c,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x2_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X2_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [1]
  // S2(w,y,a,c) += (    4.00000000) Fc1(c1,w) T2(y,c1,a,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    if(hintmo.iproc_havingimo()[ic] == myrank) {           
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x3_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X3_TYPE1_NOERI)
      (sc, ic, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [1]
  // S2(y,w,c,a) += (    4.00000000) Fc1(c1,y) T2(w,c1,c,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x4_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X4_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [1]
  // S2(w,y,a,c) += (   -8.00000000) Fc1(c1,y) T2(w,c1,a,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    if(hintmo.iproc_havingimo()[ic] == myrank) {           
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x5_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X5_TYPE1_NOERI)
      (sc, ic, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  if(myrank == 0){
  { 
  // No. 6, [2]
  // W0() += (    1.00000000) D1(o1,o2) Fc1(o1,o2) 
  // S2(y,w,c,a) += (    8.00000000) W0 T2(y,w,c,a) 
  double flops = 0; // Flop count
  double W0_sigma_ccvv_ccvv = 0;
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x6_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X6_TYPE1_NOERI)
    (&W0_sigma_ccvv_ccvv, nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x6_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO1_X6_TYPE1_NOERI)
      (sa, ia, &W0_sigma_ccvv_ccvv, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 7, [2]
  // W1() += (    1.00000000) D1(o1,o2) Fc1(o1,o2) 
  // S2(w,y,a,c) += (   -4.00000000) W1 T2(y,w,a,c) 
  double flops = 0; // Flop count
  double W1_sigma_ccvv_ccvv = 0;
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x7_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X7_TYPE1_NOERI)
    (&W1_sigma_ccvv_ccvv, nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x7_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO1_X7_TYPE1_NOERI)
      (sc, ic, &W1_sigma_ccvv_ccvv, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 8, [1]
  // S2(y,w,c,a) += (    8.00000000) Fc1(c,v1) T2(y,w,v1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x8_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X8_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 9, [1]
  // S2(y,w,c,a) += (   -4.00000000) Fc1(c,v1) T2(w,y,v1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x9_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X9_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 10, [1]
  // S2(w,y,a,c) += (    8.00000000) Fc1(a,v1) T2(w,y,v1,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    if(hintmo.iproc_havingimo()[ic] == myrank) {           
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x10_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X10_TYPE1_NOERI)
      (sc, ic, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 11, [1]
  // S2(w,y,a,c) += (   -4.00000000) Fc1(a,v1) T2(y,w,v1,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    if(hintmo.iproc_havingimo()[ic] == myrank) {           
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x11_type1_noeri,G_IF_SIGMA_CCVV_CCVV_NO0_X11_TYPE1_NOERI)
      (sc, ic, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccvv_ccvv
  { 
  // No. 0, [1]
  // S2(y,w,c,a) += (    8.00000000) T2(c1,c2,c,a) V2(c1,y,c2,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x0_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X0_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(y,w,c,a) += (   -4.00000000) T2(c1,c2,c,a) V2(c1,w,c2,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x1_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X1_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [2]
  // W0(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,y,o1,o2) 
  // S2(w,y,a,c) += (   -8.00000000) T2(w,c1,a,c) W0(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W0c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x2_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X2_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W0c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x2_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X2_TYPE1_ERI_C)
      (sc, ic, sc1, ic1, T2b.cptr(), W0c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [2]
  // W1(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,y,o1,o2) 
  // S2(y,w,c,a) += (    4.00000000) T2(w,c1,c,a) W1(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W1c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x3_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X3_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W1c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x3_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X3_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W1c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [2]
  // W2(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,w,o1,o2) 
  // S2(w,y,a,c) += (    4.00000000) T2(y,c1,a,c) W2(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W2c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x4_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X4_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W2c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x4_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X4_TYPE1_ERI_C)
      (sc, ic, sc1, ic1, T2b.cptr(), W2c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [2]
  // W3(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,w,o1,o2) 
  // S2(y,w,c,a) += (   -8.00000000) T2(y,c1,c,a) W3(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W3c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x5_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X5_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W3c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x5_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X5_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W3c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [2]
  // W4(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,o1,y,o2) 
  // S2(w,y,a,c) += (    4.00000000) T2(w,c1,a,c) W4(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W4c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x6_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X6_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W4c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x6_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X6_TYPE1_ERI_C)
      (sc, ic, sc1, ic1, T2b.cptr(), W4c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [2]
  // W5(c1,y) += (    1.00000000) D1(o1,o2) V2(c1,o1,y,o2) 
  // S2(y,w,c,a) += (   -2.00000000) T2(w,c1,c,a) W5(c1,y) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W5c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x7_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X7_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W5c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x7_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X7_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W5c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [2]
  // W6(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,o1,w,o2) 
  // S2(w,y,a,c) += (   -2.00000000) T2(y,c1,a,c) W6(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W6c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x8_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X8_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W6c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x8_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X8_TYPE1_ERI_C)
      (sc, ic, sc1, ic1, T2b.cptr(), W6c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [2]
  // W7(c1,w) += (    1.00000000) D1(o1,o2) V2(c1,o1,w,o2) 
  // S2(y,w,c,a) += (    4.00000000) T2(y,c1,c,a) W7(c1,w) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W7c_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xc(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x9_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO0_X9_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W7c_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x9_type1_eri_c,G_IF_SIGMA_CCVV_CCVV_NO1_X9_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W7c_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_ccvv_ccvv
  //  >> Intermediates for the type 2 contractions are defined here << 
  double W0_sigma_ccvv_ccvv = 0;
  double W1_sigma_ccvv_ccvv = 0;
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccvv_ccvv
  { 
  // No. 0, [1]
  // W0() += (    1.00000000) D2(o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x0_type1_eri_o,G_IF_SIGMA_CCVV_CCVV_NO0_X0_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), &W0_sigma_ccvv_ccvv, nir, nsym, psym, &flops);
  } // End scope

  { 
  // No. 1, [1]
  // W1() += (    1.00000000) D2(o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x1_type1_eri_o,G_IF_SIGMA_CCVV_CCVV_NO0_X1_TYPE1_ERI_O)
    (so1, io1, V2_sym.cptr(), &W1_sigma_ccvv_ccvv, nir, nsym, psym, &flops);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_ccvv_ccvv
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(y,w,c,a) += (    4.00000000) W0 T2(y,w,c,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x0_type2_eri_o,G_IF_SIGMA_CCVV_CCVV_NO0_X0_TYPE2_ERI_O)
      (sa, ia, &W0_sigma_ccvv_ccvv, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(w,y,a,c) += (   -2.00000000) W1 T2(y,w,a,c) 
  double flops = 0; // Flop count
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    T2b = T2.get_amp2(ic);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x1_type2_eri_o,G_IF_SIGMA_CCVV_CCVV_NO0_X1_TYPE2_ERI_O)
      (sc, ic, &W1_sigma_ccvv_ccvv, T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ccvv_ccvv
  { 
  // No. 0, [1]
  // S2(y,w,c,a) += (   -8.00000000) T2(y,c1,v1,a) V2(v1,c,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x0_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X0_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(y,w,c,a) += (    4.00000000) T2(y,c1,a,v1) V2(v1,c,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x1_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X1_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(y,w,c,a) += (    4.00000000) T2(w,c1,v1,a) V2(v1,c,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x2_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X2_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(y,w,c,a) += (   -8.00000000) T2(w,c1,a,v1) V2(v1,c,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x3_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X3_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // S2(w,y,a,c) += (   -8.00000000) T2(w,c1,v1,c) V2(v1,a,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x4_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X4_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // S2(w,y,a,c) += (    4.00000000) T2(w,c1,c,v1) V2(v1,a,c1,y) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x5_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X5_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // S2(w,y,a,c) += (    4.00000000) T2(y,c1,v1,c) V2(v1,a,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x6_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X6_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // S2(w,y,a,c) += (   -8.00000000) T2(y,c1,c,v1) V2(v1,a,c1,w) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x7_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X7_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 8, [1]
  // S2(y,w,c,a) += (   16.00000000) T2(w,c1,a,v1) V2(v1,c1,y,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x8_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X8_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 9, [1]
  // S2(y,w,c,a) += (   -8.00000000) T2(y,c1,a,v1) V2(v1,c1,w,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x9_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X9_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 10, [1]
  // S2(y,w,c,a) += (   -8.00000000) T2(w,c1,v1,a) V2(v1,c1,y,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x10_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X10_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // S2(y,w,c,a) += (    4.00000000) T2(y,c1,v1,a) V2(v1,c1,w,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x11_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X11_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 12, [1]
  // S2(w,y,a,c) += (   16.00000000) T2(y,c1,c,v1) V2(v1,c1,w,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x12_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X12_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 13, [1]
  // S2(w,y,a,c) += (   -8.00000000) T2(w,c1,c,v1) V2(v1,c1,y,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  T2b = T2.get_amp2(iv1);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x13_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X13_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 14, [1]
  // S2(w,y,a,c) += (   -8.00000000) T2(y,c1,v1,c) V2(v1,c1,w,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x14_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X14_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 15, [1]
  // S2(w,y,a,c) += (    4.00000000) T2(w,c1,v1,c) V2(v1,c1,y,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x15_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X15_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 16, [2]
  // W0(v1,c) += (    1.00000000) D1(o1,o2) V2(v1,c,o1,o2) 
  // S2(y,w,c,a) += (    8.00000000) T2(y,w,v1,a) W0(v1,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W0v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x16_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X16_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W0v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x16_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X16_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W0v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 17, [2]
  // W1(v1,c) += (    1.00000000) D1(o1,o2) V2(v1,c,o1,o2) 
  // S2(y,w,c,a) += (   -4.00000000) T2(y,w,a,v1) W1(v1,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W1v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x17_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X17_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W1v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x17_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X17_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W1v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 18, [2]
  // W2(v1,a) += (    1.00000000) D1(o1,o2) V2(v1,a,o1,o2) 
  // S2(w,y,a,c) += (    8.00000000) T2(y,w,c,v1) W2(v1,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W2v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x18_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X18_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W2v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x18_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X18_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), W2v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 19, [2]
  // W3(v1,a) += (    1.00000000) D1(o1,o2) V2(v1,a,o1,o2) 
  // S2(w,y,a,c) += (   -4.00000000) T2(y,w,v1,c) W3(v1,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W3v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x19_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X19_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W3v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x19_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X19_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), W3v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 20, [2]
  // W4(v1,c) += (    1.00000000) D1(o1,o2) V2(v1,o2,o1,c) 
  // S2(y,w,c,a) += (    2.00000000) T2(y,w,a,v1) W4(v1,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W4v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x20_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X20_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W4v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x20_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X20_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W4v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 21, [2]
  // W5(v1,c) += (    1.00000000) D1(o1,o2) V2(v1,o2,o1,c) 
  // S2(y,w,c,a) += (   -4.00000000) T2(y,w,v1,a) W5(v1,c) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W5v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x21_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X21_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W5v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x21_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X21_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), W5v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 22, [2]
  // W6(v1,a) += (    1.00000000) D1(o1,o2) V2(v1,o1,o2,a) 
  // S2(w,y,a,c) += (    2.00000000) T2(y,w,v1,c) W6(v1,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W6v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x22_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X22_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W6v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    T2b = T2.get_amp2(ic);
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x22_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X22_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), W6v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 23, [2]
  // W7(v1,a) += (    1.00000000) D1(o1,o2) V2(v1,o1,o2,a) 
  // S2(w,y,a,c) += (   -4.00000000) T2(y,w,c,v1) W7(v1,a) 
  double flops = 0; // Flop count
  int sv1(s_eri);
  int iv1(i_eri);
  orz::DTensor W7v_sigma_ccvv_ccvv(orz::mr::sizeof_sympack_Xv(symblockinfo, sv1));
  FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x23_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X23_TYPE1_ERI_V)
    (sv1, iv1, V2_sym.cptr(), W7v_sigma_ccvv_ccvv.cptr(), nir, nsym, psym, &flops);
  T2b = T2.get_amp2(iv1);
  for(int sc = 0;sc < nir;++sc){ 
  for(int ic = symblockinfo.psym()(sc,I_V,I_BEGIN);ic <= symblockinfo.psym()(sc,I_V,I_END);++ic){ 
    S2b = orz::DTensor(retval.namps_iamp()[ic]);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no1_x23_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO1_X23_TYPE1_ERI_V)
      (sc, ic, sv1, iv1, T2b.cptr(), W7v_sigma_ccvv_ccvv.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ic, S2b);
  }
  }
  } // End scope

  { 
  // No. 24, [1]
  // S2(y,w,c,a) += (    8.00000000) T2(w,y,v2,v1) V2(a,v2,c,v1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x24_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X24_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 25, [1]
  // S2(y,w,c,a) += (   -4.00000000) T2(w,y,v2,v1) V2(a,v1,c,v2) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccvv_ccvv_no0_x25_type1_eri_v,G_IF_SIGMA_CCVV_CCVV_NO0_X25_TYPE1_ERI_V)
      (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ccvv_ccvv", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
