                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_diag_ooov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  ___________                __               
//  \_   _____/____    _____ _/  |_  ____      
//   |    __)_/ __ \  /     \\   __\/  _ \ 
//   |     \ \  ___/ |  Y Y  \|  | (  <_> )  
//   \___  /  \___  >|__|_|  /|__|  \____/   
//       \/       \/       \/                

//                                   Generated date : Wed Feb 19 15:54:51 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::diag_ooov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const int num_sigma,
                                  const double Ecas) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "Hdiag" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor Hdiagb; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  { 
  // No. 0, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D3(i,m,k,k,o1,i) Fc1(m,o1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x0_type1_noeri,G_IF_DIAG_OOOV_NO0_X0_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 1, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D2(i,i,k,k) Fc1(m,m) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x1_type1_noeri,G_IF_DIAG_OOOV_NO0_X1_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 2, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D3(i,m,k,k,m,o1) Fc1(i,o1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x2_type1_noeri,G_IF_DIAG_OOOV_NO0_X2_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 3, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D2(i,o1,k,k) Fc1(i,o1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x3_type1_noeri,G_IF_DIAG_OOOV_NO0_X3_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 4, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D3(i,m,k,o1,m,i) Fc1(k,o1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x4_type1_noeri,G_IF_DIAG_OOOV_NO0_X4_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 5, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D2(i,i,k,o1) Fc1(k,o1) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x5_type1_noeri,G_IF_DIAG_OOOV_NO0_X5_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 6, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D3(i,m,k,k,m,i) Fc1(a,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x6_type1_noeri,G_IF_DIAG_OOOV_NO0_X6_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 7, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D2(i,i,k,k) Fc1(a,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x7_type1_noeri,G_IF_DIAG_OOOV_NO0_X7_TYPE1_NOERI)
      (sa, ia, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 8, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) Ecas D3(i,m,k,k,m,i) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x8_type1_noeri,G_IF_DIAG_OOOV_NO0_X8_TYPE1_NOERI)
      (sa, ia, &Ecas, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();

  { 
  // No. 9, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) Ecas D2(i,i,k,k) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x9_type1_noeri,G_IF_DIAG_OOOV_NO0_X9_TYPE1_NOERI)
      (sa, ia, &Ecas, Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : diag_ooov
  { 
  // No. 0, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D4(m,i,k,k,o3,o1,i,o2) V2(m,o2,o1,o3) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 

    int imoi = amo2imo[im] - nclosed;                              
    int imoj = amo2imo[ii] - nclosed;                              
                                                                                         
    // Generate D4 by cumulant expansion ....                                            
    if(ctinp.use_d4cum_of()){
    FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
      (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
       rdm4_ij_sliced.cptr(), imoi, imoj);                                               
    rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, im, sm, ii, si, rdm4_ij_sliced);    
    flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
    } // End if
    // Slice the already existing 8-index 4-RDM ....                                            
    else{
    const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
    rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, im, sm, ii, si, rdm4_ij_sliced);    
    }
    FC_FUNC(g_if_set_d4,G_IF_SET_D4)(sm, si, im, ii, rdm4_sym.cptr(), nir, nsym, psym);  
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 

      int imoi = amo2imo[im] - nclosed;                              
      int imoj = amo2imo[ii] - nclosed;                              
                                                                                           
      // Generate D4 by cumulant expansion ....                                            
      if(ctinp.use_d4cum_of()){
      FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
        (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
         rdm4_ij_sliced.cptr(), imoi, imoj);                                               
      rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, im, sm, ii, si, rdm4_ij_sliced);    
      flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
      } // End if
      // Slice the already existing 8-index 4-RDM ....                                            
      else{
      const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
      rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, im, sm, ii, si, rdm4_ij_sliced);    
      }
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(sm, si, im, ii, rdm4_sym.cptr(), nir, nsym, psym);  
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_ooov_no0_x0_type1_eri_o,G_IF_DIAG_OOOV_NO0_X0_TYPE1_ERI_O)
        (sa, ia, si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, Hdiagb);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D3(i,i,k,k,o1,o2) V2(m,m,o1,o2) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x1_type1_eri_o,G_IF_DIAG_OOOV_NO0_X1_TYPE1_ERI_O)
      (sa, ia, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D3(i,o1,k,k,o2,i) V2(m,o1,m,o2) 
  double flops = 0; // Flop count
  int sm(s_eri);
  int im(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x2_type1_eri_o,G_IF_DIAG_OOOV_NO0_X2_TYPE1_ERI_O)
      (sa, ia, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D4(i,m,k,k,m,o2,o3,o1) V2(i,o2,o1,o3) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 

    int imoi = amo2imo[ii] - nclosed;                              
    int imoj = amo2imo[im] - nclosed;                              
                                                                                         
    // Generate D4 by cumulant expansion ....                                            
    if(ctinp.use_d4cum_of()){
    FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
      (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
       rdm4_ij_sliced.cptr(), imoi, imoj);                                               
    rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
    flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
    } // End if
    // Slice the already existing 8-index 4-RDM ....                                            
    else{
    const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
    rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
    }
    FC_FUNC(g_if_set_d4,G_IF_SET_D4)(si, sm, ii, im, rdm4_sym.cptr(), nir, nsym, psym);  
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 

      int imoi = amo2imo[ii] - nclosed;                              
      int imoj = amo2imo[im] - nclosed;                              
                                                                                           
      // Generate D4 by cumulant expansion ....                                            
      if(ctinp.use_d4cum_of()){
      FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
        (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
         rdm4_ij_sliced.cptr(), imoi, imoj);                                               
      rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
      flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
      } // End if
      // Slice the already existing 8-index 4-RDM ....                                            
      else{
      const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
      rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
      }
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(si, sm, ii, im, rdm4_sym.cptr(), nir, nsym, psym);  
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_ooov_no0_x3_type1_eri_o,G_IF_DIAG_OOOV_NO0_X3_TYPE1_ERI_O)
        (sa, ia, si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, Hdiagb);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
  }
  }
  } // End scope

  { 
  // No. 4, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D3(i,o2,k,k,o3,o1) V2(i,o2,o1,o3) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x4_type1_eri_o,G_IF_DIAG_OOOV_NO0_X4_TYPE1_ERI_O)
      (sa, ia, si, ii, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 5, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D3(i,o2,k,k,m,o1) V2(i,o1,m,o2) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x5_type1_eri_o,G_IF_DIAG_OOOV_NO0_X5_TYPE1_ERI_O)
      (sa, ia, si, ii, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 6, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D4(k,o2,i,m,m,i,o3,o1) V2(k,o2,o1,o3) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 

      int imoi = amo2imo[ik] - nclosed;                              
      int imoj = amo2imo[io2] - nclosed;                              
                                                                                           
      // Generate D4 by cumulant expansion ....                                            
      if(ctinp.use_d4cum_of()){
      FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
        (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
         rdm4_ij_sliced.cptr(), imoi, imoj);                                               
      rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, ik, sk, io2, so2, rdm4_ij_sliced);    
      flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
      } // End if
      // Slice the already existing 8-index 4-RDM ....                                            
      else{
      const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
      rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, ik, sk, io2, so2, rdm4_ij_sliced);    
      }
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(sk, so2, ik, io2, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_diag_ooov_no0_x6_type1_eri_o,G_IF_DIAG_OOOV_NO0_X6_TYPE1_ERI_O)
        (sa, ia, sk, ik, so2, io2, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 7, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D3(i,i,k,o2,o3,o1) V2(k,o2,o1,o3) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x7_type1_eri_o,G_IF_DIAG_OOOV_NO0_X7_TYPE1_ERI_O)
      (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 8, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D3(i,m,o1,k,o2,i) V2(k,o1,m,o2) 
  double flops = 0; // Flop count
  int sk(s_eri);
  int ik(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x8_type1_eri_o,G_IF_DIAG_OOOV_NO0_X8_TYPE1_ERI_O)
      (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 9, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D3(i,m,k,o2,m,o1) V2(i,o1,k,o2) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x9_type1_eri_o,G_IF_DIAG_OOOV_NO0_X9_TYPE1_ERI_O)
      (sa, ia, si, ii, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 10, [1]
  // Hdiag(i,k,m,a) += (   -1.00000000) D2(i,o2,k,o1) V2(i,o2,k,o1) 
  double flops = 0; // Flop count
  int si(s_eri);
  int ii(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_ooov_no0_x10_type1_eri_o,G_IF_DIAG_OOOV_NO0_X10_TYPE1_ERI_O)
      (sa, ia, si, ii, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 11, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D4(o1,o2,i,m,k,k,m,i) V2(o1,o2,a,a) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 

      int imoi = amo2imo[io1] - nclosed;                              
      int imoj = amo2imo[io2] - nclosed;                              
                                                                                           
      // Generate D4 by cumulant expansion ....                                            
      if(ctinp.use_d4cum_of()){
      FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
        (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
         rdm4_ij_sliced.cptr(), imoi, imoj);                                               
      rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, io1, so1, io2, so2, rdm4_ij_sliced);    
      flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
      } // End if
      // Slice the already existing 8-index 4-RDM ....                                            
      else{
      const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
      rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, io1, so1, io2, so2, rdm4_ij_sliced);    
      }
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, so2, io1, io2, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_diag_ooov_no0_x11_type1_eri_o,G_IF_DIAG_OOOV_NO0_X11_TYPE1_ERI_O)
        (sa, ia, so1, io1, so2, io2, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  } // End scope

  { 
  // No. 12, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D4(o1,k,m,i,i,m,k,o2) V2(o1,a,o2,a) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 

    int imoi = amo2imo[io1] - nclosed;                              
    int imoj = amo2imo[ik] - nclosed;                              
                                                                                         
    // Generate D4 by cumulant expansion ....                                            
    if(ctinp.use_d4cum_of()){
    FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
      (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
       rdm4_ij_sliced.cptr(), imoi, imoj);                                               
    rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, io1, so1, ik, sk, rdm4_ij_sliced);    
    flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
    } // End if
    // Slice the already existing 8-index 4-RDM ....                                            
    else{
    const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
    rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, io1, so1, ik, sk, rdm4_ij_sliced);    
    }
    FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, sk, io1, ik, rdm4_sym.cptr(), nir, nsym, psym);  
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 

      int imoi = amo2imo[io1] - nclosed;                              
      int imoj = amo2imo[ik] - nclosed;                              
                                                                                           
      // Generate D4 by cumulant expansion ....                                            
      if(ctinp.use_d4cum_of()){
      FC_FUNC(f_mr_rdm4_cumulant_partial_opt,F_MR_RDM4_CUMULANT_PARTIAL_OPT)                  
        (nocc, 0, rdmPack.rdm1().cptr(), rdmPack.rdm2().cptr(), rdmPack.cum2().cptr(), rdmPack.rdm3().cptr(),     
         rdm4_ij_sliced.cptr(), imoi, imoj);                                               
      rdm4_sym = orz::mr::sympack_rdm4_2(symblockinfo, io1, so1, ik, sk, rdm4_ij_sliced);    
      flops += nocc*nocc*nocc*nocc*nocc*nocc*70;
      } // End if
      // Slice the already existing 8-index 4-RDM ....                                            
      else{
      const double* rdm4_ij_sliced = rdm4.cptr() + (imoi*nocc+imoj)*nocc*nocc*nocc*nocc*nocc*nocc;
      rdm4_sym = orz::mr::sympack_rdm4_2x(symblockinfo, io1, so1, ik, sk, rdm4_ij_sliced);    
      }
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, sk, io1, ik, rdm4_sym.cptr(), nir, nsym, psym);  
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_ooov_no0_x12_type1_eri_o,G_IF_DIAG_OOOV_NO0_X12_TYPE1_ERI_O)
        (sa, ia, sk, ik, so1, io1, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
      retval.acc_amp2(ia, Hdiagb);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : diag_ooov
  { 
  // No. 0, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D3(i,i,k,k,o1,o2) V2(a,a,o1,o2) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_ooov_no0_x0_type1_eri_v,G_IF_DIAG_OOOV_NO0_X0_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 1, [1]
  // Hdiag(i,k,m,a) += (    2.00000000) D3(i,m,k,k,o1,i) V2(a,a,m,o1) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_ooov_no0_x1_type1_eri_v,G_IF_DIAG_OOOV_NO0_X1_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 2, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D2(i,i,k,k) V2(a,a,m,m) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_ooov_no0_x2_type1_eri_v,G_IF_DIAG_OOOV_NO0_X2_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 3, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D3(i,i,k,o1,o2,k) V2(a,o1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_ooov_no0_x3_type1_eri_v,G_IF_DIAG_OOOV_NO0_X3_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 4, [1]
  // Hdiag(i,k,m,a) += (    2.00000000) D3(i,k,k,o1,m,i) V2(a,m,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_ooov_no0_x4_type1_eri_v,G_IF_DIAG_OOOV_NO0_X4_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

  { 
  // No. 5, [1]
  // Hdiag(i,k,m,a) += (    1.00000000) D2(i,k,k,i) V2(a,m,m,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
  FC_FUNC(g_if_diag_ooov_no0_x5_type1_eri_v,G_IF_DIAG_OOOV_NO0_X5_TYPE1_ERI_V)
    (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, Hdiagb);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@D4C.contractions(end)

  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("diag_ooov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
