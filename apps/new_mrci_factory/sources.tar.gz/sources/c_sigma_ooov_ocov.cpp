                                                                                
#include <orz/orz.h>
#include <orz/openmp.h>
#include <orz/cblas.h>
#include <orz/clapack.h>
#include <tensor/tensor.h>
#include <sci/hint/para_disttools.h>
#include <sci/icmr/mr.h>
#include <sci/icmr/mr_f.h>
#include <sci/icmr/mrclass_input.h>
#include <sci/icmr/mrclass_symblock.h>
#include <sci/icmr/mrclass_hintmo.h>
#include <sci/icmr/mrclass_rdmpack.h>
#include <sci/icmr/mrclass_bareamppack.h>
#include <sci/icmr/mrclass_orthamppack.h>
#include <sci/icmr/diaghessian.h>
#include <sci/icmr/symamp2.h>
#include <sci/icmr/femto/femto.h>
#include <sci/icmr/femto/elems/c_sigma_ooov_ocov.h>                                  
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//Timing object                                                                 
extern std::vector<boost::tuple<std::string, double, double> > my_timer;

// File stream object to write timing data                              
extern std::ofstream file_timing;                                       

// Core integrals                                                               
extern double Fc0;                                                              
extern double h1_int;                                                           

// CAS-Fock matrix                                                              
extern double h6_int;                                                           

//  __/\\\\\\\\\\\\\\\____________________________________________________________________                                   
//   _\/\\\///////////_____________________________________________________________________                                             
//    _\/\\\_______________________________________________________/\\\_____________________                                         
//     _\/\\\\\\\\\\\__________/\\\\\\\\______/\\\\\__/\\\\\_____/\\\\\\\\\\\______/\\\\\____ 
//      _\/\\\///////_________/\\\/////\\\___/\\\///\\\\\///\\\__\////\\\////_____/\\\///\\\__               
//       _\/\\\_______________/\\\\\\\\\\\___\/\\\_\//\\\__\/\\\_____\/\\\________/\\\__\//\\\_       
//        _\/\\\______________\//\\///////____\/\\\__\/\\\__\/\\\_____\/\\\_/\\___\//\\\__/\\\__            
//         _\/\\\_______________\//\\\\\\\\\\__\/\\\__\/\\\__\/\\\_____\//\\\\\_____\///\\\\\/___    
//          _\///_________________\//////////___\///___\///___\///_______\/////________\/////_____                                   

//                                   Generated date : Wed Feb 19 15:55:29 2014

                                                                                
// ***************************************************************************  
// orz::mr::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::mr::BareAmpPack orz::mr::femto::sigma_ooov_ocov(const orz::mr::Input &ctinp,                                    
                                  const orz::mr::SymBlockInfo &symblockinfo,                                 
                                  const orz::mr::HintMO &hintmo,                                             
                                  const int alloc_type,                                                      
                                  const orz::mr::RdmPack &rdmPack,                                           
                                  const orz::DTensor &rdm4,                                                  
                                  const orz::mr::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                 
                                                                                                                 
  // set up nmo nclosed, nocc                                                                                    
  const FC_INT nclosed = ctinp.nclosed();                                                                        
  const FC_INT nocc    = ctinp.nocc();                                                                           
  const FC_INT nvir    = ctinp.nvir();                                                                           
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                  
  const FC_INT nir     = symblockinfo.nir();                                                                     
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                     
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                     
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                  
                                                                                                                 
  std::ostringstream stm;                                                                                        
  stm << num_sigma;                                                                                              
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::mr::BareAmpPack retval                                                                                    
    = orz::mr::BareAmpPack(ctinp, symblockinfo, name_of_sigma, alloc_type); // Sigma(a, a', e, e') tensor        
                                                                                                                 
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                 
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                         
  orz::DTensor rdm4_ij_sliced(ctinp.use_d4cum_of() ? nocc*nocc*nocc*nocc*nocc*nocc : 0);                         
  // set nproc, myrank                      
  const int nproc = orz::world().size();    
  const int myrank = orz::world().rank();   

  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = (myrank == 0) ? orz::mr::sympack_int1(symblockinfo, moint1) : orz::DTensor(); // moint1=(IR-COV index)
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  

  // Timing object
  orz::ProgressTimer time_sigma(false);

  if(nclosed){
  if(nocc){
  //*-- FEMTO begins --//*
  // Label : noeri
  {

  //*-- Entering to take the type 1 contractions --*//
  if(myrank == 0){
  { 
  // No. 0, [2]
  // W0(c1,i,m,k,o2,o3) += (    1.00000000) D3(i,m,k,o1,o2,o3) Fc1(c1,o1) 
  // S2(i,k,m,a) += (   -1.00000000) T2(o3,c1,o2,a) W0(c1,i,m,k,o2,o3) 
  double flops = 0; // Flop count
  orz::DTensor W0caaaaa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xcaaaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ooov_ocov_no0_x0_type1_noeri,G_IF_SIGMA_OOOV_OCOV_NO0_X0_TYPE1_NOERI)
    (W0caaaaa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x0_type1_noeri,G_IF_SIGMA_OOOV_OCOV_NO1_X0_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W0caaaaa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  if(myrank == 0){
  { 
  // No. 1, [2]
  // W1(c1,i,o1,k) += (    1.00000000) D2(i,o1,k,o2) Fc1(c1,o2) 
  // S2(i,k,m,a) += (   -1.00000000) T2(o1,c1,m,a) W1(c1,i,o1,k) 
  double flops = 0; // Flop count
  orz::DTensor W1caaa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xcaaa(symblockinfo, 0));
  FC_FUNC(g_if_sigma_ooov_ocov_no0_x1_type1_noeri,G_IF_SIGMA_OOOV_OCOV_NO0_X1_TYPE1_NOERI)
    (W1caaa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x1_type1_noeri,G_IF_SIGMA_OOOV_OCOV_NO1_X1_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W1caaa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope
  } // End myrank

  { 
  // No. 2, [2]
  // W2(o1,a) += (    1.00000000) Fc1(c1,o2) T2(o1,c1,o2,a) 
  // S2(i,k,m,a) += (   -1.00000000) D2(i,m,k,o1) W2(o1,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    if(hintmo.iproc_havingimo()[ia] == myrank) {           
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor W2a_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x2_type1_noeri,G_IF_SIGMA_OOOV_OCOV_NO0_X2_TYPE1_NOERI)
      (sa, ia, T2b.cptr(), W2a_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x2_type1_noeri,G_IF_SIGMA_OOOV_OCOV_NO1_X2_TYPE1_NOERI)
      (sa, ia, W2a_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
    } // End para
  }
  }
  } // End scope
  //orz::world().barrier();


  } // End femto
  //*-- FEMTO ends --//*

//-@ERI.contractions(begin)

//-@loadERI(c,begin)
  //*-- FEMTO begins --//*
  // Label : eri_c
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ooov_ocov
  { 
  // No. 0, [2]
  // W0(c1,i,o3,k) += (    1.00000000) D3(i,o3,k,o2,o4,o1) V2(c1,o2,o1,o4) 
  // S2(i,k,m,a) += (   -1.00000000) T2(o3,c1,m,a) W0(c1,i,o3,k) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W0aaa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ooov_ocov_no0_x0_type1_eri_c,G_IF_SIGMA_OOOV_OCOV_NO0_X0_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W0aaa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x0_type1_eri_c,G_IF_SIGMA_OOOV_OCOV_NO1_X0_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W0aaa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [2]
  // W1(c1,i,k,o4,o1,m) += (    1.00000000) D3(i,o3,k,o2,o4,o1) V2(c1,o2,m,o3) 
  // S2(i,k,m,a) += (   -1.00000000) T2(o1,c1,o4,a) W1(c1,i,k,o4,o1,m) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  orz::DTensor W1aaaaa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaaaaa(symblockinfo, sc1));
  FC_FUNC(g_if_sigma_ooov_ocov_no0_x1_type1_eri_c,G_IF_SIGMA_OOOV_OCOV_NO0_X1_TYPE1_ERI_C)
    (sc1, ic1, V2_sym.cptr(), W1aaaaa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x1_type1_eri_c,G_IF_SIGMA_OOOV_OCOV_NO1_X1_TYPE1_ERI_C)
      (sa, ia, sc1, ic1, T2b.cptr(), W1aaaaa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(c,end)

//-@loadERI(a,begin)
  //*-- FEMTO begins --//*
  // Label : eri_o
  {

//-@type(2).declaration(begin)
  // --  Title : sigma_ooov_ocov
  //  >> Intermediates for the type 2 contractions are defined here << 
  orz::DTensor W0aaav_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaaav(symblockinfo, 0));
  orz::DTensor W1aaav_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaaav(symblockinfo, 0));
  orz::DTensor W2aaav_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaaav(symblockinfo, 0));
  orz::DTensor W3aaav_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaaav(symblockinfo, 0));
//-@type(2).declaration(end)
  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_O,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_O,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ooov_ocov
  { 
  // No. 0, [1]
  // W0(o3,o2,o4,a) += (    1.00000000) T2(o3,c1,o1,a) V2(o1,c1,o2,o4) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x0_type1_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X0_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W0aaav_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // W1(o2,m,o3,a) += (    1.00000000) T2(o2,c1,o1,a) V2(o1,c1,m,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x1_type1_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X1_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W1aaav_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // W2(o2,o4,o3,a) += (    1.00000000) T2(o2,c1,o1,a) V2(o1,o4,c1,o3) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x2_type1_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X2_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W2aaav_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // W3(o3,m,o2,a) += (    1.00000000) T2(o3,c1,o1,a) V2(o1,m,c1,o2) 
  double flops = 0; // Flop count
  int so1(s_eri);
  int io1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x3_type1_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X3_TYPE1_ERI_O)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W3aaav_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

//-@type(2).contraction(begin)
  // -- Title : sigma_ooov_ocov
  //*-- Entering to take the type 2 contractions --*//
  { 
  // No. 0, [1]
  // S2(i,k,m,a) += (   -1.00000000) D3(i,m,k,o3,o4,o2) W0(o3,o2,o4,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x0_type2_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X0_TYPE2_ERI_O)
      (sa, ia, W0aaav_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 1, [1]
  // S2(i,k,m,a) += (   -1.00000000) D2(i,o3,k,o2) W1(o2,m,o3,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x1_type2_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X1_TYPE2_ERI_O)
      (sa, ia, W1aaav_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 2, [1]
  // S2(i,k,m,a) += (   -1.00000000) D3(i,m,k,o3,o4,o2) W2(o2,o4,o3,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x2_type2_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X2_TYPE2_ERI_O)
      (sa, ia, W2aaav_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

  { 
  // No. 3, [1]
  // S2(i,k,m,a) += (   -1.00000000) D2(i,o3,k,o2) W3(o3,m,o2,a) 
  double flops = 0; // Flop count
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x3_type2_eri_o,G_IF_SIGMA_OOOV_OCOV_NO0_X3_TYPE2_ERI_O)
      (sa, ia, W3aaav_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(2).contraction(end)
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(a,end)

//-@loadERI(v,begin)
  //*-- FEMTO begins --//*
  // Label : eri_v
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_V,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_V,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
  V2 <<= 0.0;                                                                          
  shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(i_eri);
  for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
    // Load a signle record of integals                                                             
    const int &imo2 = loadbuf_ptr->i0;                                                              
    const int &imo3 = loadbuf_ptr->i1;                                                              
    const int &imo4 = loadbuf_ptr->i2;                                                              
    const double &v = loadbuf_ptr->v;                                                               
    V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
  }                                                                                                 
  const orz::DTensor V2_sym = orz::mr::sympack_int2(symblockinfo, i_eri, s_eri, V2); // V2=(IR-COV index) 

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ooov_ocov
  { 
  // No. 0, [2]
  // W0(o3,o1,o2,a) += (    1.00000000) T2(c1,o3,v1,o1) V2(a,v1,c1,o2) 
  // S2(i,k,m,a) += (   -1.00000000) D3(i,m,k,o2,o1,o3) W0(o3,o1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W0aa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x0_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO0_X0_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W0aa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x0_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO1_X0_TYPE1_ERI_V)
      (sa, ia, so1, io1, W0aa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 1, [2]
  // W1(o2,m,o1,a) += (    1.00000000) T2(c1,o2,v1,m) V2(a,v1,c1,o1) 
  // S2(i,k,m,a) += (   -1.00000000) D2(i,o2,k,o1) W1(o2,m,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    orz::DTensor W1aa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^sa));
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x1_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO0_X1_TYPE1_ERI_V)
      (sa, ia, sm, im, T2b.cptr(), V2_sym.cptr(), W1aa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x1_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO1_X1_TYPE1_ERI_V)
      (sa, ia, sm, im, W1aa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 2, [2]
  // W2(o1,a) += (    1.00000000) T2(c1,o1,v1,o2) V2(a,v1,c1,o2) 
  // S2(i,k,m,a) += (   -1.00000000) D2(i,m,k,o1) W2(o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W2a_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x2_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO0_X2_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), W2a_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_ocov_no1_x2_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO1_X2_TYPE1_ERI_V)
    (sa, ia, W2a_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 3, [2]
  // W3(o3,o1,o2,a) += (    1.00000000) T2(c1,o3,v1,o1) V2(a,o2,c1,v1) 
  // S2(i,k,m,a) += (    2.00000000) D3(i,m,k,o2,o1,o3) W3(o3,o1,o2,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor W3aa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaa(symblockinfo, so1^sa));
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x3_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO0_X3_TYPE1_ERI_V)
      (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), W3aa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x3_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO1_X3_TYPE1_ERI_V)
      (sa, ia, so1, io1, W3aa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 4, [2]
  // W4(o2,m,o1,a) += (    1.00000000) T2(c1,o2,v1,m) V2(a,o1,c1,v1) 
  // S2(i,k,m,a) += (    2.00000000) D2(i,o2,k,o1) W4(o2,m,o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    T2b = T2.get_amp2(im);
    orz::DTensor W4aa_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xaa(symblockinfo, sm^sa));
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x4_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO0_X4_TYPE1_ERI_V)
      (sa, ia, sm, im, T2b.cptr(), V2_sym.cptr(), W4aa_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
    FC_FUNC(g_if_sigma_ooov_ocov_no1_x4_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO1_X4_TYPE1_ERI_V)
      (sa, ia, sm, im, W4aa_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  }
  }
  retval.acc_amp2(ia, S2b);
  } // End scope

  { 
  // No. 5, [2]
  // W5(o1,a) += (    1.00000000) T2(c1,o1,v1,o2) V2(a,o2,c1,v1) 
  // S2(i,k,m,a) += (    2.00000000) D2(i,m,k,o1) W5(o1,a) 
  double flops = 0; // Flop count
  int sa(s_eri);
  int ia(i_eri);
  S2b = orz::DTensor(retval.namps_iamp()[ia]);
  orz::DTensor W5a_sigma_ooov_ocov(orz::mr::sizeof_sympack_Xa(symblockinfo, sa));
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x5_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO0_X5_TYPE1_ERI_V)
      (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), W5a_sigma_ooov_ocov.cptr(), nir, nsym, psym, &flops);
  }
  }
  FC_FUNC(g_if_sigma_ooov_ocov_no1_x5_type1_eri_v,G_IF_SIGMA_OOOV_OCOV_NO1_X5_TYPE1_ERI_V)
    (sa, ia, W5a_sigma_ooov_ocov.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
  retval.acc_amp2(ia, S2b);
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadERI(v,end)

//-@ERI.contractions(end)

//-@D4C.contractions(begin)

//-@loadD4C(c,begin)
  //*-- FEMTO begins --//*
  // Label : d4c_c
  {

  for(int s_eri = 0;s_eri < nir;++s_eri){ 
  for(int i_eri = symblockinfo.psym()(s_eri,I_C,I_BEGIN);i_eri <= symblockinfo.psym()(s_eri,I_C,I_END);++i_eri){ 
  if(hintmo.iproc_havingimo()[i_eri] == myrank) {           
  orz::DTensor C5;
  orz::LoadBin(ctinp.dir()/(format("D4C_g[%d]")%i_eri).str()) >> C5;

  //*-- Entering to take the type 1 contractions --*//
//-@type(1).contraction(begin)
  // -- Title : sigma_ooov_ocov
  { 
  // No. 0, [1]
  // S2(i,k,m,a) += (   -1.00000000) C5(i,m,o1,o4,k,c1) T2(o4,c1,o1,a) 
  double flops = 0; // Flop count
  int sc1(s_eri);
  int ic1(i_eri);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    T2b = T2.get_amp2(ia);
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ooov_ocov_no0_x0_type1_d4c_c,G_IF_SIGMA_OOOV_OCOV_NO0_X0_TYPE1_D4C_C)
      (sa, ia, sc1, ic1, C5.cptr(), T2b.cptr(), S2b.cptr(), nir, nsym, psym, &flops);
    retval.acc_amp2(ia, S2b);
  }
  }
  } // End scope

//-@type(1).contraction(end)

  } // End myrank
  }
  }
  orz::world().barrier();

  } // End femto
  //*-- FEMTO ends --//*

//-@loadD4C(c,end)

//-@D4C.contractions(end)

  } // Guard
  } // Guard
  // Do timing!
  my_timer.push_back(boost::make_tuple("sigma_ooov_ocov", time_sigma.elapsed_cputime(), time_sigma.elapsed_wallclocktime()));
  file_timing << "* " << boost::format("%20s : %10.7f %10.7f ") % my_timer.back().get<0>() % my_timer.back().get<1>() % my_timer.back().get<2>() << endl;
  flush(file_timing);

  return retval; 
} 
