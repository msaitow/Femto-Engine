

#ifndef C_FOCK_V_COOV_OCOV_H
#define C_FOCK_V_COOV_OCOV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//        :::::::::: ::::::::::   :::   ::: ::::::::::: :::::::: 
//       :+:        :+:         :+:+: :+:+:    :+:    :+:    :+: 
//      +:+        +:+        +:+ +:+:+ +:+   +:+    +:+    +:+  
//     :#::+::#   +#++:++#   +#+  +:+  +#+   +#+    +#+    +:+   
//    +#+        +#+        +#+       +#+   +#+    +#+    +#+    
//   #+#        #+#        #+#       #+#   #+#    #+#    #+#     
//  ###        ########## ###       ###   ###     ########       

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x0_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X0_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const h6_int, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x1_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x1_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X1_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const W0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x2_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X2_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const h6_int, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x3_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X3_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x3_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X3_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const W1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x4_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X4_TYPE1_NOERI)
  (const double * const P1, const double * const W2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x4_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X4_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x5_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X5_TYPE1_NOERI)
  (const double * const P1, const double * const W3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x5_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X5_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x6_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X6_TYPE1_NOERI)
  (const double * const P1, const double * const W4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x6_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X6_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x7_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X7_TYPE1_NOERI)
  (const double * const P1, const double * const W5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x7_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X7_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x8_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X8_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const W6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x8_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X8_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const P1, const double * const W6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x9_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X9_TYPE1_NOERI)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const W7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x9_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X9_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const P1, const double * const W7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no0_x10_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO0_X10_TYPE1_NOERI)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const W8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

void FC_FUNC(g_if_fock_v_coov_ocov_no1_x10_type1_noeri,G_IF_FOCK_V_COOV_OCOV_NO1_X10_TYPE1_NOERI)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const P1, const double * const W8, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym, const double * const);

      
 }     
       
       
 #endif
       
       
 