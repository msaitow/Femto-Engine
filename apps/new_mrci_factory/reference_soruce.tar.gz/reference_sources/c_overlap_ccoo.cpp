                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_overlap_ccoo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//                                                              
//   _______________                                  ______    
//  |          |                 .'. .`. `````|`````.~      ~.  
//  |______    |______         .'   `   `.    |    |          | 
//  |          |             .'           `.  |    |          | 
//  |          |___________.'               `.|     `.______.'  
//                                                              

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::overlap_ccoo(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "O2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor O2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* O2(w,y,i,k)  <--  (    1.00000000) D2(i,o2,k,o1) T2(w,y,o2,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_overlap_ccoo_no0_x0, G_IF_OVERLAP_CCOO_NO0_X0)
        (sk, ik, so1, io1, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.1
  //* O2(w,y,i,k)  <--  (    1.00000000) D2(i,o1,k,o2) T2(y,w,o2,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_overlap_ccoo_no0_x1, G_IF_OVERLAP_CCOO_NO0_X1)
        (sk, ik, so1, io1, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.2
  //* O2(w,y,i,k)  <--  (   -2.00000000) D1(k,o1) T2(w,y,i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_overlap_ccoo_no0_x2, G_IF_OVERLAP_CCOO_NO0_X2)
        (sk, ik, so1, io1, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.3
  //* O2(w,y,i,k)  <--  (    1.00000000) D1(k,o1) T2(y,w,i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_overlap_ccoo_no0_x3, G_IF_OVERLAP_CCOO_NO0_X3)
        (sk, ik, so1, io1, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.4
  //* O2(w,y,i,k)  <--  (    1.00000000) D1(k,o1) T2(w,y,o1,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_overlap_ccoo_no0_x4, G_IF_OVERLAP_CCOO_NO0_X4)
        (si, ii, sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.5
  //* O2(w,y,i,k)  <--  (   -2.00000000) D1(k,o1) T2(y,w,o1,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_overlap_ccoo_no0_x5, G_IF_OVERLAP_CCOO_NO0_X5)
        (si, ii, sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.6
  //* O2(w,y,i,k)  <--  (   -2.00000000) D1(i,o1) T2(y,w,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_overlap_ccoo_no0_x6, G_IF_OVERLAP_CCOO_NO0_X6)
        (sk, ik, so1, io1, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.7
  //* O2(w,y,i,k)  <--  (    1.00000000) D1(i,o1) T2(w,y,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_overlap_ccoo_no0_x7, G_IF_OVERLAP_CCOO_NO0_X7)
        (sk, ik, so1, io1, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.8
  //* O2(w,y,i,k)  <--  (    1.00000000) D1(i,o1) T2(y,w,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_overlap_ccoo_no0_x8, G_IF_OVERLAP_CCOO_NO0_X8)
      (sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.9
  //* O2(w,y,i,k)  <--  (   -2.00000000) D1(i,o1) T2(w,y,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_overlap_ccoo_no0_x9, G_IF_OVERLAP_CCOO_NO0_X9)
      (sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.10
  //* O2(w,y,i,k)  <--  (    4.00000000) T2(w,y,i,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_overlap_ccoo_no0_x10, G_IF_OVERLAP_CCOO_NO0_X10)
      (sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.11
  //* O2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,i,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    O2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_overlap_ccoo_no0_x11, G_IF_OVERLAP_CCOO_NO0_X11)
      (sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, O2b);
  }
  }
  }


  {
  // No.12
  //* O2(w,y,i,k)  <--  (    4.00000000) T2(y,w,k,i) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      O2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_overlap_ccoo_no0_x12, G_IF_OVERLAP_CCOO_NO0_X12)
        (si, ii, sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, O2b);
    }
    }
  }
  }
  }


  {
  // No.13
  //* O2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,k,i) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      O2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_overlap_ccoo_no0_x13, G_IF_OVERLAP_CCOO_NO0_X13)
        (si, ii, sk, ik, T2b.cptr(), O2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, O2b);
    }
    }
  }
  }
  }

  return retval; 
} 
