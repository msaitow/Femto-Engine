                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_cooo_g.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//       #                #########      #     #   # 
//  ########## ##########         #   #######  #   # 
//      #    #         #          #    # #     #   # 
//      #    #        #   ########     # #     #   # 
//     #     #     # #           #  ##########    #  
//    #   # #       #            #       #       #   
//   #     #         #    ########       #     ##    

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_cooo_g(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const int num_sigma,
                                  const double T0) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                


  {
  // No.0
  //* S2(w,i,k,m)  <--  (   -1.00000000) T0 D2(i,m,o1,k) h(w,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x0, G_IF_SIGMA_COOO_G_NO0_X0)
      (sm, im, &T0, moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.1
  //* S2(w,i,k,m)  <--  (    2.00000000) T0 D1(i,m) h(w,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x1, G_IF_SIGMA_COOO_G_NO0_X1)
      (sm, im, &T0, moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.2
  //* S2(w,i,k,m)  <--  (    4.00000000) T0 D1(i,m) Y0(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y0 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_y2, G_IF_SIGMA_COOO_G_Y2)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x2, G_IF_SIGMA_COOO_G_NO0_X2)
      (sm, im, &T0, Y0.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.3
  //* S2(w,i,k,m)  <--  (   -2.00000000) T0 D1(i,m) Y1(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y1 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_y3, G_IF_SIGMA_COOO_G_Y3)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x3, G_IF_SIGMA_COOO_G_NO0_X3)
      (sm, im, &T0, Y1.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.4
  //* S2(w,i,k,m)  <--  (   -1.00000000) T0 D1(i,k) h(w,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x4, G_IF_SIGMA_COOO_G_NO0_X4)
      (sm, im, &T0, moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.5
  //* S2(w,i,k,m)  <--  (   -2.00000000) T0 D2(i,m,o1,k) Y2(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y2 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_y5, G_IF_SIGMA_COOO_G_Y5)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x5, G_IF_SIGMA_COOO_G_NO0_X5)
      (sm, im, &T0, Y2.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.6
  //* S2(w,i,k,m)  <--  (    1.00000000) T0 D2(i,m,o1,k) Y3(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y3 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_y6, G_IF_SIGMA_COOO_G_Y6)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x6, G_IF_SIGMA_COOO_G_NO0_X6)
      (sm, im, &T0, Y3.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.7
  //* S2(w,i,k,m)  <--  (   -2.00000000) T0 D1(i,k) Y4(w,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y4 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_y7, G_IF_SIGMA_COOO_G_Y7)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x7, G_IF_SIGMA_COOO_G_NO0_X7)
      (sm, im, &T0, Y4.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.8
  //* S2(w,i,k,m)  <--  (    1.00000000) T0 D1(i,k) Y5(w,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y5 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_y8, G_IF_SIGMA_COOO_G_Y8)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_g_no0_x8, G_IF_SIGMA_COOO_G_NO0_X8)
      (sm, im, &T0, Y5.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.9
  //* S2(w,i,k,m)  <--  (   -1.00000000) T0 D3(i,m,o1,k,o2,o3) V2(w,o1,o2,o3) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_g_no0_x9, G_IF_SIGMA_COOO_G_NO0_X9)
        (sm, im, sw, iw, &T0, V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.10
  //* S2(w,i,k,m)  <--  (    2.00000000) T0 D2(i,m,o2,o1) V2(w,k,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_g_no0_x10, G_IF_SIGMA_COOO_G_NO0_X10)
        (sm, im, sw, iw, &T0, V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.11
  //* S2(w,i,k,m)  <--  (   -1.00000000) T0 D2(i,m,o2,o1) V2(w,o2,k,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_g_no0_x11, G_IF_SIGMA_COOO_G_NO0_X11)
        (sm, im, sw, iw, &T0, V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.12
  //* S2(w,i,k,m)  <--  (   -1.00000000) T0 D2(i,k,o2,o1) V2(m,w,o1,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_no0_x12, G_IF_SIGMA_COOO_G_NO0_X12)
      (sm, im, &T0, V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.13
  //* S2(w,i,k,m)  <--  (   -1.00000000) T0 D2(i,o2,o1,k) V2(m,o2,w,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_no0_x13, G_IF_SIGMA_COOO_G_NO0_X13)
      (sm, im, &T0, V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.14
  //* S2(w,i,k,m)  <--  (    2.00000000) T0 D1(i,o1) V2(m,o1,w,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_no0_x14, G_IF_SIGMA_COOO_G_NO0_X14)
      (sm, im, &T0, V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.15
  //* S2(w,i,k,m)  <--  (   -1.00000000) T0 D1(i,o1) V2(m,w,k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_g_no0_x15, G_IF_SIGMA_COOO_G_NO0_X15)
      (sm, im, &T0, V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }

  return retval; 
} 
