                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_diag_coov.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//      ______                  __           
//     / ____/___   ____ ___   / /_ ____     
//    / /_   / _ \ / __ `__ \ / __// __ \ 
//   / __/  /  __// / / / / // /_ / /_/ /    
//  /_/     \___//_/ /_/ /_/ \__/ \____/  

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::diag_coov(const orz::ct::Input &ctinp,                                    
					 const orz::ct::SymBlockInfo &symblockinfo,                                
					 const orz::ct::HintMO &hintmo,                                            
					 const orz::ct::RdmPack &rdmPack_sym,                                      
					 const orz::DTensor &rdm4,                                                 
					 const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "Hdiag" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor Hdiagb; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor rdm4_sym;                                                                                        


  {
  // No.0
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) Y0 D2(i,i,k,k) 
  // The effective tensor is detected .... 
  double Y0 = 0;
  FC_FUNC(g_if_diag_coov_y0, G_IF_DIAG_COOV_Y0)
    (moint1_sym.cptr(), &Y0, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x0, G_IF_DIAG_COOV_NO0_X0)
      (sa, ia, &Y0, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.1
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D2(i,i,k,k) h(w,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x1, G_IF_DIAG_COOV_NO0_X1)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.2
  //* Hdiag(w,i,k,a)  <--  (   -1.00000000) D2(i,i,k,k) h(a,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x2, G_IF_DIAG_COOV_NO0_X2)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.3
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) Y1 D2(i,i,k,k) 
  // The effective tensor is detected .... 
  double Y1 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y3, G_IF_DIAG_COOV_Y3)
      (sc1, ic1, V2_sym.cptr(), &Y1, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x3, G_IF_DIAG_COOV_NO0_X3)
      (sa, ia, &Y1, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.4
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D2(i,i,k,k) Y2(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y2 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y4, G_IF_DIAG_COOV_Y4)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x4, G_IF_DIAG_COOV_NO0_X4)
      (sa, ia, Y2.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.5
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) Y3 D2(i,i,k,k) 
  // The effective tensor is detected .... 
  double Y3 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y5, G_IF_DIAG_COOV_Y5)
      (sc1, ic1, V2_sym.cptr(), &Y3, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x5, G_IF_DIAG_COOV_NO0_X5)
      (sa, ia, &Y3, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.6
  //* Hdiag(w,i,k,a)  <--  (   -1.00000000) D2(i,i,k,k) Y4(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y4 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y6, G_IF_DIAG_COOV_Y6)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x6, G_IF_DIAG_COOV_NO0_X6)
      (sa, ia, Y4.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.7
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D2(i,i,k,k) Y5(a,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y5 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y7, G_IF_DIAG_COOV_Y7)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x7, G_IF_DIAG_COOV_NO0_X7)
      (sa, ia, Y5.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.8
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D2(i,i,k,k) V2(a,a,w,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x8, G_IF_DIAG_COOV_NO0_X8)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.9
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D2(i,i,k,k) Y6(a,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y6 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y9, G_IF_DIAG_COOV_Y9)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x9, G_IF_DIAG_COOV_NO0_X9)
      (sa, ia, Y6.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.10
  //* Hdiag(w,i,k,a)  <--  (    4.00000000) Y7 D1(i,i) 
  // The effective tensor is detected .... 
  double Y7 = 0;
  FC_FUNC(g_if_diag_coov_y10, G_IF_DIAG_COOV_Y10)
    (moint1_sym.cptr(), &Y7, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x10, G_IF_DIAG_COOV_NO0_X10)
      (sa, ia, &Y7, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.11
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D1(i,i) h(w,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x11, G_IF_DIAG_COOV_NO0_X11)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.12
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D1(i,i) h(k,k) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x12, G_IF_DIAG_COOV_NO0_X12)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.13
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D1(i,i) h(a,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x13, G_IF_DIAG_COOV_NO0_X13)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.14
  //* Hdiag(w,i,k,a)  <--  (    4.00000000) Y8 D1(i,i) 
  // The effective tensor is detected .... 
  double Y8 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y14, G_IF_DIAG_COOV_Y14)
      (sc1, ic1, V2_sym.cptr(), &Y8, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x14, G_IF_DIAG_COOV_NO0_X14)
      (sa, ia, &Y8, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.15
  //* Hdiag(w,i,k,a)  <--  (   -4.00000000) D1(i,i) Y9(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y9 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y15, G_IF_DIAG_COOV_Y15)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x15, G_IF_DIAG_COOV_NO0_X15)
      (sa, ia, Y9.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.16
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) Y10 D1(i,i) 
  // The effective tensor is detected .... 
  double Y10 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y16, G_IF_DIAG_COOV_Y16)
      (sc1, ic1, V2_sym.cptr(), &Y10, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x16, G_IF_DIAG_COOV_NO0_X16)
      (sa, ia, &Y10, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.17
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D1(i,i) Y11(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y11 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y17, G_IF_DIAG_COOV_Y17)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x17, G_IF_DIAG_COOV_NO0_X17)
      (sa, ia, Y11.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.18
  //* Hdiag(w,i,k,a)  <--  (    4.00000000) D1(i,i) Y12(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y12 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y18, G_IF_DIAG_COOV_Y18)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x18, G_IF_DIAG_COOV_NO0_X18)
      (sa, ia, Y12.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.19
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D1(i,i) V2(w,w,k,k) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x19, G_IF_DIAG_COOV_NO0_X19)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.20
  //* Hdiag(w,i,k,a)  <--  (    4.00000000) D1(i,i) V2(w,k,w,k) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x20, G_IF_DIAG_COOV_NO0_X20)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.21
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D1(i,i) Y13(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y13 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y21, G_IF_DIAG_COOV_Y21)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x21, G_IF_DIAG_COOV_NO0_X21)
      (sa, ia, Y13.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.22
  //* Hdiag(w,i,k,a)  <--  (    4.00000000) D1(i,i) Y14(a,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y14 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y22, G_IF_DIAG_COOV_Y22)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x22, G_IF_DIAG_COOV_NO0_X22)
      (sa, ia, Y14.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.23
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D1(i,i) V2(a,a,w,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x23, G_IF_DIAG_COOV_NO0_X23)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.24
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D1(i,i) V2(a,w,w,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x24, G_IF_DIAG_COOV_NO0_X24)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.25
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D1(i,i) Y15(a,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y15 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y25, G_IF_DIAG_COOV_Y25)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x25, G_IF_DIAG_COOV_NO0_X25)
      (sa, ia, Y15.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.26
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D1(i,i) V2(a,a,k,k) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x26, G_IF_DIAG_COOV_NO0_X26)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.27
  //* Hdiag(w,i,k,a)  <--  (   -1.00000000) D1(i,i) V2(a,k,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x27, G_IF_DIAG_COOV_NO0_X27)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.28
  //* Hdiag(w,i,k,a)  <--  (   -1.00000000) D3(i,i,k,k,o1,o2) h(o1,o2) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x28, G_IF_DIAG_COOV_NO0_X28)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.29
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D2(i,i,o1,o2) h(o2,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x29, G_IF_DIAG_COOV_NO0_X29)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.30
  //* Hdiag(w,i,k,a)  <--  (    4.00000000) D2(i,i,o1,o2) Y16(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y16 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y30, G_IF_DIAG_COOV_Y30)
      (sc1, ic1, V2_sym.cptr(), Y16.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x30, G_IF_DIAG_COOV_NO0_X30)
      (sa, ia, Y16.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.31
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D2(i,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x31, G_IF_DIAG_COOV_NO0_X31)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.32
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D2(i,i,o1,o2) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x32, G_IF_DIAG_COOV_NO0_X32)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.33
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D2(i,i,o1,o2) Y17(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y17 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y33, G_IF_DIAG_COOV_Y33)
      (sc1, ic1, V2_sym.cptr(), Y17.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x33, G_IF_DIAG_COOV_NO0_X33)
      (sa, ia, Y17.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.34
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D2(i,i,o1,o2) V2(k,k,o1,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x34, G_IF_DIAG_COOV_NO0_X34)
        (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.35
  //* Hdiag(w,i,k,a)  <--  (   -1.00000000) D2(i,i,o1,o2) V2(k,o1,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x35, G_IF_DIAG_COOV_NO0_X35)
        (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.36
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D2(i,i,o1,o2) V2(a,a,o1,o2) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x36, G_IF_DIAG_COOV_NO0_X36)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.37
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D2(i,i,k,o1) h(k,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x37, G_IF_DIAG_COOV_NO0_X37)
      (sa, ia, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.38
  //* Hdiag(w,i,k,a)  <--  (   -4.00000000) D2(i,i,k,o1) Y18(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y18 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y38, G_IF_DIAG_COOV_Y38)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x38, G_IF_DIAG_COOV_NO0_X38)
      (sa, ia, Y18.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.39
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D2(i,i,k,o1) V2(w,w,k,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x39, G_IF_DIAG_COOV_NO0_X39)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.40
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D2(i,i,k,o1) Y19(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y19 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y40, G_IF_DIAG_COOV_Y40)
      (sc1, ic1, V2_sym.cptr(), Y19.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x40, G_IF_DIAG_COOV_NO0_X40)
      (sa, ia, Y19.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.41
  //* Hdiag(w,i,k,a)  <--  (   -4.00000000) D2(i,i,k,o1) V2(w,k,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x41, G_IF_DIAG_COOV_NO0_X41)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.42
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D2(i,i,k,o1) V2(a,a,k,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x42, G_IF_DIAG_COOV_NO0_X42)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.43
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D3(i,i,k,k,o1,o2) Y20(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y20 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y43, G_IF_DIAG_COOV_Y43)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x43, G_IF_DIAG_COOV_NO0_X43)
      (sa, ia, Y20.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.44
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D3(i,i,k,k,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x44, G_IF_DIAG_COOV_NO0_X44)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.45
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D3(i,i,k,k,o1,o2) Y21(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y21 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_y45, G_IF_DIAG_COOV_Y45)
      (sc1, ic1, V2_sym.cptr(), Y21.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_diag_coov_no0_x45, G_IF_DIAG_COOV_NO0_X45)
      (sa, ia, Y21.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.46
  //* Hdiag(w,i,k,a)  <--  (   -1.00000000) D3(i,i,k,k,o1,o2) V2(a,a,o1,o2) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x46, G_IF_DIAG_COOV_NO0_X46)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.47
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D3(i,i,k,o1,o2,k) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x47, G_IF_DIAG_COOV_NO0_X47)
        (sa, ia, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.48
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D2(i,k,k,i) V2(a,w,w,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x48, G_IF_DIAG_COOV_NO0_X48)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.49
  //* Hdiag(w,i,k,a)  <--  (   -0.50000000) D4(o1,o3,i,i,k,k,o2,o4) V2(o1,o3,o2,o4) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      for(int sa = 0;sa < nir;++sa){ 
      for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
        Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
        // Load D4 from disk, or GA ....                                                     
        int imoi = amo2imo[io1] - nclosed;                              
        int imoj = amo2imo[io3] - nclosed;                              
                                                                                             
        orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice()).copy();    
        rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io1, so1, io3, so3, rdm4_ij_sliced);    
        FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, so3, io1, io3, rdm4_sym.cptr(), nir, nsym, psym);  
        FC_FUNC(g_if_diag_coov_no0_x49, G_IF_DIAG_COOV_NO0_X49)
          (sa, ia, so1, io1, so3, io3, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
        retval.acc_amp2(ia, Hdiagb);
        FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
      }
      }
    }
    }
  }
  }
  }


  {
  // No.50
  //* Hdiag(w,i,k,a)  <--  (    1.00000000) D3(i,i,o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x50, G_IF_DIAG_COOV_NO0_X50)
        (sa, ia, so1, io1, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.51
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D3(i,i,k,o2,o3,o1) V2(k,o2,o1,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_diag_coov_no0_x51, G_IF_DIAG_COOV_NO0_X51)
        (sa, ia, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.52
  //* Hdiag(w,i,k,a)  <--  (   -1.00000000) D3(i,o1,k,k,o2,i) V2(a,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x52, G_IF_DIAG_COOV_NO0_X52)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.53
  //* Hdiag(w,i,k,a)  <--  (    2.00000000) D2(i,o1,o2,i) V2(a,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x53, G_IF_DIAG_COOV_NO0_X53)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }


  {
  // No.54
  //* Hdiag(w,i,k,a)  <--  (   -2.00000000) D2(i,k,o1,i) V2(a,k,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_coov_no0_x54, G_IF_DIAG_COOV_NO0_X54)
      (sa, ia, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, Hdiagb);
  }
  }
  }

  return retval; 
} 
