                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_ccov_ccoo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//      _/_/_/_/                            _/             
//     _/        _/_/    _/_/_/  _/_/    _/_/_/_/    _/_/  
//    _/_/_/  _/_/_/_/  _/    _/    _/    _/      _/    _/ 
//   _/      _/        _/    _/    _/    _/      _/    _/  
//  _/        _/_/_/  _/    _/    _/      _/_/    _/_/     

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_ccov_ccoo(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* X(w,y,i,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,y,o2,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) X(w,y,i,o3) h(o3,a) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x0, G_IF_SIGMA_CCOV_CCOO_NO0_X0)
      (so1, io1, T2b.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x0, G_IF_SIGMA_CCOV_CCOO_NO1_X0)
      (sa, ia, Xccaa.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.1
  //* X(y,w,i,o1)  <--  (    1.00000000)  D2(i,o2,o1,o3) T2(y,w,o3,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) X(y,w,i,o1) h(o1,a) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x1, G_IF_SIGMA_CCOV_CCOO_NO0_X1)
      (so2, io2, T2b.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x1, G_IF_SIGMA_CCOV_CCOO_NO1_X1)
      (sa, ia, Xccaa.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.2
  //* X(o1,a)  <--  (    1.00000000)  D1(o1,o2) h(o2,a) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,i,o1) X(o1,a) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x2, G_IF_SIGMA_CCOV_CCOO_NO0_X2)
        (sa, ia, so1, io1, moint1_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x2, G_IF_SIGMA_CCOV_CCOO_NO1_X2)
        (sa, ia, so1, io1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.3
  //* X(o1,a)  <--  (    1.00000000)  D1(o1,o2) h(o2,a) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,i,o1) X(o1,a) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x3, G_IF_SIGMA_CCOV_CCOO_NO0_X3)
        (sa, ia, so1, io1, moint1_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x3, G_IF_SIGMA_CCOV_CCOO_NO1_X3)
        (sa, ia, so1, io1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.4
  //* X(o1,a)  <--  (    1.00000000)  D1(o1,o2) h(o2,a) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o1,i) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x4, G_IF_SIGMA_CCOV_CCOO_NO0_X4)
      (sa, ia, moint1_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x4, G_IF_SIGMA_CCOV_CCOO_NO1_X4)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.5
  //* X(o1,a)  <--  (    1.00000000)  D1(o1,o2) h(o2,a) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o1,i) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x5, G_IF_SIGMA_CCOV_CCOO_NO0_X5)
      (sa, ia, moint1_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x5, G_IF_SIGMA_CCOV_CCOO_NO1_X5)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.6
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,o2) h(o1,a) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x6, G_IF_SIGMA_CCOV_CCOO_NO0_X6)
        (sa, ia, so2, io2, T2b.cptr(), moint1_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x6, G_IF_SIGMA_CCOV_CCOO_NO1_X6)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.7
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,o2) Y0(o1,a) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o2) X(y,w,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y0 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y7, G_IF_SIGMA_CCOV_CCOO_Y7)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x7, G_IF_SIGMA_CCOV_CCOO_NO0_X7)
        (sa, ia, so2, io2, T2b.cptr(), Y0.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x7, G_IF_SIGMA_CCOV_CCOO_NO1_X7)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.8
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,o2) Y1(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y1 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y8, G_IF_SIGMA_CCOV_CCOO_Y8)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x8, G_IF_SIGMA_CCOV_CCOO_NO0_X8)
        (sa, ia, so2, io2, T2b.cptr(), Y1.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x8, G_IF_SIGMA_CCOV_CCOO_NO1_X8)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.9
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o1,o2) h(o1,a) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x9, G_IF_SIGMA_CCOV_CCOO_NO0_X9)
        (sa, ia, so2, io2, T2b.cptr(), moint1_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x9, G_IF_SIGMA_CCOV_CCOO_NO1_X9)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.10
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(y,w,o1,i) h(o1,a) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x10, G_IF_SIGMA_CCOV_CCOO_NO0_X10)
        (sa, ia, si, ii, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.11
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,i) h(o1,a) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x11, G_IF_SIGMA_CCOV_CCOO_NO0_X11)
        (sa, ia, si, ii, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.12
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,y,o1,i) Y2(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y2 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y12, G_IF_SIGMA_CCOV_CCOO_Y12)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x12, G_IF_SIGMA_CCOV_CCOO_NO0_X12)
        (sa, ia, si, ii, T2b.cptr(), Y2.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.13
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,y,o1,i) Y3(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y3 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y13, G_IF_SIGMA_CCOV_CCOO_Y13)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x13, G_IF_SIGMA_CCOV_CCOO_NO0_X13)
        (sa, ia, si, ii, T2b.cptr(), Y3.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.14
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o2,o1) h(o1,a) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x14, G_IF_SIGMA_CCOV_CCOO_NO0_X14)
        (sa, ia, so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x14, G_IF_SIGMA_CCOV_CCOO_NO1_X14)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.15
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o2,o1) Y4(o1,a) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o2) X(w,y,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y4 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y15, G_IF_SIGMA_CCOV_CCOO_Y15)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x15, G_IF_SIGMA_CCOV_CCOO_NO0_X15)
        (sa, ia, so1, io1, T2b.cptr(), Y4.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x15, G_IF_SIGMA_CCOV_CCOO_NO1_X15)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.16
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o2,o1) Y5(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y5 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y16, G_IF_SIGMA_CCOV_CCOO_Y16)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x16, G_IF_SIGMA_CCOV_CCOO_NO0_X16)
        (sa, ia, so1, io1, T2b.cptr(), Y5.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x16, G_IF_SIGMA_CCOV_CCOO_NO1_X16)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.17
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,w,o1,o2) h(o2,a) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x17, G_IF_SIGMA_CCOV_CCOO_NO0_X17)
        (sa, ia, so2, io2, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x17, G_IF_SIGMA_CCOV_CCOO_NO1_X17)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.18
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,i,o1) h(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x18, G_IF_SIGMA_CCOV_CCOO_NO0_X18)
        (sa, ia, so1, io1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.19
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,i,o1) h(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x19, G_IF_SIGMA_CCOV_CCOO_NO0_X19)
        (sa, ia, so1, io1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.20
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,w,i,o1) Y6(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y6 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y20, G_IF_SIGMA_CCOV_CCOO_Y20)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x20, G_IF_SIGMA_CCOV_CCOO_NO0_X20)
        (sa, ia, so1, io1, T2b.cptr(), Y6.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.21
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,w,i,o1) Y7(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y7 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y21, G_IF_SIGMA_CCOV_CCOO_Y21)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x21, G_IF_SIGMA_CCOV_CCOO_NO0_X21)
        (sa, ia, so1, io1, T2b.cptr(), Y7.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.22
  //* X(w,y,o1,o2,o3,a)  <--  (    1.00000000)  T2(c1,w,o1,o2) V2(a,o3,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,y,o1,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x22, G_IF_SIGMA_CCOV_CCOO_NO0_X22)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x22, G_IF_SIGMA_CCOV_CCOO_NO1_X22)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.23
  //* X(y,w,o2,o1,o3,a)  <--  (    1.00000000)  T2(c1,y,o2,o1) V2(a,o3,c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(y,w,o2,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x23, G_IF_SIGMA_CCOV_CCOO_NO0_X23)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x23, G_IF_SIGMA_CCOV_CCOO_NO1_X23)
        (sa, ia, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.24
  //* X(w,y,o2,o1,o3,a)  <--  (    1.00000000)  T2(w,c1,o2,o1) V2(a,o3,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,y,o2,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x24, G_IF_SIGMA_CCOV_CCOO_NO0_X24)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x24, G_IF_SIGMA_CCOV_CCOO_NO1_X24)
        (sa, ia, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.25
  //* X(y,w,o1,o2,o3,a)  <--  (    1.00000000)  T2(y,c1,o1,o2) V2(a,o3,c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(y,w,o1,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x25, G_IF_SIGMA_CCOV_CCOO_NO0_X25)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x25, G_IF_SIGMA_CCOV_CCOO_NO1_X25)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.26
  //* X(w,y,i,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,y,o2,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(w,y,i,o3) Y8(o3,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y8 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y26, G_IF_SIGMA_CCOV_CCOO_Y26)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x26, G_IF_SIGMA_CCOV_CCOO_NO0_X26)
      (so1, io1, T2b.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x26, G_IF_SIGMA_CCOV_CCOO_NO1_X26)
      (sa, ia, Xccaa.cptr(), Y8.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.27
  //* X(w,y,i,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,y,o2,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) X(w,y,i,o3) Y9(o3,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y9 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y27, G_IF_SIGMA_CCOV_CCOO_Y27)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x27, G_IF_SIGMA_CCOV_CCOO_NO0_X27)
      (so1, io1, T2b.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x27, G_IF_SIGMA_CCOV_CCOO_NO1_X27)
      (sa, ia, Xccaa.cptr(), Y9.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.28
  //* X(y,w,i,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(y,w,o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(y,w,i,o3) Y10(o3,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y10 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y28, G_IF_SIGMA_CCOV_CCOO_Y28)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x28, G_IF_SIGMA_CCOV_CCOO_NO0_X28)
      (so2, io2, T2b.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x28, G_IF_SIGMA_CCOV_CCOO_NO1_X28)
      (sa, ia, Xccaa.cptr(), Y10.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.29
  //* X(y,w,i,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(y,w,o1,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) X(y,w,i,o3) Y11(o3,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y11 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y29, G_IF_SIGMA_CCOV_CCOO_Y29)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x29, G_IF_SIGMA_CCOV_CCOO_NO0_X29)
      (so2, io2, T2b.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x29, G_IF_SIGMA_CCOV_CCOO_NO1_X29)
      (sa, ia, Xccaa.cptr(), Y11.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.30
  //* X(c1,y,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,c1,i,o2) X(c1,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x30, G_IF_SIGMA_CCOV_CCOO_NO0_X30)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x30, G_IF_SIGMA_CCOV_CCOO_NO1_X30)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.31
  //* X(y,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,c1,i,o2) X(y,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x31, G_IF_SIGMA_CCOV_CCOO_NO0_X31)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x31, G_IF_SIGMA_CCOV_CCOO_NO1_X31)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.32
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y12(o1,a) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,y,i,o2) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y12 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y32, G_IF_SIGMA_CCOV_CCOO_Y32)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x32, G_IF_SIGMA_CCOV_CCOO_NO0_X32)
        (sa, ia, so2, io2, Y12.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x32, G_IF_SIGMA_CCOV_CCOO_NO1_X32)
        (sa, ia, so2, io2, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.33
  //* X(c1,y,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,w,i,o2) X(c1,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x33, G_IF_SIGMA_CCOV_CCOO_NO0_X33)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x33, G_IF_SIGMA_CCOV_CCOO_NO1_X33)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.34
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y13(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,w,i,o2) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y13 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y34, G_IF_SIGMA_CCOV_CCOO_Y34)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x34, G_IF_SIGMA_CCOV_CCOO_NO0_X34)
        (sa, ia, so2, io2, Y13.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x34, G_IF_SIGMA_CCOV_CCOO_NO1_X34)
        (sa, ia, so2, io2, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.35
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y14(o1,a) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,w,i,o2) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y14 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y35, G_IF_SIGMA_CCOV_CCOO_Y35)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x35, G_IF_SIGMA_CCOV_CCOO_NO0_X35)
        (sa, ia, so2, io2, Y14.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x35, G_IF_SIGMA_CCOV_CCOO_NO1_X35)
        (sa, ia, so2, io2, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.36
  //* X(c1,w,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,i,o2) X(c1,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x36, G_IF_SIGMA_CCOV_CCOO_NO0_X36)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x36, G_IF_SIGMA_CCOV_CCOO_NO1_X36)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.37
  //* X(w,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,y,i,o2) X(w,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x37, G_IF_SIGMA_CCOV_CCOO_NO0_X37)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x37, G_IF_SIGMA_CCOV_CCOO_NO1_X37)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.38
  //* X(c1,w,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,c1,i,o2) X(c1,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x38, G_IF_SIGMA_CCOV_CCOO_NO0_X38)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x38, G_IF_SIGMA_CCOV_CCOO_NO1_X38)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.39
  //* X(c1,y,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(w,c1,o2,i) X(c1,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x39, G_IF_SIGMA_CCOV_CCOO_NO0_X39)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x39, G_IF_SIGMA_CCOV_CCOO_NO1_X39)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.40
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y15(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,y,o2,i) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y15 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y40, G_IF_SIGMA_CCOV_CCOO_Y40)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x40, G_IF_SIGMA_CCOV_CCOO_NO0_X40)
      (sa, ia, Y15.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x40, G_IF_SIGMA_CCOV_CCOO_NO1_X40)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.41
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y16(o1,a) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(w,y,o2,i) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y16 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y41, G_IF_SIGMA_CCOV_CCOO_Y41)
      (sc1, ic1, V2_sym.cptr(), Y16.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x41, G_IF_SIGMA_CCOV_CCOO_NO0_X41)
      (sa, ia, Y16.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x41, G_IF_SIGMA_CCOV_CCOO_NO1_X41)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.42
  //* X(c1,y,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,o2,i) X(c1,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x42, G_IF_SIGMA_CCOV_CCOO_NO0_X42)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x42, G_IF_SIGMA_CCOV_CCOO_NO1_X42)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.43
  //* X(y,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,w,o2,i) X(y,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x43, G_IF_SIGMA_CCOV_CCOO_NO0_X43)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x43, G_IF_SIGMA_CCOV_CCOO_NO1_X43)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.44
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y17(o1,a) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,w,o2,i) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y17 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y44, G_IF_SIGMA_CCOV_CCOO_Y44)
      (sc1, ic1, V2_sym.cptr(), Y17.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x44, G_IF_SIGMA_CCOV_CCOO_NO0_X44)
      (sa, ia, Y17.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x44, G_IF_SIGMA_CCOV_CCOO_NO1_X44)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.45
  //* X(c1,w,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,y,o2,i) X(c1,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x45, G_IF_SIGMA_CCOV_CCOO_NO0_X45)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x45, G_IF_SIGMA_CCOV_CCOO_NO1_X45)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.46
  //* X(c1,w,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,o2,i) X(c1,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x46, G_IF_SIGMA_CCOV_CCOO_NO0_X46)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x46, G_IF_SIGMA_CCOV_CCOO_NO1_X46)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.47
  //* X(w,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,c1,o2,i) X(w,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x47, G_IF_SIGMA_CCOV_CCOO_NO0_X47)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x47, G_IF_SIGMA_CCOV_CCOO_NO1_X47)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.48
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,c1,o1,o2) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x48, G_IF_SIGMA_CCOV_CCOO_NO0_X48)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x48, G_IF_SIGMA_CCOV_CCOO_NO1_X48)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.49
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,c1,o1,o2) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x49, G_IF_SIGMA_CCOV_CCOO_NO0_X49)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x49, G_IF_SIGMA_CCOV_CCOO_NO1_X49)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.50
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(c1,y,o1,o2) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x50, G_IF_SIGMA_CCOV_CCOO_NO0_X50)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x50, G_IF_SIGMA_CCOV_CCOO_NO1_X50)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.51
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o1,o2) Y18(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y18 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y51, G_IF_SIGMA_CCOV_CCOO_Y51)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x51, G_IF_SIGMA_CCOV_CCOO_NO0_X51)
        (sa, ia, so2, io2, T2b.cptr(), Y18.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x51, G_IF_SIGMA_CCOV_CCOO_NO1_X51)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.52
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o1,o2) Y19(o1,a) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(w,y,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y19 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y52, G_IF_SIGMA_CCOV_CCOO_Y52)
      (sc1, ic1, V2_sym.cptr(), Y19.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x52, G_IF_SIGMA_CCOV_CCOO_NO0_X52)
        (sa, ia, so2, io2, T2b.cptr(), Y19.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x52, G_IF_SIGMA_CCOV_CCOO_NO1_X52)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.53
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,o2) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x53, G_IF_SIGMA_CCOV_CCOO_NO0_X53)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x53, G_IF_SIGMA_CCOV_CCOO_NO1_X53)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.54
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,o2) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x54, G_IF_SIGMA_CCOV_CCOO_NO0_X54)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x54, G_IF_SIGMA_CCOV_CCOO_NO1_X54)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.55
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,o2) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x55, G_IF_SIGMA_CCOV_CCOO_NO0_X55)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x55, G_IF_SIGMA_CCOV_CCOO_NO1_X55)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.56
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(y,w,o1,i) Y20(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y20 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y56, G_IF_SIGMA_CCOV_CCOO_Y56)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x56, G_IF_SIGMA_CCOV_CCOO_NO0_X56)
        (sa, ia, si, ii, T2b.cptr(), Y20.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.57
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,c1,o1,i) V2(a,o1,c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x57, G_IF_SIGMA_CCOV_CCOO_NO0_X57)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.58
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,o1,i) V2(a,o1,c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x58, G_IF_SIGMA_CCOV_CCOO_NO0_X58)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.59
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,y,o1,i) V2(a,w,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x59, G_IF_SIGMA_CCOV_CCOO_NO0_X59)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.60
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,c1,o1,i) V2(a,o1,c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x60, G_IF_SIGMA_CCOV_CCOO_NO0_X60)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.61
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,c1,o1,i) V2(a,y,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x61, G_IF_SIGMA_CCOV_CCOO_NO0_X61)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.62
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,w,o1,i) V2(a,o1,c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x62, G_IF_SIGMA_CCOV_CCOO_NO0_X62)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.63
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,c1,o2,o1) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x63, G_IF_SIGMA_CCOV_CCOO_NO0_X63)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x63, G_IF_SIGMA_CCOV_CCOO_NO1_X63)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.64
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o2,o1) Y21(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y21 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y64, G_IF_SIGMA_CCOV_CCOO_Y64)
      (sc1, ic1, V2_sym.cptr(), Y21.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x64, G_IF_SIGMA_CCOV_CCOO_NO0_X64)
        (sa, ia, so1, io1, T2b.cptr(), Y21.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x64, G_IF_SIGMA_CCOV_CCOO_NO1_X64)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.65
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o2,o1) Y22(o1,a) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(y,w,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y22 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y65, G_IF_SIGMA_CCOV_CCOO_Y65)
      (sc1, ic1, V2_sym.cptr(), Y22.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x65, G_IF_SIGMA_CCOV_CCOO_NO0_X65)
        (sa, ia, so1, io1, T2b.cptr(), Y22.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x65, G_IF_SIGMA_CCOV_CCOO_NO1_X65)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.66
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(c1,y,o2,o1) V2(a,o1,c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x66, G_IF_SIGMA_CCOV_CCOO_NO0_X66)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x66, G_IF_SIGMA_CCOV_CCOO_NO1_X66)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.67
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(c1,y,o2,o1) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x67, G_IF_SIGMA_CCOV_CCOO_NO0_X67)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x67, G_IF_SIGMA_CCOV_CCOO_NO1_X67)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.68
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(c1,w,o2,o1) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x68, G_IF_SIGMA_CCOV_CCOO_NO0_X68)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x68, G_IF_SIGMA_CCOV_CCOO_NO1_X68)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.69
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,c1,o2,o1) V2(a,o1,c1,y) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x69, G_IF_SIGMA_CCOV_CCOO_NO0_X69)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x69, G_IF_SIGMA_CCOV_CCOO_NO1_X69)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.70
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,c1,o2,o1) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x70, G_IF_SIGMA_CCOV_CCOO_NO0_X70)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x70, G_IF_SIGMA_CCOV_CCOO_NO1_X70)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.71
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(w,y,i,o1) Y23(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y23 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y71, G_IF_SIGMA_CCOV_CCOO_Y71)
      (sc1, ic1, V2_sym.cptr(), Y23.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x71, G_IF_SIGMA_CCOV_CCOO_NO0_X71)
        (sa, ia, so1, io1, T2b.cptr(), Y23.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.72
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,c1,i,o1) V2(a,o1,c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x72, G_IF_SIGMA_CCOV_CCOO_NO0_X72)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.73
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,i,o1) V2(a,o1,c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x73, G_IF_SIGMA_CCOV_CCOO_NO0_X73)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.74
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,w,i,o1) V2(a,y,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x74, G_IF_SIGMA_CCOV_CCOO_NO0_X74)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.75
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,i,o1) V2(a,o1,c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x75, G_IF_SIGMA_CCOV_CCOO_NO0_X75)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.76
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,c1,i,o1) V2(a,w,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x76, G_IF_SIGMA_CCOV_CCOO_NO0_X76)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.77
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,y,i,o1) V2(a,o1,c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x77, G_IF_SIGMA_CCOV_CCOO_NO0_X77)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.78
  //* X(y,w,o2,o1,o3,a)  <--  (    1.00000000)  T2(y,c1,o2,o1) V2(a,w,c1,o3) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(y,w,o2,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x78, G_IF_SIGMA_CCOV_CCOO_NO0_X78)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x78, G_IF_SIGMA_CCOV_CCOO_NO1_X78)
        (sa, ia, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.79
  //* X(y,w,o1,o2,o3,a)  <--  (    1.00000000)  T2(c1,y,o1,o2) V2(a,w,c1,o3) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(y,w,o1,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x79, G_IF_SIGMA_CCOV_CCOO_NO0_X79)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x79, G_IF_SIGMA_CCOV_CCOO_NO1_X79)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.80
  //* X(w,y,o2,o1,o3,a)  <--  (    1.00000000)  T2(w,c1,o2,o1) V2(a,y,c1,o3) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D2(i,o2,o3,o1) X(w,y,o2,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x80, G_IF_SIGMA_CCOV_CCOO_NO0_X80)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x80, G_IF_SIGMA_CCOV_CCOO_NO1_X80)
        (sa, ia, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.81
  //* X(w,y,o1,o2,o3,a)  <--  (    1.00000000)  T2(c1,w,o1,o2) V2(a,y,c1,o3) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D2(i,o2,o3,o1) X(w,y,o1,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x81, G_IF_SIGMA_CCOV_CCOO_NO0_X81)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x81, G_IF_SIGMA_CCOV_CCOO_NO1_X81)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.82
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y24(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,y,i,o2) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y24 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y82, G_IF_SIGMA_CCOV_CCOO_Y82)
      (sc1, ic1, V2_sym.cptr(), Y24.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x82, G_IF_SIGMA_CCOV_CCOO_NO0_X82)
        (sa, ia, so2, io2, Y24.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x82, G_IF_SIGMA_CCOV_CCOO_NO1_X82)
        (sa, ia, so2, io2, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.83
  //* X(y,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,i,o2) X(y,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x83, G_IF_SIGMA_CCOV_CCOO_NO0_X83)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x83, G_IF_SIGMA_CCOV_CCOO_NO1_X83)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.84
  //* X(w,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,i,o2) X(w,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x84, G_IF_SIGMA_CCOV_CCOO_NO0_X84)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x84, G_IF_SIGMA_CCOV_CCOO_NO1_X84)
        (sa, ia, so2, io2, T2b.cptr(), Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.85
  //* X(y,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,c1,o2,i) X(y,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x85, G_IF_SIGMA_CCOV_CCOO_NO0_X85)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x85, G_IF_SIGMA_CCOV_CCOO_NO1_X85)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.86
  //* X(o2,a)  <--  (    1.00000000)  D1(o1,o2) Y25(o1,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,w,o2,i) X(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y25 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y86, G_IF_SIGMA_CCOV_CCOO_Y86)
      (sc1, ic1, V2_sym.cptr(), Y25.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x86, G_IF_SIGMA_CCOV_CCOO_NO0_X86)
      (sa, ia, Y25.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x86, G_IF_SIGMA_CCOV_CCOO_NO1_X86)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.87
  //* X(w,c1,o2,a)  <--  (    1.00000000)  D1(o1,o2) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,o2,i) X(w,c1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x87, G_IF_SIGMA_CCOV_CCOO_NO0_X87)
      (sa, ia, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x87, G_IF_SIGMA_CCOV_CCOO_NO1_X87)
        (sa, ia, si, ii, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.88
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(c1,y,o1,o2) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x88, G_IF_SIGMA_CCOV_CCOO_NO0_X88)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x88, G_IF_SIGMA_CCOV_CCOO_NO1_X88)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.89
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,o2) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed);
      orz::DTensor Xcc = orz::ct::sympack_Xcc(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x89, G_IF_SIGMA_CCOV_CCOO_NO0_X89)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcc.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x89, G_IF_SIGMA_CCOV_CCOO_NO1_X89)
        (sa, ia, so2, io2, Xcc.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.90
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(c1,w,o1,i) V2(a,y,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x90, G_IF_SIGMA_CCOV_CCOO_NO0_X90)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.91
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,o1,i) V2(a,w,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x91, G_IF_SIGMA_CCOV_CCOO_NO0_X91)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.92
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,w,o1,i) Y26(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y26 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y92, G_IF_SIGMA_CCOV_CCOO_Y92)
      (sc1, ic1, V2_sym.cptr(), Y26.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x92, G_IF_SIGMA_CCOV_CCOO_NO0_X92)
        (sa, ia, si, ii, T2b.cptr(), Y26.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.93
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(c1,w,o2,o1) V2(a,y,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x93, G_IF_SIGMA_CCOV_CCOO_NO0_X93)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x93, G_IF_SIGMA_CCOV_CCOO_NO1_X93)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.94
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,c1,o2,o1) V2(a,w,c1,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x94, G_IF_SIGMA_CCOV_CCOO_NO0_X94)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x94, G_IF_SIGMA_CCOV_CCOO_NO1_X94)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.95
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(w,c1,i,o1) V2(a,y,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x95, G_IF_SIGMA_CCOV_CCOO_NO0_X95)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.96
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,y,i,o1) Y27(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y27 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccoo_y96, G_IF_SIGMA_CCOV_CCOO_Y96)
      (sc1, ic1, V2_sym.cptr(), Y27.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x96, G_IF_SIGMA_CCOV_CCOO_NO0_X96)
        (sa, ia, so1, io1, T2b.cptr(), Y27.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.97
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,i,o1) V2(a,w,c1,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x97, G_IF_SIGMA_CCOV_CCOO_NO0_X97)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.98
  //* X(i,o3,o2,a)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(a,o5,o1,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o3,o2) X(i,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x98, G_IF_SIGMA_CCOV_CCOO_NO0_X98)
        (sa, ia, so2, io2, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x98, G_IF_SIGMA_CCOV_CCOO_NO1_X98)
        (sa, ia, so2, io2, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.99
  //* X(i,o3,o4,a)  <--  (    1.00000000)  D3(i,o3,o1,o4,o2,o5) V2(a,o1,o2,o5) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o4,o3) X(i,o3,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x99, G_IF_SIGMA_CCOV_CCOO_NO0_X99)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x99, G_IF_SIGMA_CCOV_CCOO_NO1_X99)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.100
  //* X(o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,i,o3) X(o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x100, G_IF_SIGMA_CCOV_CCOO_NO0_X100)
        (sa, ia, so3, io3, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x100, G_IF_SIGMA_CCOV_CCOO_NO1_X100)
        (sa, ia, so3, io3, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.101
  //* X(o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,i,o3) X(o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x101, G_IF_SIGMA_CCOV_CCOO_NO0_X101)
        (sa, ia, so3, io3, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x101, G_IF_SIGMA_CCOV_CCOO_NO1_X101)
        (sa, ia, so3, io3, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.102
  //* X(o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o3,i) X(o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x102, G_IF_SIGMA_CCOV_CCOO_NO0_X102)
      (sa, ia, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x102, G_IF_SIGMA_CCOV_CCOO_NO1_X102)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.103
  //* X(o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o3,i) X(o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x103, G_IF_SIGMA_CCOV_CCOO_NO0_X103)
      (sa, ia, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x103, G_IF_SIGMA_CCOV_CCOO_NO1_X103)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.104
  //* X(o3,o4,i,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o2,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o3,o4) X(o3,o4,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x104, G_IF_SIGMA_CCOV_CCOO_NO0_X104)
        (sa, ia, so4, io4, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x104, G_IF_SIGMA_CCOV_CCOO_NO1_X104)
        (sa, ia, so4, io4, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.105
  //* X(o3,o4,i,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o3,o4) X(o3,o4,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x105, G_IF_SIGMA_CCOV_CCOO_NO0_X105)
        (sa, ia, so4, io4, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x105, G_IF_SIGMA_CCOV_CCOO_NO1_X105)
        (sa, ia, so4, io4, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.106
  //* X(i,o2,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o4,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o1,o2) X(i,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x106, G_IF_SIGMA_CCOV_CCOO_NO0_X106)
        (sa, ia, so2, io2, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x106, G_IF_SIGMA_CCOV_CCOO_NO1_X106)
        (sa, ia, so2, io2, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.107
  //* X(i,o3,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o4,o1,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o1,o3) X(i,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x107, G_IF_SIGMA_CCOV_CCOO_NO0_X107)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x107, G_IF_SIGMA_CCOV_CCOO_NO1_X107)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.108
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o1,i) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x108, G_IF_SIGMA_CCOV_CCOO_NO0_X108)
      (sa, ia, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x108, G_IF_SIGMA_CCOV_CCOO_NO1_X108)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.109
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o1,i) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x109, G_IF_SIGMA_CCOV_CCOO_NO0_X109)
      (sa, ia, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x109, G_IF_SIGMA_CCOV_CCOO_NO1_X109)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.110
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(y,w,o1,i) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x110, G_IF_SIGMA_CCOV_CCOO_NO0_X110)
      (sa, ia, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x110, G_IF_SIGMA_CCOV_CCOO_NO1_X110)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.111
  //* X(o3,i,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,i,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,o3) X(o3,i,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x111, G_IF_SIGMA_CCOV_CCOO_NO0_X111)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x111, G_IF_SIGMA_CCOV_CCOO_NO1_X111)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.112
  //* X(o3,o1,i,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o1,o3) X(o3,o1,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x112, G_IF_SIGMA_CCOV_CCOO_NO0_X112)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x112, G_IF_SIGMA_CCOV_CCOO_NO1_X112)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.113
  //* X(o3,i,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o1,o3) X(o3,i,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x113, G_IF_SIGMA_CCOV_CCOO_NO0_X113)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x113, G_IF_SIGMA_CCOV_CCOO_NO1_X113)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.114
  //* X(i,o3,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o4,o1,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o3,o1) X(i,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x114, G_IF_SIGMA_CCOV_CCOO_NO0_X114)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x114, G_IF_SIGMA_CCOV_CCOO_NO1_X114)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.115
  //* X(i,o2,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o4,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o2,o1) X(i,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x115, G_IF_SIGMA_CCOV_CCOO_NO0_X115)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x115, G_IF_SIGMA_CCOV_CCOO_NO1_X115)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.116
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,i,o1) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x116, G_IF_SIGMA_CCOV_CCOO_NO0_X116)
        (sa, ia, so1, io1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x116, G_IF_SIGMA_CCOV_CCOO_NO1_X116)
        (sa, ia, so1, io1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.117
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,i,o1) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x117, G_IF_SIGMA_CCOV_CCOO_NO0_X117)
        (sa, ia, so1, io1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x117, G_IF_SIGMA_CCOV_CCOO_NO1_X117)
        (sa, ia, so1, io1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.118
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,i,o1) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x118, G_IF_SIGMA_CCOV_CCOO_NO0_X118)
        (sa, ia, so1, io1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x118, G_IF_SIGMA_CCOV_CCOO_NO1_X118)
        (sa, ia, so1, io1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.119
  //* X(o3,i,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o3,o1) X(o3,i,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x119, G_IF_SIGMA_CCOV_CCOO_NO0_X119)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x119, G_IF_SIGMA_CCOV_CCOO_NO1_X119)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.120
  //* X(o3,i,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o2,i,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o3,o1) X(o3,i,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x120, G_IF_SIGMA_CCOV_CCOO_NO0_X120)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x120, G_IF_SIGMA_CCOV_CCOO_NO1_X120)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.121
  //* X(o3,o1,i,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o3,o1) X(o3,o1,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x121, G_IF_SIGMA_CCOV_CCOO_NO0_X121)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x121, G_IF_SIGMA_CCOV_CCOO_NO1_X121)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.122
  //* X(i,o3,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o1,o3) X(i,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x122, G_IF_SIGMA_CCOV_CCOO_NO0_X122)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x122, G_IF_SIGMA_CCOV_CCOO_NO1_X122)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.123
  //* X(i,o3,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o1,o3) X(i,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x123, G_IF_SIGMA_CCOV_CCOO_NO0_X123)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x123, G_IF_SIGMA_CCOV_CCOO_NO1_X123)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.124
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,i) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccoo_no0_x124, G_IF_SIGMA_CCOV_CCOO_NO0_X124)
      (sa, ia, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x124, G_IF_SIGMA_CCOV_CCOO_NO1_X124)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.125
  //* X(o3,o1,i,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o1,o3) X(o3,o1,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x125, G_IF_SIGMA_CCOV_CCOO_NO0_X125)
        (sa, ia, so3, io3, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x125, G_IF_SIGMA_CCOV_CCOO_NO1_X125)
        (sa, ia, so3, io3, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.126
  //* X(i,o3,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o3,o1) X(i,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x126, G_IF_SIGMA_CCOV_CCOO_NO0_X126)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x126, G_IF_SIGMA_CCOV_CCOO_NO1_X126)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.127
  //* X(i,o2,o4,a)  <--  (    1.00000000)  D2(i,o2,o1,o3) V2(a,o4,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o2,o4) X(i,o2,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x127, G_IF_SIGMA_CCOV_CCOO_NO0_X127)
        (sa, ia, so4, io4, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x127, G_IF_SIGMA_CCOV_CCOO_NO1_X127)
        (sa, ia, so4, io4, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.128
  //* X(o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,i,o1) X(o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x128, G_IF_SIGMA_CCOV_CCOO_NO0_X128)
        (sa, ia, so1, io1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x128, G_IF_SIGMA_CCOV_CCOO_NO1_X128)
        (sa, ia, so1, io1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.129
  //* X(o3,o1,i,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o3,o1) X(o3,o1,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x129, G_IF_SIGMA_CCOV_CCOO_NO0_X129)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no1_x129, G_IF_SIGMA_CCOV_CCOO_NO1_X129)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.130
  //* X(y,w,o3,a)  <--  (    1.00000000)  T2(y,w,o2,o1) V2(a,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o3) X(y,w,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x130, G_IF_SIGMA_CCOV_CCOO_NO0_X130)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x130, G_IF_SIGMA_CCOV_CCOO_NO1_X130)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.131
  //* X(w,y,o3,a)  <--  (    1.00000000)  T2(w,y,o2,o1) V2(a,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o3) X(w,y,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x131, G_IF_SIGMA_CCOV_CCOO_NO0_X131)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x131, G_IF_SIGMA_CCOV_CCOO_NO1_X131)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.132
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,o2,o1) V2(a,o1,i,o2) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x132, G_IF_SIGMA_CCOV_CCOO_NO0_X132)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.133
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o2,o1) V2(a,o1,i,o2) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x133, G_IF_SIGMA_CCOV_CCOO_NO0_X133)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.134
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(y,w,o2,o1) V2(a,o2,i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x134, G_IF_SIGMA_CCOV_CCOO_NO0_X134)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.135
  //* X(y,w,o3,a)  <--  (    1.00000000)  T2(y,w,o2,o1) V2(a,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o3) X(y,w,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x135, G_IF_SIGMA_CCOV_CCOO_NO0_X135)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x135, G_IF_SIGMA_CCOV_CCOO_NO1_X135)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.136
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,y,o2,o3) V2(a,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x136, G_IF_SIGMA_CCOV_CCOO_NO0_X136)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccoo_no1_x136, G_IF_SIGMA_CCOV_CCOO_NO1_X136)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.137
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,o2) V2(a,o1,i,o2) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_ccoo_no0_x137, G_IF_SIGMA_CCOV_CCOO_NO0_X137)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }

  return retval; 
} 
