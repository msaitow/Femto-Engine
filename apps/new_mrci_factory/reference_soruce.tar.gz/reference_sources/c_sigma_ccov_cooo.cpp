                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_ccov_cooo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//      _/_/_/_/                            _/             
//     _/        _/_/    _/_/_/  _/_/    _/_/_/_/    _/_/  
//    _/_/_/  _/_/_/_/  _/    _/    _/    _/      _/    _/ 
//   _/      _/        _/    _/    _/    _/      _/    _/  
//  _/        _/_/_/  _/    _/    _/      _/_/    _/_/     

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_ccov_cooo(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* X(w,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) X(w,i) h(y,a) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x0, G_IF_SIGMA_CCOV_COOO_NO0_X0)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x0, G_IF_SIGMA_CCOV_COOO_NO1_X0)
      (sa, ia, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.1
  //* X(w,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) X(w,i) Y0(y,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y0 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y1, G_IF_SIGMA_CCOV_COOO_Y1)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x1, G_IF_SIGMA_CCOV_COOO_NO0_X1)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x1, G_IF_SIGMA_CCOV_COOO_NO1_X1)
      (sa, ia, Xca.cptr(), Y0.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.2
  //* X(w,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(w,i) Y1(y,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y1 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y2, G_IF_SIGMA_CCOV_COOO_Y2)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x2, G_IF_SIGMA_CCOV_COOO_NO0_X2)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x2, G_IF_SIGMA_CCOV_COOO_NO1_X2)
      (sa, ia, Xca.cptr(), Y1.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.3
  //* X(y,i)  <--  (    1.00000000)  D2(i,o2,o1,o3) T2(y,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) X(y,i) h(w,a) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x3, G_IF_SIGMA_CCOV_COOO_NO0_X3)
      (so3, io3, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x3, G_IF_SIGMA_CCOV_COOO_NO1_X3)
      (sa, ia, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.4
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (    4.00000000) X(w,i) h(y,a) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x4, G_IF_SIGMA_CCOV_COOO_NO0_X4)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x4, G_IF_SIGMA_CCOV_COOO_NO1_X4)
      (sa, ia, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.5
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) X(y,i) h(w,a) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x5, G_IF_SIGMA_CCOV_COOO_NO0_X5)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x5, G_IF_SIGMA_CCOV_COOO_NO1_X5)
      (sa, ia, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.6
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(y,i) Y2(w,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y2 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y6, G_IF_SIGMA_CCOV_COOO_Y6)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x6, G_IF_SIGMA_CCOV_COOO_NO0_X6)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x6, G_IF_SIGMA_CCOV_COOO_NO1_X6)
      (sa, ia, Xca.cptr(), Y2.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.7
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) X(y,i) Y3(w,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y3 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y7, G_IF_SIGMA_CCOV_COOO_Y7)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x7, G_IF_SIGMA_CCOV_COOO_NO0_X7)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x7, G_IF_SIGMA_CCOV_COOO_NO1_X7)
      (sa, ia, Xca.cptr(), Y3.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.8
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o2,o1,i) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) X(w,i) h(y,a) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x8, G_IF_SIGMA_CCOV_COOO_NO0_X8)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x8, G_IF_SIGMA_CCOV_COOO_NO1_X8)
        (sa, ia, si, ii, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.9
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,i) 
  //* S2(w,y,i,a)  <--  (    1.00000000) X(y,i) h(w,a) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x9, G_IF_SIGMA_CCOV_COOO_NO0_X9)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x9, G_IF_SIGMA_CCOV_COOO_NO1_X9)
        (sa, ia, si, ii, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.10
  //* X(w,y,o3,o2,o1,a)  <--  (    1.00000000)  T2(c1,o3,o2,o1) V2(a,w,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,y,o3,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x10, G_IF_SIGMA_CCOV_COOO_NO0_X10)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x10, G_IF_SIGMA_CCOV_COOO_NO1_X10)
        (sa, ia, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.11
  //* X(y,w,o3,o2,o1,a)  <--  (    1.00000000)  T2(c1,o3,o2,o1) V2(a,y,c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D2(i,o2,o3,o1) X(y,w,o3,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x11, G_IF_SIGMA_CCOV_COOO_NO0_X11)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x11, G_IF_SIGMA_CCOV_COOO_NO1_X11)
        (sa, ia, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.12
  //* X(y,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(y,o3,o2,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(y,i) Y4(w,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y4 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y12, G_IF_SIGMA_CCOV_COOO_Y12)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x12, G_IF_SIGMA_CCOV_COOO_NO0_X12)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x12, G_IF_SIGMA_CCOV_COOO_NO1_X12)
      (sa, ia, Xca.cptr(), Y4.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.13
  //* X(y,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(y,o3,o2,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) X(y,i) Y5(w,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y5 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y13, G_IF_SIGMA_CCOV_COOO_Y13)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x13, G_IF_SIGMA_CCOV_COOO_NO0_X13)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x13, G_IF_SIGMA_CCOV_COOO_NO1_X13)
      (sa, ia, Xca.cptr(), Y5.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.14
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (    8.00000000) X(w,i) Y6(y,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y6 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y14, G_IF_SIGMA_CCOV_COOO_Y14)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x14, G_IF_SIGMA_CCOV_COOO_NO0_X14)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x14, G_IF_SIGMA_CCOV_COOO_NO1_X14)
      (sa, ia, Xca.cptr(), Y6.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.15
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,i,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) X(w,i) Y7(y,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y7 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y15, G_IF_SIGMA_CCOV_COOO_Y15)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x15, G_IF_SIGMA_CCOV_COOO_NO0_X15)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x15, G_IF_SIGMA_CCOV_COOO_NO1_X15)
      (sa, ia, Xca.cptr(), Y7.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.16
  //* X(y,w,o1,i,o2,a)  <--  (    1.00000000)  T2(c1,o1,i,o2) V2(a,y,c1,w) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(o1,o2) X(y,w,o1,i,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x16, G_IF_SIGMA_CCOV_COOO_NO0_X16)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x16, G_IF_SIGMA_CCOV_COOO_NO1_X16)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.17
  //* X(w,y,o1,i,o2,a)  <--  (    1.00000000)  T2(c1,o1,i,o2) V2(a,w,c1,y) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(o1,o2) X(w,y,o1,i,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x17, G_IF_SIGMA_CCOV_COOO_NO0_X17)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x17, G_IF_SIGMA_CCOV_COOO_NO1_X17)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,y,o1,o2,i,a)  <--  (    1.00000000)  T2(c1,o1,o2,i) V2(a,w,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(o1,o2) X(w,y,o1,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, si^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x18, G_IF_SIGMA_CCOV_COOO_NO0_X18)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x18, G_IF_SIGMA_CCOV_COOO_NO1_X18)
        (sa, ia, si, ii, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.19
  //* X(y,w,o1,o2,i,a)  <--  (    1.00000000)  T2(c1,o1,o2,i) V2(a,y,c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(o1,o2) X(y,w,o1,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, si^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x19, G_IF_SIGMA_CCOV_COOO_NO0_X19)
        (sa, ia, si, ii, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x19, G_IF_SIGMA_CCOV_COOO_NO1_X19)
        (sa, ia, si, ii, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.20
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,i) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(y,i) Y8(w,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y8 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y20, G_IF_SIGMA_CCOV_COOO_Y20)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x20, G_IF_SIGMA_CCOV_COOO_NO0_X20)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x20, G_IF_SIGMA_CCOV_COOO_NO1_X20)
        (sa, ia, si, ii, Xc.cptr(), Y8.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.21
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,i) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) X(y,i) Y9(w,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y9 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y21, G_IF_SIGMA_CCOV_COOO_Y21)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x21, G_IF_SIGMA_CCOV_COOO_NO0_X21)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x21, G_IF_SIGMA_CCOV_COOO_NO1_X21)
        (sa, ia, si, ii, Xc.cptr(), Y9.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.22
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,i) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) X(w,i) Y10(y,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y10 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y22, G_IF_SIGMA_CCOV_COOO_Y22)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x22, G_IF_SIGMA_CCOV_COOO_NO0_X22)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x22, G_IF_SIGMA_CCOV_COOO_NO1_X22)
        (sa, ia, si, ii, Xc.cptr(), Y10.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.23
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,i) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(w,i) Y11(y,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nvir);
  orz::DTensor Y11 = orz::ct::sympack_Xcv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_cooo_y23, G_IF_SIGMA_CCOV_COOO_Y23)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x23, G_IF_SIGMA_CCOV_COOO_NO0_X23)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x23, G_IF_SIGMA_CCOV_COOO_NO1_X23)
        (sa, ia, si, ii, Xc.cptr(), Y11.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.24
  //* X(y,i,o3,o5,o2,a)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(a,o4,y,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o5,o3,o2) X(y,i,o3,o5,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x24, G_IF_SIGMA_CCOV_COOO_NO0_X24)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x24, G_IF_SIGMA_CCOV_COOO_NO1_X24)
        (sa, ia, so2, io2, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.25
  //* X(w,i,o1,o5,o2,a)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(a,o4,w,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o5,o1,o2) X(w,i,o1,o5,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x25, G_IF_SIGMA_CCOV_COOO_NO0_X25)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x25, G_IF_SIGMA_CCOV_COOO_NO1_X25)
        (sa, ia, so2, io2, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.26
  //* X(y,o2,o4,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,y,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o2,i,o4) X(y,o2,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x26, G_IF_SIGMA_CCOV_COOO_NO0_X26)
        (sa, ia, so4, io4, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x26, G_IF_SIGMA_CCOV_COOO_NO1_X26)
        (sa, ia, so4, io4, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.27
  //* X(w,o2,o4,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,w,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o2,i,o4) X(w,o2,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x27, G_IF_SIGMA_CCOV_COOO_NO0_X27)
        (sa, ia, so4, io4, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x27, G_IF_SIGMA_CCOV_COOO_NO1_X27)
        (sa, ia, so4, io4, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.28
  //* X(y,o1,o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o2,y,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o1,o3,i) X(y,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x28, G_IF_SIGMA_CCOV_COOO_NO0_X28)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x28, G_IF_SIGMA_CCOV_COOO_NO1_X28)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.29
  //* X(w,o3,o2,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,w,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o2,o3,i) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x29, G_IF_SIGMA_CCOV_COOO_NO0_X29)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x29, G_IF_SIGMA_CCOV_COOO_NO1_X29)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.30
  //* X(y,o3,o2,o4,i,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,y,i) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o2,o3,o4) X(y,o3,o2,o4,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x30, G_IF_SIGMA_CCOV_COOO_NO0_X30)
        (sa, ia, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x30, G_IF_SIGMA_CCOV_COOO_NO1_X30)
        (sa, ia, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.31
  //* X(w,o3,o2,o4,i,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,o1,w,i) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,o2,o3,o4) X(w,o3,o2,o4,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x31, G_IF_SIGMA_CCOV_COOO_NO0_X31)
        (sa, ia, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x31, G_IF_SIGMA_CCOV_COOO_NO1_X31)
        (sa, ia, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.32
  //* X(w,o3,o2,o4,i,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,w,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o2,o3,o4) X(w,o3,o2,o4,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x32, G_IF_SIGMA_CCOV_COOO_NO0_X32)
        (sa, ia, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x32, G_IF_SIGMA_CCOV_COOO_NO1_X32)
        (sa, ia, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.33
  //* X(y,w,o4,o2,o3,a)  <--  (    1.00000000)  T2(y,o4,o1,o2) V2(a,o1,w,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D2(i,o3,o4,o2) X(y,w,o4,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x33, G_IF_SIGMA_CCOV_COOO_NO0_X33)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x33, G_IF_SIGMA_CCOV_COOO_NO1_X33)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.34
  //* X(y,w,o4,o2,o3,a)  <--  (    1.00000000)  T2(y,o4,o1,o2) V2(a,w,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o3,o4,o2) X(y,w,o4,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x34, G_IF_SIGMA_CCOV_COOO_NO0_X34)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x34, G_IF_SIGMA_CCOV_COOO_NO1_X34)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.35
  //* X(w,y,o4,o2,o3,a)  <--  (    1.00000000)  T2(w,o4,o1,o2) V2(a,o1,y,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o3,o4,o2) X(w,y,o4,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x35, G_IF_SIGMA_CCOV_COOO_NO0_X35)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x35, G_IF_SIGMA_CCOV_COOO_NO1_X35)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.36
  //* X(w,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,w,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,o2,o1,i) X(w,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x36, G_IF_SIGMA_CCOV_COOO_NO0_X36)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x36, G_IF_SIGMA_CCOV_COOO_NO1_X36)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.37
  //* X(w,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,w,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o2,o1,i) X(w,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x37, G_IF_SIGMA_CCOV_COOO_NO0_X37)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x37, G_IF_SIGMA_CCOV_COOO_NO1_X37)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.38
  //* X(y,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,y,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o2,o1,i) X(y,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x38, G_IF_SIGMA_CCOV_COOO_NO0_X38)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x38, G_IF_SIGMA_CCOV_COOO_NO1_X38)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.39
  //* X(y,w,o2,o3,i,a)  <--  (    1.00000000)  T2(y,o2,o1,o3) V2(a,o1,w,i) 
  //* S2(w,y,i,a)  <--  (    4.00000000) D1(o2,o3) X(y,w,o2,o3,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x39, G_IF_SIGMA_CCOV_COOO_NO0_X39)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x39, G_IF_SIGMA_CCOV_COOO_NO1_X39)
        (sa, ia, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.40
  //* X(w,y,o2,o3,i,a)  <--  (    1.00000000)  T2(w,o2,o1,o3) V2(a,o1,y,i) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(o2,o3) X(w,y,o2,o3,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x40, G_IF_SIGMA_CCOV_COOO_NO0_X40)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x40, G_IF_SIGMA_CCOV_COOO_NO1_X40)
        (sa, ia, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.41
  //* X(w,y,o2,o3,i,a)  <--  (    1.00000000)  T2(w,o2,o1,o3) V2(a,y,i,o1) 
  //* S2(w,y,i,a)  <--  (    4.00000000) D1(o2,o3) X(w,y,o2,o3,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x41, G_IF_SIGMA_CCOV_COOO_NO0_X41)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x41, G_IF_SIGMA_CCOV_COOO_NO1_X41)
        (sa, ia, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.42
  //* X(w,y,o4,o3,o2,a)  <--  (    1.00000000)  T2(w,o4,o3,o1) V2(a,o1,y,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o3,o4,o2) X(w,y,o4,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x42, G_IF_SIGMA_CCOV_COOO_NO0_X42)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x42, G_IF_SIGMA_CCOV_COOO_NO1_X42)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.43
  //* X(y,w,o4,o2,o3,a)  <--  (    1.00000000)  T2(y,o4,o2,o1) V2(a,o1,w,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o3,o4,o2) X(y,w,o4,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x43, G_IF_SIGMA_CCOV_COOO_NO0_X43)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x43, G_IF_SIGMA_CCOV_COOO_NO1_X43)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.44
  //* X(y,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,y,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o2,i,o1) X(y,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x44, G_IF_SIGMA_CCOV_COOO_NO0_X44)
        (sa, ia, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x44, G_IF_SIGMA_CCOV_COOO_NO1_X44)
        (sa, ia, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.45
  //* X(y,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,y,o1,o3) 
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,o2,i,o1) X(y,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x45, G_IF_SIGMA_CCOV_COOO_NO0_X45)
        (sa, ia, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x45, G_IF_SIGMA_CCOV_COOO_NO1_X45)
        (sa, ia, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.46
  //* X(w,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,o1,w,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o2,i,o1) X(w,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x46, G_IF_SIGMA_CCOV_COOO_NO0_X46)
        (sa, ia, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x46, G_IF_SIGMA_CCOV_COOO_NO1_X46)
        (sa, ia, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.47
  //* X(w,y,o3,o2,i,a)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(a,o1,y,i) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(o2,o3) X(w,y,o3,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x47, G_IF_SIGMA_CCOV_COOO_NO0_X47)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x47, G_IF_SIGMA_CCOV_COOO_NO1_X47)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.48
  //* X(y,w,o3,o2,i,a)  <--  (    1.00000000)  T2(y,o3,o2,o1) V2(a,o1,w,i) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(o2,o3) X(y,w,o3,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x48, G_IF_SIGMA_CCOV_COOO_NO0_X48)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x48, G_IF_SIGMA_CCOV_COOO_NO1_X48)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.49
  //* X(y,w,o3,o2,i,a)  <--  (    1.00000000)  T2(y,o3,o2,o1) V2(a,w,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(o2,o3) X(y,w,o3,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x49, G_IF_SIGMA_CCOV_COOO_NO0_X49)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x49, G_IF_SIGMA_CCOV_COOO_NO1_X49)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.50
  //* X(w,i,o3,o5,o2,a)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(a,w,o1,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o5,o3,o2) X(w,i,o3,o5,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x50, G_IF_SIGMA_CCOV_COOO_NO0_X50)
        (sa, ia, so2, io2, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x50, G_IF_SIGMA_CCOV_COOO_NO1_X50)
        (sa, ia, so2, io2, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.51
  //* X(y,i,o3,o1,o4,a)  <--  (    1.00000000)  D3(i,o3,o1,o4,o2,o5) V2(a,y,o2,o5) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o1,o3,o4) X(y,i,o3,o1,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x51, G_IF_SIGMA_CCOV_COOO_NO0_X51)
        (sa, ia, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x51, G_IF_SIGMA_CCOV_COOO_NO1_X51)
        (sa, ia, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.52
  //* X(y,o1,o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,y,o2,o4) 
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,o1,i,o3) X(y,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x52, G_IF_SIGMA_CCOV_COOO_NO0_X52)
        (sa, ia, so3, io3, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x52, G_IF_SIGMA_CCOV_COOO_NO1_X52)
        (sa, ia, so3, io3, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.53
  //* X(w,o1,o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,w,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,o1,i,o3) X(w,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x53, G_IF_SIGMA_CCOV_COOO_NO0_X53)
        (sa, ia, so3, io3, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x53, G_IF_SIGMA_CCOV_COOO_NO1_X53)
        (sa, ia, so3, io3, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.54
  //* X(w,o1,o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,w,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o1,o3,i) X(w,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x54, G_IF_SIGMA_CCOV_COOO_NO0_X54)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x54, G_IF_SIGMA_CCOV_COOO_NO1_X54)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.55
  //* X(y,o1,o3,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,y,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o1,o3,i) X(y,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x55, G_IF_SIGMA_CCOV_COOO_NO0_X55)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x55, G_IF_SIGMA_CCOV_COOO_NO1_X55)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.56
  //* X(y,o3,o2,o4,i,a)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(a,y,i,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o2,o3,o4) X(y,o3,o2,o4,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x56, G_IF_SIGMA_CCOV_COOO_NO0_X56)
        (sa, ia, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x56, G_IF_SIGMA_CCOV_COOO_NO1_X56)
        (sa, ia, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.57
  //* X(w,y,o4,o2,o3,a)  <--  (    1.00000000)  T2(w,o4,o1,o2) V2(a,y,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D2(i,o3,o4,o2) X(w,y,o4,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x57, G_IF_SIGMA_CCOV_COOO_NO0_X57)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x57, G_IF_SIGMA_CCOV_COOO_NO1_X57)
        (sa, ia, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.58
  //* X(y,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,y,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o2,o1,i) X(y,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_cooo_no0_x58, G_IF_SIGMA_CCOV_COOO_NO0_X58)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x58, G_IF_SIGMA_CCOV_COOO_NO1_X58)
        (sa, ia, si, ii, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.59
  //* X(y,w,o2,o3,i,a)  <--  (    1.00000000)  T2(y,o2,o1,o3) V2(a,w,i,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(o2,o3) X(y,w,o2,o3,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x59, G_IF_SIGMA_CCOV_COOO_NO0_X59)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x59, G_IF_SIGMA_CCOV_COOO_NO1_X59)
        (sa, ia, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.60
  //* X(y,w,o4,o3,o2,a)  <--  (    1.00000000)  T2(y,o4,o3,o1) V2(a,w,o1,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o3,o4,o2) X(y,w,o4,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x60, G_IF_SIGMA_CCOV_COOO_NO0_X60)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x60, G_IF_SIGMA_CCOV_COOO_NO1_X60)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.61
  //* X(w,y,o1,o2,o3,a)  <--  (    1.00000000)  T2(w,o1,o2,o4) V2(a,y,o3,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D2(i,o2,o1,o3) X(w,y,o1,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x61, G_IF_SIGMA_CCOV_COOO_NO0_X61)
        (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x61, G_IF_SIGMA_CCOV_COOO_NO1_X61)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.62
  //* X(w,o2,o1,a)  <--  (    1.00000000)  D1(o2,o3) V2(a,w,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,o2,i,o1) X(w,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x62, G_IF_SIGMA_CCOV_COOO_NO0_X62)
        (sa, ia, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccov_cooo_no1_x62, G_IF_SIGMA_CCOV_COOO_NO1_X62)
        (sa, ia, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.63
  //* X(w,y,o1,o2,i,a)  <--  (    1.00000000)  T2(w,o1,o2,o3) V2(a,y,i,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(o1,o2) X(w,y,o1,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccov_cooo_no0_x63, G_IF_SIGMA_CCOV_COOO_NO0_X63)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_cooo_no1_x63, G_IF_SIGMA_CCOV_COOO_NO1_X63)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }

  return retval; 
} 
