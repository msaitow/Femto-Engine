                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_cooo_ocov.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//  ___________                __               
//  \_   _____/____    _____ _/  |_  ____      
//   |    __)_/ __ \  /     \\   __\/  _ \ 
//   |     \ \  ___/ |  Y Y  \|  | (  <_> )  
//   \___  /  \___  >|__|_|  /|__|  \____/   
//       \/       \/       \/                

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_cooo_ocov(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::DTensor &rdm4,                                                 
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                        


  {
  // No.0
  //* X(w,o3,o1,o2)  <--  (    1.00000000)  T2(o3,w,o1,v1) h(o2,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o1,o3,o2,k) X(w,o3,o1,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x0, G_IF_SIGMA_COOO_OCOV_NO0_X0)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x0, G_IF_SIGMA_COOO_OCOV_NO1_X0)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.1
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(o1,w,k,v1) h(o2,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x1, G_IF_SIGMA_COOO_OCOV_NO0_X1)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x1, G_IF_SIGMA_COOO_OCOV_NO1_X1)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.2
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(o1,w,o2,v1) h(k,v1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x2, G_IF_SIGMA_COOO_OCOV_NO0_X2)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x2, G_IF_SIGMA_COOO_OCOV_NO1_X2)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.3
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(o1,w,o2,v1) Y0(k,v1) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y0 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y3, G_IF_SIGMA_COOO_OCOV_Y3)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x3, G_IF_SIGMA_COOO_OCOV_NO0_X3)
      (sv1, iv1, T2b.cptr(), Y0.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x3, G_IF_SIGMA_COOO_OCOV_NO1_X3)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.4
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(o1,w,o2,v1) Y1(k,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y1 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y4, G_IF_SIGMA_COOO_OCOV_Y4)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x4, G_IF_SIGMA_COOO_OCOV_NO0_X4)
      (sv1, iv1, T2b.cptr(), Y1.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x4, G_IF_SIGMA_COOO_OCOV_NO1_X4)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.5
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(o1,w,m,v1) h(o2,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o1,o2,k) X(w,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x5, G_IF_SIGMA_COOO_OCOV_NO0_X5)
        (sm, im, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x5, G_IF_SIGMA_COOO_OCOV_NO1_X5)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.6
  //* X(w,o2,o1,m)  <--  (    1.00000000)  T2(o2,w,o1,v1) h(m,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o1,o2) X(w,o2,o1,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x6, G_IF_SIGMA_COOO_OCOV_NO0_X6)
        (sm, im, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x6, G_IF_SIGMA_COOO_OCOV_NO1_X6)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.7
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(o1,w,k,v1) h(m,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o1) X(w,o1,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x7, G_IF_SIGMA_COOO_OCOV_NO0_X7)
        (sm, im, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x7, G_IF_SIGMA_COOO_OCOV_NO1_X7)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.8
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(o1,w,m,v1) h(k,v1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o1) X(w,o1,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x8, G_IF_SIGMA_COOO_OCOV_NO0_X8)
        (sm, im, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x8, G_IF_SIGMA_COOO_OCOV_NO1_X8)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.9
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(o1,w,m,v1) Y2(k,v1) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D1(i,o1) X(w,o1,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y2 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y9, G_IF_SIGMA_COOO_OCOV_Y9)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x9, G_IF_SIGMA_COOO_OCOV_NO0_X9)
        (sm, im, sv1, iv1, T2b.cptr(), Y2.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x9, G_IF_SIGMA_COOO_OCOV_NO1_X9)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.10
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(o1,w,m,v1) Y3(k,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o1) X(w,o1,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y3 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y10, G_IF_SIGMA_COOO_OCOV_Y10)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x10, G_IF_SIGMA_COOO_OCOV_NO0_X10)
        (sm, im, sv1, iv1, T2b.cptr(), Y3.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x10, G_IF_SIGMA_COOO_OCOV_NO1_X10)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.11
  //* X(w,o1,o3,o2)  <--  (    1.00000000)  T2(o1,c1,o3,v1) V2(v1,o2,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o2,k,o3,o1) X(w,o1,o3,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x11, G_IF_SIGMA_COOO_OCOV_NO0_X11)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x11, G_IF_SIGMA_COOO_OCOV_NO1_X11)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.12
  //* X(w,o1,o3,o2)  <--  (    1.00000000)  T2(o1,w,o3,v1) Y4(o2,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D3(i,m,o2,k,o3,o1) X(w,o1,o3,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y4 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y12, G_IF_SIGMA_COOO_OCOV_Y12)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x12, G_IF_SIGMA_COOO_OCOV_NO0_X12)
      (sv1, iv1, T2b.cptr(), Y4.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x12, G_IF_SIGMA_COOO_OCOV_NO1_X12)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.13
  //* X(w,o1,o3,o2)  <--  (    1.00000000)  T2(o1,w,o3,v1) Y5(o2,v1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o2,k,o3,o1) X(w,o1,o3,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y5 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y13, G_IF_SIGMA_COOO_OCOV_Y13)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x13, G_IF_SIGMA_COOO_OCOV_NO0_X13)
      (sv1, iv1, T2b.cptr(), Y5.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x13, G_IF_SIGMA_COOO_OCOV_NO1_X13)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.14
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(o1,c1,k,v1) V2(v1,o2,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x14, G_IF_SIGMA_COOO_OCOV_NO0_X14)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x14, G_IF_SIGMA_COOO_OCOV_NO1_X14)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.15
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(o1,w,k,v1) Y6(o2,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y6 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y15, G_IF_SIGMA_COOO_OCOV_Y15)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x15, G_IF_SIGMA_COOO_OCOV_NO0_X15)
      (sv1, iv1, T2b.cptr(), Y6.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x15, G_IF_SIGMA_COOO_OCOV_NO1_X15)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.16
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(o1,w,k,v1) Y7(o2,v1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y7 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y16, G_IF_SIGMA_COOO_OCOV_Y16)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x16, G_IF_SIGMA_COOO_OCOV_NO0_X16)
      (sv1, iv1, T2b.cptr(), Y7.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x16, G_IF_SIGMA_COOO_OCOV_NO1_X16)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.17
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(o1,c1,o2,v1) V2(v1,k,c1,w) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x17, G_IF_SIGMA_COOO_OCOV_NO0_X17)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x17, G_IF_SIGMA_COOO_OCOV_NO1_X17)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(o1,c1,o2,v1) V2(v1,c1,w,k) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x18, G_IF_SIGMA_COOO_OCOV_NO0_X18)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x18, G_IF_SIGMA_COOO_OCOV_NO1_X18)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.19
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(o1,c1,m,v1) V2(v1,o2,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o1,o2,k) X(w,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x19, G_IF_SIGMA_COOO_OCOV_NO0_X19)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x19, G_IF_SIGMA_COOO_OCOV_NO1_X19)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.20
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(o1,w,m,v1) Y8(o2,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o1,o2,k) X(w,o1,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y8 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y20, G_IF_SIGMA_COOO_OCOV_Y20)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x20, G_IF_SIGMA_COOO_OCOV_NO0_X20)
        (sm, im, sv1, iv1, T2b.cptr(), Y8.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x20, G_IF_SIGMA_COOO_OCOV_NO1_X20)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.21
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(o1,w,m,v1) Y9(o2,v1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o1,o2,k) X(w,o1,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y9 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y21, G_IF_SIGMA_COOO_OCOV_Y21)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x21, G_IF_SIGMA_COOO_OCOV_NO0_X21)
        (sm, im, sv1, iv1, T2b.cptr(), Y9.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x21, G_IF_SIGMA_COOO_OCOV_NO1_X21)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.22
  //* X(w,o1,o2,m)  <--  (    1.00000000)  T2(o1,c1,o2,v1) V2(m,v1,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o2,o1) X(w,o1,o2,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x22, G_IF_SIGMA_COOO_OCOV_NO0_X22)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x22, G_IF_SIGMA_COOO_OCOV_NO1_X22)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.23
  //* X(w,o1,o2,m)  <--  (    1.00000000)  T2(o1,w,o2,v1) Y10(m,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,k,o2,o1) X(w,o1,o2,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y10 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y23, G_IF_SIGMA_COOO_OCOV_Y23)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x23, G_IF_SIGMA_COOO_OCOV_NO0_X23)
        (sm, im, sv1, iv1, T2b.cptr(), Y10.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x23, G_IF_SIGMA_COOO_OCOV_NO1_X23)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.24
  //* X(w,o1,o2,m)  <--  (    1.00000000)  T2(o1,w,o2,v1) Y11(m,v1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o2,o1) X(w,o1,o2,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y11 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y24, G_IF_SIGMA_COOO_OCOV_Y24)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x24, G_IF_SIGMA_COOO_OCOV_NO0_X24)
        (sm, im, sv1, iv1, T2b.cptr(), Y11.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x24, G_IF_SIGMA_COOO_OCOV_NO1_X24)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.25
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(o1,c1,k,v1) V2(m,v1,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o1) X(w,o1,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x25, G_IF_SIGMA_COOO_OCOV_NO0_X25)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x25, G_IF_SIGMA_COOO_OCOV_NO1_X25)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.26
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(o1,w,k,v1) Y12(m,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o1) X(w,o1,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y12 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y26, G_IF_SIGMA_COOO_OCOV_Y26)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x26, G_IF_SIGMA_COOO_OCOV_NO0_X26)
        (sm, im, sv1, iv1, T2b.cptr(), Y12.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x26, G_IF_SIGMA_COOO_OCOV_NO1_X26)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.27
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(o1,w,k,v1) Y13(m,v1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o1) X(w,o1,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y13 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_ocov_y27, G_IF_SIGMA_COOO_OCOV_Y27)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x27, G_IF_SIGMA_COOO_OCOV_NO0_X27)
        (sm, im, sv1, iv1, T2b.cptr(), Y13.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x27, G_IF_SIGMA_COOO_OCOV_NO1_X27)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.28
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(o1,c1,m,v1) V2(v1,k,c1,w) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o1) X(w,o1,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x28, G_IF_SIGMA_COOO_OCOV_NO0_X28)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x28, G_IF_SIGMA_COOO_OCOV_NO1_X28)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.29
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(o1,c1,m,v1) V2(v1,c1,w,k) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D1(i,o1) X(w,o1,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x29, G_IF_SIGMA_COOO_OCOV_NO0_X29)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x29, G_IF_SIGMA_COOO_OCOV_NO1_X29)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.30
  //* X(w,o1,o3,o2)  <--  (    1.00000000)  T2(o1,c1,o3,v1) V2(v1,c1,w,o2) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D3(i,m,o2,k,o3,o1) X(w,o1,o3,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x30, G_IF_SIGMA_COOO_OCOV_NO0_X30)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x30, G_IF_SIGMA_COOO_OCOV_NO1_X30)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.31
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(o1,c1,k,v1) V2(v1,c1,w,o2) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x31, G_IF_SIGMA_COOO_OCOV_NO0_X31)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x31, G_IF_SIGMA_COOO_OCOV_NO1_X31)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.32
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(o1,c1,m,v1) V2(v1,c1,w,o2) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o1,o2,k) X(w,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x32, G_IF_SIGMA_COOO_OCOV_NO0_X32)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x32, G_IF_SIGMA_COOO_OCOV_NO1_X32)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.33
  //* X(w,o1,o2,m)  <--  (    1.00000000)  T2(o1,c1,o2,v1) V2(m,w,c1,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,k,o2,o1) X(w,o1,o2,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x33, G_IF_SIGMA_COOO_OCOV_NO0_X33)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x33, G_IF_SIGMA_COOO_OCOV_NO1_X33)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.34
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(o1,c1,k,v1) V2(m,w,c1,v1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o1) X(w,o1,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x34, G_IF_SIGMA_COOO_OCOV_NO0_X34)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x34, G_IF_SIGMA_COOO_OCOV_NO1_X34)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.35
  //* X(w,o4,o2,o1,o3,o5)  <--  (    1.00000000)  T2(o4,w,o2,v1) V2(v1,o1,o3,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D4(i,m,o1,k,o2,o4,o3,o5) X(w,o4,o2,o1,o3,o5) 
  orz::DTensor X(nclosed, nocc, nocc, nocc, nocc, nocc);
  orz::DTensor Xcaaaaa = orz::ct::sympack_Xcaaaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x35, G_IF_SIGMA_COOO_OCOV_NO0_X35)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      // Load D4 from disk, or GA ....                                                     
      int imoi = amo2imo[ii] - nclosed;                              
      int imoj = amo2imo[im] - nclosed;                              
                                                                                           
      orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice()).copy();    
      rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(si, sm, ii, im, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_sigma_cooo_ocov_no1_x35, G_IF_SIGMA_COOO_OCOV_NO1_X35)
        (si, ii, sm, im, Xcaaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.36
  //* X(i,m,o1,v1)  <--  (    1.00000000)  D3(i,m,o3,o1,o4,o2) V2(v1,o3,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(o1,w,k,v1) X(i,m,o1,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^sv1, X);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x36, G_IF_SIGMA_COOO_OCOV_NO0_X36)
        (sm, im, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no1_x36, G_IF_SIGMA_COOO_OCOV_NO1_X36)
        (sm, im, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.37
  //* X(w,o2,o4,o3,k,o1)  <--  (    1.00000000)  T2(o2,w,o4,v1) V2(v1,o3,k,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o3,o1,o4,o2) X(w,o2,o4,o3,k,o1) 
  orz::DTensor X(nclosed, nocc, nocc, nocc, nocc, nocc);
  orz::DTensor Xcaaaaa = orz::ct::sympack_Xcaaaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x37, G_IF_SIGMA_COOO_OCOV_NO0_X37)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x37, G_IF_SIGMA_COOO_OCOV_NO1_X37)
      (sm, im, Xcaaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.38
  //* X(w,o1,o3,k,o2,o4)  <--  (    1.00000000)  T2(o1,w,o3,v1) V2(v1,k,o2,o4) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D3(i,m,o3,o1,o4,o2) X(w,o1,o3,k,o2,o4) 
  orz::DTensor X(nclosed, nocc, nocc, nocc, nocc, nocc);
  orz::DTensor Xcaaaaa = orz::ct::sympack_Xcaaaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x38, G_IF_SIGMA_COOO_OCOV_NO0_X38)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x38, G_IF_SIGMA_COOO_OCOV_NO1_X38)
      (sm, im, Xcaaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.39
  //* X(i,o2,k,v1)  <--  (    1.00000000)  D3(i,o2,o3,k,o4,o1) V2(v1,o3,o1,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(o2,w,m,v1) X(i,o2,k,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x39, G_IF_SIGMA_COOO_OCOV_NO0_X39)
      (sv1, iv1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no1_x39, G_IF_SIGMA_COOO_OCOV_NO1_X39)
        (sm, im, sv1, iv1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.40
  //* X(w,o1,o4,m,o2,o3)  <--  (    1.00000000)  T2(o1,w,o4,v1) V2(m,o2,o3,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,o2,o3,k,o4,o1) X(w,o1,o4,m,o2,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x40, G_IF_SIGMA_COOO_OCOV_NO0_X40)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x40, G_IF_SIGMA_COOO_OCOV_NO1_X40)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.41
  //* X(w,o1,o3,m,o2,o4)  <--  (    1.00000000)  T2(o1,w,o3,v1) V2(m,v1,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,k,o3,o1,o4,o2) X(w,o1,o3,m,o2,o4) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x41, G_IF_SIGMA_COOO_OCOV_NO0_X41)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x41, G_IF_SIGMA_COOO_OCOV_NO1_X41)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.42
  //* X(i,o1,m,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(m,o2,o3,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(o1,w,k,v1) X(i,o1,m,v1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^sv1, X);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x42, G_IF_SIGMA_COOO_OCOV_NO0_X42)
        (sm, im, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no1_x42, G_IF_SIGMA_COOO_OCOV_NO1_X42)
        (sm, im, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.43
  //* X(i,o2,m,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(m,v1,o1,o3) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(o2,w,k,v1) X(i,o2,m,v1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^sv1, X);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x43, G_IF_SIGMA_COOO_OCOV_NO0_X43)
        (sm, im, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no1_x43, G_IF_SIGMA_COOO_OCOV_NO1_X43)
        (sm, im, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.44
  //* X(w,o1,o3,m,k,o2)  <--  (    1.00000000)  T2(o1,w,o3,v1) V2(m,v1,k,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,o1,o3,m,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x44, G_IF_SIGMA_COOO_OCOV_NO0_X44)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x44, G_IF_SIGMA_COOO_OCOV_NO1_X44)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.45
  //* X(i,o2,k,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(v1,o3,k,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(o2,w,m,v1) X(i,o2,k,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x45, G_IF_SIGMA_COOO_OCOV_NO0_X45)
      (sv1, iv1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no1_x45, G_IF_SIGMA_COOO_OCOV_NO1_X45)
        (sm, im, sv1, iv1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.46
  //* X(i,o2,k,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(v1,k,o1,o3) 
  //* S2(w,i,k,m)  <--  (    2.00000000) T2(o2,w,m,v1) X(i,o2,k,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x46, G_IF_SIGMA_COOO_OCOV_NO0_X46)
      (sv1, iv1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no1_x46, G_IF_SIGMA_COOO_OCOV_NO1_X46)
        (sm, im, sv1, iv1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.47
  //* X(w,o1,o3,m,o2,k)  <--  (    1.00000000)  T2(o1,w,o3,v1) V2(m,o2,k,v1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,o2,o3,o1) X(w,o1,o3,m,o2,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x47, G_IF_SIGMA_COOO_OCOV_NO0_X47)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x47, G_IF_SIGMA_COOO_OCOV_NO1_X47)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.48
  //* X(w,o3,o1,o2)  <--  (    1.00000000)  T2(o3,w,o4,v1) V2(v1,o1,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o1,k,o2,o3) X(w,o3,o1,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x48, G_IF_SIGMA_COOO_OCOV_NO0_X48)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x48, G_IF_SIGMA_COOO_OCOV_NO1_X48)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.49
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(o2,w,o1,v1) V2(v1,o3,k,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x49, G_IF_SIGMA_COOO_OCOV_NO0_X49)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x49, G_IF_SIGMA_COOO_OCOV_NO1_X49)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.50
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(o2,w,o1,v1) V2(v1,k,o1,o3) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_cooo_ocov_no0_x50, G_IF_SIGMA_COOO_OCOV_NO0_X50)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x50, G_IF_SIGMA_COOO_OCOV_NO1_X50)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.51
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(o2,w,o1,v1) V2(m,o1,o3,v1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o2,o3,k) X(w,o2,m,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x51, G_IF_SIGMA_COOO_OCOV_NO0_X51)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x51, G_IF_SIGMA_COOO_OCOV_NO1_X51)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.52
  //* X(w,o2,m,o1)  <--  (    1.00000000)  T2(o2,w,o3,v1) V2(m,v1,o1,o3) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o1,o2) X(w,o2,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x52, G_IF_SIGMA_COOO_OCOV_NO0_X52)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x52, G_IF_SIGMA_COOO_OCOV_NO1_X52)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.53
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(o2,w,o1,v1) V2(m,v1,k,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o2) X(w,o2,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x53, G_IF_SIGMA_COOO_OCOV_NO0_X53)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x53, G_IF_SIGMA_COOO_OCOV_NO1_X53)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.54
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(o1,w,o2,v1) V2(m,o2,k,v1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o1) X(w,o1,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_cooo_ocov_no0_x54, G_IF_SIGMA_COOO_OCOV_NO0_X54)
        (sm, im, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_ocov_no1_x54, G_IF_SIGMA_COOO_OCOV_NO1_X54)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }

  return retval; 
} 
