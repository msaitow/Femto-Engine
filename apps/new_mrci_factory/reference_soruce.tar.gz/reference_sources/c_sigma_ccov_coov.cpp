                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_ccov_coov.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//        :::::::::: ::::::::::   :::   ::: ::::::::::: :::::::: 
//       :+:        :+:         :+:+: :+:+:    :+:    :+:    :+: 
//      +:+        +:+        +:+ +:+:+ +:+   +:+    +:+    +:+  
//     :#::+::#   +#++:++#   +#+  +:+  +#+   +#+    +#+    +:+   
//    +#+        +#+        +#+       +#+   +#+    +#+    +#+    
//   #+#        #+#        #+#       #+#   #+#    #+#    #+#     
//  ###        ########## ###       ###   ###     ########       

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_ccov_coov(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(w,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o3,o1,a) X(w,i,o3,o1) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x0, G_IF_SIGMA_CCOV_COOV_NO0_X0)
    (moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x0, G_IF_SIGMA_CCOV_COOV_NO1_X0)
      (sa, ia, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.1
  //* X(y,i,o2,o1)  <--  (    1.00000000)  D2(i,o2,o1,o3) h(y,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o1,o2,a) X(y,i,o2,o1) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x1, G_IF_SIGMA_CCOV_COOV_NO0_X1)
    (moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x1, G_IF_SIGMA_CCOV_COOV_NO1_X1)
      (sa, ia, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.2
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) h(w,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o1,i,a) X(w,o1) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x2, G_IF_SIGMA_CCOV_COOV_NO0_X2)
    (moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x2, G_IF_SIGMA_CCOV_COOV_NO1_X2)
      (sa, ia, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.3
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) h(y,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o1,i,a) X(y,o1) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x3, G_IF_SIGMA_CCOV_COOV_NO0_X3)
    (moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x3, G_IF_SIGMA_CCOV_COOV_NO1_X3)
      (sa, ia, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.4
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) Y0(y,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,o1,i,a) X(y,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y0 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y4, G_IF_SIGMA_CCOV_COOV_Y4)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x4, G_IF_SIGMA_CCOV_COOV_NO0_X4)
    (Y0.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x4, G_IF_SIGMA_CCOV_COOV_NO1_X4)
      (sa, ia, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.5
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) Y1(y,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,o1,i,a) X(y,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y1 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y5, G_IF_SIGMA_CCOV_COOV_Y5)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x5, G_IF_SIGMA_CCOV_COOV_NO0_X5)
    (Y1.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x5, G_IF_SIGMA_CCOV_COOV_NO1_X5)
      (sa, ia, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.6
  //* X(y,a)  <--  (    1.00000000)  D1(o1,o2) T2(y,o2,o1,a) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) X(y,a) h(w,i) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x6, G_IF_SIGMA_CCOV_COOV_NO0_X6)
      (sa, ia, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x6, G_IF_SIGMA_CCOV_COOV_NO1_X6)
      (sa, ia, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.7
  //* X(w,a)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,a) 
  //* S2(w,y,i,a)  <--  (    1.00000000) X(w,a) h(y,i) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x7, G_IF_SIGMA_CCOV_COOV_NO0_X7)
      (sa, ia, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x7, G_IF_SIGMA_CCOV_COOV_NO1_X7)
      (sa, ia, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.8
  //* X(w,y,o3,o2,o1,a)  <--  (    1.00000000)  T2(c1,o3,o2,a) V2(c1,w,y,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,y,o3,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_coov_no0_x8, G_IF_SIGMA_CCOV_COOV_NO0_X8)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x8, G_IF_SIGMA_CCOV_COOV_NO1_X8)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.9
  //* X(y,w,o3,o1,o2,a)  <--  (    1.00000000)  T2(c1,o3,o1,a) V2(c1,y,w,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(y,w,o3,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_coov_no0_x9, G_IF_SIGMA_CCOV_COOV_NO0_X9)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x9, G_IF_SIGMA_CCOV_COOV_NO1_X9)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.10
  //* X(y,i,o2,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y2(y,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,o3,o2,a) X(y,i,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y2 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y10, G_IF_SIGMA_CCOV_COOV_Y10)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x10, G_IF_SIGMA_CCOV_COOV_NO0_X10)
    (Y2.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x10, G_IF_SIGMA_CCOV_COOV_NO1_X10)
      (sa, ia, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.11
  //* X(y,i,o2,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y3(y,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(w,o3,o2,a) X(y,i,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y3 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y11, G_IF_SIGMA_CCOV_COOV_Y11)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x11, G_IF_SIGMA_CCOV_COOV_NO0_X11)
    (Y3.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x11, G_IF_SIGMA_CCOV_COOV_NO1_X11)
      (sa, ia, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.12
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y4(w,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,o3,o1,a) X(w,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y4 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y12, G_IF_SIGMA_CCOV_COOV_Y12)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x12, G_IF_SIGMA_CCOV_COOV_NO0_X12)
    (Y4.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x12, G_IF_SIGMA_CCOV_COOV_NO1_X12)
      (sa, ia, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.13
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y5(w,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,o3,o1,a) X(w,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y5 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y13, G_IF_SIGMA_CCOV_COOV_Y13)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x13, G_IF_SIGMA_CCOV_COOV_NO0_X13)
    (Y5.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x13, G_IF_SIGMA_CCOV_COOV_NO1_X13)
      (sa, ia, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.14
  //* X(c1,w,y,o1)  <--  (    1.00000000)  D1(o1,o2) V2(c1,w,y,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,o1,i,a) X(c1,w,y,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x14, G_IF_SIGMA_CCOV_COOV_NO0_X14)
      (sc1, ic1, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x14, G_IF_SIGMA_CCOV_COOV_NO1_X14)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.15
  //* X(c1,y,w,o1)  <--  (    1.00000000)  D1(o1,o2) V2(c1,y,w,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,o1,i,a) X(c1,y,w,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x15, G_IF_SIGMA_CCOV_COOV_NO0_X15)
      (sc1, ic1, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x15, G_IF_SIGMA_CCOV_COOV_NO1_X15)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.16
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) Y6(w,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,o1,i,a) X(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y6 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y16, G_IF_SIGMA_CCOV_COOV_Y16)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x16, G_IF_SIGMA_CCOV_COOV_NO0_X16)
    (Y6.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x16, G_IF_SIGMA_CCOV_COOV_NO1_X16)
      (sa, ia, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.17
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) Y7(w,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,o1,i,a) X(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y7 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y17, G_IF_SIGMA_CCOV_COOV_Y17)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_coov_no0_x17, G_IF_SIGMA_CCOV_COOV_NO0_X17)
    (Y7.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x17, G_IF_SIGMA_CCOV_COOV_NO1_X17)
      (sa, ia, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,y,o1,o2,i,a)  <--  (    1.00000000)  T2(c1,o1,o2,a) V2(c1,w,y,i) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(o1,o2) X(w,y,o1,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_coov_no0_x18, G_IF_SIGMA_CCOV_COOV_NO0_X18)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x18, G_IF_SIGMA_CCOV_COOV_NO1_X18)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.19
  //* X(y,w,o1,o2,i,a)  <--  (    1.00000000)  T2(c1,o1,o2,a) V2(c1,y,w,i) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(o1,o2) X(y,w,o1,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_coov_no0_x19, G_IF_SIGMA_CCOV_COOV_NO0_X19)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x19, G_IF_SIGMA_CCOV_COOV_NO1_X19)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.20
  //* X(w,a)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(w,a) Y8(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y8 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y20, G_IF_SIGMA_CCOV_COOV_Y20)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x20, G_IF_SIGMA_CCOV_COOV_NO0_X20)
      (sa, ia, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x20, G_IF_SIGMA_CCOV_COOV_NO1_X20)
      (sa, ia, Xc.cptr(), Y8.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.21
  //* X(w,a)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,a) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) X(w,a) Y9(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y9 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y21, G_IF_SIGMA_CCOV_COOV_Y21)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x21, G_IF_SIGMA_CCOV_COOV_NO0_X21)
      (sa, ia, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x21, G_IF_SIGMA_CCOV_COOV_NO1_X21)
      (sa, ia, Xc.cptr(), Y9.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.22
  //* X(y,a)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,a) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) X(y,a) Y10(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y10 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y22, G_IF_SIGMA_CCOV_COOV_Y22)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x22, G_IF_SIGMA_CCOV_COOV_NO0_X22)
      (sa, ia, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x22, G_IF_SIGMA_CCOV_COOV_NO1_X22)
      (sa, ia, Xc.cptr(), Y10.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.23
  //* X(y,a)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,a) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X(y,a) Y11(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y11 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_coov_y23, G_IF_SIGMA_CCOV_COOV_Y23)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x23, G_IF_SIGMA_CCOV_COOV_NO0_X23)
      (sa, ia, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_coov_no1_x23, G_IF_SIGMA_CCOV_COOV_NO1_X23)
      (sa, ia, Xc.cptr(), Y11.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.24
  //* X(y,i,o3,o5)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(y,o2,o1,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o5,o3,a) X(y,i,o3,o5) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x24, G_IF_SIGMA_CCOV_COOV_NO0_X24)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x24, G_IF_SIGMA_CCOV_COOV_NO1_X24)
        (sa, ia, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.25
  //* X(w,i,o1,o4)  <--  (    1.00000000)  D3(i,o3,o1,o4,o2,o5) V2(w,o3,o2,o5) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o1,o4,a) X(w,i,o1,o4) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x25, G_IF_SIGMA_CCOV_COOV_NO0_X25)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x25, G_IF_SIGMA_CCOV_COOV_NO1_X25)
        (sa, ia, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.26
  //* X(y,o1)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,o3,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o1,i,a) X(y,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x26, G_IF_SIGMA_CCOV_COOV_NO0_X26)
      (sy, iy, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x26, G_IF_SIGMA_CCOV_COOV_NO1_X26)
        (sa, ia, sy, iy, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.27
  //* X(w,o1)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,o3,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o1,i,a) X(w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x27, G_IF_SIGMA_CCOV_COOV_NO0_X27)
      (sw, iw, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x27, G_IF_SIGMA_CCOV_COOV_NO1_X27)
        (sa, ia, sw, iw, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.28
  //* X(y,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,i,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o1,o3,a) X(y,o1,o3,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x28, G_IF_SIGMA_CCOV_COOV_NO0_X28)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x28, G_IF_SIGMA_CCOV_COOV_NO1_X28)
        (sa, ia, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.29
  //* X(w,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,i,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,o1,o3,a) X(w,o1,o3,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x29, G_IF_SIGMA_CCOV_COOV_NO0_X29)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x29, G_IF_SIGMA_CCOV_COOV_NO1_X29)
        (sa, ia, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.30
  //* X(w,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,o4,i,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o1,o3,a) X(w,o1,o3,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x30, G_IF_SIGMA_CCOV_COOV_NO0_X30)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x30, G_IF_SIGMA_CCOV_COOV_NO1_X30)
        (sa, ia, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.31
  //* X(y,o3,o2,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,o4,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o2,o3,a) X(y,o3,o2,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x31, G_IF_SIGMA_CCOV_COOV_NO0_X31)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x31, G_IF_SIGMA_CCOV_COOV_NO1_X31)
        (sa, ia, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.32
  //* X(y,i,o4,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(y,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o4,o1,a) X(y,i,o4,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x32, G_IF_SIGMA_CCOV_COOV_NO0_X32)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x32, G_IF_SIGMA_CCOV_COOV_NO1_X32)
        (sa, ia, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.33
  //* X(w,i,o4,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(w,o3,o1,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o4,o1,a) X(w,i,o4,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x33, G_IF_SIGMA_CCOV_COOV_NO0_X33)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x33, G_IF_SIGMA_CCOV_COOV_NO1_X33)
        (sa, ia, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.34
  //* X(y,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(y,i,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,o2,o1,a) X(y,o2,i,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x34, G_IF_SIGMA_CCOV_COOV_NO0_X34)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x34, G_IF_SIGMA_CCOV_COOV_NO1_X34)
        (sa, ia, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.35
  //* X(w,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(w,i,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,o2,o1,a) X(w,o2,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x35, G_IF_SIGMA_CCOV_COOV_NO0_X35)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x35, G_IF_SIGMA_CCOV_COOV_NO1_X35)
        (sa, ia, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.36
  //* X(w,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(w,o3,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o2,o1,a) X(w,o2,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x36, G_IF_SIGMA_CCOV_COOV_NO0_X36)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x36, G_IF_SIGMA_CCOV_COOV_NO1_X36)
        (sa, ia, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.37
  //* X(y,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(y,o3,i,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o2,o1,a) X(y,o2,i,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccov_coov_no0_x37, G_IF_SIGMA_CCOV_COOV_NO0_X37)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x37, G_IF_SIGMA_CCOV_COOV_NO1_X37)
        (sa, ia, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.38
  //* X(w,y,o3,o2,o1,a)  <--  (    1.00000000)  T2(w,o3,o2,v1) V2(a,v1,y,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,y,o3,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x38, G_IF_SIGMA_CCOV_COOV_NO0_X38)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x38, G_IF_SIGMA_CCOV_COOV_NO1_X38)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.39
  //* X(y,w,o3,o1,o2,a)  <--  (    1.00000000)  T2(y,o3,o1,v1) V2(a,v1,w,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o2,o3,o1) X(y,w,o3,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x39, G_IF_SIGMA_CCOV_COOV_NO0_X39)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x39, G_IF_SIGMA_CCOV_COOV_NO1_X39)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.40
  //* X(y,o1,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,v1,y,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,o1,i,v1) X(y,o1,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x40, G_IF_SIGMA_CCOV_COOV_NO0_X40)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x40, G_IF_SIGMA_CCOV_COOV_NO1_X40)
        (sa, ia, sv1, iv1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.41
  //* X(y,o1,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,y,o2,v1) 
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,o1,i,v1) X(y,o1,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x41, G_IF_SIGMA_CCOV_COOV_NO0_X41)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x41, G_IF_SIGMA_CCOV_COOV_NO1_X41)
        (sa, ia, sv1, iv1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.42
  //* X(w,o1,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,v1,w,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,o1,i,v1) X(w,o1,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x42, G_IF_SIGMA_CCOV_COOV_NO0_X42)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x42, G_IF_SIGMA_CCOV_COOV_NO1_X42)
        (sa, ia, sv1, iv1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.43
  //* X(w,y,o2,o1,i,a)  <--  (    1.00000000)  T2(w,o2,o1,v1) V2(a,v1,y,i) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(o1,o2) X(w,y,o2,o1,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x43, G_IF_SIGMA_CCOV_COOV_NO0_X43)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x43, G_IF_SIGMA_CCOV_COOV_NO1_X43)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.44
  //* X(y,w,o2,o1,i,a)  <--  (    1.00000000)  T2(y,o2,o1,v1) V2(a,v1,w,i) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(o1,o2) X(y,w,o2,o1,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x44, G_IF_SIGMA_CCOV_COOV_NO0_X44)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x44, G_IF_SIGMA_CCOV_COOV_NO1_X44)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.45
  //* X(y,w,o2,o1,i,a)  <--  (    1.00000000)  T2(y,o2,o1,v1) V2(a,w,i,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(o1,o2) X(y,w,o2,o1,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x45, G_IF_SIGMA_CCOV_COOV_NO0_X45)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x45, G_IF_SIGMA_CCOV_COOV_NO1_X45)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.46
  //* X(y,w,o3,o2,o1,a)  <--  (    1.00000000)  T2(y,o3,o2,v1) V2(a,w,o1,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D2(i,o2,o3,o1) X(y,w,o3,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x46, G_IF_SIGMA_CCOV_COOV_NO0_X46)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x46, G_IF_SIGMA_CCOV_COOV_NO1_X46)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.47
  //* X(w,y,o1,o2,o3,a)  <--  (    1.00000000)  T2(w,o1,o2,v1) V2(a,y,o3,v1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D2(i,o2,o1,o3) X(w,y,o1,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x47, G_IF_SIGMA_CCOV_COOV_NO0_X47)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x47, G_IF_SIGMA_CCOV_COOV_NO1_X47)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.48
  //* X(w,o1,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,w,o2,v1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,o1,i,v1) X(w,o1,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x48, G_IF_SIGMA_CCOV_COOV_NO0_X48)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no1_x48, G_IF_SIGMA_CCOV_COOV_NO1_X48)
        (sa, ia, sv1, iv1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.49
  //* X(w,y,o1,o2,i,a)  <--  (    1.00000000)  T2(w,o1,o2,v1) V2(a,y,i,v1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(o1,o2) X(w,y,o1,o2,i,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_coov_no0_x49, G_IF_SIGMA_CCOV_COOV_NO0_X49)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_coov_no1_x49, G_IF_SIGMA_CCOV_COOV_NO1_X49)
      (sa, ia, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }

  return retval; 
} 
