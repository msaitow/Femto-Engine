                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_ccoo_ccov.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//  8888888888                     888                  
//  888                            888                  
//  888                            888                  
//  8888888  .d88b.  88888b.d88b.  888888  .d88b.       
//  888     d8P  Y8b 888 "888 "88b 888    d88""88b  
//  888     88888888 888  888  888 888    888  888      
//  888     Y8b.     888  888  888 Y88b.  Y88..88P      
//  888      "Y8888  888  888  888  "Y888  "Y88P"   

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_ccoo_ccov(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* X(w,y,o2,o1)  <--  (    1.00000000)  T2(w,y,o2,v1) h(o1,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o2,k,o1) X(w,y,o2,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x0, G_IF_SIGMA_CCOO_CCOV_NO0_X0)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x0, G_IF_SIGMA_CCOO_CCOV_NO1_X0)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.1
  //* X(y,w,o2,o1)  <--  (    1.00000000)  T2(y,w,o2,v1) h(o1,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o1,k,o2) X(y,w,o2,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x1, G_IF_SIGMA_CCOO_CCOV_NO0_X1)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x1, G_IF_SIGMA_CCOO_CCOV_NO1_X1)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.2
  //* X(w,y,i,o1)  <--  (    1.00000000)  T2(w,y,i,v1) h(o1,v1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(k,o1) X(w,y,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x2, G_IF_SIGMA_CCOO_CCOV_NO0_X2)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x2, G_IF_SIGMA_CCOO_CCOV_NO1_X2)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.3
  //* X(w,y,i,o1)  <--  (    1.00000000)  T2(w,y,i,v1) Y0(o1,v1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(k,o1) X(w,y,i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y0 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y3, G_IF_SIGMA_CCOO_CCOV_Y3)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x3, G_IF_SIGMA_CCOO_CCOV_NO0_X3)
      (sv1, iv1, T2b.cptr(), Y0.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x3, G_IF_SIGMA_CCOO_CCOV_NO1_X3)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.4
  //* X(w,y,i,o1)  <--  (    1.00000000)  T2(w,y,i,v1) Y1(o1,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(w,y,i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y1 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y4, G_IF_SIGMA_CCOO_CCOV_Y4)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x4, G_IF_SIGMA_CCOO_CCOV_NO0_X4)
      (sv1, iv1, T2b.cptr(), Y1.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x4, G_IF_SIGMA_CCOO_CCOV_NO1_X4)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.5
  //* X(y,w,i,o1)  <--  (    1.00000000)  T2(y,w,i,v1) h(o1,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(k,o1) X(y,w,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x5, G_IF_SIGMA_CCOO_CCOV_NO0_X5)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x5, G_IF_SIGMA_CCOO_CCOV_NO1_X5)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.6
  //* X(y,w,o1,i)  <--  (    1.00000000)  T2(y,w,o1,v1) h(i,v1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(k,o1) X(y,w,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x6, G_IF_SIGMA_CCOO_CCOV_NO0_X6)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x6, G_IF_SIGMA_CCOO_CCOV_NO1_X6)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.7
  //* X(y,w,o1,i)  <--  (    1.00000000)  T2(y,w,o1,v1) Y2(i,v1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(k,o1) X(y,w,o1,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y2 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y7, G_IF_SIGMA_CCOO_CCOV_Y7)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x7, G_IF_SIGMA_CCOO_CCOV_NO0_X7)
      (sv1, iv1, T2b.cptr(), Y2.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x7, G_IF_SIGMA_CCOO_CCOV_NO1_X7)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.8
  //* X(y,w,o1,i)  <--  (    1.00000000)  T2(y,w,o1,v1) Y3(i,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(y,w,o1,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y3 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y8, G_IF_SIGMA_CCOO_CCOV_Y8)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x8, G_IF_SIGMA_CCOO_CCOV_NO0_X8)
      (sv1, iv1, T2b.cptr(), Y3.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x8, G_IF_SIGMA_CCOO_CCOV_NO1_X8)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.9
  //* X(w,y,o1,i)  <--  (    1.00000000)  T2(w,y,o1,v1) h(i,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(k,o1) X(w,y,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x9, G_IF_SIGMA_CCOO_CCOV_NO0_X9)
      (sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x9, G_IF_SIGMA_CCOO_CCOV_NO1_X9)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.10
  //* X(y,w,k,o1)  <--  (    1.00000000)  T2(y,w,k,v1) h(o1,v1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(i,o1) X(y,w,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x10, G_IF_SIGMA_CCOO_CCOV_NO0_X10)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x10, G_IF_SIGMA_CCOO_CCOV_NO1_X10)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.11
  //* X(y,w,k,o1)  <--  (    1.00000000)  T2(y,w,k,v1) Y4(o1,v1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(i,o1) X(y,w,k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y4 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y11, G_IF_SIGMA_CCOO_CCOV_Y11)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x11, G_IF_SIGMA_CCOO_CCOV_NO0_X11)
        (sk, ik, sv1, iv1, T2b.cptr(), Y4.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x11, G_IF_SIGMA_CCOO_CCOV_NO1_X11)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.12
  //* X(y,w,k,o1)  <--  (    1.00000000)  T2(y,w,k,v1) Y5(o1,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(y,w,k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y5 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y12, G_IF_SIGMA_CCOO_CCOV_Y12)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x12, G_IF_SIGMA_CCOO_CCOV_NO0_X12)
        (sk, ik, sv1, iv1, T2b.cptr(), Y5.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x12, G_IF_SIGMA_CCOO_CCOV_NO1_X12)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.13
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(w,y,k,v1) h(o1,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(i,o1) X(w,y,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x13, G_IF_SIGMA_CCOO_CCOV_NO0_X13)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x13, G_IF_SIGMA_CCOO_CCOV_NO1_X13)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.14
  //* X(w,y,o1,k)  <--  (    1.00000000)  T2(w,y,o1,v1) h(k,v1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(i,o1) X(w,y,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x14, G_IF_SIGMA_CCOO_CCOV_NO0_X14)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x14, G_IF_SIGMA_CCOO_CCOV_NO1_X14)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.15
  //* X(w,y,o1,k)  <--  (    1.00000000)  T2(w,y,o1,v1) Y6(k,v1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(i,o1) X(w,y,o1,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y6 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y15, G_IF_SIGMA_CCOO_CCOV_Y15)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x15, G_IF_SIGMA_CCOO_CCOV_NO0_X15)
        (sk, ik, sv1, iv1, T2b.cptr(), Y6.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x15, G_IF_SIGMA_CCOO_CCOV_NO1_X15)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.16
  //* X(w,y,o1,k)  <--  (    1.00000000)  T2(w,y,o1,v1) Y7(k,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(w,y,o1,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y7 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y16, G_IF_SIGMA_CCOO_CCOV_Y16)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x16, G_IF_SIGMA_CCOO_CCOV_NO0_X16)
        (sk, ik, sv1, iv1, T2b.cptr(), Y7.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x16, G_IF_SIGMA_CCOO_CCOV_NO1_X16)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.17
  //* X(y,w,o1,k)  <--  (    1.00000000)  T2(y,w,o1,v1) h(k,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(i,o1) X(y,w,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x17, G_IF_SIGMA_CCOO_CCOV_NO0_X17)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x17, G_IF_SIGMA_CCOO_CCOV_NO1_X17)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.18
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(w,y,i,v1) h(k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x18, G_IF_SIGMA_CCOO_CCOV_NO0_X18)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.19
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,i,v1) h(k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x19, G_IF_SIGMA_CCOO_CCOV_NO0_X19)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.20
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(y,w,i,v1) Y8(k,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y8 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y20, G_IF_SIGMA_CCOO_CCOV_Y20)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x20, G_IF_SIGMA_CCOO_CCOV_NO0_X20)
        (sk, ik, sv1, iv1, T2b.cptr(), Y8.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.21
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,w,i,v1) Y9(k,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y9 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y21, G_IF_SIGMA_CCOO_CCOV_Y21)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x21, G_IF_SIGMA_CCOO_CCOV_NO0_X21)
        (sk, ik, sv1, iv1, T2b.cptr(), Y9.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.22
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(y,w,k,v1) h(i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x22, G_IF_SIGMA_CCOO_CCOV_NO0_X22)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.23
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,k,v1) h(i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x23, G_IF_SIGMA_CCOO_CCOV_NO0_X23)
        (sk, ik, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.24
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(w,y,k,v1) Y10(i,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y10 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y24, G_IF_SIGMA_CCOO_CCOV_Y24)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x24, G_IF_SIGMA_CCOO_CCOV_NO0_X24)
        (sk, ik, sv1, iv1, T2b.cptr(), Y10.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.25
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,y,k,v1) Y11(i,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y11 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y25, G_IF_SIGMA_CCOO_CCOV_Y25)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x25, G_IF_SIGMA_CCOO_CCOV_NO0_X25)
        (sk, ik, sv1, iv1, T2b.cptr(), Y11.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.26
  //* X(w,y,o1,o2)  <--  (    1.00000000)  T2(c1,w,o1,v1) V2(v1,o2,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(w,y,o1,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x26, G_IF_SIGMA_CCOO_CCOV_NO0_X26)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x26, G_IF_SIGMA_CCOO_CCOV_NO1_X26)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.27
  //* X(y,w,o2,o1)  <--  (    1.00000000)  T2(c1,y,o2,v1) V2(v1,o1,c1,w) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(y,w,o2,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x27, G_IF_SIGMA_CCOO_CCOV_NO0_X27)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x27, G_IF_SIGMA_CCOO_CCOV_NO1_X27)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.28
  //* X(w,y,o2,o1)  <--  (    1.00000000)  T2(w,c1,o2,v1) V2(v1,o1,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(w,y,o2,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x28, G_IF_SIGMA_CCOO_CCOV_NO0_X28)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x28, G_IF_SIGMA_CCOO_CCOV_NO1_X28)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.29
  //* X(y,w,o1,o2)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(v1,o2,c1,w) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(y,w,o1,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x29, G_IF_SIGMA_CCOO_CCOV_NO0_X29)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x29, G_IF_SIGMA_CCOO_CCOV_NO1_X29)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.30
  //* X(w,y,o2,o1)  <--  (    1.00000000)  T2(w,y,o2,v1) Y12(o1,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(i,o2,k,o1) X(w,y,o2,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y12 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y30, G_IF_SIGMA_CCOO_CCOV_Y30)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x30, G_IF_SIGMA_CCOO_CCOV_NO0_X30)
      (sv1, iv1, T2b.cptr(), Y12.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x30, G_IF_SIGMA_CCOO_CCOV_NO1_X30)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.31
  //* X(w,y,o2,o1)  <--  (    1.00000000)  T2(w,y,o2,v1) Y13(o1,v1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(w,y,o2,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y13 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y31, G_IF_SIGMA_CCOO_CCOV_Y31)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x31, G_IF_SIGMA_CCOO_CCOV_NO0_X31)
      (sv1, iv1, T2b.cptr(), Y13.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x31, G_IF_SIGMA_CCOO_CCOV_NO1_X31)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.32
  //* X(y,w,o1,o2)  <--  (    1.00000000)  T2(y,w,o1,v1) Y14(o2,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(i,o2,k,o1) X(y,w,o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y14 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y32, G_IF_SIGMA_CCOO_CCOV_Y32)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x32, G_IF_SIGMA_CCOO_CCOV_NO0_X32)
      (sv1, iv1, T2b.cptr(), Y14.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x32, G_IF_SIGMA_CCOO_CCOV_NO1_X32)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.33
  //* X(y,w,o1,o2)  <--  (    1.00000000)  T2(y,w,o1,v1) Y15(o2,v1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(y,w,o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y15 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y33, G_IF_SIGMA_CCOO_CCOV_Y33)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x33, G_IF_SIGMA_CCOO_CCOV_NO0_X33)
      (sv1, iv1, T2b.cptr(), Y15.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x33, G_IF_SIGMA_CCOO_CCOV_NO1_X33)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.34
  //* X(w,y,i,o1)  <--  (    1.00000000)  T2(w,c1,i,v1) V2(v1,o1,c1,y) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(w,y,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x34, G_IF_SIGMA_CCOO_CCOV_NO0_X34)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x34, G_IF_SIGMA_CCOO_CCOV_NO1_X34)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.35
  //* X(w,y,i,o1)  <--  (    1.00000000)  T2(w,c1,i,v1) V2(v1,c1,y,o1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(k,o1) X(w,y,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x35, G_IF_SIGMA_CCOO_CCOV_NO0_X35)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x35, G_IF_SIGMA_CCOO_CCOV_NO1_X35)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.36
  //* X(w,y,i,o1)  <--  (    1.00000000)  T2(c1,w,i,v1) V2(v1,o1,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(w,y,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x36, G_IF_SIGMA_CCOO_CCOV_NO0_X36)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x36, G_IF_SIGMA_CCOO_CCOV_NO1_X36)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.37
  //* X(y,w,i,o1)  <--  (    1.00000000)  T2(y,w,i,v1) Y16(o1,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(y,w,i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y16 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y37, G_IF_SIGMA_CCOO_CCOV_Y37)
      (sc1, ic1, V2_sym.cptr(), Y16.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x37, G_IF_SIGMA_CCOO_CCOV_NO0_X37)
      (sv1, iv1, T2b.cptr(), Y16.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x37, G_IF_SIGMA_CCOO_CCOV_NO1_X37)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.38
  //* X(y,w,i,o1)  <--  (    1.00000000)  T2(y,w,i,v1) Y17(o1,v1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(y,w,i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y17 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y38, G_IF_SIGMA_CCOO_CCOV_Y38)
      (sc1, ic1, V2_sym.cptr(), Y17.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x38, G_IF_SIGMA_CCOO_CCOV_NO0_X38)
      (sv1, iv1, T2b.cptr(), Y17.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x38, G_IF_SIGMA_CCOO_CCOV_NO1_X38)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.39
  //* X(y,w,i,o1)  <--  (    1.00000000)  T2(c1,y,i,v1) V2(v1,o1,c1,w) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(y,w,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x39, G_IF_SIGMA_CCOO_CCOV_NO0_X39)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x39, G_IF_SIGMA_CCOO_CCOV_NO1_X39)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.40
  //* X(y,w,i,o1)  <--  (    1.00000000)  T2(c1,y,i,v1) V2(v1,c1,w,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(y,w,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x40, G_IF_SIGMA_CCOO_CCOV_NO0_X40)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x40, G_IF_SIGMA_CCOO_CCOV_NO1_X40)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.41
  //* X(y,w,i,o1)  <--  (    1.00000000)  T2(y,c1,i,v1) V2(v1,o1,c1,w) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(y,w,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x41, G_IF_SIGMA_CCOO_CCOV_NO0_X41)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x41, G_IF_SIGMA_CCOO_CCOV_NO1_X41)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.42
  //* X(w,y,o1,i)  <--  (    1.00000000)  T2(w,c1,o1,v1) V2(v1,i,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(w,y,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x42, G_IF_SIGMA_CCOO_CCOV_NO0_X42)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x42, G_IF_SIGMA_CCOO_CCOV_NO1_X42)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.43
  //* X(w,y,o1,i)  <--  (    1.00000000)  T2(w,y,o1,v1) Y18(i,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(w,y,o1,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y18 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y43, G_IF_SIGMA_CCOO_CCOV_Y43)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x43, G_IF_SIGMA_CCOO_CCOV_NO0_X43)
      (sv1, iv1, T2b.cptr(), Y18.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x43, G_IF_SIGMA_CCOO_CCOV_NO1_X43)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.44
  //* X(w,y,o1,i)  <--  (    1.00000000)  T2(w,y,o1,v1) Y19(i,v1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(w,y,o1,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y19 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y44, G_IF_SIGMA_CCOO_CCOV_Y44)
      (sc1, ic1, V2_sym.cptr(), Y19.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x44, G_IF_SIGMA_CCOO_CCOV_NO0_X44)
      (sv1, iv1, T2b.cptr(), Y19.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x44, G_IF_SIGMA_CCOO_CCOV_NO1_X44)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.45
  //* X(w,y,o1,i)  <--  (    1.00000000)  T2(c1,w,o1,v1) V2(v1,i,c1,y) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(w,y,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x45, G_IF_SIGMA_CCOO_CCOV_NO0_X45)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x45, G_IF_SIGMA_CCOO_CCOV_NO1_X45)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.46
  //* X(w,y,o1,i)  <--  (    1.00000000)  T2(c1,w,o1,v1) V2(v1,c1,y,i) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(w,y,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x46, G_IF_SIGMA_CCOO_CCOV_NO0_X46)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x46, G_IF_SIGMA_CCOO_CCOV_NO1_X46)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.47
  //* X(y,w,o1,i)  <--  (    1.00000000)  T2(c1,y,o1,v1) V2(v1,i,c1,w) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(k,o1) X(y,w,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x47, G_IF_SIGMA_CCOO_CCOV_NO0_X47)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x47, G_IF_SIGMA_CCOO_CCOV_NO1_X47)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.48
  //* X(y,w,o1,i)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(v1,i,c1,w) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(y,w,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x48, G_IF_SIGMA_CCOO_CCOV_NO0_X48)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x48, G_IF_SIGMA_CCOO_CCOV_NO1_X48)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.49
  //* X(y,w,o1,i)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(v1,c1,w,i) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(k,o1) X(y,w,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x49, G_IF_SIGMA_CCOO_CCOV_NO0_X49)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x49, G_IF_SIGMA_CCOO_CCOV_NO1_X49)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.50
  //* X(y,w,k,o1)  <--  (    1.00000000)  T2(y,c1,k,v1) V2(v1,o1,c1,w) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(y,w,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x50, G_IF_SIGMA_CCOO_CCOV_NO0_X50)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x50, G_IF_SIGMA_CCOO_CCOV_NO1_X50)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.51
  //* X(y,w,k,o1)  <--  (    1.00000000)  T2(y,c1,k,v1) V2(v1,c1,w,o1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(i,o1) X(y,w,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x51, G_IF_SIGMA_CCOO_CCOV_NO0_X51)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x51, G_IF_SIGMA_CCOO_CCOV_NO1_X51)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.52
  //* X(y,w,k,o1)  <--  (    1.00000000)  T2(c1,y,k,v1) V2(v1,o1,c1,w) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(y,w,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x52, G_IF_SIGMA_CCOO_CCOV_NO0_X52)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x52, G_IF_SIGMA_CCOO_CCOV_NO1_X52)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.53
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(w,y,k,v1) Y20(o1,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(w,y,k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y20 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y53, G_IF_SIGMA_CCOO_CCOV_Y53)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x53, G_IF_SIGMA_CCOO_CCOV_NO0_X53)
        (sk, ik, sv1, iv1, T2b.cptr(), Y20.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x53, G_IF_SIGMA_CCOO_CCOV_NO1_X53)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.54
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(w,y,k,v1) Y21(o1,v1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(w,y,k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y21 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y54, G_IF_SIGMA_CCOO_CCOV_Y54)
      (sc1, ic1, V2_sym.cptr(), Y21.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x54, G_IF_SIGMA_CCOO_CCOV_NO0_X54)
        (sk, ik, sv1, iv1, T2b.cptr(), Y21.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x54, G_IF_SIGMA_CCOO_CCOV_NO1_X54)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.55
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(c1,w,k,v1) V2(v1,o1,c1,y) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(w,y,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x55, G_IF_SIGMA_CCOO_CCOV_NO0_X55)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x55, G_IF_SIGMA_CCOO_CCOV_NO1_X55)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.56
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(c1,w,k,v1) V2(v1,c1,y,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(w,y,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x56, G_IF_SIGMA_CCOO_CCOV_NO0_X56)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x56, G_IF_SIGMA_CCOO_CCOV_NO1_X56)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.57
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(w,c1,k,v1) V2(v1,o1,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(w,y,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x57, G_IF_SIGMA_CCOO_CCOV_NO0_X57)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x57, G_IF_SIGMA_CCOO_CCOV_NO1_X57)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.58
  //* X(y,w,o1,k)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(k,v1,c1,w) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(y,w,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x58, G_IF_SIGMA_CCOO_CCOV_NO0_X58)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x58, G_IF_SIGMA_CCOO_CCOV_NO1_X58)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.59
  //* X(y,w,o1,k)  <--  (    1.00000000)  T2(y,w,o1,v1) Y22(k,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(y,w,o1,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y22 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y59, G_IF_SIGMA_CCOO_CCOV_Y59)
      (sc1, ic1, V2_sym.cptr(), Y22.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x59, G_IF_SIGMA_CCOO_CCOV_NO0_X59)
        (sk, ik, sv1, iv1, T2b.cptr(), Y22.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x59, G_IF_SIGMA_CCOO_CCOV_NO1_X59)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.60
  //* X(y,w,o1,k)  <--  (    1.00000000)  T2(y,w,o1,v1) Y23(k,v1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(y,w,o1,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y23 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y60, G_IF_SIGMA_CCOO_CCOV_Y60)
      (sc1, ic1, V2_sym.cptr(), Y23.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x60, G_IF_SIGMA_CCOO_CCOV_NO0_X60)
        (sk, ik, sv1, iv1, T2b.cptr(), Y23.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x60, G_IF_SIGMA_CCOO_CCOV_NO1_X60)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.61
  //* X(y,w,o1,k)  <--  (    1.00000000)  T2(c1,y,o1,v1) V2(k,v1,c1,w) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(y,w,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x61, G_IF_SIGMA_CCOO_CCOV_NO0_X61)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x61, G_IF_SIGMA_CCOO_CCOV_NO1_X61)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.62
  //* X(y,w,o1,k)  <--  (    1.00000000)  T2(c1,y,o1,v1) V2(k,w,c1,v1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(y,w,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x62, G_IF_SIGMA_CCOO_CCOV_NO0_X62)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x62, G_IF_SIGMA_CCOO_CCOV_NO1_X62)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.63
  //* X(w,y,o1,k)  <--  (    1.00000000)  T2(c1,w,o1,v1) V2(k,v1,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(i,o1) X(w,y,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x63, G_IF_SIGMA_CCOO_CCOV_NO0_X63)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x63, G_IF_SIGMA_CCOO_CCOV_NO1_X63)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.64
  //* X(w,y,o1,k)  <--  (    1.00000000)  T2(w,c1,o1,v1) V2(k,v1,c1,y) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(w,y,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x64, G_IF_SIGMA_CCOO_CCOV_NO0_X64)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x64, G_IF_SIGMA_CCOO_CCOV_NO1_X64)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.65
  //* X(w,y,o1,k)  <--  (    1.00000000)  T2(w,c1,o1,v1) V2(k,y,c1,v1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(i,o1) X(w,y,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x65, G_IF_SIGMA_CCOO_CCOV_NO0_X65)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x65, G_IF_SIGMA_CCOO_CCOV_NO1_X65)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.66
  //* S2(w,y,i,k)  <--  (    8.00000000) T2(w,y,i,v1) Y24(k,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y24 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y66, G_IF_SIGMA_CCOO_CCOV_Y66)
      (sc1, ic1, V2_sym.cptr(), Y24.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x66, G_IF_SIGMA_CCOO_CCOV_NO0_X66)
        (sk, ik, sv1, iv1, T2b.cptr(), Y24.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.67
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(w,c1,i,v1) V2(k,v1,c1,y) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x67, G_IF_SIGMA_CCOO_CCOV_NO0_X67)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.68
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(c1,w,i,v1) V2(k,v1,c1,y) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x68, G_IF_SIGMA_CCOO_CCOV_NO0_X68)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.69
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(c1,w,i,v1) V2(k,y,c1,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x69, G_IF_SIGMA_CCOO_CCOV_NO0_X69)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.70
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,c1,i,v1) V2(k,v1,c1,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x70, G_IF_SIGMA_CCOO_CCOV_NO0_X70)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.71
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(y,c1,i,v1) V2(k,w,c1,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x71, G_IF_SIGMA_CCOO_CCOV_NO0_X71)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.72
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(c1,y,i,v1) V2(k,v1,c1,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x72, G_IF_SIGMA_CCOO_CCOV_NO0_X72)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.73
  //* S2(w,y,i,k)  <--  (    8.00000000) T2(y,w,k,v1) Y25(i,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y25 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y73, G_IF_SIGMA_CCOO_CCOV_Y73)
      (sc1, ic1, V2_sym.cptr(), Y25.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x73, G_IF_SIGMA_CCOO_CCOV_NO0_X73)
        (sk, ik, sv1, iv1, T2b.cptr(), Y25.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.74
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(y,c1,k,v1) V2(v1,i,c1,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x74, G_IF_SIGMA_CCOO_CCOV_NO0_X74)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.75
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(c1,y,k,v1) V2(v1,i,c1,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x75, G_IF_SIGMA_CCOO_CCOV_NO0_X75)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.76
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(c1,y,k,v1) V2(v1,c1,w,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x76, G_IF_SIGMA_CCOO_CCOV_NO0_X76)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.77
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,c1,k,v1) V2(v1,i,c1,y) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x77, G_IF_SIGMA_CCOO_CCOV_NO0_X77)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.78
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(w,c1,k,v1) V2(v1,c1,y,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x78, G_IF_SIGMA_CCOO_CCOV_NO0_X78)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.79
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(c1,w,k,v1) V2(v1,i,c1,y) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x79, G_IF_SIGMA_CCOO_CCOV_NO0_X79)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.80
  //* X(w,y,o2,o1)  <--  (    1.00000000)  T2(c1,w,o2,v1) V2(v1,c1,y,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(w,y,o2,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x80, G_IF_SIGMA_CCOO_CCOV_NO0_X80)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x80, G_IF_SIGMA_CCOO_CCOV_NO1_X80)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.81
  //* X(y,w,o1,o2)  <--  (    1.00000000)  T2(c1,y,o1,v1) V2(v1,c1,w,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,k,o1) X(y,w,o1,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x81, G_IF_SIGMA_CCOO_CCOV_NO0_X81)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x81, G_IF_SIGMA_CCOO_CCOV_NO1_X81)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.82
  //* X(w,y,o2,o1)  <--  (    1.00000000)  T2(w,c1,o2,v1) V2(v1,c1,y,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(i,o2,k,o1) X(w,y,o2,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x82, G_IF_SIGMA_CCOO_CCOV_NO0_X82)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x82, G_IF_SIGMA_CCOO_CCOV_NO1_X82)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.83
  //* X(y,w,o1,o2)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(v1,c1,w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(i,o2,k,o1) X(y,w,o1,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x83, G_IF_SIGMA_CCOO_CCOV_NO0_X83)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x83, G_IF_SIGMA_CCOO_CCOV_NO1_X83)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.84
  //* X(w,y,i,o1)  <--  (    1.00000000)  T2(c1,w,i,v1) V2(v1,c1,y,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(w,y,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x84, G_IF_SIGMA_CCOO_CCOV_NO0_X84)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x84, G_IF_SIGMA_CCOO_CCOV_NO1_X84)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.85
  //* X(y,w,i,o1)  <--  (    1.00000000)  T2(y,c1,i,v1) V2(v1,c1,w,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(y,w,i,o1) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x85, G_IF_SIGMA_CCOO_CCOV_NO0_X85)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x85, G_IF_SIGMA_CCOO_CCOV_NO1_X85)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.86
  //* X(y,w,o1,i)  <--  (    1.00000000)  T2(c1,y,o1,v1) V2(v1,c1,w,i) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(y,w,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x86, G_IF_SIGMA_CCOO_CCOV_NO0_X86)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x86, G_IF_SIGMA_CCOO_CCOV_NO1_X86)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.87
  //* X(w,y,o1,i)  <--  (    1.00000000)  T2(w,c1,o1,v1) V2(v1,c1,y,i) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(k,o1) X(w,y,o1,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x87, G_IF_SIGMA_CCOO_CCOV_NO0_X87)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x87, G_IF_SIGMA_CCOO_CCOV_NO1_X87)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.88
  //* X(y,w,k,o1)  <--  (    1.00000000)  T2(c1,y,k,v1) V2(v1,c1,w,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(y,w,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x88, G_IF_SIGMA_CCOO_CCOV_NO0_X88)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x88, G_IF_SIGMA_CCOO_CCOV_NO1_X88)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.89
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(w,c1,k,v1) V2(v1,c1,y,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(w,y,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x89, G_IF_SIGMA_CCOO_CCOV_NO0_X89)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x89, G_IF_SIGMA_CCOO_CCOV_NO1_X89)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.90
  //* X(w,y,o1,k)  <--  (    1.00000000)  T2(c1,w,o1,v1) V2(k,y,c1,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(w,y,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x90, G_IF_SIGMA_CCOO_CCOV_NO0_X90)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x90, G_IF_SIGMA_CCOO_CCOV_NO1_X90)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.91
  //* X(y,w,o1,k)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(k,w,c1,v1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(i,o1) X(y,w,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x91, G_IF_SIGMA_CCOO_CCOV_NO0_X91)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x91, G_IF_SIGMA_CCOO_CCOV_NO1_X91)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.92
  //* S2(w,y,i,k)  <--  (    8.00000000) T2(w,c1,i,v1) V2(k,y,c1,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x92, G_IF_SIGMA_CCOO_CCOV_NO0_X92)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.93
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(w,y,i,v1) Y26(k,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y26 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y93, G_IF_SIGMA_CCOO_CCOV_Y93)
      (sc1, ic1, V2_sym.cptr(), Y26.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x93, G_IF_SIGMA_CCOO_CCOV_NO0_X93)
        (sk, ik, sv1, iv1, T2b.cptr(), Y26.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.94
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(c1,y,i,v1) V2(k,w,c1,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x94, G_IF_SIGMA_CCOO_CCOV_NO0_X94)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.95
  //* S2(w,y,i,k)  <--  (    8.00000000) T2(y,c1,k,v1) V2(v1,c1,w,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x95, G_IF_SIGMA_CCOO_CCOV_NO0_X95)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.96
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(y,w,k,v1) Y27(i,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y27 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_ccov_y96, G_IF_SIGMA_CCOO_CCOV_Y96)
      (sc1, ic1, V2_sym.cptr(), Y27.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x96, G_IF_SIGMA_CCOO_CCOV_NO0_X96)
        (sk, ik, sv1, iv1, T2b.cptr(), Y27.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.97
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(c1,w,k,v1) V2(v1,c1,y,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x97, G_IF_SIGMA_CCOO_CCOV_NO0_X97)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.98
  //* X(i,o3,k,v1)  <--  (    1.00000000)  D3(i,o3,k,o2,o4,o1) V2(v1,o2,o1,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,y,o3,v1) X(i,o3,k,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x98, G_IF_SIGMA_CCOO_CCOV_NO0_X98)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x98, G_IF_SIGMA_CCOO_CCOV_NO1_X98)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.99
  //* X(i,k,o3,v1)  <--  (    1.00000000)  D3(i,o2,k,o3,o1,o4) V2(v1,o2,o1,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,w,o3,v1) X(i,k,o3,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x99, G_IF_SIGMA_CCOO_CCOV_NO0_X99)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x99, G_IF_SIGMA_CCOO_CCOV_NO1_X99)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.100
  //* X(k,v1)  <--  (    1.00000000)  D2(k,o2,o3,o1) V2(v1,o2,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,i,v1) X(k,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x100, G_IF_SIGMA_CCOO_CCOV_NO0_X100)
        (sk, ik, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x100, G_IF_SIGMA_CCOO_CCOV_NO1_X100)
        (sk, ik, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.101
  //* X(k,v1)  <--  (    1.00000000)  D2(k,o2,o3,o1) V2(v1,o2,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,w,i,v1) X(k,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      double X = 0;
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x101, G_IF_SIGMA_CCOO_CCOV_NO0_X101)
        (sk, ik, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x101, G_IF_SIGMA_CCOO_CCOV_NO1_X101)
        (sk, ik, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.102
  //* X(k,o2,i,v1)  <--  (    1.00000000)  D2(k,o2,o3,o1) V2(v1,o1,i,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,w,o2,v1) X(k,o2,i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x102, G_IF_SIGMA_CCOO_CCOV_NO0_X102)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x102, G_IF_SIGMA_CCOO_CCOV_NO1_X102)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.103
  //* X(k,o1,i,v1)  <--  (    1.00000000)  D2(k,o2,o3,o1) V2(v1,o2,i,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,y,o1,v1) X(k,o1,i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x103, G_IF_SIGMA_CCOO_CCOV_NO0_X103)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x103, G_IF_SIGMA_CCOO_CCOV_NO1_X103)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.104
  //* X(k,o2,i,v1)  <--  (    1.00000000)  D2(k,o2,o3,o1) V2(v1,i,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,y,o2,v1) X(k,o2,i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x104, G_IF_SIGMA_CCOO_CCOV_NO0_X104)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x104, G_IF_SIGMA_CCOO_CCOV_NO1_X104)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.105
  //* X(k,o2,i,v1)  <--  (    1.00000000)  D2(k,o2,o3,o1) V2(v1,i,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,o2,v1) X(k,o2,i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x105, G_IF_SIGMA_CCOO_CCOV_NO0_X105)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x105, G_IF_SIGMA_CCOO_CCOV_NO1_X105)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.106
  //* X(i,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(v1,o2,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,k,v1) X(i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x106, G_IF_SIGMA_CCOO_CCOV_NO0_X106)
      (sv1, iv1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x106, G_IF_SIGMA_CCOO_CCOV_NO1_X106)
        (sk, ik, sv1, iv1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.107
  //* X(i,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(v1,o2,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,y,k,v1) X(i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x107, G_IF_SIGMA_CCOO_CCOV_NO0_X107)
      (sv1, iv1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x107, G_IF_SIGMA_CCOO_CCOV_NO1_X107)
        (sk, ik, sv1, iv1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.108
  //* X(i,o2,k,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(k,o3,o1,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,y,o2,v1) X(i,o2,k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x108, G_IF_SIGMA_CCOO_CCOV_NO0_X108)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x108, G_IF_SIGMA_CCOO_CCOV_NO1_X108)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.109
  //* X(i,o1,k,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(k,o3,o2,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,w,o1,v1) X(i,o1,k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x109, G_IF_SIGMA_CCOO_CCOV_NO0_X109)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x109, G_IF_SIGMA_CCOO_CCOV_NO1_X109)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.110
  //* X(i,o2,k,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(k,v1,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,w,o2,v1) X(i,o2,k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x110, G_IF_SIGMA_CCOO_CCOV_NO0_X110)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x110, G_IF_SIGMA_CCOO_CCOV_NO1_X110)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.111
  //* X(i,o2,k,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(k,v1,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,o2,v1) X(i,o2,k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x111, G_IF_SIGMA_CCOO_CCOV_NO0_X111)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x111, G_IF_SIGMA_CCOO_CCOV_NO1_X111)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.112
  //* X(k,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,o1,o2,v1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,i,v1) X(k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x112, G_IF_SIGMA_CCOO_CCOV_NO0_X112)
        (sk, ik, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x112, G_IF_SIGMA_CCOO_CCOV_NO1_X112)
        (sk, ik, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.113
  //* X(k,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,v1,o1,o2) 
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(w,y,i,v1) X(k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x113, G_IF_SIGMA_CCOO_CCOV_NO0_X113)
        (sk, ik, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x113, G_IF_SIGMA_CCOO_CCOV_NO1_X113)
        (sk, ik, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.114
  //* X(k,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,o1,o2,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,w,i,v1) X(k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x114, G_IF_SIGMA_CCOO_CCOV_NO0_X114)
        (sk, ik, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x114, G_IF_SIGMA_CCOO_CCOV_NO1_X114)
        (sk, ik, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.115
  //* X(k,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,v1,o1,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,i,v1) X(k,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x115, G_IF_SIGMA_CCOO_CCOV_NO0_X115)
        (sk, ik, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x115, G_IF_SIGMA_CCOO_CCOV_NO1_X115)
        (sk, ik, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.116
  //* X(o2,k,i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,v1,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,w,o2,v1) X(o2,k,i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x116, G_IF_SIGMA_CCOO_CCOV_NO0_X116)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x116, G_IF_SIGMA_CCOO_CCOV_NO1_X116)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.117
  //* X(o2,k,i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,v1,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,o2,v1) X(o2,k,i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x117, G_IF_SIGMA_CCOO_CCOV_NO0_X117)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x117, G_IF_SIGMA_CCOO_CCOV_NO1_X117)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.118
  //* X(o2,k,i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,o1,i,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,y,o2,v1) X(o2,k,i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x118, G_IF_SIGMA_CCOO_CCOV_NO0_X118)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x118, G_IF_SIGMA_CCOO_CCOV_NO1_X118)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.119
  //* X(i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(v1,o2,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,k,v1) X(i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x119, G_IF_SIGMA_CCOO_CCOV_NO0_X119)
      (sv1, iv1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x119, G_IF_SIGMA_CCOO_CCOV_NO1_X119)
        (sk, ik, sv1, iv1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.120
  //* X(i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(v1,i,o1,o2) 
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(y,w,k,v1) X(i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x120, G_IF_SIGMA_CCOO_CCOV_NO0_X120)
      (sv1, iv1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x120, G_IF_SIGMA_CCOO_CCOV_NO1_X120)
        (sk, ik, sv1, iv1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.121
  //* X(i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(v1,o2,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,y,k,v1) X(i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x121, G_IF_SIGMA_CCOO_CCOV_NO0_X121)
      (sv1, iv1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x121, G_IF_SIGMA_CCOO_CCOV_NO1_X121)
        (sk, ik, sv1, iv1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.122
  //* X(i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(v1,i,o1,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,k,v1) X(i,v1) 
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sv1, X);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x122, G_IF_SIGMA_CCOO_CCOV_NO0_X122)
      (sv1, iv1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x122, G_IF_SIGMA_CCOO_CCOV_NO1_X122)
        (sk, ik, sv1, iv1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.123
  //* X(o2,k,i,v1)  <--  (    1.00000000)  D1(o1,o2) V2(k,o1,i,v1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,o2,v1) X(o2,k,i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sk^sv1, X);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x123, G_IF_SIGMA_CCOO_CCOV_NO0_X123)
        (sk, ik, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no1_x123, G_IF_SIGMA_CCOO_CCOV_NO1_X123)
        (sk, ik, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.124
  //* X(w,y,o2,o3)  <--  (    1.00000000)  T2(w,y,o1,v1) V2(v1,o2,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o3,k,o2) X(w,y,o2,o3) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x124, G_IF_SIGMA_CCOO_CCOV_NO0_X124)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x124, G_IF_SIGMA_CCOO_CCOV_NO1_X124)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.125
  //* X(y,w,o1,o2)  <--  (    1.00000000)  T2(y,w,o3,v1) V2(v1,o1,o2,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o1,k,o2) X(y,w,o1,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x125, G_IF_SIGMA_CCOO_CCOV_NO0_X125)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x125, G_IF_SIGMA_CCOO_CCOV_NO1_X125)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.126
  //* X(w,y,o2,i)  <--  (    1.00000000)  T2(w,y,o1,v1) V2(v1,o2,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(k,o2) X(w,y,o2,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x126, G_IF_SIGMA_CCOO_CCOV_NO0_X126)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x126, G_IF_SIGMA_CCOO_CCOV_NO1_X126)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.127
  //* X(w,y,i,o2)  <--  (    1.00000000)  T2(w,y,o1,v1) V2(v1,i,o1,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(k,o2) X(w,y,i,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x127, G_IF_SIGMA_CCOO_CCOV_NO0_X127)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x127, G_IF_SIGMA_CCOO_CCOV_NO1_X127)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.128
  //* X(y,w,o2,i)  <--  (    1.00000000)  T2(y,w,o1,v1) V2(v1,o2,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(k,o2) X(y,w,o2,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x128, G_IF_SIGMA_CCOO_CCOV_NO0_X128)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x128, G_IF_SIGMA_CCOO_CCOV_NO1_X128)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.129
  //* X(y,w,i,o2)  <--  (    1.00000000)  T2(y,w,o1,v1) V2(v1,i,o1,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(k,o2) X(y,w,i,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc);
  orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, 0, X);
  for(int sv1 = 0;sv1 < nir;++sv1){ 
  for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iv1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iv1, sv1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(iv1);
    FC_FUNC(g_if_sigma_ccoo_ccov_no0_x129, G_IF_SIGMA_CCOO_CCOV_NO0_X129)
      (sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x129, G_IF_SIGMA_CCOO_CCOV_NO1_X129)
      (sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.130
  //* X(y,w,k,o2)  <--  (    1.00000000)  T2(y,w,o1,v1) V2(k,o1,o2,v1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(i,o2) X(y,w,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x130, G_IF_SIGMA_CCOO_CCOV_NO0_X130)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x130, G_IF_SIGMA_CCOO_CCOV_NO1_X130)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.131
  //* X(y,w,k,o2)  <--  (    1.00000000)  T2(y,w,o1,v1) V2(k,v1,o1,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(i,o2) X(y,w,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x131, G_IF_SIGMA_CCOO_CCOV_NO0_X131)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x131, G_IF_SIGMA_CCOO_CCOV_NO1_X131)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.132
  //* X(w,y,k,o2)  <--  (    1.00000000)  T2(w,y,o1,v1) V2(k,o1,o2,v1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(i,o2) X(w,y,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x132, G_IF_SIGMA_CCOO_CCOV_NO0_X132)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x132, G_IF_SIGMA_CCOO_CCOV_NO1_X132)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.133
  //* X(w,y,k,o1)  <--  (    1.00000000)  T2(w,y,o2,v1) V2(k,v1,o1,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(i,o1) X(w,y,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sk, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x133, G_IF_SIGMA_CCOO_CCOV_NO0_X133)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_ccov_no1_x133, G_IF_SIGMA_CCOO_CCOV_NO1_X133)
      (sk, ik, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.134
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(w,y,o1,v1) V2(k,v1,i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x134, G_IF_SIGMA_CCOO_CCOV_NO0_X134)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.135
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,w,o1,v1) V2(k,v1,i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x135, G_IF_SIGMA_CCOO_CCOV_NO0_X135)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.136
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(y,w,o1,v1) V2(k,o1,i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x136, G_IF_SIGMA_CCOO_CCOV_NO0_X136)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.137
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,y,o1,v1) V2(k,o1,i,v1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccoo_ccov_no0_x137, G_IF_SIGMA_CCOO_CCOV_NO0_X137)
        (sk, ik, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }

  return retval; 
} 
