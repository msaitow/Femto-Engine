                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_g_ccoo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
double orz::ct::sigma_g_ccoo(const orz::ct::Input &ctinp,                                                  
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const double init_value,                                                  
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  double S0 = init_value;                                                               
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* X(o4,o3,o2,o1)  <--  (    1.00000000)  T2(c1,c2,o4,o3) V2(c1,o2,c2,o1) 
  //* S0()  <--  (    1.00000000) D2(o1,o3,o2,o4) X(o4,o3,o2,o1) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_g_ccoo_no0_x0, G_IF_SIGMA_G_CCOO_NO0_X0)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_g_ccoo_no1_x0, G_IF_SIGMA_G_CCOO_NO1_X0)
      (so3, io3, Xaaa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.1
  //* X(o3,o2)  <--  (    1.00000000)  T2(c2,c1,o1,o3) V2(c1,o2,c2,o1) 
  //* S0()  <--  (   -2.00000000) D1(o2,o3) X(o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_g_ccoo_no0_x1, G_IF_SIGMA_G_CCOO_NO0_X1)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_g_ccoo_no1_x1, G_IF_SIGMA_G_CCOO_NO1_X1)
      (so3, io3, Xa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.2
  //* X(o3,o2)  <--  (    1.00000000)  T2(c2,c1,o1,o3) V2(c1,o1,c2,o2) 
  //* S0()  <--  (    1.00000000) D1(o2,o3) X(o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_g_ccoo_no0_x2, G_IF_SIGMA_G_CCOO_NO0_X2)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_g_ccoo_no1_x2, G_IF_SIGMA_G_CCOO_NO1_X2)
      (so3, io3, Xa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.3
  //* X(o2,o3)  <--  (    1.00000000)  T2(c2,c1,o2,o1) V2(o1,c2,c1,o3) 
  //* S0()  <--  (    1.00000000) D1(o2,o3) X(o2,o3) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_g_ccoo_no0_x3, G_IF_SIGMA_G_CCOO_NO0_X3)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_ccoo_no1_x3, G_IF_SIGMA_G_CCOO_NO1_X3)
    (Xaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.4
  //* X(o2,o1)  <--  (    1.00000000)  T2(c1,c2,o2,o3) V2(o3,c2,c1,o1) 
  //* S0()  <--  (   -2.00000000) D1(o1,o2) X(o2,o1) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io3);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io3, so3, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_g_ccoo_no0_x4, G_IF_SIGMA_G_CCOO_NO0_X4)
      (so3, io3, T2b.cptr(), V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_ccoo_no1_x4, G_IF_SIGMA_G_CCOO_NO1_X4)
    (Xaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.5
  //* S0()  <--  (    4.00000000) T2(c2,c1,o2,o1) V2(o1,c1,c2,o2) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_g_ccoo_no0_x5, G_IF_SIGMA_G_CCOO_NO0_X5)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.6
  //* S0()  <--  (   -2.00000000) T2(c1,c2,o1,o2) V2(o2,c1,c2,o1) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io2);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io2, so2, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_g_ccoo_no0_x6, G_IF_SIGMA_G_CCOO_NO0_X6)
      (so2, io2, T2b.cptr(), V2_sym.cptr(), &S0, nir, nsym, psym);
  }
  }
  }

  return  S0;
} 
