                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_coov_cooo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_coov_cooo(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::DTensor &rdm4,                                                 
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                        


  {
  // No.0
  //* X(w,i,o3,k)  <--  (    1.00000000)  D3(i,o3,o1,k,o2,o4) T2(w,o4,o1,o2) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) X(w,i,o3,k) h(o3,a) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x0, G_IF_SIGMA_COOV_COOO_NO0_X0)
      (so2, io2, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x0, G_IF_SIGMA_COOV_COOO_NO1_X0)
      (sa, ia, Xcaaa.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.1
  //* X(w,i,o2,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o1,k,o3) 
  //* S2(w,i,k,a)  <--  (    2.00000000) X(w,i,o2,k) h(o2,a) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x1, G_IF_SIGMA_COOV_COOO_NO0_X1)
      (so3, io3, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x1, G_IF_SIGMA_COOV_COOO_NO1_X1)
      (sa, ia, Xcaaa.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.2
  //* X(w,i,o2,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o1,k,o3) 
  //* S2(w,i,k,a)  <--  (    4.00000000) X(w,i,o2,k) Y0(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y0 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y2, G_IF_SIGMA_COOV_COOO_Y2)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x2, G_IF_SIGMA_COOV_COOO_NO0_X2)
      (so3, io3, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x2, G_IF_SIGMA_COOV_COOO_NO1_X2)
      (sa, ia, Xcaaa.cptr(), Y0.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.3
  //* X(w,i,o2,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o1,k,o3) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) X(w,i,o2,k) Y1(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y1 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y3, G_IF_SIGMA_COOV_COOO_Y3)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x3, G_IF_SIGMA_COOV_COOO_NO0_X3)
      (so3, io3, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x3, G_IF_SIGMA_COOV_COOO_NO1_X3)
      (sa, ia, Xcaaa.cptr(), Y1.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.4
  //* X(w,i,o2,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o1,o3,k) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) X(w,i,o2,k) h(o2,a) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x4, G_IF_SIGMA_COOV_COOO_NO0_X4)
      (sk, ik, T2b.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x4, G_IF_SIGMA_COOV_COOO_NO1_X4)
        (sa, ia, sk, ik, Xcaa.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.5
  //* X(w,i,k,o1)  <--  (    1.00000000)  D2(i,k,o3,o2) T2(w,o2,o1,o3) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) X(w,i,k,o1) h(o1,a) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x5, G_IF_SIGMA_COOV_COOO_NO0_X5)
      (so3, io3, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x5, G_IF_SIGMA_COOV_COOO_NO1_X5)
      (sa, ia, Xcaaa.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.6
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(w,o2,o1,k) h(o1,a) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x6, G_IF_SIGMA_COOV_COOO_NO0_X6)
        (sa, ia, sk, ik, T2b.cptr(), moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x6, G_IF_SIGMA_COOV_COOO_NO1_X6)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.7
  //* X(w,i,k,o3)  <--  (    1.00000000)  D2(i,o2,o1,k) T2(w,o2,o1,o3) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) X(w,i,k,o3) h(o3,a) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x7, G_IF_SIGMA_COOV_COOO_NO0_X7)
      (so3, io3, T2b.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x7, G_IF_SIGMA_COOV_COOO_NO1_X7)
        (sa, ia, so3, io3, Xcaa.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.8
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(w,o1,k,o2) h(o2,a) 
  //* S2(w,i,k,a)  <--  (    2.00000000) D1(i,o1) X(w,o1,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x8, G_IF_SIGMA_COOV_COOO_NO0_X8)
        (sa, ia, so2, io2, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x8, G_IF_SIGMA_COOV_COOO_NO1_X8)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.9
  //* X(w,o1,o3,o4,o2,a)  <--  (    1.00000000)  T2(c1,o1,o3,o4) V2(a,o2,c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D3(i,o2,o3,k,o4,o1) X(w,o1,o3,o4,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x9, G_IF_SIGMA_COOV_COOO_NO0_X9)
        (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x9, G_IF_SIGMA_COOV_COOO_NO1_X9)
        (sa, ia, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.10
  //* X(w,i,o2,k)  <--  (    1.00000000)  D3(i,o2,o3,k,o4,o1) T2(w,o1,o3,o4) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) X(w,i,o2,k) Y2(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y2 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y10, G_IF_SIGMA_COOV_COOO_Y10)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x10, G_IF_SIGMA_COOV_COOO_NO0_X10)
      (so4, io4, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x10, G_IF_SIGMA_COOV_COOO_NO1_X10)
      (sa, ia, Xcaaa.cptr(), Y2.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.11
  //* X(w,i,o2,k)  <--  (    1.00000000)  D3(i,o2,o3,k,o4,o1) T2(w,o1,o3,o4) 
  //* S2(w,i,k,a)  <--  (    1.00000000) X(w,i,o2,k) Y3(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y3 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y11, G_IF_SIGMA_COOV_COOO_Y11)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x11, G_IF_SIGMA_COOV_COOO_NO0_X11)
      (so4, io4, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x11, G_IF_SIGMA_COOV_COOO_NO1_X11)
      (sa, ia, Xcaaa.cptr(), Y3.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.12
  //* X(w,o1,k,o3,o2,a)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(a,o2,c1,w) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D2(i,o2,o3,o1) X(w,o1,k,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x12, G_IF_SIGMA_COOV_COOO_NO0_X12)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x12, G_IF_SIGMA_COOV_COOO_NO1_X12)
        (sa, ia, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.13
  //* X(w,o1,k,o3,o2,a)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(a,w,c1,o2) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o1,k,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x13, G_IF_SIGMA_COOV_COOO_NO0_X13)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x13, G_IF_SIGMA_COOV_COOO_NO1_X13)
        (sa, ia, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.14
  //* X(w,o1,o3,k,o2,a)  <--  (    1.00000000)  T2(c1,o1,o3,k) V2(a,o2,c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o1,o3,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x14, G_IF_SIGMA_COOV_COOO_NO0_X14)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x14, G_IF_SIGMA_COOV_COOO_NO1_X14)
        (sa, ia, sk, ik, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.15
  //* X(w,i,o2,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o1,o3,k) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) X(w,i,o2,k) Y4(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y4 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y15, G_IF_SIGMA_COOV_COOO_Y15)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x15, G_IF_SIGMA_COOV_COOO_NO0_X15)
      (sk, ik, T2b.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x15, G_IF_SIGMA_COOV_COOO_NO1_X15)
        (sa, ia, sk, ik, Xcaa.cptr(), Y4.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.16
  //* X(w,i,o2,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o1,o3,k) 
  //* S2(w,i,k,a)  <--  (    1.00000000) X(w,i,o2,k) Y5(o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y5 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y16, G_IF_SIGMA_COOV_COOO_Y16)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x16, G_IF_SIGMA_COOV_COOO_NO0_X16)
      (sk, ik, T2b.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x16, G_IF_SIGMA_COOV_COOO_NO1_X16)
        (sa, ia, sk, ik, Xcaa.cptr(), Y5.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.17
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(c1,o2,o1,o3) V2(a,o1,c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x17, G_IF_SIGMA_COOV_COOO_NO0_X17)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x17, G_IF_SIGMA_COOV_COOO_NO1_X17)
        (sa, ia, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,i,k,o1)  <--  (    1.00000000)  D2(i,k,o3,o2) T2(w,o2,o1,o3) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) X(w,i,k,o1) Y6(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y6 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y18, G_IF_SIGMA_COOV_COOO_Y18)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x18, G_IF_SIGMA_COOV_COOO_NO0_X18)
      (so3, io3, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x18, G_IF_SIGMA_COOV_COOO_NO1_X18)
      (sa, ia, Xcaaa.cptr(), Y6.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.19
  //* X(w,i,k,o1)  <--  (    1.00000000)  D2(i,k,o3,o2) T2(w,o2,o1,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) X(w,i,k,o1) Y7(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y7 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y19, G_IF_SIGMA_COOV_COOO_Y19)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x19, G_IF_SIGMA_COOV_COOO_NO0_X19)
      (so3, io3, T2b.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    FC_FUNC(g_if_sigma_coov_cooo_no1_x19, G_IF_SIGMA_COOV_COOO_NO1_X19)
      (sa, ia, Xcaaa.cptr(), Y7.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.20
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(c1,o2,o1,k) V2(a,o1,c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x20, G_IF_SIGMA_COOV_COOO_NO0_X20)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x20, G_IF_SIGMA_COOV_COOO_NO1_X20)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.21
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(w,o2,o1,k) Y8(o1,a) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y8 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y21, G_IF_SIGMA_COOV_COOO_Y21)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x21, G_IF_SIGMA_COOV_COOO_NO0_X21)
        (sa, ia, sk, ik, T2b.cptr(), Y8.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x21, G_IF_SIGMA_COOV_COOO_NO1_X21)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.22
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(w,o2,o1,k) Y9(o1,a) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y9 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y22, G_IF_SIGMA_COOV_COOO_Y22)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x22, G_IF_SIGMA_COOV_COOO_NO0_X22)
        (sa, ia, sk, ik, T2b.cptr(), Y9.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x22, G_IF_SIGMA_COOV_COOO_NO1_X22)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.23
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(a,o1,c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x23, G_IF_SIGMA_COOV_COOO_NO0_X23)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x23, G_IF_SIGMA_COOV_COOO_NO1_X23)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.24
  //* X(w,i,k,o1)  <--  (    1.00000000)  D2(i,o2,o3,k) T2(w,o2,o3,o1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) X(w,i,k,o1) Y10(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y10 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y24, G_IF_SIGMA_COOV_COOO_Y24)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x24, G_IF_SIGMA_COOV_COOO_NO0_X24)
      (so1, io1, T2b.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x24, G_IF_SIGMA_COOV_COOO_NO1_X24)
        (sa, ia, so1, io1, Xcaa.cptr(), Y10.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.25
  //* X(w,i,k,o1)  <--  (    1.00000000)  D2(i,o2,o3,k) T2(w,o2,o3,o1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) X(w,i,k,o1) Y11(o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y11 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y25, G_IF_SIGMA_COOV_COOO_Y25)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x25, G_IF_SIGMA_COOV_COOO_NO0_X25)
      (so1, io1, T2b.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x25, G_IF_SIGMA_COOV_COOO_NO1_X25)
        (sa, ia, so1, io1, Xcaa.cptr(), Y11.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.26
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(w,o2,k,o1) Y12(o1,a) 
  //* S2(w,i,k,a)  <--  (    4.00000000) D1(i,o2) X(w,o2,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y12 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y26, G_IF_SIGMA_COOV_COOO_Y26)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x26, G_IF_SIGMA_COOV_COOO_NO0_X26)
        (sa, ia, so1, io1, T2b.cptr(), Y12.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x26, G_IF_SIGMA_COOV_COOO_NO1_X26)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.27
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(c1,o2,k,o1) V2(a,o1,c1,w) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x27, G_IF_SIGMA_COOV_COOO_NO0_X27)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x27, G_IF_SIGMA_COOV_COOO_NO1_X27)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.28
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(c1,o2,k,o1) V2(a,w,c1,o1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x28, G_IF_SIGMA_COOV_COOO_NO0_X28)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x28, G_IF_SIGMA_COOV_COOO_NO1_X28)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.29
  //* X(w,o2,o3,o4,o1,a)  <--  (    1.00000000)  T2(c1,o2,o3,o4) V2(a,w,c1,o1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D3(i,k,o3,o1,o4,o2) X(w,o2,o3,o4,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x29, G_IF_SIGMA_COOV_COOO_NO0_X29)
        (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x29, G_IF_SIGMA_COOV_COOO_NO1_X29)
        (sa, ia, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.30
  //* X(w,o2,o3,k,o1,a)  <--  (    1.00000000)  T2(c1,o2,o3,k) V2(a,w,c1,o1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o2,o3,k,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x30, G_IF_SIGMA_COOV_COOO_NO0_X30)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x30, G_IF_SIGMA_COOV_COOO_NO1_X30)
        (sa, ia, sk, ik, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.31
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(c1,o2,o1,o3) V2(a,w,c1,o1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x31, G_IF_SIGMA_COOV_COOO_NO0_X31)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x31, G_IF_SIGMA_COOV_COOO_NO1_X31)
        (sa, ia, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.32
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(c1,o2,o1,k) V2(a,w,c1,o1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x32, G_IF_SIGMA_COOV_COOO_NO0_X32)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x32, G_IF_SIGMA_COOV_COOO_NO1_X32)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.33
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(a,w,c1,o1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x33, G_IF_SIGMA_COOV_COOO_NO0_X33)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x33, G_IF_SIGMA_COOV_COOO_NO1_X33)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.34
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(w,o2,k,o1) Y13(o1,a) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nvir);
  orz::DTensor Y13 = orz::ct::sympack_Xav(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_cooo_y34, G_IF_SIGMA_COOV_COOO_Y34)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x34, G_IF_SIGMA_COOV_COOO_NO0_X34)
        (sa, ia, so1, io1, T2b.cptr(), Y13.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x34, G_IF_SIGMA_COOV_COOO_NO1_X34)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.35
  //* X(i,o1,k,o2,o5,a)  <--  (    1.00000000)  D4(i,o4,o1,k,o2,o5,o3,o6) V2(a,o4,o3,o6) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(w,o5,o1,o2) X(i,o1,k,o2,o5,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      for(int so2 = 0;so2 < nir;++so2){ 
      for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
        orz::DTensor X(nocc, nocc, nocc);
        orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, si^so2^sa, X);
        for(int so4 = 0;so4 < nir;++so4){ 
        for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
          // Load D4 from disk, or GA ....                                                     
          int imoi = amo2imo[ii] - nclosed;                              
          int imoj = amo2imo[io4] - nclosed;                              
                                                                                               
          orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice()).copy();    
          rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, ii, si, io4, so4, rdm4_ij_sliced);    
          FC_FUNC(g_if_set_d4,G_IF_SET_D4)(si, so4, ii, io4, rdm4_sym.cptr(), nir, nsym, psym);  
          FC_FUNC(g_if_sigma_coov_cooo_no0_x35, G_IF_SIGMA_COOV_COOO_NO0_X35)
            (sa, ia, si, ii, so2, io2, so4, io4, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
          FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
        }
        }
        T2b = T2.get_amp2(io2);
        FC_FUNC(g_if_sigma_coov_cooo_no1_x35, G_IF_SIGMA_COOV_COOO_NO1_X35)
          (sa, ia, si, ii, so2, io2, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.36
  //* X(i,o4,o1,a)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(a,o3,o2,o5) 
  //* S2(w,i,k,a)  <--  (    2.00000000) T2(w,o1,k,o4) X(i,o4,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x36, G_IF_SIGMA_COOV_COOO_NO0_X36)
        (sa, ia, so4, io4, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x36, G_IF_SIGMA_COOV_COOO_NO1_X36)
        (sa, ia, so4, io4, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.37
  //* X(i,o4,o1,a)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(a,o3,o2,o5) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(w,o1,o4,k) X(i,o4,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x37, G_IF_SIGMA_COOV_COOO_NO0_X37)
      (sa, ia, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x37, G_IF_SIGMA_COOV_COOO_NO1_X37)
        (sa, ia, sk, ik, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.38
  //* X(i,o4,o5,o2,k,a)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(a,o3,k,o1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(w,o2,o4,o5) X(i,o4,o5,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      orz::DTensor X(nocc, nocc, nocc, nocc);
      orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, so5^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x38, G_IF_SIGMA_COOV_COOO_NO0_X38)
        (sa, ia, so5, io5, V2_sym.cptr(), Xaaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io5);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x38, G_IF_SIGMA_COOV_COOO_NO1_X38)
        (sa, ia, so5, io5, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.39
  //* X(w,o2,o5,o3,o4,a)  <--  (    1.00000000)  T2(w,o2,o1,o5) V2(a,o3,o1,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D3(i,o3,o4,k,o5,o2) X(w,o2,o5,o3,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so5^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x39, G_IF_SIGMA_COOV_COOO_NO0_X39)
        (sa, ia, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x39, G_IF_SIGMA_COOV_COOO_NO1_X39)
        (sa, ia, so5, io5, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.40
  //* X(i,o2,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o3,o1,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(w,o2,o1,k) X(i,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x40, G_IF_SIGMA_COOV_COOO_NO0_X40)
      (sa, ia, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x40, G_IF_SIGMA_COOV_COOO_NO1_X40)
        (sa, ia, sk, ik, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.41
  //* X(w,o2,o4,o3,k,a)  <--  (    1.00000000)  T2(w,o2,o1,o4) V2(a,o3,k,o1) 
  //* S2(w,i,k,a)  <--  (    2.00000000) D2(i,o3,o4,o2) X(w,o2,o4,o3,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x41, G_IF_SIGMA_COOV_COOO_NO0_X41)
        (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x41, G_IF_SIGMA_COOV_COOO_NO1_X41)
        (sa, ia, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.42
  //* X(w,o2,o4,k,o3,a)  <--  (    1.00000000)  T2(w,o2,o1,o4) V2(a,o1,k,o3) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,o3,o4,o2) X(w,o2,o4,k,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x42, G_IF_SIGMA_COOV_COOO_NO0_X42)
        (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x42, G_IF_SIGMA_COOV_COOO_NO1_X42)
        (sa, ia, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.43
  //* X(w,o2,o4,o3,o5,a)  <--  (    1.00000000)  T2(w,o2,o4,o1) V2(a,o3,o1,o5) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D3(i,o3,o4,k,o5,o2) X(w,o2,o4,o3,o5,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x43, G_IF_SIGMA_COOV_COOO_NO0_X43)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x43, G_IF_SIGMA_COOV_COOO_NO1_X43)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.44
  //* X(i,o2,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o3,o1,o4) 
  //* S2(w,i,k,a)  <--  (    2.00000000) T2(w,o2,k,o1) X(i,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x44, G_IF_SIGMA_COOV_COOO_NO0_X44)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x44, G_IF_SIGMA_COOV_COOO_NO1_X44)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.45
  //* X(w,o2,o4,o3,k,a)  <--  (    1.00000000)  T2(w,o2,o4,o1) V2(a,o3,k,o1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,o3,o4,o2) X(w,o2,o4,o3,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x45, G_IF_SIGMA_COOV_COOO_NO0_X45)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x45, G_IF_SIGMA_COOV_COOO_NO1_X45)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.46
  //* X(w,o2,o4,o3,o5,a)  <--  (    1.00000000)  T2(w,o2,o1,o4) V2(a,o1,o3,o5) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D3(i,k,o4,o2,o5,o3) X(w,o2,o4,o3,o5,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x46, G_IF_SIGMA_COOV_COOO_NO0_X46)
        (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x46, G_IF_SIGMA_COOV_COOO_NO1_X46)
        (sa, ia, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.47
  //* X(i,o3,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o1,o2,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(w,o3,o1,k) X(i,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_cooo_no0_x47, G_IF_SIGMA_COOV_COOO_NO0_X47)
      (sa, ia, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x47, G_IF_SIGMA_COOV_COOO_NO1_X47)
        (sa, ia, sk, ik, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.48
  //* X(w,o3,o1,o2,o4,a)  <--  (    1.00000000)  T2(w,o3,o1,o5) V2(a,o5,o2,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D3(i,o3,o1,k,o2,o4) X(w,o3,o1,o2,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x48, G_IF_SIGMA_COOV_COOO_NO0_X48)
        (sa, ia, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x48, G_IF_SIGMA_COOV_COOO_NO1_X48)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.49
  //* X(i,o3,o1,a)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(a,o1,o2,o4) 
  //* S2(w,i,k,a)  <--  (    2.00000000) T2(w,o3,k,o1) X(i,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so1^sa, X);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x49, G_IF_SIGMA_COOV_COOO_NO0_X49)
        (sa, ia, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no1_x49, G_IF_SIGMA_COOV_COOO_NO1_X49)
        (sa, ia, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.50
  //* X(w,o3,o4,k,o2,a)  <--  (    1.00000000)  T2(w,o3,o4,o1) V2(a,o1,k,o2) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,o3,o4,o2) X(w,o3,o4,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x50, G_IF_SIGMA_COOV_COOO_NO0_X50)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x50, G_IF_SIGMA_COOV_COOO_NO1_X50)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.51
  //* X(w,o3,o4,a)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(a,o1,o2,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,o3,o4,k) X(w,o3,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x51, G_IF_SIGMA_COOV_COOO_NO0_X51)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x51, G_IF_SIGMA_COOV_COOO_NO1_X51)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.52
  //* X(w,o3,k,a)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(a,o1,k,o2) 
  //* S2(w,i,k,a)  <--  (    2.00000000) D1(i,o3) X(w,o3,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x52, G_IF_SIGMA_COOV_COOO_NO0_X52)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x52, G_IF_SIGMA_COOV_COOO_NO1_X52)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.53
  //* X(w,o2,o1,a)  <--  (    1.00000000)  T2(w,o2,o3,o4) V2(a,o3,o1,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,k,o1,o2) X(w,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x53, G_IF_SIGMA_COOV_COOO_NO0_X53)
        (sa, ia, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x53, G_IF_SIGMA_COOV_COOO_NO1_X53)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.54
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(w,o1,o2,o3) V2(a,o2,k,o3) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D1(i,o1) X(w,o1,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_coov_cooo_no0_x54, G_IF_SIGMA_COOV_COOO_NO0_X54)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_cooo_no1_x54, G_IF_SIGMA_COOV_COOO_NO1_X54)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }

  return retval; 
} 
