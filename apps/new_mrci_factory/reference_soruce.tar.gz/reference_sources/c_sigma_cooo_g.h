

#ifndef C_SIGMA_COOO_G_H
#define C_SIGMA_COOO_G_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//       #                #########      #     #   # 
//  ########## ##########         #   #######  #   # 
//      #    #         #          #    # #     #   # 
//      #    #        #   ########     # #     #   # 
//     #     #     # #           #  ##########    #  
//    #   # #       #            #       #       #   
//   #     #         #    ########       #     ##    

void FC_FUNC(g_if_sigma_cooo_g_no0_x0, G_IF_SIGMA_COOO_G_NO0_X0)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x1, G_IF_SIGMA_COOO_G_NO0_X1)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_y2, G_IF_SIGMA_COOO_G_Y2)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x2, G_IF_SIGMA_COOO_G_NO0_X2)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const Y0, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_y3, G_IF_SIGMA_COOO_G_Y3)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x3, G_IF_SIGMA_COOO_G_NO0_X3)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const Y1, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x4, G_IF_SIGMA_COOO_G_NO0_X4)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_y5, G_IF_SIGMA_COOO_G_Y5)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x5, G_IF_SIGMA_COOO_G_NO0_X5)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const Y2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_y6, G_IF_SIGMA_COOO_G_Y6)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x6, G_IF_SIGMA_COOO_G_NO0_X6)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const Y3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_y7, G_IF_SIGMA_COOO_G_Y7)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x7, G_IF_SIGMA_COOO_G_NO0_X7)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const Y4, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_y8, G_IF_SIGMA_COOO_G_Y8)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x8, G_IF_SIGMA_COOO_G_NO0_X8)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const Y5, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x9, G_IF_SIGMA_COOO_G_NO0_X9)
  (const FC_INT &sm, const FC_INT &im, const FC_INT &sw, const FC_INT &iw, 
   const double * const T0, 
   const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x10, G_IF_SIGMA_COOO_G_NO0_X10)
  (const FC_INT &sm, const FC_INT &im, const FC_INT &sw, const FC_INT &iw, 
   const double * const T0, 
   const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x11, G_IF_SIGMA_COOO_G_NO0_X11)
  (const FC_INT &sm, const FC_INT &im, const FC_INT &sw, const FC_INT &iw, 
   const double * const T0, 
   const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x12, G_IF_SIGMA_COOO_G_NO0_X12)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x13, G_IF_SIGMA_COOO_G_NO0_X13)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x14, G_IF_SIGMA_COOO_G_NO0_X14)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_cooo_g_no0_x15, G_IF_SIGMA_COOO_G_NO0_X15)
  (const FC_INT &sm, const FC_INT &im, 
   const double * const T0, 
   const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

      
 }     
       
       
 #endif
       
       
 