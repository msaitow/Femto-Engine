                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_ocov_ccoo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_ocov_ccoo(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* X(w,o4,o3,o1,o2,a)  <--  (    1.00000000)  T2(c1,w,o4,o3) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D3(i,k,o3,o1,o4,o2) X(w,o4,o3,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x0, G_IF_SIGMA_OCOV_CCOO_NO0_X0)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x0, G_IF_SIGMA_OCOV_CCOO_NO1_X0)
        (sa, ia, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.1
  //* X(w,o1,o2,o3,o4,a)  <--  (    1.00000000)  T2(w,c1,o1,o2) V2(a,o3,c1,o4) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D3(i,k,o1,o3,o2,o4) X(w,o1,o2,o3,o4,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so2^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x1, G_IF_SIGMA_OCOV_CCOO_NO0_X1)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x1, G_IF_SIGMA_OCOV_CCOO_NO1_X1)
        (sa, ia, so2, io2, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.2
  //* X(c1,i,o3,a)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    1.00000000) T2(c1,w,k,o3) X(c1,i,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x2, G_IF_SIGMA_OCOV_CCOO_NO0_X2)
        (sa, ia, so3, io3, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x2, G_IF_SIGMA_OCOV_CCOO_NO1_X2)
        (sa, ia, so3, io3, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.3
  //* X(c1,i,o3,a)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (    1.00000000) T2(w,c1,k,o3) X(c1,i,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x3, G_IF_SIGMA_OCOV_CCOO_NO0_X3)
        (sa, ia, so3, io3, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x3, G_IF_SIGMA_OCOV_CCOO_NO1_X3)
        (sa, ia, so3, io3, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.4
  //* X(c1,i,o3,a)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (    1.00000000) T2(c1,w,o3,k) X(c1,i,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ocov_ccoo_no0_x4, G_IF_SIGMA_OCOV_CCOO_NO0_X4)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x4, G_IF_SIGMA_OCOV_CCOO_NO1_X4)
        (sa, ia, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.5
  //* X(c1,i,o3,a)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    1.00000000) T2(w,c1,o3,k) X(c1,i,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ocov_ccoo_no0_x5, G_IF_SIGMA_OCOV_CCOO_NO0_X5)
      (sa, ia, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x5, G_IF_SIGMA_OCOV_CCOO_NO1_X5)
        (sa, ia, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.6
  //* X(w,o3,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,o3) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x6, G_IF_SIGMA_OCOV_CCOO_NO0_X6)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x6, G_IF_SIGMA_OCOV_CCOO_NO1_X6)
        (sa, ia, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.7
  //* X(w,o3,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,o3) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x7, G_IF_SIGMA_OCOV_CCOO_NO0_X7)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x7, G_IF_SIGMA_OCOV_CCOO_NO1_X7)
        (sa, ia, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.8
  //* X(w,o3,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,o3) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x8, G_IF_SIGMA_OCOV_CCOO_NO0_X8)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x8, G_IF_SIGMA_OCOV_CCOO_NO1_X8)
        (sa, ia, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.9
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,k) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x9, G_IF_SIGMA_OCOV_CCOO_NO0_X9)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x9, G_IF_SIGMA_OCOV_CCOO_NO1_X9)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.10
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,k) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x10, G_IF_SIGMA_OCOV_CCOO_NO0_X10)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x10, G_IF_SIGMA_OCOV_CCOO_NO1_X10)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.11
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,k) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x11, G_IF_SIGMA_OCOV_CCOO_NO0_X11)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x11, G_IF_SIGMA_OCOV_CCOO_NO1_X11)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.12
  //* X(w,o3,o2,a)  <--  (    1.00000000)  T2(c1,w,o3,o1) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x12, G_IF_SIGMA_OCOV_CCOO_NO0_X12)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x12, G_IF_SIGMA_OCOV_CCOO_NO1_X12)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.13
  //* X(w,o3,o2,a)  <--  (    1.00000000)  T2(w,c1,o3,o1) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x13, G_IF_SIGMA_OCOV_CCOO_NO0_X13)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x13, G_IF_SIGMA_OCOV_CCOO_NO1_X13)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.14
  //* X(w,o3,o2,a)  <--  (    1.00000000)  T2(w,c1,o3,o1) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x14, G_IF_SIGMA_OCOV_CCOO_NO0_X14)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x14, G_IF_SIGMA_OCOV_CCOO_NO1_X14)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.15
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(c1,w,k,o1) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x15, G_IF_SIGMA_OCOV_CCOO_NO0_X15)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x15, G_IF_SIGMA_OCOV_CCOO_NO1_X15)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.16
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(w,c1,k,o1) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x16, G_IF_SIGMA_OCOV_CCOO_NO0_X16)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x16, G_IF_SIGMA_OCOV_CCOO_NO1_X16)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.17
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(w,c1,k,o1) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    1.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x17, G_IF_SIGMA_OCOV_CCOO_NO0_X17)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x17, G_IF_SIGMA_OCOV_CCOO_NO1_X17)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,o3,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,o3) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o3,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x18, G_IF_SIGMA_OCOV_CCOO_NO0_X18)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x18, G_IF_SIGMA_OCOV_CCOO_NO1_X18)
        (sa, ia, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.19
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,k) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sa, X);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x19, G_IF_SIGMA_OCOV_CCOO_NO0_X19)
        (sa, ia, sk, ik, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ocov_ccoo_no1_x19, G_IF_SIGMA_OCOV_CCOO_NO1_X19)
        (sa, ia, sk, ik, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.20
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,o3) V2(a,o3,c1,o2) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D2(i,k,o1,o2) X(w,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x20, G_IF_SIGMA_OCOV_CCOO_NO0_X20)
        (sa, ia, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x20, G_IF_SIGMA_OCOV_CCOO_NO1_X20)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.21
  //* X(w,k,o2,a)  <--  (    1.00000000)  T2(c1,w,k,o1) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x21, G_IF_SIGMA_OCOV_CCOO_NO0_X21)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x21, G_IF_SIGMA_OCOV_CCOO_NO1_X21)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.22
  //* X(w,a)  <--  (    1.00000000)  T2(c1,w,o2,o1) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (    4.00000000) D1(i,k) X(w,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x22, G_IF_SIGMA_OCOV_CCOO_NO0_X22)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x22, G_IF_SIGMA_OCOV_CCOO_NO1_X22)
      (sa, ia, Xc.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.23
  //* X(w,a)  <--  (    1.00000000)  T2(w,c1,o2,o1) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D1(i,k) X(w,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x23, G_IF_SIGMA_OCOV_CCOO_NO0_X23)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x23, G_IF_SIGMA_OCOV_CCOO_NO1_X23)
      (sa, ia, Xc.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.24
  //* X(w,a)  <--  (    1.00000000)  T2(w,c1,o2,o1) V2(a,o2,c1,o1) 
  //* S2(i,w,k,a)  <--  (    4.00000000) D1(i,k) X(w,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x24, G_IF_SIGMA_OCOV_CCOO_NO0_X24)
        (sa, ia, so1, io1, T2b.cptr(), V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x24, G_IF_SIGMA_OCOV_CCOO_NO1_X24)
      (sa, ia, Xc.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.25
  //* X(w,a)  <--  (    1.00000000)  T2(c1,w,o1,o2) V2(a,o1,c1,o2) 
  //* S2(i,w,k,a)  <--  (   -2.00000000) D1(i,k) X(w,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sa, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ocov_ccoo_no0_x25, G_IF_SIGMA_OCOV_CCOO_NO0_X25)
        (sa, ia, so2, io2, T2b.cptr(), V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ocov_ccoo_no1_x25, G_IF_SIGMA_OCOV_CCOO_NO1_X25)
      (sa, ia, Xc.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }

  return retval; 
} 
