                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_g_cooo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//  __/\\\\\\\\\\\\\\\____________________________________________________________________                                   
//   _\/\\\///////////_____________________________________________________________________                                             
//    _\/\\\_______________________________________________________/\\\_____________________                                         
//     _\/\\\\\\\\\\\__________/\\\\\\\\______/\\\\\__/\\\\\_____/\\\\\\\\\\\______/\\\\\____ 
//      _\/\\\///////_________/\\\/////\\\___/\\\///\\\\\///\\\__\////\\\////_____/\\\///\\\__               
//       _\/\\\_______________/\\\\\\\\\\\___\/\\\_\//\\\__\/\\\_____\/\\\________/\\\__\//\\\_       
//        _\/\\\______________\//\\///////____\/\\\__\/\\\__\/\\\_____\/\\\_/\\___\//\\\__/\\\__            
//         _\/\\\_______________\//\\\\\\\\\\__\/\\\__\/\\\__\/\\\_____\//\\\\\_____\///\\\\\/___    
//          _\///_________________\//////////___\///___\///___\///_______\/////________\/////_____                                   

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
double orz::ct::sigma_g_cooo(const orz::ct::Input &ctinp,                                                  
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const double init_value,                                                  
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  double S0 = init_value;                                                               
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* X(o4,o1,o2,o3)  <--  (    1.00000000)  T2(c1,o4,o1,o2) h(c1,o3) 
  //* S0()  <--  (   -1.00000000) D2(o1,o3,o2,o4) X(o4,o1,o2,o3) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so2, X);
    FC_FUNC(g_if_sigma_g_cooo_no0_x0, G_IF_SIGMA_G_COOO_NO0_X0)
      (so2, io2, T2b.cptr(), moint1_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_g_cooo_no1_x0, G_IF_SIGMA_G_COOO_NO1_X0)
      (so2, io2, Xaaa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.1
  //* X(o3,o2)  <--  (    1.00000000)  T2(c1,o3,o1,o2) h(c1,o1) 
  //* S0()  <--  (    2.00000000) D1(o2,o3) X(o3,o2) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so2, X);
    FC_FUNC(g_if_sigma_g_cooo_no0_x1, G_IF_SIGMA_G_COOO_NO0_X1)
      (so2, io2, T2b.cptr(), moint1_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_g_cooo_no1_x1, G_IF_SIGMA_G_COOO_NO1_X1)
      (so2, io2, Xa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.2
  //* X(o2,o1)  <--  (    1.00000000)  T2(c1,o2,o1,o3) h(c1,o3) 
  //* S0()  <--  (   -1.00000000) D1(o1,o2) X(o2,o1) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_g_cooo_no0_x2, G_IF_SIGMA_G_COOO_NO0_X2)
      (so3, io3, T2b.cptr(), moint1_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_cooo_no1_x2, G_IF_SIGMA_G_COOO_NO1_X2)
    (Xaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.3
  //* X(o2,o3,o4,o1)  <--  (    1.00000000)  T2(c2,o2,o3,o4) Y0(c2,o1) 
  //* S0()  <--  (    1.00000000) D2(o1,o3,o2,o4) X(o2,o3,o4,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y0 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_g_cooo_y3, G_IF_SIGMA_G_COOO_Y3)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so4, X);
    FC_FUNC(g_if_sigma_g_cooo_no0_x3, G_IF_SIGMA_G_COOO_NO0_X3)
      (so4, io4, T2b.cptr(), Y0.cptr(), Xaaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_g_cooo_no1_x3, G_IF_SIGMA_G_COOO_NO1_X3)
      (so4, io4, Xaaa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.4
  //* X(o2,o3,o4,o1)  <--  (    1.00000000)  T2(c2,o2,o3,o4) Y1(c2,o1) 
  //* S0()  <--  (   -2.00000000) D2(o1,o3,o2,o4) X(o2,o3,o4,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y1 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_g_cooo_y4, G_IF_SIGMA_G_COOO_Y4)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so4, X);
    FC_FUNC(g_if_sigma_g_cooo_no0_x4, G_IF_SIGMA_G_COOO_NO0_X4)
      (so4, io4, T2b.cptr(), Y1.cptr(), Xaaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_g_cooo_no1_x4, G_IF_SIGMA_G_COOO_NO1_X4)
      (so4, io4, Xaaa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.5
  //* X(o2,o3)  <--  (    1.00000000)  T2(c2,o2,o1,o3) Y2(c2,o1) 
  //* S0()  <--  (    4.00000000) D1(o2,o3) X(o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y2 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_g_cooo_y5, G_IF_SIGMA_G_COOO_Y5)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_g_cooo_no0_x5, G_IF_SIGMA_G_COOO_NO0_X5)
      (so3, io3, T2b.cptr(), Y2.cptr(), Xa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_g_cooo_no1_x5, G_IF_SIGMA_G_COOO_NO1_X5)
      (so3, io3, Xa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.6
  //* X(o2,o3)  <--  (    1.00000000)  T2(c2,o2,o1,o3) Y3(c2,o1) 
  //* S0()  <--  (   -2.00000000) D1(o2,o3) X(o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y3 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_g_cooo_y6, G_IF_SIGMA_G_COOO_Y6)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_g_cooo_no0_x6, G_IF_SIGMA_G_COOO_NO0_X6)
      (so3, io3, T2b.cptr(), Y3.cptr(), Xa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_g_cooo_no1_x6, G_IF_SIGMA_G_COOO_NO1_X6)
      (so3, io3, Xa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.7
  //* X(o2,o3)  <--  (    1.00000000)  T2(c2,o2,o3,o1) Y4(c2,o1) 
  //* S0()  <--  (    1.00000000) D1(o2,o3) X(o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y4 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_g_cooo_y7, G_IF_SIGMA_G_COOO_Y7)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_g_cooo_no0_x7, G_IF_SIGMA_G_COOO_NO0_X7)
      (so1, io1, T2b.cptr(), Y4.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_cooo_no1_x7, G_IF_SIGMA_G_COOO_NO1_X7)
    (Xaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.8
  //* X(o2,o3)  <--  (    1.00000000)  T2(c2,o2,o3,o1) Y5(c2,o1) 
  //* S0()  <--  (   -2.00000000) D1(o2,o3) X(o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y5 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_g_cooo_y8, G_IF_SIGMA_G_COOO_Y8)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_g_cooo_no0_x8, G_IF_SIGMA_G_COOO_NO0_X8)
      (so1, io1, T2b.cptr(), Y5.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_cooo_no1_x8, G_IF_SIGMA_G_COOO_NO1_X8)
    (Xaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.9
  //* X(o1,o6,o4,o3,o2,o5)  <--  (    1.00000000)  T2(c1,o1,o6,o4) V2(c1,o3,o2,o5) 
  //* S0()  <--  (   -1.00000000) D3(o1,o4,o2,o5,o3,o6) X(o1,o6,o4,o3,o2,o5) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nocc, nocc, nocc, nocc, nocc);
    orz::DTensor Xaaaaa = orz::ct::sympack_Xaaaaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_g_cooo_no0_x9, G_IF_SIGMA_G_COOO_NO0_X9)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xaaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_g_cooo_no1_x9, G_IF_SIGMA_G_COOO_NO1_X9)
      (so4, io4, Xaaaaa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.10
  //* X(o2,o4,o3,o5)  <--  (    1.00000000)  T2(c1,o2,o1,o4) V2(c1,o1,o3,o5) 
  //* S0()  <--  (    2.00000000) D2(o2,o4,o3,o5) X(o2,o4,o3,o5) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_g_cooo_no0_x10, G_IF_SIGMA_G_COOO_NO0_X10)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_g_cooo_no1_x10, G_IF_SIGMA_G_COOO_NO1_X10)
      (so4, io4, Xaaa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.11
  //* X(o2,o4,o3,o5)  <--  (    1.00000000)  T2(c1,o2,o4,o1) V2(o1,c1,o3,o5) 
  //* S0()  <--  (   -1.00000000) D2(o2,o4,o3,o5) X(o2,o4,o3,o5) 
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_g_cooo_no0_x11, G_IF_SIGMA_G_COOO_NO0_X11)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_cooo_no1_x11, G_IF_SIGMA_G_COOO_NO1_X11)
    (Xaaaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.12
  //* X(o3,o5,o2,o4)  <--  (    1.00000000)  T2(c1,o3,o1,o5) V2(c1,o2,o1,o4) 
  //* S0()  <--  (   -1.00000000) D2(o2,o4,o3,o5) X(o3,o5,o2,o4) 
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    T2b = T2.get_amp2(io5);
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so5, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_g_cooo_no0_x12, G_IF_SIGMA_G_COOO_NO0_X12)
        (sc1, ic1, so5, io5, T2b.cptr(), V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_g_cooo_no1_x12, G_IF_SIGMA_G_COOO_NO1_X12)
      (so5, io5, Xaaa.cptr(), &S0, nir, nsym, psym);
  }
  }
  }


  {
  // No.13
  //* X(o1,o4,o3,o2)  <--  (    1.00000000)  T2(c1,o1,o4,o5) V2(o5,o3,c1,o2) 
  //* S0()  <--  (   -1.00000000) D2(o1,o3,o2,o4) X(o1,o4,o3,o2) 
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io5);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io5, so5, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_g_cooo_no0_x13, G_IF_SIGMA_G_COOO_NO0_X13)
      (so5, io5, T2b.cptr(), V2_sym.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_cooo_no1_x13, G_IF_SIGMA_G_COOO_NO1_X13)
    (Xaaaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.14
  //* X(o3,o4)  <--  (    1.00000000)  T2(c1,o3,o2,o1) V2(o1,o4,c1,o2) 
  //* S0()  <--  (    2.00000000) D1(o3,o4) X(o3,o4) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_g_cooo_no0_x14, G_IF_SIGMA_G_COOO_NO0_X14)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_cooo_no1_x14, G_IF_SIGMA_G_COOO_NO1_X14)
    (Xaa.cptr(), &S0, nir, nsym, psym);
  }


  {
  // No.15
  //* X(o1,o2)  <--  (    1.00000000)  T2(c1,o1,o3,o4) V2(o4,c1,o2,o3) 
  //* S0()  <--  (   -1.00000000) D1(o1,o2) X(o1,o2) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io4);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io4, so4, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io4);
    FC_FUNC(g_if_sigma_g_cooo_no0_x15, G_IF_SIGMA_G_COOO_NO0_X15)
      (so4, io4, T2b.cptr(), V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  FC_FUNC(g_if_sigma_g_cooo_no1_x15, G_IF_SIGMA_G_COOO_NO1_X15)
    (Xaa.cptr(), &S0, nir, nsym, psym);
  }

  return  S0;
} 
