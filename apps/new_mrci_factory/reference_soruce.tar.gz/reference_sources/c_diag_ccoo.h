

#ifndef C_DIAG_CCOO_H
#define C_DIAG_CCOO_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//    o__ __o__/_                            o                         
//   <|    v                                <|>                        
//   < >                                    < >                        
//    |         o__  __o   \o__ __o__ __o    |        o__ __o         
//    o__/_    /v      |>   |     |     |>   o__/_   /v     v\        
//    |       />      //   / \   / \   / \   |      />       <\    
//   <o>      \o    o/     \o/   \o/   \o/   |      \         /   
//    |        v\  /v __o   |     |     |    o       o       o        
//   / \        <\/> __/>  / \   / \   / \   <\__    <\__ __/>  

void FC_FUNC(g_if_diag_ccoo_y0, G_IF_DIAG_CCOO_Y0)
  (const double * const h, const double * const Y0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x0, G_IF_DIAG_CCOO_NO0_X0)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y0, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x1, G_IF_DIAG_CCOO_NO0_X1)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x2, G_IF_DIAG_CCOO_NO0_X2)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y3, G_IF_DIAG_CCOO_Y3)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x3, G_IF_DIAG_CCOO_NO0_X3)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y1, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y4, G_IF_DIAG_CCOO_Y4)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x4, G_IF_DIAG_CCOO_NO0_X4)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y5, G_IF_DIAG_CCOO_Y5)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x5, G_IF_DIAG_CCOO_NO0_X5)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y3, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y6, G_IF_DIAG_CCOO_Y6)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x6, G_IF_DIAG_CCOO_NO0_X6)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y4, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y7, G_IF_DIAG_CCOO_Y7)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x7, G_IF_DIAG_CCOO_NO0_X7)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y5, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y8, G_IF_DIAG_CCOO_Y8)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x8, G_IF_DIAG_CCOO_NO0_X8)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y6, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x9, G_IF_DIAG_CCOO_NO0_X9)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y10, G_IF_DIAG_CCOO_Y10)
  (const double * const h, const double * const Y7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x10, G_IF_DIAG_CCOO_NO0_X10)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y7, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x11, G_IF_DIAG_CCOO_NO0_X11)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y12, G_IF_DIAG_CCOO_Y12)
  (const double * const h, const double * const Y8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x12, G_IF_DIAG_CCOO_NO0_X12)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y8, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y13, G_IF_DIAG_CCOO_Y13)
  (const double * const h, const double * const Y9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x13, G_IF_DIAG_CCOO_NO0_X13)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y9, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x14, G_IF_DIAG_CCOO_NO0_X14)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x15, G_IF_DIAG_CCOO_NO0_X15)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x16, G_IF_DIAG_CCOO_NO0_X16)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y17, G_IF_DIAG_CCOO_Y17)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x17, G_IF_DIAG_CCOO_NO0_X17)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y10, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y18, G_IF_DIAG_CCOO_Y18)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x18, G_IF_DIAG_CCOO_NO0_X18)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y11, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y19, G_IF_DIAG_CCOO_Y19)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x19, G_IF_DIAG_CCOO_NO0_X19)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y12, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y20, G_IF_DIAG_CCOO_Y20)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x20, G_IF_DIAG_CCOO_NO0_X20)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y13, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y21, G_IF_DIAG_CCOO_Y21)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x21, G_IF_DIAG_CCOO_NO0_X21)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y14, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y22, G_IF_DIAG_CCOO_Y22)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x22, G_IF_DIAG_CCOO_NO0_X22)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y15, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x23, G_IF_DIAG_CCOO_NO0_X23)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x24, G_IF_DIAG_CCOO_NO0_X24)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y25, G_IF_DIAG_CCOO_Y25)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y16, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x25, G_IF_DIAG_CCOO_NO0_X25)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y16, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x26, G_IF_DIAG_CCOO_NO0_X26)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x27, G_IF_DIAG_CCOO_NO0_X27)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x28, G_IF_DIAG_CCOO_NO0_X28)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y29, G_IF_DIAG_CCOO_Y29)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y17, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x29, G_IF_DIAG_CCOO_NO0_X29)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y17, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x30, G_IF_DIAG_CCOO_NO0_X30)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x31, G_IF_DIAG_CCOO_NO0_X31)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y32, G_IF_DIAG_CCOO_Y32)
  (const double * const h, const double * const Y18, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x32, G_IF_DIAG_CCOO_NO0_X32)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y18, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y33, G_IF_DIAG_CCOO_Y33)
  (const double * const h, const double * const Y19, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x33, G_IF_DIAG_CCOO_NO0_X33)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y19, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x34, G_IF_DIAG_CCOO_NO0_X34)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x35, G_IF_DIAG_CCOO_NO0_X35)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x36, G_IF_DIAG_CCOO_NO0_X36)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y37, G_IF_DIAG_CCOO_Y37)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y20, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x37, G_IF_DIAG_CCOO_NO0_X37)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y20, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y38, G_IF_DIAG_CCOO_Y38)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y21, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x38, G_IF_DIAG_CCOO_NO0_X38)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y21, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y39, G_IF_DIAG_CCOO_Y39)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y22, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x39, G_IF_DIAG_CCOO_NO0_X39)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y22, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y40, G_IF_DIAG_CCOO_Y40)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y23, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x40, G_IF_DIAG_CCOO_NO0_X40)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y23, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y41, G_IF_DIAG_CCOO_Y41)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y24, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x41, G_IF_DIAG_CCOO_NO0_X41)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y24, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y42, G_IF_DIAG_CCOO_Y42)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y25, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x42, G_IF_DIAG_CCOO_NO0_X42)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y25, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x43, G_IF_DIAG_CCOO_NO0_X43)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x44, G_IF_DIAG_CCOO_NO0_X44)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y45, G_IF_DIAG_CCOO_Y45)
  (const double * const h, const double * const Y26, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x45, G_IF_DIAG_CCOO_NO0_X45)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y26, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y46, G_IF_DIAG_CCOO_Y46)
  (const double * const h, const double * const Y27, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x46, G_IF_DIAG_CCOO_NO0_X46)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y27, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x47, G_IF_DIAG_CCOO_NO0_X47)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x48, G_IF_DIAG_CCOO_NO0_X48)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x49, G_IF_DIAG_CCOO_NO0_X49)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x50, G_IF_DIAG_CCOO_NO0_X50)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y51, G_IF_DIAG_CCOO_Y51)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y28, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x51, G_IF_DIAG_CCOO_NO0_X51)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y28, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y52, G_IF_DIAG_CCOO_Y52)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y29, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x52, G_IF_DIAG_CCOO_NO0_X52)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y29, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y53, G_IF_DIAG_CCOO_Y53)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y30, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x53, G_IF_DIAG_CCOO_NO0_X53)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y30, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y54, G_IF_DIAG_CCOO_Y54)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y31, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x54, G_IF_DIAG_CCOO_NO0_X54)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y31, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y55, G_IF_DIAG_CCOO_Y55)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y32, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x55, G_IF_DIAG_CCOO_NO0_X55)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y32, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y56, G_IF_DIAG_CCOO_Y56)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y33, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x56, G_IF_DIAG_CCOO_NO0_X56)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y33, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x57, G_IF_DIAG_CCOO_NO0_X57)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x58, G_IF_DIAG_CCOO_NO0_X58)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y59, G_IF_DIAG_CCOO_Y59)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y34, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x59, G_IF_DIAG_CCOO_NO0_X59)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y34, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x60, G_IF_DIAG_CCOO_NO0_X60)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x61, G_IF_DIAG_CCOO_NO0_X61)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x62, G_IF_DIAG_CCOO_NO0_X62)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y63, G_IF_DIAG_CCOO_Y63)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y35, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x63, G_IF_DIAG_CCOO_NO0_X63)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y35, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x64, G_IF_DIAG_CCOO_NO0_X64)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y65, G_IF_DIAG_CCOO_Y65)
  (const double * const h, const double * const Y36, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x65, G_IF_DIAG_CCOO_NO0_X65)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y36, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y66, G_IF_DIAG_CCOO_Y66)
  (const double * const h, const double * const Y37, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x66, G_IF_DIAG_CCOO_NO0_X66)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y37, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x67, G_IF_DIAG_CCOO_NO0_X67)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x68, G_IF_DIAG_CCOO_NO0_X68)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x69, G_IF_DIAG_CCOO_NO0_X69)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y70, G_IF_DIAG_CCOO_Y70)
  (const double * const h, const double * const Y38, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x70, G_IF_DIAG_CCOO_NO0_X70)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y38, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y71, G_IF_DIAG_CCOO_Y71)
  (const double * const h, const double * const Y39, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x71, G_IF_DIAG_CCOO_NO0_X71)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y39, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x72, G_IF_DIAG_CCOO_NO0_X72)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x73, G_IF_DIAG_CCOO_NO0_X73)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x74, G_IF_DIAG_CCOO_NO0_X74)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y75, G_IF_DIAG_CCOO_Y75)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y40, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x75, G_IF_DIAG_CCOO_NO0_X75)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y40, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y76, G_IF_DIAG_CCOO_Y76)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y41, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x76, G_IF_DIAG_CCOO_NO0_X76)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y41, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y77, G_IF_DIAG_CCOO_Y77)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y42, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x77, G_IF_DIAG_CCOO_NO0_X77)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y42, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y78, G_IF_DIAG_CCOO_Y78)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y43, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x78, G_IF_DIAG_CCOO_NO0_X78)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y43, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y79, G_IF_DIAG_CCOO_Y79)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y44, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x79, G_IF_DIAG_CCOO_NO0_X79)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y44, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y80, G_IF_DIAG_CCOO_Y80)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y45, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x80, G_IF_DIAG_CCOO_NO0_X80)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y45, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x81, G_IF_DIAG_CCOO_NO0_X81)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x82, G_IF_DIAG_CCOO_NO0_X82)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x83, G_IF_DIAG_CCOO_NO0_X83)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x84, G_IF_DIAG_CCOO_NO0_X84)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x85, G_IF_DIAG_CCOO_NO0_X85)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y86, G_IF_DIAG_CCOO_Y86)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y46, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x86, G_IF_DIAG_CCOO_NO0_X86)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y46, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x87, G_IF_DIAG_CCOO_NO0_X87)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x88, G_IF_DIAG_CCOO_NO0_X88)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x89, G_IF_DIAG_CCOO_NO0_X89)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y90, G_IF_DIAG_CCOO_Y90)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y47, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x90, G_IF_DIAG_CCOO_NO0_X90)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y47, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x91, G_IF_DIAG_CCOO_NO0_X91)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x92, G_IF_DIAG_CCOO_NO0_X92)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x93, G_IF_DIAG_CCOO_NO0_X93)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x94, G_IF_DIAG_CCOO_NO0_X94)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x95, G_IF_DIAG_CCOO_NO0_X95)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x96, G_IF_DIAG_CCOO_NO0_X96)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y97, G_IF_DIAG_CCOO_Y97)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y48, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x97, G_IF_DIAG_CCOO_NO0_X97)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y48, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x98, G_IF_DIAG_CCOO_NO0_X98)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x99, G_IF_DIAG_CCOO_NO0_X99)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y100, G_IF_DIAG_CCOO_Y100)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y49, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x100, G_IF_DIAG_CCOO_NO0_X100)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y49, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x101, G_IF_DIAG_CCOO_NO0_X101)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x102, G_IF_DIAG_CCOO_NO0_X102)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x103, G_IF_DIAG_CCOO_NO0_X103)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x104, G_IF_DIAG_CCOO_NO0_X104)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y105, G_IF_DIAG_CCOO_Y105)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y50, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x105, G_IF_DIAG_CCOO_NO0_X105)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y50, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x106, G_IF_DIAG_CCOO_NO0_X106)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x107, G_IF_DIAG_CCOO_NO0_X107)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x108, G_IF_DIAG_CCOO_NO0_X108)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y109, G_IF_DIAG_CCOO_Y109)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y51, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x109, G_IF_DIAG_CCOO_NO0_X109)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y51, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x110, G_IF_DIAG_CCOO_NO0_X110)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x111, G_IF_DIAG_CCOO_NO0_X111)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x112, G_IF_DIAG_CCOO_NO0_X112)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y113, G_IF_DIAG_CCOO_Y113)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y52, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x113, G_IF_DIAG_CCOO_NO0_X113)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y52, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x114, G_IF_DIAG_CCOO_NO0_X114)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x115, G_IF_DIAG_CCOO_NO0_X115)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y116, G_IF_DIAG_CCOO_Y116)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y53, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x116, G_IF_DIAG_CCOO_NO0_X116)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y53, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x117, G_IF_DIAG_CCOO_NO0_X117)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x118, G_IF_DIAG_CCOO_NO0_X118)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x119, G_IF_DIAG_CCOO_NO0_X119)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x120, G_IF_DIAG_CCOO_NO0_X120)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x121, G_IF_DIAG_CCOO_NO0_X121)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x122, G_IF_DIAG_CCOO_NO0_X122)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x123, G_IF_DIAG_CCOO_NO0_X123)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x124, G_IF_DIAG_CCOO_NO0_X124)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x125, G_IF_DIAG_CCOO_NO0_X125)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y126, G_IF_DIAG_CCOO_Y126)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y54, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x126, G_IF_DIAG_CCOO_NO0_X126)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y54, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x127, G_IF_DIAG_CCOO_NO0_X127)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x128, G_IF_DIAG_CCOO_NO0_X128)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x129, G_IF_DIAG_CCOO_NO0_X129)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x130, G_IF_DIAG_CCOO_NO0_X130)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x131, G_IF_DIAG_CCOO_NO0_X131)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y132, G_IF_DIAG_CCOO_Y132)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y55, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x132, G_IF_DIAG_CCOO_NO0_X132)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y55, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x133, G_IF_DIAG_CCOO_NO0_X133)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y134, G_IF_DIAG_CCOO_Y134)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y56, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x134, G_IF_DIAG_CCOO_NO0_X134)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y56, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x135, G_IF_DIAG_CCOO_NO0_X135)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x136, G_IF_DIAG_CCOO_NO0_X136)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x137, G_IF_DIAG_CCOO_NO0_X137)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x138, G_IF_DIAG_CCOO_NO0_X138)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x139, G_IF_DIAG_CCOO_NO0_X139)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x140, G_IF_DIAG_CCOO_NO0_X140)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x141, G_IF_DIAG_CCOO_NO0_X141)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x142, G_IF_DIAG_CCOO_NO0_X142)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y143, G_IF_DIAG_CCOO_Y143)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y57, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x143, G_IF_DIAG_CCOO_NO0_X143)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y57, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x144, G_IF_DIAG_CCOO_NO0_X144)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x145, G_IF_DIAG_CCOO_NO0_X145)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x146, G_IF_DIAG_CCOO_NO0_X146)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y147, G_IF_DIAG_CCOO_Y147)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y58, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x147, G_IF_DIAG_CCOO_NO0_X147)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y58, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x148, G_IF_DIAG_CCOO_NO0_X148)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x149, G_IF_DIAG_CCOO_NO0_X149)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x150, G_IF_DIAG_CCOO_NO0_X150)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x151, G_IF_DIAG_CCOO_NO0_X151)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x152, G_IF_DIAG_CCOO_NO0_X152)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y153, G_IF_DIAG_CCOO_Y153)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y59, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x153, G_IF_DIAG_CCOO_NO0_X153)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y59, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y154, G_IF_DIAG_CCOO_Y154)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y60, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x154, G_IF_DIAG_CCOO_NO0_X154)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y60, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x155, G_IF_DIAG_CCOO_NO0_X155)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x156, G_IF_DIAG_CCOO_NO0_X156)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x157, G_IF_DIAG_CCOO_NO0_X157)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y158, G_IF_DIAG_CCOO_Y158)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y61, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x158, G_IF_DIAG_CCOO_NO0_X158)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y61, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y159, G_IF_DIAG_CCOO_Y159)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y62, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x159, G_IF_DIAG_CCOO_NO0_X159)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y62, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y160, G_IF_DIAG_CCOO_Y160)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y63, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x160, G_IF_DIAG_CCOO_NO0_X160)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y63, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y161, G_IF_DIAG_CCOO_Y161)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y64, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x161, G_IF_DIAG_CCOO_NO0_X161)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y64, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x162, G_IF_DIAG_CCOO_NO0_X162)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y163, G_IF_DIAG_CCOO_Y163)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y65, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x163, G_IF_DIAG_CCOO_NO0_X163)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y65, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y164, G_IF_DIAG_CCOO_Y164)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y66, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x164, G_IF_DIAG_CCOO_NO0_X164)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y66, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y165, G_IF_DIAG_CCOO_Y165)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y67, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x165, G_IF_DIAG_CCOO_NO0_X165)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y67, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y166, G_IF_DIAG_CCOO_Y166)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y68, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x166, G_IF_DIAG_CCOO_NO0_X166)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y68, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y167, G_IF_DIAG_CCOO_Y167)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y69, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x167, G_IF_DIAG_CCOO_NO0_X167)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y69, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y168, G_IF_DIAG_CCOO_Y168)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y70, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x168, G_IF_DIAG_CCOO_NO0_X168)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y70, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y169, G_IF_DIAG_CCOO_Y169)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y71, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x169, G_IF_DIAG_CCOO_NO0_X169)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y71, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y170, G_IF_DIAG_CCOO_Y170)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y72, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x170, G_IF_DIAG_CCOO_NO0_X170)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y72, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y171, G_IF_DIAG_CCOO_Y171)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y73, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x171, G_IF_DIAG_CCOO_NO0_X171)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y73, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y172, G_IF_DIAG_CCOO_Y172)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y74, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x172, G_IF_DIAG_CCOO_NO0_X172)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y74, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y173, G_IF_DIAG_CCOO_Y173)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y75, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x173, G_IF_DIAG_CCOO_NO0_X173)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y75, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y174, G_IF_DIAG_CCOO_Y174)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y76, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x174, G_IF_DIAG_CCOO_NO0_X174)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y76, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y175, G_IF_DIAG_CCOO_Y175)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y77, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x175, G_IF_DIAG_CCOO_NO0_X175)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y77, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y176, G_IF_DIAG_CCOO_Y176)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y78, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x176, G_IF_DIAG_CCOO_NO0_X176)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y78, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y177, G_IF_DIAG_CCOO_Y177)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y79, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x177, G_IF_DIAG_CCOO_NO0_X177)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y79, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y178, G_IF_DIAG_CCOO_Y178)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y80, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x178, G_IF_DIAG_CCOO_NO0_X178)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y80, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y179, G_IF_DIAG_CCOO_Y179)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y81, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x179, G_IF_DIAG_CCOO_NO0_X179)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y81, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y180, G_IF_DIAG_CCOO_Y180)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y82, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x180, G_IF_DIAG_CCOO_NO0_X180)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y82, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y181, G_IF_DIAG_CCOO_Y181)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y83, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x181, G_IF_DIAG_CCOO_NO0_X181)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y83, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y182, G_IF_DIAG_CCOO_Y182)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y84, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x182, G_IF_DIAG_CCOO_NO0_X182)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y84, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x183, G_IF_DIAG_CCOO_NO0_X183)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x184, G_IF_DIAG_CCOO_NO0_X184)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y185, G_IF_DIAG_CCOO_Y185)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y85, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x185, G_IF_DIAG_CCOO_NO0_X185)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y85, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x186, G_IF_DIAG_CCOO_NO0_X186)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x187, G_IF_DIAG_CCOO_NO0_X187)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y188, G_IF_DIAG_CCOO_Y188)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y86, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x188, G_IF_DIAG_CCOO_NO0_X188)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y86, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x189, G_IF_DIAG_CCOO_NO0_X189)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x190, G_IF_DIAG_CCOO_NO0_X190)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x191, G_IF_DIAG_CCOO_NO0_X191)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y192, G_IF_DIAG_CCOO_Y192)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y87, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x192, G_IF_DIAG_CCOO_NO0_X192)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y87, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x193, G_IF_DIAG_CCOO_NO0_X193)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x194, G_IF_DIAG_CCOO_NO0_X194)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x195, G_IF_DIAG_CCOO_NO0_X195)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y196, G_IF_DIAG_CCOO_Y196)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y88, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x196, G_IF_DIAG_CCOO_NO0_X196)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y88, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x197, G_IF_DIAG_CCOO_NO0_X197)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x198, G_IF_DIAG_CCOO_NO0_X198)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y199, G_IF_DIAG_CCOO_Y199)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y89, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x199, G_IF_DIAG_CCOO_NO0_X199)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y89, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y200, G_IF_DIAG_CCOO_Y200)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y90, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x200, G_IF_DIAG_CCOO_NO0_X200)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y90, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y201, G_IF_DIAG_CCOO_Y201)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y91, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x201, G_IF_DIAG_CCOO_NO0_X201)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y91, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y202, G_IF_DIAG_CCOO_Y202)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y92, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x202, G_IF_DIAG_CCOO_NO0_X202)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y92, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y203, G_IF_DIAG_CCOO_Y203)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y93, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x203, G_IF_DIAG_CCOO_NO0_X203)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y93, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x204, G_IF_DIAG_CCOO_NO0_X204)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x205, G_IF_DIAG_CCOO_NO0_X205)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y206, G_IF_DIAG_CCOO_Y206)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y94, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x206, G_IF_DIAG_CCOO_NO0_X206)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y94, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y207, G_IF_DIAG_CCOO_Y207)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y95, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x207, G_IF_DIAG_CCOO_NO0_X207)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y95, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x208, G_IF_DIAG_CCOO_NO0_X208)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y209, G_IF_DIAG_CCOO_Y209)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y96, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x209, G_IF_DIAG_CCOO_NO0_X209)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y96, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x210, G_IF_DIAG_CCOO_NO0_X210)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y211, G_IF_DIAG_CCOO_Y211)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y97, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x211, G_IF_DIAG_CCOO_NO0_X211)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y97, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y212, G_IF_DIAG_CCOO_Y212)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y98, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x212, G_IF_DIAG_CCOO_NO0_X212)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y98, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x213, G_IF_DIAG_CCOO_NO0_X213)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x214, G_IF_DIAG_CCOO_NO0_X214)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x215, G_IF_DIAG_CCOO_NO0_X215)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y216, G_IF_DIAG_CCOO_Y216)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y99, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x216, G_IF_DIAG_CCOO_NO0_X216)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y99, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x217, G_IF_DIAG_CCOO_NO0_X217)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y218, G_IF_DIAG_CCOO_Y218)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y100, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x218, G_IF_DIAG_CCOO_NO0_X218)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y100, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x219, G_IF_DIAG_CCOO_NO0_X219)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y220, G_IF_DIAG_CCOO_Y220)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y101, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x220, G_IF_DIAG_CCOO_NO0_X220)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y101, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x221, G_IF_DIAG_CCOO_NO0_X221)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y222, G_IF_DIAG_CCOO_Y222)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y102, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x222, G_IF_DIAG_CCOO_NO0_X222)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y102, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y223, G_IF_DIAG_CCOO_Y223)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y103, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x223, G_IF_DIAG_CCOO_NO0_X223)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y103, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x224, G_IF_DIAG_CCOO_NO0_X224)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x225, G_IF_DIAG_CCOO_NO0_X225)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x226, G_IF_DIAG_CCOO_NO0_X226)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y227, G_IF_DIAG_CCOO_Y227)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y104, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x227, G_IF_DIAG_CCOO_NO0_X227)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y104, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y228, G_IF_DIAG_CCOO_Y228)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y105, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x228, G_IF_DIAG_CCOO_NO0_X228)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y105, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x229, G_IF_DIAG_CCOO_NO0_X229)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x230, G_IF_DIAG_CCOO_NO0_X230)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x231, G_IF_DIAG_CCOO_NO0_X231)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y232, G_IF_DIAG_CCOO_Y232)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y106, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x232, G_IF_DIAG_CCOO_NO0_X232)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y106, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y233, G_IF_DIAG_CCOO_Y233)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y107, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x233, G_IF_DIAG_CCOO_NO0_X233)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y107, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x234, G_IF_DIAG_CCOO_NO0_X234)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x235, G_IF_DIAG_CCOO_NO0_X235)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x236, G_IF_DIAG_CCOO_NO0_X236)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y237, G_IF_DIAG_CCOO_Y237)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y108, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x237, G_IF_DIAG_CCOO_NO0_X237)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y108, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y238, G_IF_DIAG_CCOO_Y238)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y109, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x238, G_IF_DIAG_CCOO_NO0_X238)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y109, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x239, G_IF_DIAG_CCOO_NO0_X239)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x240, G_IF_DIAG_CCOO_NO0_X240)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x241, G_IF_DIAG_CCOO_NO0_X241)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y242, G_IF_DIAG_CCOO_Y242)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y110, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x242, G_IF_DIAG_CCOO_NO0_X242)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y110, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y243, G_IF_DIAG_CCOO_Y243)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y111, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x243, G_IF_DIAG_CCOO_NO0_X243)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y111, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x244, G_IF_DIAG_CCOO_NO0_X244)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x245, G_IF_DIAG_CCOO_NO0_X245)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x246, G_IF_DIAG_CCOO_NO0_X246)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y247, G_IF_DIAG_CCOO_Y247)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y112, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x247, G_IF_DIAG_CCOO_NO0_X247)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y112, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y248, G_IF_DIAG_CCOO_Y248)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y113, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x248, G_IF_DIAG_CCOO_NO0_X248)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y113, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x249, G_IF_DIAG_CCOO_NO0_X249)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x250, G_IF_DIAG_CCOO_NO0_X250)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x251, G_IF_DIAG_CCOO_NO0_X251)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y252, G_IF_DIAG_CCOO_Y252)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y114, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x252, G_IF_DIAG_CCOO_NO0_X252)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y114, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x253, G_IF_DIAG_CCOO_NO0_X253)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y254, G_IF_DIAG_CCOO_Y254)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y115, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x254, G_IF_DIAG_CCOO_NO0_X254)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y115, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x255, G_IF_DIAG_CCOO_NO0_X255)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y256, G_IF_DIAG_CCOO_Y256)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y116, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x256, G_IF_DIAG_CCOO_NO0_X256)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y116, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y257, G_IF_DIAG_CCOO_Y257)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y117, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x257, G_IF_DIAG_CCOO_NO0_X257)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y117, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x258, G_IF_DIAG_CCOO_NO0_X258)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x259, G_IF_DIAG_CCOO_NO0_X259)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x260, G_IF_DIAG_CCOO_NO0_X260)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y261, G_IF_DIAG_CCOO_Y261)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y118, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x261, G_IF_DIAG_CCOO_NO0_X261)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y118, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x262, G_IF_DIAG_CCOO_NO0_X262)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y263, G_IF_DIAG_CCOO_Y263)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y119, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x263, G_IF_DIAG_CCOO_NO0_X263)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y119, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x264, G_IF_DIAG_CCOO_NO0_X264)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y265, G_IF_DIAG_CCOO_Y265)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y120, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x265, G_IF_DIAG_CCOO_NO0_X265)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y120, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x266, G_IF_DIAG_CCOO_NO0_X266)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x267, G_IF_DIAG_CCOO_NO0_X267)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x268, G_IF_DIAG_CCOO_NO0_X268)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x269, G_IF_DIAG_CCOO_NO0_X269)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y270, G_IF_DIAG_CCOO_Y270)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y121, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x270, G_IF_DIAG_CCOO_NO0_X270)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y121, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x271, G_IF_DIAG_CCOO_NO0_X271)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x272, G_IF_DIAG_CCOO_NO0_X272)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y273, G_IF_DIAG_CCOO_Y273)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y122, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x273, G_IF_DIAG_CCOO_NO0_X273)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y122, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x274, G_IF_DIAG_CCOO_NO0_X274)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x275, G_IF_DIAG_CCOO_NO0_X275)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x276, G_IF_DIAG_CCOO_NO0_X276)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x277, G_IF_DIAG_CCOO_NO0_X277)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y278, G_IF_DIAG_CCOO_Y278)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y123, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x278, G_IF_DIAG_CCOO_NO0_X278)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y123, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y279, G_IF_DIAG_CCOO_Y279)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y124, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x279, G_IF_DIAG_CCOO_NO0_X279)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y124, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y280, G_IF_DIAG_CCOO_Y280)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y125, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x280, G_IF_DIAG_CCOO_NO0_X280)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y125, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x281, G_IF_DIAG_CCOO_NO0_X281)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x282, G_IF_DIAG_CCOO_NO0_X282)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x283, G_IF_DIAG_CCOO_NO0_X283)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x284, G_IF_DIAG_CCOO_NO0_X284)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y285, G_IF_DIAG_CCOO_Y285)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y126, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x285, G_IF_DIAG_CCOO_NO0_X285)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y126, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x286, G_IF_DIAG_CCOO_NO0_X286)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y287, G_IF_DIAG_CCOO_Y287)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y127, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x287, G_IF_DIAG_CCOO_NO0_X287)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y127, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x288, G_IF_DIAG_CCOO_NO0_X288)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x289, G_IF_DIAG_CCOO_NO0_X289)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x290, G_IF_DIAG_CCOO_NO0_X290)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x291, G_IF_DIAG_CCOO_NO0_X291)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x292, G_IF_DIAG_CCOO_NO0_X292)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x293, G_IF_DIAG_CCOO_NO0_X293)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y294, G_IF_DIAG_CCOO_Y294)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y128, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x294, G_IF_DIAG_CCOO_NO0_X294)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y128, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x295, G_IF_DIAG_CCOO_NO0_X295)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x296, G_IF_DIAG_CCOO_NO0_X296)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x297, G_IF_DIAG_CCOO_NO0_X297)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x298, G_IF_DIAG_CCOO_NO0_X298)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y299, G_IF_DIAG_CCOO_Y299)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y129, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x299, G_IF_DIAG_CCOO_NO0_X299)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y129, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x300, G_IF_DIAG_CCOO_NO0_X300)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y301, G_IF_DIAG_CCOO_Y301)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y130, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x301, G_IF_DIAG_CCOO_NO0_X301)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y130, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x302, G_IF_DIAG_CCOO_NO0_X302)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x303, G_IF_DIAG_CCOO_NO0_X303)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x304, G_IF_DIAG_CCOO_NO0_X304)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x305, G_IF_DIAG_CCOO_NO0_X305)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y306, G_IF_DIAG_CCOO_Y306)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y131, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x306, G_IF_DIAG_CCOO_NO0_X306)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y131, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x307, G_IF_DIAG_CCOO_NO0_X307)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x308, G_IF_DIAG_CCOO_NO0_X308)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x309, G_IF_DIAG_CCOO_NO0_X309)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y310, G_IF_DIAG_CCOO_Y310)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y132, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x310, G_IF_DIAG_CCOO_NO0_X310)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y132, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x311, G_IF_DIAG_CCOO_NO0_X311)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y312, G_IF_DIAG_CCOO_Y312)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y133, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x312, G_IF_DIAG_CCOO_NO0_X312)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y133, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y313, G_IF_DIAG_CCOO_Y313)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y134, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x313, G_IF_DIAG_CCOO_NO0_X313)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y134, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x314, G_IF_DIAG_CCOO_NO0_X314)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x315, G_IF_DIAG_CCOO_NO0_X315)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y316, G_IF_DIAG_CCOO_Y316)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y135, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x316, G_IF_DIAG_CCOO_NO0_X316)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y135, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y317, G_IF_DIAG_CCOO_Y317)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y136, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x317, G_IF_DIAG_CCOO_NO0_X317)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y136, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x318, G_IF_DIAG_CCOO_NO0_X318)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x319, G_IF_DIAG_CCOO_NO0_X319)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x320, G_IF_DIAG_CCOO_NO0_X320)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sy, const FC_INT &iy, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x321, G_IF_DIAG_CCOO_NO0_X321)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x322, G_IF_DIAG_CCOO_NO0_X322)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x323, G_IF_DIAG_CCOO_NO0_X323)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x324, G_IF_DIAG_CCOO_NO0_X324)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y325, G_IF_DIAG_CCOO_Y325)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y137, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x325, G_IF_DIAG_CCOO_NO0_X325)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y137, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x326, G_IF_DIAG_CCOO_NO0_X326)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y327, G_IF_DIAG_CCOO_Y327)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y138, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x327, G_IF_DIAG_CCOO_NO0_X327)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y138, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x328, G_IF_DIAG_CCOO_NO0_X328)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x329, G_IF_DIAG_CCOO_NO0_X329)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x330, G_IF_DIAG_CCOO_NO0_X330)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x331, G_IF_DIAG_CCOO_NO0_X331)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y332, G_IF_DIAG_CCOO_Y332)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y139, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x332, G_IF_DIAG_CCOO_NO0_X332)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y139, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x333, G_IF_DIAG_CCOO_NO0_X333)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y334, G_IF_DIAG_CCOO_Y334)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y140, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x334, G_IF_DIAG_CCOO_NO0_X334)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const Y140, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x335, G_IF_DIAG_CCOO_NO0_X335)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y336, G_IF_DIAG_CCOO_Y336)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y141, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x336, G_IF_DIAG_CCOO_NO0_X336)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y141, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x337, G_IF_DIAG_CCOO_NO0_X337)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y338, G_IF_DIAG_CCOO_Y338)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y142, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x338, G_IF_DIAG_CCOO_NO0_X338)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y142, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x339, G_IF_DIAG_CCOO_NO0_X339)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_y340, G_IF_DIAG_CCOO_Y340)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y143, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x340, G_IF_DIAG_CCOO_NO0_X340)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y143, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x341, G_IF_DIAG_CCOO_NO0_X341)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x342, G_IF_DIAG_CCOO_NO0_X342)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x343, G_IF_DIAG_CCOO_NO0_X343)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x344, G_IF_DIAG_CCOO_NO0_X344)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x345, G_IF_DIAG_CCOO_NO0_X345)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x346, G_IF_DIAG_CCOO_NO0_X346)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x347, G_IF_DIAG_CCOO_NO0_X347)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x348, G_IF_DIAG_CCOO_NO0_X348)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x349, G_IF_DIAG_CCOO_NO0_X349)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x350, G_IF_DIAG_CCOO_NO0_X350)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x351, G_IF_DIAG_CCOO_NO0_X351)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x352, G_IF_DIAG_CCOO_NO0_X352)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x353, G_IF_DIAG_CCOO_NO0_X353)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x354, G_IF_DIAG_CCOO_NO0_X354)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x355, G_IF_DIAG_CCOO_NO0_X355)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x356, G_IF_DIAG_CCOO_NO0_X356)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x357, G_IF_DIAG_CCOO_NO0_X357)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x358, G_IF_DIAG_CCOO_NO0_X358)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x359, G_IF_DIAG_CCOO_NO0_X359)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x360, G_IF_DIAG_CCOO_NO0_X360)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x361, G_IF_DIAG_CCOO_NO0_X361)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x362, G_IF_DIAG_CCOO_NO0_X362)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x363, G_IF_DIAG_CCOO_NO0_X363)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x364, G_IF_DIAG_CCOO_NO0_X364)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x365, G_IF_DIAG_CCOO_NO0_X365)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x366, G_IF_DIAG_CCOO_NO0_X366)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x367, G_IF_DIAG_CCOO_NO0_X367)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x368, G_IF_DIAG_CCOO_NO0_X368)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x369, G_IF_DIAG_CCOO_NO0_X369)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x370, G_IF_DIAG_CCOO_NO0_X370)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x371, G_IF_DIAG_CCOO_NO0_X371)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x372, G_IF_DIAG_CCOO_NO0_X372)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x373, G_IF_DIAG_CCOO_NO0_X373)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x374, G_IF_DIAG_CCOO_NO0_X374)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x375, G_IF_DIAG_CCOO_NO0_X375)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x376, G_IF_DIAG_CCOO_NO0_X376)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x377, G_IF_DIAG_CCOO_NO0_X377)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x378, G_IF_DIAG_CCOO_NO0_X378)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x379, G_IF_DIAG_CCOO_NO0_X379)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x380, G_IF_DIAG_CCOO_NO0_X380)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x381, G_IF_DIAG_CCOO_NO0_X381)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x382, G_IF_DIAG_CCOO_NO0_X382)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x383, G_IF_DIAG_CCOO_NO0_X383)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x384, G_IF_DIAG_CCOO_NO0_X384)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x385, G_IF_DIAG_CCOO_NO0_X385)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x386, G_IF_DIAG_CCOO_NO0_X386)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x387, G_IF_DIAG_CCOO_NO0_X387)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_ccoo_no0_x388, G_IF_DIAG_CCOO_NO0_X388)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

      
 }     
       
       
 #endif
       
       
 