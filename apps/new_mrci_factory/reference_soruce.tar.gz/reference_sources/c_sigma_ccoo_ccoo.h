

#ifndef C_SIGMA_CCOO_CCOO_H
#define C_SIGMA_CCOO_CCOO_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//  8 8888888888   8 8888888888            ,8.       ,8.    8888888 8888888888 ,o888888o.     
//  8 8888         8 8888                 ,888.     ,888.         8 8888    . 8888     `88.   
//  8 8888         8 8888                .`8888.   .`8888.        8 8888   ,8 8888       `8b  
//  8 8888         8 8888               ,8.`8888. ,8.`8888.       8 8888   88 8888        `8b 
//  8 888888888888 8 888888888888      ,8'8.`8888,8^8.`8888.      8 8888   88 8888         88 
//  8 8888         8 8888             ,8' `8.`8888' `8.`8888.     8 8888   88 8888         88 
//  8 8888         8 8888            ,8'   `8.`88'   `8.`8888.    8 8888   88 8888        ,8P 
//  8 8888         8 8888           ,8'     `8.`'     `8.`8888.   8 8888   `8 8888       ,8P  
//  8 8888         8 8888          ,8'       `8        `8.`8888.  8 8888    ` 8888     ,88'   
//  8 8888         8 888888888888 ,8'         `         `8.`8888. 8 8888       `8888888P'     

void FC_FUNC(g_if_sigma_ccoo_ccoo_y0, G_IF_SIGMA_CCOO_CCOO_Y0)
  (const double * const h, const double * const Y0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x0, G_IF_SIGMA_CCOO_CCOO_NO0_X0)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y0, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y1, G_IF_SIGMA_CCOO_CCOO_Y1)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x1, G_IF_SIGMA_CCOO_CCOO_NO0_X1)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y1, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y2, G_IF_SIGMA_CCOO_CCOO_Y2)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x2, G_IF_SIGMA_CCOO_CCOO_NO0_X2)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y2, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y3, G_IF_SIGMA_CCOO_CCOO_Y3)
  (const double * const h, const double * const Y3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x3, G_IF_SIGMA_CCOO_CCOO_NO0_X3)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y3, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y4, G_IF_SIGMA_CCOO_CCOO_Y4)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x4, G_IF_SIGMA_CCOO_CCOO_NO0_X4)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y4, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y5, G_IF_SIGMA_CCOO_CCOO_Y5)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x5, G_IF_SIGMA_CCOO_CCOO_NO0_X5)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y5, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x6, G_IF_SIGMA_CCOO_CCOO_NO0_X6)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x6, G_IF_SIGMA_CCOO_CCOO_NO1_X6)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x7, G_IF_SIGMA_CCOO_CCOO_NO0_X7)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x7, G_IF_SIGMA_CCOO_CCOO_NO1_X7)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x8, G_IF_SIGMA_CCOO_CCOO_NO0_X8)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x8, G_IF_SIGMA_CCOO_CCOO_NO1_X8)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x9, G_IF_SIGMA_CCOO_CCOO_NO0_X9)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x9, G_IF_SIGMA_CCOO_CCOO_NO1_X9)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y10, G_IF_SIGMA_CCOO_CCOO_Y10)
  (const double * const h, const double * const Y6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x10, G_IF_SIGMA_CCOO_CCOO_NO0_X10)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y6, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y11, G_IF_SIGMA_CCOO_CCOO_Y11)
  (const double * const h, const double * const Y7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x11, G_IF_SIGMA_CCOO_CCOO_NO0_X11)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y7, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y12, G_IF_SIGMA_CCOO_CCOO_Y12)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x12, G_IF_SIGMA_CCOO_CCOO_NO0_X12)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y8, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y13, G_IF_SIGMA_CCOO_CCOO_Y13)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x13, G_IF_SIGMA_CCOO_CCOO_NO0_X13)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y9, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x14, G_IF_SIGMA_CCOO_CCOO_NO0_X14)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x14, G_IF_SIGMA_CCOO_CCOO_NO1_X14)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x15, G_IF_SIGMA_CCOO_CCOO_NO0_X15)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x15, G_IF_SIGMA_CCOO_CCOO_NO1_X15)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x16, G_IF_SIGMA_CCOO_CCOO_NO0_X16)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x16, G_IF_SIGMA_CCOO_CCOO_NO1_X16)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x17, G_IF_SIGMA_CCOO_CCOO_NO0_X17)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x17, G_IF_SIGMA_CCOO_CCOO_NO1_X17)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y18, G_IF_SIGMA_CCOO_CCOO_Y18)
  (const double * const h, const double * const Y10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x18, G_IF_SIGMA_CCOO_CCOO_NO0_X18)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y10, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y19, G_IF_SIGMA_CCOO_CCOO_Y19)
  (const double * const h, const double * const Y11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x19, G_IF_SIGMA_CCOO_CCOO_NO0_X19)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y11, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y20, G_IF_SIGMA_CCOO_CCOO_Y20)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x20, G_IF_SIGMA_CCOO_CCOO_NO0_X20)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y12, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y21, G_IF_SIGMA_CCOO_CCOO_Y21)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x21, G_IF_SIGMA_CCOO_CCOO_NO0_X21)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y13, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x22, G_IF_SIGMA_CCOO_CCOO_NO0_X22)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x22, G_IF_SIGMA_CCOO_CCOO_NO1_X22)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x23, G_IF_SIGMA_CCOO_CCOO_NO0_X23)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x23, G_IF_SIGMA_CCOO_CCOO_NO1_X23)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x24, G_IF_SIGMA_CCOO_CCOO_NO0_X24)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x24, G_IF_SIGMA_CCOO_CCOO_NO1_X24)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x25, G_IF_SIGMA_CCOO_CCOO_NO0_X25)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x25, G_IF_SIGMA_CCOO_CCOO_NO1_X25)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y26, G_IF_SIGMA_CCOO_CCOO_Y26)
  (const double * const h, const double * const Y14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x26, G_IF_SIGMA_CCOO_CCOO_NO0_X26)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y14, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y27, G_IF_SIGMA_CCOO_CCOO_Y27)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x27, G_IF_SIGMA_CCOO_CCOO_NO0_X27)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y15, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y28, G_IF_SIGMA_CCOO_CCOO_Y28)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y16, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x28, G_IF_SIGMA_CCOO_CCOO_NO0_X28)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y16, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y29, G_IF_SIGMA_CCOO_CCOO_Y29)
  (const double * const h, const double * const Y17, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x29, G_IF_SIGMA_CCOO_CCOO_NO0_X29)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y17, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x30, G_IF_SIGMA_CCOO_CCOO_NO0_X30)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x30, G_IF_SIGMA_CCOO_CCOO_NO1_X30)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x31, G_IF_SIGMA_CCOO_CCOO_NO0_X31)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x31, G_IF_SIGMA_CCOO_CCOO_NO1_X31)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x32, G_IF_SIGMA_CCOO_CCOO_NO0_X32)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x32, G_IF_SIGMA_CCOO_CCOO_NO1_X32)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x33, G_IF_SIGMA_CCOO_CCOO_NO0_X33)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x33, G_IF_SIGMA_CCOO_CCOO_NO1_X33)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y34, G_IF_SIGMA_CCOO_CCOO_Y34)
  (const double * const h, const double * const Y18, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x34, G_IF_SIGMA_CCOO_CCOO_NO0_X34)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y18, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y35, G_IF_SIGMA_CCOO_CCOO_Y35)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y19, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x35, G_IF_SIGMA_CCOO_CCOO_NO0_X35)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y19, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y36, G_IF_SIGMA_CCOO_CCOO_Y36)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y20, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x36, G_IF_SIGMA_CCOO_CCOO_NO0_X36)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y20, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y37, G_IF_SIGMA_CCOO_CCOO_Y37)
  (const double * const h, const double * const Y21, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x37, G_IF_SIGMA_CCOO_CCOO_NO0_X37)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y21, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x38, G_IF_SIGMA_CCOO_CCOO_NO0_X38)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x38, G_IF_SIGMA_CCOO_CCOO_NO1_X38)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x39, G_IF_SIGMA_CCOO_CCOO_NO0_X39)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x39, G_IF_SIGMA_CCOO_CCOO_NO1_X39)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x40, G_IF_SIGMA_CCOO_CCOO_NO0_X40)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x40, G_IF_SIGMA_CCOO_CCOO_NO1_X40)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x41, G_IF_SIGMA_CCOO_CCOO_NO0_X41)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x41, G_IF_SIGMA_CCOO_CCOO_NO1_X41)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y42, G_IF_SIGMA_CCOO_CCOO_Y42)
  (const double * const h, const double * const Y22, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x42, G_IF_SIGMA_CCOO_CCOO_NO0_X42)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y22, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y43, G_IF_SIGMA_CCOO_CCOO_Y43)
  (const double * const h, const double * const Y23, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x43, G_IF_SIGMA_CCOO_CCOO_NO0_X43)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y23, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x44, G_IF_SIGMA_CCOO_CCOO_NO0_X44)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x45, G_IF_SIGMA_CCOO_CCOO_NO0_X45)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x46, G_IF_SIGMA_CCOO_CCOO_NO0_X46)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x47, G_IF_SIGMA_CCOO_CCOO_NO0_X47)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y48, G_IF_SIGMA_CCOO_CCOO_Y48)
  (const double * const h, const double * const Y24, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x48, G_IF_SIGMA_CCOO_CCOO_NO0_X48)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y24, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y49, G_IF_SIGMA_CCOO_CCOO_Y49)
  (const double * const h, const double * const Y25, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x49, G_IF_SIGMA_CCOO_CCOO_NO0_X49)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y25, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x50, G_IF_SIGMA_CCOO_CCOO_NO0_X50)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x51, G_IF_SIGMA_CCOO_CCOO_NO0_X51)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x52, G_IF_SIGMA_CCOO_CCOO_NO0_X52)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x53, G_IF_SIGMA_CCOO_CCOO_NO0_X53)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x54, G_IF_SIGMA_CCOO_CCOO_NO0_X54)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x54, G_IF_SIGMA_CCOO_CCOO_NO1_X54)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x55, G_IF_SIGMA_CCOO_CCOO_NO0_X55)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x55, G_IF_SIGMA_CCOO_CCOO_NO1_X55)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x56, G_IF_SIGMA_CCOO_CCOO_NO0_X56)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x56, G_IF_SIGMA_CCOO_CCOO_NO1_X56)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y57, G_IF_SIGMA_CCOO_CCOO_Y57)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y26, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x57, G_IF_SIGMA_CCOO_CCOO_NO0_X57)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y26, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x57, G_IF_SIGMA_CCOO_CCOO_NO1_X57)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y58, G_IF_SIGMA_CCOO_CCOO_Y58)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y27, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x58, G_IF_SIGMA_CCOO_CCOO_NO0_X58)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y27, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x58, G_IF_SIGMA_CCOO_CCOO_NO1_X58)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x59, G_IF_SIGMA_CCOO_CCOO_NO0_X59)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x59, G_IF_SIGMA_CCOO_CCOO_NO1_X59)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x60, G_IF_SIGMA_CCOO_CCOO_NO0_X60)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x60, G_IF_SIGMA_CCOO_CCOO_NO1_X60)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y61, G_IF_SIGMA_CCOO_CCOO_Y61)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y28, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x61, G_IF_SIGMA_CCOO_CCOO_NO0_X61)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y28, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x61, G_IF_SIGMA_CCOO_CCOO_NO1_X61)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y62, G_IF_SIGMA_CCOO_CCOO_Y62)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y29, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x62, G_IF_SIGMA_CCOO_CCOO_NO0_X62)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y29, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x62, G_IF_SIGMA_CCOO_CCOO_NO1_X62)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x63, G_IF_SIGMA_CCOO_CCOO_NO0_X63)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x63, G_IF_SIGMA_CCOO_CCOO_NO1_X63)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x64, G_IF_SIGMA_CCOO_CCOO_NO0_X64)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x64, G_IF_SIGMA_CCOO_CCOO_NO1_X64)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x65, G_IF_SIGMA_CCOO_CCOO_NO0_X65)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x65, G_IF_SIGMA_CCOO_CCOO_NO1_X65)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x66, G_IF_SIGMA_CCOO_CCOO_NO0_X66)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x66, G_IF_SIGMA_CCOO_CCOO_NO1_X66)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y67, G_IF_SIGMA_CCOO_CCOO_Y67)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y30, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x67, G_IF_SIGMA_CCOO_CCOO_NO0_X67)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y30, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x67, G_IF_SIGMA_CCOO_CCOO_NO1_X67)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y68, G_IF_SIGMA_CCOO_CCOO_Y68)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y31, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x68, G_IF_SIGMA_CCOO_CCOO_NO0_X68)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y31, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x68, G_IF_SIGMA_CCOO_CCOO_NO1_X68)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x69, G_IF_SIGMA_CCOO_CCOO_NO0_X69)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x69, G_IF_SIGMA_CCOO_CCOO_NO1_X69)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x70, G_IF_SIGMA_CCOO_CCOO_NO0_X70)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x70, G_IF_SIGMA_CCOO_CCOO_NO1_X70)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y71, G_IF_SIGMA_CCOO_CCOO_Y71)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y32, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x71, G_IF_SIGMA_CCOO_CCOO_NO0_X71)
  (const double * const Y32, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x71, G_IF_SIGMA_CCOO_CCOO_NO1_X71)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y72, G_IF_SIGMA_CCOO_CCOO_Y72)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y33, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x72, G_IF_SIGMA_CCOO_CCOO_NO0_X72)
  (const double * const Y33, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x72, G_IF_SIGMA_CCOO_CCOO_NO1_X72)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x73, G_IF_SIGMA_CCOO_CCOO_NO0_X73)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x73, G_IF_SIGMA_CCOO_CCOO_NO1_X73)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x74, G_IF_SIGMA_CCOO_CCOO_NO0_X74)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x74, G_IF_SIGMA_CCOO_CCOO_NO1_X74)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x75, G_IF_SIGMA_CCOO_CCOO_NO0_X75)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x75, G_IF_SIGMA_CCOO_CCOO_NO1_X75)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x76, G_IF_SIGMA_CCOO_CCOO_NO0_X76)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x76, G_IF_SIGMA_CCOO_CCOO_NO1_X76)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x77, G_IF_SIGMA_CCOO_CCOO_NO0_X77)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x77, G_IF_SIGMA_CCOO_CCOO_NO1_X77)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y78, G_IF_SIGMA_CCOO_CCOO_Y78)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y34, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x78, G_IF_SIGMA_CCOO_CCOO_NO0_X78)
  (const double * const Y34, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x78, G_IF_SIGMA_CCOO_CCOO_NO1_X78)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y79, G_IF_SIGMA_CCOO_CCOO_Y79)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y35, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x79, G_IF_SIGMA_CCOO_CCOO_NO0_X79)
  (const double * const Y35, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x79, G_IF_SIGMA_CCOO_CCOO_NO1_X79)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x80, G_IF_SIGMA_CCOO_CCOO_NO0_X80)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x80, G_IF_SIGMA_CCOO_CCOO_NO1_X80)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x81, G_IF_SIGMA_CCOO_CCOO_NO0_X81)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x81, G_IF_SIGMA_CCOO_CCOO_NO1_X81)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x82, G_IF_SIGMA_CCOO_CCOO_NO0_X82)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x82, G_IF_SIGMA_CCOO_CCOO_NO1_X82)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x83, G_IF_SIGMA_CCOO_CCOO_NO0_X83)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x83, G_IF_SIGMA_CCOO_CCOO_NO1_X83)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x84, G_IF_SIGMA_CCOO_CCOO_NO0_X84)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x84, G_IF_SIGMA_CCOO_CCOO_NO1_X84)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x85, G_IF_SIGMA_CCOO_CCOO_NO0_X85)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x85, G_IF_SIGMA_CCOO_CCOO_NO1_X85)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y86, G_IF_SIGMA_CCOO_CCOO_Y86)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y36, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x86, G_IF_SIGMA_CCOO_CCOO_NO0_X86)
  (const double * const Y36, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x86, G_IF_SIGMA_CCOO_CCOO_NO1_X86)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y87, G_IF_SIGMA_CCOO_CCOO_Y87)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y37, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x87, G_IF_SIGMA_CCOO_CCOO_NO0_X87)
  (const double * const Y37, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x87, G_IF_SIGMA_CCOO_CCOO_NO1_X87)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x88, G_IF_SIGMA_CCOO_CCOO_NO0_X88)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x88, G_IF_SIGMA_CCOO_CCOO_NO1_X88)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x89, G_IF_SIGMA_CCOO_CCOO_NO0_X89)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x89, G_IF_SIGMA_CCOO_CCOO_NO1_X89)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x90, G_IF_SIGMA_CCOO_CCOO_NO0_X90)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x90, G_IF_SIGMA_CCOO_CCOO_NO1_X90)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x91, G_IF_SIGMA_CCOO_CCOO_NO0_X91)
  (const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x91, G_IF_SIGMA_CCOO_CCOO_NO1_X91)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x92, G_IF_SIGMA_CCOO_CCOO_NO0_X92)
  (const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x92, G_IF_SIGMA_CCOO_CCOO_NO1_X92)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x93, G_IF_SIGMA_CCOO_CCOO_NO0_X93)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x93, G_IF_SIGMA_CCOO_CCOO_NO1_X93)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x94, G_IF_SIGMA_CCOO_CCOO_NO0_X94)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x94, G_IF_SIGMA_CCOO_CCOO_NO1_X94)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y95, G_IF_SIGMA_CCOO_CCOO_Y95)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y38, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x95, G_IF_SIGMA_CCOO_CCOO_NO0_X95)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y38, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x95, G_IF_SIGMA_CCOO_CCOO_NO1_X95)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y96, G_IF_SIGMA_CCOO_CCOO_Y96)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y39, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x96, G_IF_SIGMA_CCOO_CCOO_NO0_X96)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y39, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x96, G_IF_SIGMA_CCOO_CCOO_NO1_X96)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x97, G_IF_SIGMA_CCOO_CCOO_NO0_X97)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x97, G_IF_SIGMA_CCOO_CCOO_NO1_X97)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x98, G_IF_SIGMA_CCOO_CCOO_NO0_X98)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x98, G_IF_SIGMA_CCOO_CCOO_NO1_X98)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y99, G_IF_SIGMA_CCOO_CCOO_Y99)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y40, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x99, G_IF_SIGMA_CCOO_CCOO_NO0_X99)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y40, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x99, G_IF_SIGMA_CCOO_CCOO_NO1_X99)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y100, G_IF_SIGMA_CCOO_CCOO_Y100)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y41, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x100, G_IF_SIGMA_CCOO_CCOO_NO0_X100)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y41, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x100, G_IF_SIGMA_CCOO_CCOO_NO1_X100)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x101, G_IF_SIGMA_CCOO_CCOO_NO0_X101)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x101, G_IF_SIGMA_CCOO_CCOO_NO1_X101)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x102, G_IF_SIGMA_CCOO_CCOO_NO0_X102)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x102, G_IF_SIGMA_CCOO_CCOO_NO1_X102)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y103, G_IF_SIGMA_CCOO_CCOO_Y103)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y42, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x103, G_IF_SIGMA_CCOO_CCOO_NO0_X103)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y42, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x103, G_IF_SIGMA_CCOO_CCOO_NO1_X103)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y104, G_IF_SIGMA_CCOO_CCOO_Y104)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y43, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x104, G_IF_SIGMA_CCOO_CCOO_NO0_X104)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y43, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x104, G_IF_SIGMA_CCOO_CCOO_NO1_X104)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x105, G_IF_SIGMA_CCOO_CCOO_NO0_X105)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x105, G_IF_SIGMA_CCOO_CCOO_NO1_X105)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x106, G_IF_SIGMA_CCOO_CCOO_NO0_X106)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x106, G_IF_SIGMA_CCOO_CCOO_NO1_X106)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y107, G_IF_SIGMA_CCOO_CCOO_Y107)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y44, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x107, G_IF_SIGMA_CCOO_CCOO_NO0_X107)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y44, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x107, G_IF_SIGMA_CCOO_CCOO_NO1_X107)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y108, G_IF_SIGMA_CCOO_CCOO_Y108)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y45, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x108, G_IF_SIGMA_CCOO_CCOO_NO0_X108)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y45, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x108, G_IF_SIGMA_CCOO_CCOO_NO1_X108)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x109, G_IF_SIGMA_CCOO_CCOO_NO0_X109)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x109, G_IF_SIGMA_CCOO_CCOO_NO1_X109)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x110, G_IF_SIGMA_CCOO_CCOO_NO0_X110)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x111, G_IF_SIGMA_CCOO_CCOO_NO0_X111)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y112, G_IF_SIGMA_CCOO_CCOO_Y112)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y46, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x112, G_IF_SIGMA_CCOO_CCOO_NO0_X112)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y46, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y113, G_IF_SIGMA_CCOO_CCOO_Y113)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y47, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x113, G_IF_SIGMA_CCOO_CCOO_NO0_X113)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y47, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x114, G_IF_SIGMA_CCOO_CCOO_NO0_X114)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x115, G_IF_SIGMA_CCOO_CCOO_NO0_X115)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y116, G_IF_SIGMA_CCOO_CCOO_Y116)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y48, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x116, G_IF_SIGMA_CCOO_CCOO_NO0_X116)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y48, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y117, G_IF_SIGMA_CCOO_CCOO_Y117)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y49, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x117, G_IF_SIGMA_CCOO_CCOO_NO0_X117)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y49, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x118, G_IF_SIGMA_CCOO_CCOO_NO0_X118)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x118, G_IF_SIGMA_CCOO_CCOO_NO1_X118)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x119, G_IF_SIGMA_CCOO_CCOO_NO0_X119)
  (const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x119, G_IF_SIGMA_CCOO_CCOO_NO1_X119)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x120, G_IF_SIGMA_CCOO_CCOO_NO0_X120)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x120, G_IF_SIGMA_CCOO_CCOO_NO1_X120)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y121, G_IF_SIGMA_CCOO_CCOO_Y121)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y50, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x121, G_IF_SIGMA_CCOO_CCOO_NO0_X121)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y50, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x121, G_IF_SIGMA_CCOO_CCOO_NO1_X121)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y122, G_IF_SIGMA_CCOO_CCOO_Y122)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y51, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x122, G_IF_SIGMA_CCOO_CCOO_NO0_X122)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y51, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x122, G_IF_SIGMA_CCOO_CCOO_NO1_X122)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x123, G_IF_SIGMA_CCOO_CCOO_NO0_X123)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x123, G_IF_SIGMA_CCOO_CCOO_NO1_X123)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x124, G_IF_SIGMA_CCOO_CCOO_NO0_X124)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x124, G_IF_SIGMA_CCOO_CCOO_NO1_X124)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y125, G_IF_SIGMA_CCOO_CCOO_Y125)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y52, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x125, G_IF_SIGMA_CCOO_CCOO_NO0_X125)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y52, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x125, G_IF_SIGMA_CCOO_CCOO_NO1_X125)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y126, G_IF_SIGMA_CCOO_CCOO_Y126)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y53, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x126, G_IF_SIGMA_CCOO_CCOO_NO0_X126)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y53, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x126, G_IF_SIGMA_CCOO_CCOO_NO1_X126)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x127, G_IF_SIGMA_CCOO_CCOO_NO0_X127)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x127, G_IF_SIGMA_CCOO_CCOO_NO1_X127)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x128, G_IF_SIGMA_CCOO_CCOO_NO0_X128)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x128, G_IF_SIGMA_CCOO_CCOO_NO1_X128)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y129, G_IF_SIGMA_CCOO_CCOO_Y129)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y54, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x129, G_IF_SIGMA_CCOO_CCOO_NO0_X129)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y54, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x129, G_IF_SIGMA_CCOO_CCOO_NO1_X129)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y130, G_IF_SIGMA_CCOO_CCOO_Y130)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y55, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x130, G_IF_SIGMA_CCOO_CCOO_NO0_X130)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y55, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x130, G_IF_SIGMA_CCOO_CCOO_NO1_X130)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x131, G_IF_SIGMA_CCOO_CCOO_NO0_X131)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x131, G_IF_SIGMA_CCOO_CCOO_NO1_X131)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x132, G_IF_SIGMA_CCOO_CCOO_NO0_X132)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x132, G_IF_SIGMA_CCOO_CCOO_NO1_X132)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y133, G_IF_SIGMA_CCOO_CCOO_Y133)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y56, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x133, G_IF_SIGMA_CCOO_CCOO_NO0_X133)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y56, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x133, G_IF_SIGMA_CCOO_CCOO_NO1_X133)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y134, G_IF_SIGMA_CCOO_CCOO_Y134)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y57, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x134, G_IF_SIGMA_CCOO_CCOO_NO0_X134)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y57, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x134, G_IF_SIGMA_CCOO_CCOO_NO1_X134)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x135, G_IF_SIGMA_CCOO_CCOO_NO0_X135)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x135, G_IF_SIGMA_CCOO_CCOO_NO1_X135)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x136, G_IF_SIGMA_CCOO_CCOO_NO0_X136)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x137, G_IF_SIGMA_CCOO_CCOO_NO0_X137)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y138, G_IF_SIGMA_CCOO_CCOO_Y138)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y58, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x138, G_IF_SIGMA_CCOO_CCOO_NO0_X138)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y58, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y139, G_IF_SIGMA_CCOO_CCOO_Y139)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y59, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x139, G_IF_SIGMA_CCOO_CCOO_NO0_X139)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y59, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x140, G_IF_SIGMA_CCOO_CCOO_NO0_X140)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x141, G_IF_SIGMA_CCOO_CCOO_NO0_X141)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y142, G_IF_SIGMA_CCOO_CCOO_Y142)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y60, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x142, G_IF_SIGMA_CCOO_CCOO_NO0_X142)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y60, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y143, G_IF_SIGMA_CCOO_CCOO_Y143)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y61, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x143, G_IF_SIGMA_CCOO_CCOO_NO0_X143)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y61, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x144, G_IF_SIGMA_CCOO_CCOO_NO0_X144)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x144, G_IF_SIGMA_CCOO_CCOO_NO1_X144)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x145, G_IF_SIGMA_CCOO_CCOO_NO0_X145)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x145, G_IF_SIGMA_CCOO_CCOO_NO1_X145)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y146, G_IF_SIGMA_CCOO_CCOO_Y146)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y62, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x146, G_IF_SIGMA_CCOO_CCOO_NO0_X146)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y62, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x146, G_IF_SIGMA_CCOO_CCOO_NO1_X146)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y147, G_IF_SIGMA_CCOO_CCOO_Y147)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y63, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x147, G_IF_SIGMA_CCOO_CCOO_NO0_X147)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y63, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x147, G_IF_SIGMA_CCOO_CCOO_NO1_X147)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y148, G_IF_SIGMA_CCOO_CCOO_Y148)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y64, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x148, G_IF_SIGMA_CCOO_CCOO_NO0_X148)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y64, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x148, G_IF_SIGMA_CCOO_CCOO_NO1_X148)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y149, G_IF_SIGMA_CCOO_CCOO_Y149)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y65, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x149, G_IF_SIGMA_CCOO_CCOO_NO0_X149)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y65, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x149, G_IF_SIGMA_CCOO_CCOO_NO1_X149)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y150, G_IF_SIGMA_CCOO_CCOO_Y150)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y66, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x150, G_IF_SIGMA_CCOO_CCOO_NO0_X150)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y66, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x150, G_IF_SIGMA_CCOO_CCOO_NO1_X150)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y151, G_IF_SIGMA_CCOO_CCOO_Y151)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y67, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x151, G_IF_SIGMA_CCOO_CCOO_NO0_X151)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y67, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x151, G_IF_SIGMA_CCOO_CCOO_NO1_X151)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y152, G_IF_SIGMA_CCOO_CCOO_Y152)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y68, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x152, G_IF_SIGMA_CCOO_CCOO_NO0_X152)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y68, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x152, G_IF_SIGMA_CCOO_CCOO_NO1_X152)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y153, G_IF_SIGMA_CCOO_CCOO_Y153)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y69, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x153, G_IF_SIGMA_CCOO_CCOO_NO0_X153)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y69, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x153, G_IF_SIGMA_CCOO_CCOO_NO1_X153)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y154, G_IF_SIGMA_CCOO_CCOO_Y154)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y70, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x154, G_IF_SIGMA_CCOO_CCOO_NO0_X154)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y70, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x154, G_IF_SIGMA_CCOO_CCOO_NO1_X154)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y155, G_IF_SIGMA_CCOO_CCOO_Y155)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y71, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x155, G_IF_SIGMA_CCOO_CCOO_NO0_X155)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y71, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x155, G_IF_SIGMA_CCOO_CCOO_NO1_X155)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y156, G_IF_SIGMA_CCOO_CCOO_Y156)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y72, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x156, G_IF_SIGMA_CCOO_CCOO_NO0_X156)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y72, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y157, G_IF_SIGMA_CCOO_CCOO_Y157)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y73, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x157, G_IF_SIGMA_CCOO_CCOO_NO0_X157)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y73, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y158, G_IF_SIGMA_CCOO_CCOO_Y158)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y74, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x158, G_IF_SIGMA_CCOO_CCOO_NO0_X158)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y74, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x158, G_IF_SIGMA_CCOO_CCOO_NO1_X158)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y159, G_IF_SIGMA_CCOO_CCOO_Y159)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y75, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x159, G_IF_SIGMA_CCOO_CCOO_NO0_X159)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y75, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x159, G_IF_SIGMA_CCOO_CCOO_NO1_X159)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x160, G_IF_SIGMA_CCOO_CCOO_NO0_X160)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x160, G_IF_SIGMA_CCOO_CCOO_NO1_X160)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x161, G_IF_SIGMA_CCOO_CCOO_NO0_X161)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x161, G_IF_SIGMA_CCOO_CCOO_NO1_X161)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y162, G_IF_SIGMA_CCOO_CCOO_Y162)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y76, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x162, G_IF_SIGMA_CCOO_CCOO_NO0_X162)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y76, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x162, G_IF_SIGMA_CCOO_CCOO_NO1_X162)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y163, G_IF_SIGMA_CCOO_CCOO_Y163)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y77, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x163, G_IF_SIGMA_CCOO_CCOO_NO0_X163)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y77, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x163, G_IF_SIGMA_CCOO_CCOO_NO1_X163)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y164, G_IF_SIGMA_CCOO_CCOO_Y164)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y78, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x164, G_IF_SIGMA_CCOO_CCOO_NO0_X164)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y78, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x164, G_IF_SIGMA_CCOO_CCOO_NO1_X164)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y165, G_IF_SIGMA_CCOO_CCOO_Y165)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y79, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x165, G_IF_SIGMA_CCOO_CCOO_NO0_X165)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y79, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x165, G_IF_SIGMA_CCOO_CCOO_NO1_X165)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y166, G_IF_SIGMA_CCOO_CCOO_Y166)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y80, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x166, G_IF_SIGMA_CCOO_CCOO_NO0_X166)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y80, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x166, G_IF_SIGMA_CCOO_CCOO_NO1_X166)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y167, G_IF_SIGMA_CCOO_CCOO_Y167)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y81, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x167, G_IF_SIGMA_CCOO_CCOO_NO0_X167)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y81, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x167, G_IF_SIGMA_CCOO_CCOO_NO1_X167)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y168, G_IF_SIGMA_CCOO_CCOO_Y168)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y82, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x168, G_IF_SIGMA_CCOO_CCOO_NO0_X168)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y82, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x168, G_IF_SIGMA_CCOO_CCOO_NO1_X168)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y169, G_IF_SIGMA_CCOO_CCOO_Y169)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y83, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x169, G_IF_SIGMA_CCOO_CCOO_NO0_X169)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y83, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x169, G_IF_SIGMA_CCOO_CCOO_NO1_X169)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y170, G_IF_SIGMA_CCOO_CCOO_Y170)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y84, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x170, G_IF_SIGMA_CCOO_CCOO_NO0_X170)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y84, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y171, G_IF_SIGMA_CCOO_CCOO_Y171)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y85, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x171, G_IF_SIGMA_CCOO_CCOO_NO0_X171)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y85, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x172, G_IF_SIGMA_CCOO_CCOO_NO0_X172)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x172, G_IF_SIGMA_CCOO_CCOO_NO1_X172)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y173, G_IF_SIGMA_CCOO_CCOO_Y173)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y86, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x173, G_IF_SIGMA_CCOO_CCOO_NO0_X173)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y86, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x173, G_IF_SIGMA_CCOO_CCOO_NO1_X173)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y174, G_IF_SIGMA_CCOO_CCOO_Y174)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y87, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x174, G_IF_SIGMA_CCOO_CCOO_NO0_X174)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y87, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x174, G_IF_SIGMA_CCOO_CCOO_NO1_X174)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x175, G_IF_SIGMA_CCOO_CCOO_NO0_X175)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x175, G_IF_SIGMA_CCOO_CCOO_NO1_X175)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y176, G_IF_SIGMA_CCOO_CCOO_Y176)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y88, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x176, G_IF_SIGMA_CCOO_CCOO_NO0_X176)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y88, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x176, G_IF_SIGMA_CCOO_CCOO_NO1_X176)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y177, G_IF_SIGMA_CCOO_CCOO_Y177)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y89, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x177, G_IF_SIGMA_CCOO_CCOO_NO0_X177)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y89, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x177, G_IF_SIGMA_CCOO_CCOO_NO1_X177)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y178, G_IF_SIGMA_CCOO_CCOO_Y178)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y90, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x178, G_IF_SIGMA_CCOO_CCOO_NO0_X178)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y90, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x178, G_IF_SIGMA_CCOO_CCOO_NO1_X178)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y179, G_IF_SIGMA_CCOO_CCOO_Y179)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y91, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x179, G_IF_SIGMA_CCOO_CCOO_NO0_X179)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y91, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x179, G_IF_SIGMA_CCOO_CCOO_NO1_X179)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y180, G_IF_SIGMA_CCOO_CCOO_Y180)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y92, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x180, G_IF_SIGMA_CCOO_CCOO_NO0_X180)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y92, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y181, G_IF_SIGMA_CCOO_CCOO_Y181)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y93, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x181, G_IF_SIGMA_CCOO_CCOO_NO0_X181)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y93, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y182, G_IF_SIGMA_CCOO_CCOO_Y182)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y94, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x182, G_IF_SIGMA_CCOO_CCOO_NO0_X182)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y94, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x182, G_IF_SIGMA_CCOO_CCOO_NO1_X182)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y183, G_IF_SIGMA_CCOO_CCOO_Y183)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y95, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x183, G_IF_SIGMA_CCOO_CCOO_NO0_X183)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y95, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x183, G_IF_SIGMA_CCOO_CCOO_NO1_X183)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x184, G_IF_SIGMA_CCOO_CCOO_NO0_X184)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x184, G_IF_SIGMA_CCOO_CCOO_NO1_X184)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x185, G_IF_SIGMA_CCOO_CCOO_NO0_X185)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x185, G_IF_SIGMA_CCOO_CCOO_NO1_X185)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y186, G_IF_SIGMA_CCOO_CCOO_Y186)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y96, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x186, G_IF_SIGMA_CCOO_CCOO_NO0_X186)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y96, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x186, G_IF_SIGMA_CCOO_CCOO_NO1_X186)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y187, G_IF_SIGMA_CCOO_CCOO_Y187)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y97, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x187, G_IF_SIGMA_CCOO_CCOO_NO0_X187)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y97, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x187, G_IF_SIGMA_CCOO_CCOO_NO1_X187)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y188, G_IF_SIGMA_CCOO_CCOO_Y188)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y98, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x188, G_IF_SIGMA_CCOO_CCOO_NO0_X188)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y98, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x188, G_IF_SIGMA_CCOO_CCOO_NO1_X188)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y189, G_IF_SIGMA_CCOO_CCOO_Y189)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y99, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x189, G_IF_SIGMA_CCOO_CCOO_NO0_X189)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y99, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x189, G_IF_SIGMA_CCOO_CCOO_NO1_X189)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y190, G_IF_SIGMA_CCOO_CCOO_Y190)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y100, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x190, G_IF_SIGMA_CCOO_CCOO_NO0_X190)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y100, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x190, G_IF_SIGMA_CCOO_CCOO_NO1_X190)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y191, G_IF_SIGMA_CCOO_CCOO_Y191)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y101, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x191, G_IF_SIGMA_CCOO_CCOO_NO0_X191)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y101, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x191, G_IF_SIGMA_CCOO_CCOO_NO1_X191)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y192, G_IF_SIGMA_CCOO_CCOO_Y192)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y102, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x192, G_IF_SIGMA_CCOO_CCOO_NO0_X192)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y102, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x192, G_IF_SIGMA_CCOO_CCOO_NO1_X192)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y193, G_IF_SIGMA_CCOO_CCOO_Y193)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y103, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x193, G_IF_SIGMA_CCOO_CCOO_NO0_X193)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y103, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x193, G_IF_SIGMA_CCOO_CCOO_NO1_X193)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y194, G_IF_SIGMA_CCOO_CCOO_Y194)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y104, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x194, G_IF_SIGMA_CCOO_CCOO_NO0_X194)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y104, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y195, G_IF_SIGMA_CCOO_CCOO_Y195)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y105, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x195, G_IF_SIGMA_CCOO_CCOO_NO0_X195)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y105, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x196, G_IF_SIGMA_CCOO_CCOO_NO0_X196)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x196, G_IF_SIGMA_CCOO_CCOO_NO1_X196)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y197, G_IF_SIGMA_CCOO_CCOO_Y197)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y106, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x197, G_IF_SIGMA_CCOO_CCOO_NO0_X197)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y106, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x197, G_IF_SIGMA_CCOO_CCOO_NO1_X197)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y198, G_IF_SIGMA_CCOO_CCOO_Y198)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y107, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x198, G_IF_SIGMA_CCOO_CCOO_NO0_X198)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y107, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x198, G_IF_SIGMA_CCOO_CCOO_NO1_X198)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x199, G_IF_SIGMA_CCOO_CCOO_NO0_X199)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x199, G_IF_SIGMA_CCOO_CCOO_NO1_X199)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y200, G_IF_SIGMA_CCOO_CCOO_Y200)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y108, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x200, G_IF_SIGMA_CCOO_CCOO_NO0_X200)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y108, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x200, G_IF_SIGMA_CCOO_CCOO_NO1_X200)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y201, G_IF_SIGMA_CCOO_CCOO_Y201)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y109, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x201, G_IF_SIGMA_CCOO_CCOO_NO0_X201)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y109, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x201, G_IF_SIGMA_CCOO_CCOO_NO1_X201)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y202, G_IF_SIGMA_CCOO_CCOO_Y202)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y110, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x202, G_IF_SIGMA_CCOO_CCOO_NO0_X202)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y110, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y203, G_IF_SIGMA_CCOO_CCOO_Y203)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y111, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x203, G_IF_SIGMA_CCOO_CCOO_NO0_X203)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y111, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y204, G_IF_SIGMA_CCOO_CCOO_Y204)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y112, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x204, G_IF_SIGMA_CCOO_CCOO_NO0_X204)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y112, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y205, G_IF_SIGMA_CCOO_CCOO_Y205)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y113, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x205, G_IF_SIGMA_CCOO_CCOO_NO0_X205)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y113, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y206, G_IF_SIGMA_CCOO_CCOO_Y206)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y114, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x206, G_IF_SIGMA_CCOO_CCOO_NO0_X206)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y114, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y207, G_IF_SIGMA_CCOO_CCOO_Y207)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y115, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x207, G_IF_SIGMA_CCOO_CCOO_NO0_X207)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y115, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y208, G_IF_SIGMA_CCOO_CCOO_Y208)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y116, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x208, G_IF_SIGMA_CCOO_CCOO_NO0_X208)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y116, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y209, G_IF_SIGMA_CCOO_CCOO_Y209)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y117, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x209, G_IF_SIGMA_CCOO_CCOO_NO0_X209)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y117, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y210, G_IF_SIGMA_CCOO_CCOO_Y210)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y118, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x210, G_IF_SIGMA_CCOO_CCOO_NO0_X210)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y118, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y211, G_IF_SIGMA_CCOO_CCOO_Y211)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y119, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x211, G_IF_SIGMA_CCOO_CCOO_NO0_X211)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y119, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y212, G_IF_SIGMA_CCOO_CCOO_Y212)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y120, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x212, G_IF_SIGMA_CCOO_CCOO_NO0_X212)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y120, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y213, G_IF_SIGMA_CCOO_CCOO_Y213)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y121, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x213, G_IF_SIGMA_CCOO_CCOO_NO0_X213)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y121, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x214, G_IF_SIGMA_CCOO_CCOO_NO0_X214)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x215, G_IF_SIGMA_CCOO_CCOO_NO0_X215)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y216, G_IF_SIGMA_CCOO_CCOO_Y216)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y122, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x216, G_IF_SIGMA_CCOO_CCOO_NO0_X216)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y122, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y217, G_IF_SIGMA_CCOO_CCOO_Y217)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y123, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x217, G_IF_SIGMA_CCOO_CCOO_NO0_X217)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y123, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y218, G_IF_SIGMA_CCOO_CCOO_Y218)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y124, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x218, G_IF_SIGMA_CCOO_CCOO_NO0_X218)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y124, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y219, G_IF_SIGMA_CCOO_CCOO_Y219)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y125, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x219, G_IF_SIGMA_CCOO_CCOO_NO0_X219)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y125, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y220, G_IF_SIGMA_CCOO_CCOO_Y220)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y126, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x220, G_IF_SIGMA_CCOO_CCOO_NO0_X220)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y126, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y221, G_IF_SIGMA_CCOO_CCOO_Y221)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y127, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x221, G_IF_SIGMA_CCOO_CCOO_NO0_X221)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const Y127, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y222, G_IF_SIGMA_CCOO_CCOO_Y222)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y128, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x222, G_IF_SIGMA_CCOO_CCOO_NO0_X222)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y128, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y223, G_IF_SIGMA_CCOO_CCOO_Y223)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y129, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x223, G_IF_SIGMA_CCOO_CCOO_NO0_X223)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y129, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y224, G_IF_SIGMA_CCOO_CCOO_Y224)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y130, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x224, G_IF_SIGMA_CCOO_CCOO_NO0_X224)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y130, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y225, G_IF_SIGMA_CCOO_CCOO_Y225)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y131, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x225, G_IF_SIGMA_CCOO_CCOO_NO0_X225)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y131, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y226, G_IF_SIGMA_CCOO_CCOO_Y226)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y132, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x226, G_IF_SIGMA_CCOO_CCOO_NO0_X226)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y132, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y227, G_IF_SIGMA_CCOO_CCOO_Y227)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y133, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x227, G_IF_SIGMA_CCOO_CCOO_NO0_X227)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y133, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x228, G_IF_SIGMA_CCOO_CCOO_NO0_X228)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x229, G_IF_SIGMA_CCOO_CCOO_NO0_X229)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x230, G_IF_SIGMA_CCOO_CCOO_NO0_X230)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x230, G_IF_SIGMA_CCOO_CCOO_NO1_X230)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x231, G_IF_SIGMA_CCOO_CCOO_NO0_X231)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x231, G_IF_SIGMA_CCOO_CCOO_NO1_X231)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x232, G_IF_SIGMA_CCOO_CCOO_NO0_X232)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x232, G_IF_SIGMA_CCOO_CCOO_NO1_X232)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x233, G_IF_SIGMA_CCOO_CCOO_NO0_X233)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x233, G_IF_SIGMA_CCOO_CCOO_NO1_X233)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y234, G_IF_SIGMA_CCOO_CCOO_Y234)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y134, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x234, G_IF_SIGMA_CCOO_CCOO_NO0_X234)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y134, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x234, G_IF_SIGMA_CCOO_CCOO_NO1_X234)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y235, G_IF_SIGMA_CCOO_CCOO_Y235)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y135, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x235, G_IF_SIGMA_CCOO_CCOO_NO0_X235)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y135, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x235, G_IF_SIGMA_CCOO_CCOO_NO1_X235)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y236, G_IF_SIGMA_CCOO_CCOO_Y236)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y136, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x236, G_IF_SIGMA_CCOO_CCOO_NO0_X236)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const Y136, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x236, G_IF_SIGMA_CCOO_CCOO_NO1_X236)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y237, G_IF_SIGMA_CCOO_CCOO_Y237)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y137, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x237, G_IF_SIGMA_CCOO_CCOO_NO0_X237)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const Y137, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x237, G_IF_SIGMA_CCOO_CCOO_NO1_X237)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x238, G_IF_SIGMA_CCOO_CCOO_NO0_X238)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x238, G_IF_SIGMA_CCOO_CCOO_NO1_X238)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x239, G_IF_SIGMA_CCOO_CCOO_NO0_X239)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x239, G_IF_SIGMA_CCOO_CCOO_NO1_X239)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y240, G_IF_SIGMA_CCOO_CCOO_Y240)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y138, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x240, G_IF_SIGMA_CCOO_CCOO_NO0_X240)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y138, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x240, G_IF_SIGMA_CCOO_CCOO_NO1_X240)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y241, G_IF_SIGMA_CCOO_CCOO_Y241)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y139, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x241, G_IF_SIGMA_CCOO_CCOO_NO0_X241)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y139, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x241, G_IF_SIGMA_CCOO_CCOO_NO1_X241)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x242, G_IF_SIGMA_CCOO_CCOO_NO0_X242)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x242, G_IF_SIGMA_CCOO_CCOO_NO1_X242)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x243, G_IF_SIGMA_CCOO_CCOO_NO0_X243)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x243, G_IF_SIGMA_CCOO_CCOO_NO1_X243)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x244, G_IF_SIGMA_CCOO_CCOO_NO0_X244)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x244, G_IF_SIGMA_CCOO_CCOO_NO1_X244)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x245, G_IF_SIGMA_CCOO_CCOO_NO0_X245)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x245, G_IF_SIGMA_CCOO_CCOO_NO1_X245)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y246, G_IF_SIGMA_CCOO_CCOO_Y246)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y140, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x246, G_IF_SIGMA_CCOO_CCOO_NO0_X246)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y140, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x246, G_IF_SIGMA_CCOO_CCOO_NO1_X246)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y247, G_IF_SIGMA_CCOO_CCOO_Y247)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y141, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x247, G_IF_SIGMA_CCOO_CCOO_NO0_X247)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y141, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x247, G_IF_SIGMA_CCOO_CCOO_NO1_X247)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x248, G_IF_SIGMA_CCOO_CCOO_NO0_X248)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x248, G_IF_SIGMA_CCOO_CCOO_NO1_X248)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x249, G_IF_SIGMA_CCOO_CCOO_NO0_X249)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x249, G_IF_SIGMA_CCOO_CCOO_NO1_X249)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x250, G_IF_SIGMA_CCOO_CCOO_NO0_X250)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x250, G_IF_SIGMA_CCOO_CCOO_NO1_X250)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x251, G_IF_SIGMA_CCOO_CCOO_NO0_X251)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x251, G_IF_SIGMA_CCOO_CCOO_NO1_X251)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x252, G_IF_SIGMA_CCOO_CCOO_NO0_X252)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x252, G_IF_SIGMA_CCOO_CCOO_NO1_X252)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x253, G_IF_SIGMA_CCOO_CCOO_NO0_X253)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x253, G_IF_SIGMA_CCOO_CCOO_NO1_X253)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x254, G_IF_SIGMA_CCOO_CCOO_NO0_X254)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x254, G_IF_SIGMA_CCOO_CCOO_NO1_X254)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x255, G_IF_SIGMA_CCOO_CCOO_NO0_X255)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x255, G_IF_SIGMA_CCOO_CCOO_NO1_X255)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y256, G_IF_SIGMA_CCOO_CCOO_Y256)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y142, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x256, G_IF_SIGMA_CCOO_CCOO_NO0_X256)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y142, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x256, G_IF_SIGMA_CCOO_CCOO_NO1_X256)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y257, G_IF_SIGMA_CCOO_CCOO_Y257)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y143, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x257, G_IF_SIGMA_CCOO_CCOO_NO0_X257)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y143, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x257, G_IF_SIGMA_CCOO_CCOO_NO1_X257)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y258, G_IF_SIGMA_CCOO_CCOO_Y258)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y144, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x258, G_IF_SIGMA_CCOO_CCOO_NO0_X258)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y144, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x258, G_IF_SIGMA_CCOO_CCOO_NO1_X258)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y259, G_IF_SIGMA_CCOO_CCOO_Y259)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y145, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x259, G_IF_SIGMA_CCOO_CCOO_NO0_X259)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y145, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x259, G_IF_SIGMA_CCOO_CCOO_NO1_X259)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x260, G_IF_SIGMA_CCOO_CCOO_NO0_X260)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x260, G_IF_SIGMA_CCOO_CCOO_NO1_X260)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x261, G_IF_SIGMA_CCOO_CCOO_NO0_X261)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x261, G_IF_SIGMA_CCOO_CCOO_NO1_X261)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y262, G_IF_SIGMA_CCOO_CCOO_Y262)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y146, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x262, G_IF_SIGMA_CCOO_CCOO_NO0_X262)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y146, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x262, G_IF_SIGMA_CCOO_CCOO_NO1_X262)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y263, G_IF_SIGMA_CCOO_CCOO_Y263)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y147, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x263, G_IF_SIGMA_CCOO_CCOO_NO0_X263)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y147, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x263, G_IF_SIGMA_CCOO_CCOO_NO1_X263)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x264, G_IF_SIGMA_CCOO_CCOO_NO0_X264)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x264, G_IF_SIGMA_CCOO_CCOO_NO1_X264)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x265, G_IF_SIGMA_CCOO_CCOO_NO0_X265)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x265, G_IF_SIGMA_CCOO_CCOO_NO1_X265)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x266, G_IF_SIGMA_CCOO_CCOO_NO0_X266)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x266, G_IF_SIGMA_CCOO_CCOO_NO1_X266)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x267, G_IF_SIGMA_CCOO_CCOO_NO0_X267)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x267, G_IF_SIGMA_CCOO_CCOO_NO1_X267)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y268, G_IF_SIGMA_CCOO_CCOO_Y268)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y148, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x268, G_IF_SIGMA_CCOO_CCOO_NO0_X268)
  (const double * const Y148, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x268, G_IF_SIGMA_CCOO_CCOO_NO1_X268)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y269, G_IF_SIGMA_CCOO_CCOO_Y269)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y149, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x269, G_IF_SIGMA_CCOO_CCOO_NO0_X269)
  (const double * const Y149, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x269, G_IF_SIGMA_CCOO_CCOO_NO1_X269)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x270, G_IF_SIGMA_CCOO_CCOO_NO0_X270)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x270, G_IF_SIGMA_CCOO_CCOO_NO1_X270)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x271, G_IF_SIGMA_CCOO_CCOO_NO0_X271)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x271, G_IF_SIGMA_CCOO_CCOO_NO1_X271)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x272, G_IF_SIGMA_CCOO_CCOO_NO0_X272)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x272, G_IF_SIGMA_CCOO_CCOO_NO1_X272)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x273, G_IF_SIGMA_CCOO_CCOO_NO0_X273)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x273, G_IF_SIGMA_CCOO_CCOO_NO1_X273)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x274, G_IF_SIGMA_CCOO_CCOO_NO0_X274)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x274, G_IF_SIGMA_CCOO_CCOO_NO1_X274)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x275, G_IF_SIGMA_CCOO_CCOO_NO0_X275)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x275, G_IF_SIGMA_CCOO_CCOO_NO1_X275)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x276, G_IF_SIGMA_CCOO_CCOO_NO0_X276)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x276, G_IF_SIGMA_CCOO_CCOO_NO1_X276)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x277, G_IF_SIGMA_CCOO_CCOO_NO0_X277)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x277, G_IF_SIGMA_CCOO_CCOO_NO1_X277)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y278, G_IF_SIGMA_CCOO_CCOO_Y278)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y150, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x278, G_IF_SIGMA_CCOO_CCOO_NO0_X278)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y150, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x278, G_IF_SIGMA_CCOO_CCOO_NO1_X278)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y279, G_IF_SIGMA_CCOO_CCOO_Y279)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y151, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x279, G_IF_SIGMA_CCOO_CCOO_NO0_X279)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const Y151, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x279, G_IF_SIGMA_CCOO_CCOO_NO1_X279)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y280, G_IF_SIGMA_CCOO_CCOO_Y280)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y152, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x280, G_IF_SIGMA_CCOO_CCOO_NO0_X280)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y152, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x280, G_IF_SIGMA_CCOO_CCOO_NO1_X280)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y281, G_IF_SIGMA_CCOO_CCOO_Y281)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y153, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x281, G_IF_SIGMA_CCOO_CCOO_NO0_X281)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y153, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x281, G_IF_SIGMA_CCOO_CCOO_NO1_X281)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y282, G_IF_SIGMA_CCOO_CCOO_Y282)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y154, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x282, G_IF_SIGMA_CCOO_CCOO_NO0_X282)
  (const double * const Y154, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x282, G_IF_SIGMA_CCOO_CCOO_NO1_X282)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x283, G_IF_SIGMA_CCOO_CCOO_NO0_X283)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x283, G_IF_SIGMA_CCOO_CCOO_NO1_X283)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x284, G_IF_SIGMA_CCOO_CCOO_NO0_X284)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x284, G_IF_SIGMA_CCOO_CCOO_NO1_X284)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x285, G_IF_SIGMA_CCOO_CCOO_NO0_X285)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x285, G_IF_SIGMA_CCOO_CCOO_NO1_X285)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x286, G_IF_SIGMA_CCOO_CCOO_NO0_X286)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x286, G_IF_SIGMA_CCOO_CCOO_NO1_X286)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x287, G_IF_SIGMA_CCOO_CCOO_NO0_X287)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x287, G_IF_SIGMA_CCOO_CCOO_NO1_X287)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x288, G_IF_SIGMA_CCOO_CCOO_NO0_X288)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x288, G_IF_SIGMA_CCOO_CCOO_NO1_X288)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x289, G_IF_SIGMA_CCOO_CCOO_NO0_X289)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x289, G_IF_SIGMA_CCOO_CCOO_NO1_X289)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x290, G_IF_SIGMA_CCOO_CCOO_NO0_X290)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x290, G_IF_SIGMA_CCOO_CCOO_NO1_X290)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y291, G_IF_SIGMA_CCOO_CCOO_Y291)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y155, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x291, G_IF_SIGMA_CCOO_CCOO_NO0_X291)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y155, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x291, G_IF_SIGMA_CCOO_CCOO_NO1_X291)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x292, G_IF_SIGMA_CCOO_CCOO_NO0_X292)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x292, G_IF_SIGMA_CCOO_CCOO_NO1_X292)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y293, G_IF_SIGMA_CCOO_CCOO_Y293)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y156, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x293, G_IF_SIGMA_CCOO_CCOO_NO0_X293)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y156, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x293, G_IF_SIGMA_CCOO_CCOO_NO1_X293)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y294, G_IF_SIGMA_CCOO_CCOO_Y294)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y157, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x294, G_IF_SIGMA_CCOO_CCOO_NO0_X294)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y157, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x294, G_IF_SIGMA_CCOO_CCOO_NO1_X294)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x295, G_IF_SIGMA_CCOO_CCOO_NO0_X295)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x295, G_IF_SIGMA_CCOO_CCOO_NO1_X295)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x296, G_IF_SIGMA_CCOO_CCOO_NO0_X296)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x296, G_IF_SIGMA_CCOO_CCOO_NO1_X296)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x297, G_IF_SIGMA_CCOO_CCOO_NO0_X297)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x297, G_IF_SIGMA_CCOO_CCOO_NO1_X297)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x298, G_IF_SIGMA_CCOO_CCOO_NO0_X298)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x298, G_IF_SIGMA_CCOO_CCOO_NO1_X298)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y299, G_IF_SIGMA_CCOO_CCOO_Y299)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y158, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x299, G_IF_SIGMA_CCOO_CCOO_NO0_X299)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y158, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x299, G_IF_SIGMA_CCOO_CCOO_NO1_X299)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y300, G_IF_SIGMA_CCOO_CCOO_Y300)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y159, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x300, G_IF_SIGMA_CCOO_CCOO_NO0_X300)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y159, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x300, G_IF_SIGMA_CCOO_CCOO_NO1_X300)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x301, G_IF_SIGMA_CCOO_CCOO_NO0_X301)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x301, G_IF_SIGMA_CCOO_CCOO_NO1_X301)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x302, G_IF_SIGMA_CCOO_CCOO_NO0_X302)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x302, G_IF_SIGMA_CCOO_CCOO_NO1_X302)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y303, G_IF_SIGMA_CCOO_CCOO_Y303)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y160, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x303, G_IF_SIGMA_CCOO_CCOO_NO0_X303)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y160, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x303, G_IF_SIGMA_CCOO_CCOO_NO1_X303)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x304, G_IF_SIGMA_CCOO_CCOO_NO0_X304)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x304, G_IF_SIGMA_CCOO_CCOO_NO1_X304)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x305, G_IF_SIGMA_CCOO_CCOO_NO0_X305)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x305, G_IF_SIGMA_CCOO_CCOO_NO1_X305)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x306, G_IF_SIGMA_CCOO_CCOO_NO0_X306)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x306, G_IF_SIGMA_CCOO_CCOO_NO1_X306)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y307, G_IF_SIGMA_CCOO_CCOO_Y307)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y161, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x307, G_IF_SIGMA_CCOO_CCOO_NO0_X307)
  (const double * const Y161, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x307, G_IF_SIGMA_CCOO_CCOO_NO1_X307)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x308, G_IF_SIGMA_CCOO_CCOO_NO0_X308)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x308, G_IF_SIGMA_CCOO_CCOO_NO1_X308)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x309, G_IF_SIGMA_CCOO_CCOO_NO0_X309)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x309, G_IF_SIGMA_CCOO_CCOO_NO1_X309)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x310, G_IF_SIGMA_CCOO_CCOO_NO0_X310)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x310, G_IF_SIGMA_CCOO_CCOO_NO1_X310)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x311, G_IF_SIGMA_CCOO_CCOO_NO0_X311)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x311, G_IF_SIGMA_CCOO_CCOO_NO1_X311)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x312, G_IF_SIGMA_CCOO_CCOO_NO0_X312)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x312, G_IF_SIGMA_CCOO_CCOO_NO1_X312)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x313, G_IF_SIGMA_CCOO_CCOO_NO0_X313)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x313, G_IF_SIGMA_CCOO_CCOO_NO1_X313)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x314, G_IF_SIGMA_CCOO_CCOO_NO0_X314)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x314, G_IF_SIGMA_CCOO_CCOO_NO1_X314)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x315, G_IF_SIGMA_CCOO_CCOO_NO0_X315)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x315, G_IF_SIGMA_CCOO_CCOO_NO1_X315)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y316, G_IF_SIGMA_CCOO_CCOO_Y316)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y162, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x316, G_IF_SIGMA_CCOO_CCOO_NO0_X316)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y162, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x316, G_IF_SIGMA_CCOO_CCOO_NO1_X316)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x317, G_IF_SIGMA_CCOO_CCOO_NO0_X317)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x317, G_IF_SIGMA_CCOO_CCOO_NO1_X317)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y318, G_IF_SIGMA_CCOO_CCOO_Y318)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y163, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x318, G_IF_SIGMA_CCOO_CCOO_NO0_X318)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y163, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x318, G_IF_SIGMA_CCOO_CCOO_NO1_X318)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y319, G_IF_SIGMA_CCOO_CCOO_Y319)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y164, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x319, G_IF_SIGMA_CCOO_CCOO_NO0_X319)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y164, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x319, G_IF_SIGMA_CCOO_CCOO_NO1_X319)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x320, G_IF_SIGMA_CCOO_CCOO_NO0_X320)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x320, G_IF_SIGMA_CCOO_CCOO_NO1_X320)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x321, G_IF_SIGMA_CCOO_CCOO_NO0_X321)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x321, G_IF_SIGMA_CCOO_CCOO_NO1_X321)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x322, G_IF_SIGMA_CCOO_CCOO_NO0_X322)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x322, G_IF_SIGMA_CCOO_CCOO_NO1_X322)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x323, G_IF_SIGMA_CCOO_CCOO_NO0_X323)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x323, G_IF_SIGMA_CCOO_CCOO_NO1_X323)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y324, G_IF_SIGMA_CCOO_CCOO_Y324)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y165, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x324, G_IF_SIGMA_CCOO_CCOO_NO0_X324)
  (const double * const Y165, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x324, G_IF_SIGMA_CCOO_CCOO_NO1_X324)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y325, G_IF_SIGMA_CCOO_CCOO_Y325)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y166, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x325, G_IF_SIGMA_CCOO_CCOO_NO0_X325)
  (const double * const Y166, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x325, G_IF_SIGMA_CCOO_CCOO_NO1_X325)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x326, G_IF_SIGMA_CCOO_CCOO_NO0_X326)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x326, G_IF_SIGMA_CCOO_CCOO_NO1_X326)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x327, G_IF_SIGMA_CCOO_CCOO_NO0_X327)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x327, G_IF_SIGMA_CCOO_CCOO_NO1_X327)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y328, G_IF_SIGMA_CCOO_CCOO_Y328)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y167, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x328, G_IF_SIGMA_CCOO_CCOO_NO0_X328)
  (const double * const Y167, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x328, G_IF_SIGMA_CCOO_CCOO_NO1_X328)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x329, G_IF_SIGMA_CCOO_CCOO_NO0_X329)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x329, G_IF_SIGMA_CCOO_CCOO_NO1_X329)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x330, G_IF_SIGMA_CCOO_CCOO_NO0_X330)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x330, G_IF_SIGMA_CCOO_CCOO_NO1_X330)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x331, G_IF_SIGMA_CCOO_CCOO_NO0_X331)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x331, G_IF_SIGMA_CCOO_CCOO_NO1_X331)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x332, G_IF_SIGMA_CCOO_CCOO_NO0_X332)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x332, G_IF_SIGMA_CCOO_CCOO_NO1_X332)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x333, G_IF_SIGMA_CCOO_CCOO_NO0_X333)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x333, G_IF_SIGMA_CCOO_CCOO_NO1_X333)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x334, G_IF_SIGMA_CCOO_CCOO_NO0_X334)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x334, G_IF_SIGMA_CCOO_CCOO_NO1_X334)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x335, G_IF_SIGMA_CCOO_CCOO_NO0_X335)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x335, G_IF_SIGMA_CCOO_CCOO_NO1_X335)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y336, G_IF_SIGMA_CCOO_CCOO_Y336)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y168, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x336, G_IF_SIGMA_CCOO_CCOO_NO0_X336)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y168, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x336, G_IF_SIGMA_CCOO_CCOO_NO1_X336)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y337, G_IF_SIGMA_CCOO_CCOO_Y337)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y169, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x337, G_IF_SIGMA_CCOO_CCOO_NO0_X337)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y169, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x337, G_IF_SIGMA_CCOO_CCOO_NO1_X337)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y338, G_IF_SIGMA_CCOO_CCOO_Y338)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y170, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x338, G_IF_SIGMA_CCOO_CCOO_NO0_X338)
  (const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const Y170, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x338, G_IF_SIGMA_CCOO_CCOO_NO1_X338)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y339, G_IF_SIGMA_CCOO_CCOO_Y339)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y171, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x339, G_IF_SIGMA_CCOO_CCOO_NO0_X339)
  (const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const Y171, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x339, G_IF_SIGMA_CCOO_CCOO_NO1_X339)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x340, G_IF_SIGMA_CCOO_CCOO_NO0_X340)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x340, G_IF_SIGMA_CCOO_CCOO_NO1_X340)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y341, G_IF_SIGMA_CCOO_CCOO_Y341)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y172, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x341, G_IF_SIGMA_CCOO_CCOO_NO0_X341)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y172, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x341, G_IF_SIGMA_CCOO_CCOO_NO1_X341)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y342, G_IF_SIGMA_CCOO_CCOO_Y342)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y173, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x342, G_IF_SIGMA_CCOO_CCOO_NO0_X342)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const Y173, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x342, G_IF_SIGMA_CCOO_CCOO_NO1_X342)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x343, G_IF_SIGMA_CCOO_CCOO_NO0_X343)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x343, G_IF_SIGMA_CCOO_CCOO_NO1_X343)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x344, G_IF_SIGMA_CCOO_CCOO_NO0_X344)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x344, G_IF_SIGMA_CCOO_CCOO_NO1_X344)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x345, G_IF_SIGMA_CCOO_CCOO_NO0_X345)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x345, G_IF_SIGMA_CCOO_CCOO_NO1_X345)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x346, G_IF_SIGMA_CCOO_CCOO_NO0_X346)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x346, G_IF_SIGMA_CCOO_CCOO_NO1_X346)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x347, G_IF_SIGMA_CCOO_CCOO_NO0_X347)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x347, G_IF_SIGMA_CCOO_CCOO_NO1_X347)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x348, G_IF_SIGMA_CCOO_CCOO_NO0_X348)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x348, G_IF_SIGMA_CCOO_CCOO_NO1_X348)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x349, G_IF_SIGMA_CCOO_CCOO_NO0_X349)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x349, G_IF_SIGMA_CCOO_CCOO_NO1_X349)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x350, G_IF_SIGMA_CCOO_CCOO_NO0_X350)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x350, G_IF_SIGMA_CCOO_CCOO_NO1_X350)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y351, G_IF_SIGMA_CCOO_CCOO_Y351)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y174, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x351, G_IF_SIGMA_CCOO_CCOO_NO0_X351)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y174, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x351, G_IF_SIGMA_CCOO_CCOO_NO1_X351)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y352, G_IF_SIGMA_CCOO_CCOO_Y352)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y175, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x352, G_IF_SIGMA_CCOO_CCOO_NO0_X352)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y175, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x352, G_IF_SIGMA_CCOO_CCOO_NO1_X352)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x353, G_IF_SIGMA_CCOO_CCOO_NO0_X353)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x353, G_IF_SIGMA_CCOO_CCOO_NO1_X353)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x354, G_IF_SIGMA_CCOO_CCOO_NO0_X354)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x354, G_IF_SIGMA_CCOO_CCOO_NO1_X354)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x355, G_IF_SIGMA_CCOO_CCOO_NO0_X355)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x355, G_IF_SIGMA_CCOO_CCOO_NO1_X355)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x356, G_IF_SIGMA_CCOO_CCOO_NO0_X356)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x356, G_IF_SIGMA_CCOO_CCOO_NO1_X356)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y357, G_IF_SIGMA_CCOO_CCOO_Y357)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y176, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x357, G_IF_SIGMA_CCOO_CCOO_NO0_X357)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y176, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x357, G_IF_SIGMA_CCOO_CCOO_NO1_X357)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y358, G_IF_SIGMA_CCOO_CCOO_Y358)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y177, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x358, G_IF_SIGMA_CCOO_CCOO_NO0_X358)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y177, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x358, G_IF_SIGMA_CCOO_CCOO_NO1_X358)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x359, G_IF_SIGMA_CCOO_CCOO_NO0_X359)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x359, G_IF_SIGMA_CCOO_CCOO_NO1_X359)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x360, G_IF_SIGMA_CCOO_CCOO_NO0_X360)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x360, G_IF_SIGMA_CCOO_CCOO_NO1_X360)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x361, G_IF_SIGMA_CCOO_CCOO_NO0_X361)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x361, G_IF_SIGMA_CCOO_CCOO_NO1_X361)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x362, G_IF_SIGMA_CCOO_CCOO_NO0_X362)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x362, G_IF_SIGMA_CCOO_CCOO_NO1_X362)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x363, G_IF_SIGMA_CCOO_CCOO_NO0_X363)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x363, G_IF_SIGMA_CCOO_CCOO_NO1_X363)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x364, G_IF_SIGMA_CCOO_CCOO_NO0_X364)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x364, G_IF_SIGMA_CCOO_CCOO_NO1_X364)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x365, G_IF_SIGMA_CCOO_CCOO_NO0_X365)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x365, G_IF_SIGMA_CCOO_CCOO_NO1_X365)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x366, G_IF_SIGMA_CCOO_CCOO_NO0_X366)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x366, G_IF_SIGMA_CCOO_CCOO_NO1_X366)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y367, G_IF_SIGMA_CCOO_CCOO_Y367)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y178, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x367, G_IF_SIGMA_CCOO_CCOO_NO0_X367)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y178, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x367, G_IF_SIGMA_CCOO_CCOO_NO1_X367)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y368, G_IF_SIGMA_CCOO_CCOO_Y368)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y179, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x368, G_IF_SIGMA_CCOO_CCOO_NO0_X368)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const Y179, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x368, G_IF_SIGMA_CCOO_CCOO_NO1_X368)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x369, G_IF_SIGMA_CCOO_CCOO_NO0_X369)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x369, G_IF_SIGMA_CCOO_CCOO_NO1_X369)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x370, G_IF_SIGMA_CCOO_CCOO_NO0_X370)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x370, G_IF_SIGMA_CCOO_CCOO_NO1_X370)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x371, G_IF_SIGMA_CCOO_CCOO_NO0_X371)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x371, G_IF_SIGMA_CCOO_CCOO_NO1_X371)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y372, G_IF_SIGMA_CCOO_CCOO_Y372)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y180, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x372, G_IF_SIGMA_CCOO_CCOO_NO0_X372)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y180, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x373, G_IF_SIGMA_CCOO_CCOO_NO0_X373)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x374, G_IF_SIGMA_CCOO_CCOO_NO0_X374)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x375, G_IF_SIGMA_CCOO_CCOO_NO0_X375)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x376, G_IF_SIGMA_CCOO_CCOO_NO0_X376)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x377, G_IF_SIGMA_CCOO_CCOO_NO0_X377)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x378, G_IF_SIGMA_CCOO_CCOO_NO0_X378)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y379, G_IF_SIGMA_CCOO_CCOO_Y379)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y181, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x379, G_IF_SIGMA_CCOO_CCOO_NO0_X379)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y181, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x380, G_IF_SIGMA_CCOO_CCOO_NO0_X380)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x381, G_IF_SIGMA_CCOO_CCOO_NO0_X381)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x382, G_IF_SIGMA_CCOO_CCOO_NO0_X382)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x383, G_IF_SIGMA_CCOO_CCOO_NO0_X383)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x384, G_IF_SIGMA_CCOO_CCOO_NO0_X384)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x385, G_IF_SIGMA_CCOO_CCOO_NO0_X385)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x386, G_IF_SIGMA_CCOO_CCOO_NO0_X386)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x386, G_IF_SIGMA_CCOO_CCOO_NO1_X386)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x387, G_IF_SIGMA_CCOO_CCOO_NO0_X387)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x387, G_IF_SIGMA_CCOO_CCOO_NO1_X387)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x388, G_IF_SIGMA_CCOO_CCOO_NO0_X388)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x388, G_IF_SIGMA_CCOO_CCOO_NO1_X388)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x389, G_IF_SIGMA_CCOO_CCOO_NO0_X389)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x389, G_IF_SIGMA_CCOO_CCOO_NO1_X389)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y390, G_IF_SIGMA_CCOO_CCOO_Y390)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y182, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x390, G_IF_SIGMA_CCOO_CCOO_NO0_X390)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y182, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x390, G_IF_SIGMA_CCOO_CCOO_NO1_X390)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y391, G_IF_SIGMA_CCOO_CCOO_Y391)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y183, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x391, G_IF_SIGMA_CCOO_CCOO_NO0_X391)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y183, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x391, G_IF_SIGMA_CCOO_CCOO_NO1_X391)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y392, G_IF_SIGMA_CCOO_CCOO_Y392)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y184, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x392, G_IF_SIGMA_CCOO_CCOO_NO0_X392)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y184, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x392, G_IF_SIGMA_CCOO_CCOO_NO1_X392)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y393, G_IF_SIGMA_CCOO_CCOO_Y393)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y185, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x393, G_IF_SIGMA_CCOO_CCOO_NO0_X393)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y185, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x393, G_IF_SIGMA_CCOO_CCOO_NO1_X393)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x394, G_IF_SIGMA_CCOO_CCOO_NO0_X394)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x394, G_IF_SIGMA_CCOO_CCOO_NO1_X394)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x395, G_IF_SIGMA_CCOO_CCOO_NO0_X395)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x395, G_IF_SIGMA_CCOO_CCOO_NO1_X395)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x396, G_IF_SIGMA_CCOO_CCOO_NO0_X396)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x396, G_IF_SIGMA_CCOO_CCOO_NO1_X396)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y397, G_IF_SIGMA_CCOO_CCOO_Y397)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y186, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x397, G_IF_SIGMA_CCOO_CCOO_NO0_X397)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y186, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x397, G_IF_SIGMA_CCOO_CCOO_NO1_X397)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y398, G_IF_SIGMA_CCOO_CCOO_Y398)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y187, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x398, G_IF_SIGMA_CCOO_CCOO_NO0_X398)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y187, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x398, G_IF_SIGMA_CCOO_CCOO_NO1_X398)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x399, G_IF_SIGMA_CCOO_CCOO_NO0_X399)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x399, G_IF_SIGMA_CCOO_CCOO_NO1_X399)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x400, G_IF_SIGMA_CCOO_CCOO_NO0_X400)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x400, G_IF_SIGMA_CCOO_CCOO_NO1_X400)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x401, G_IF_SIGMA_CCOO_CCOO_NO0_X401)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x401, G_IF_SIGMA_CCOO_CCOO_NO1_X401)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x402, G_IF_SIGMA_CCOO_CCOO_NO0_X402)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x402, G_IF_SIGMA_CCOO_CCOO_NO1_X402)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y403, G_IF_SIGMA_CCOO_CCOO_Y403)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y188, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x403, G_IF_SIGMA_CCOO_CCOO_NO0_X403)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y188, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x403, G_IF_SIGMA_CCOO_CCOO_NO1_X403)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y404, G_IF_SIGMA_CCOO_CCOO_Y404)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y189, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x404, G_IF_SIGMA_CCOO_CCOO_NO0_X404)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y189, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x404, G_IF_SIGMA_CCOO_CCOO_NO1_X404)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x405, G_IF_SIGMA_CCOO_CCOO_NO0_X405)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x405, G_IF_SIGMA_CCOO_CCOO_NO1_X405)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x406, G_IF_SIGMA_CCOO_CCOO_NO0_X406)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x406, G_IF_SIGMA_CCOO_CCOO_NO1_X406)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x407, G_IF_SIGMA_CCOO_CCOO_NO0_X407)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x407, G_IF_SIGMA_CCOO_CCOO_NO1_X407)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x408, G_IF_SIGMA_CCOO_CCOO_NO0_X408)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x408, G_IF_SIGMA_CCOO_CCOO_NO1_X408)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x409, G_IF_SIGMA_CCOO_CCOO_NO0_X409)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x409, G_IF_SIGMA_CCOO_CCOO_NO1_X409)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x410, G_IF_SIGMA_CCOO_CCOO_NO0_X410)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x410, G_IF_SIGMA_CCOO_CCOO_NO1_X410)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x411, G_IF_SIGMA_CCOO_CCOO_NO0_X411)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x411, G_IF_SIGMA_CCOO_CCOO_NO1_X411)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x412, G_IF_SIGMA_CCOO_CCOO_NO0_X412)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x412, G_IF_SIGMA_CCOO_CCOO_NO1_X412)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y413, G_IF_SIGMA_CCOO_CCOO_Y413)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y190, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x413, G_IF_SIGMA_CCOO_CCOO_NO0_X413)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y190, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x413, G_IF_SIGMA_CCOO_CCOO_NO1_X413)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y414, G_IF_SIGMA_CCOO_CCOO_Y414)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y191, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x414, G_IF_SIGMA_CCOO_CCOO_NO0_X414)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y191, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x414, G_IF_SIGMA_CCOO_CCOO_NO1_X414)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x415, G_IF_SIGMA_CCOO_CCOO_NO0_X415)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x415, G_IF_SIGMA_CCOO_CCOO_NO1_X415)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x416, G_IF_SIGMA_CCOO_CCOO_NO0_X416)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x416, G_IF_SIGMA_CCOO_CCOO_NO1_X416)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x417, G_IF_SIGMA_CCOO_CCOO_NO0_X417)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x417, G_IF_SIGMA_CCOO_CCOO_NO1_X417)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x418, G_IF_SIGMA_CCOO_CCOO_NO0_X418)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x418, G_IF_SIGMA_CCOO_CCOO_NO1_X418)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y419, G_IF_SIGMA_CCOO_CCOO_Y419)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y192, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x419, G_IF_SIGMA_CCOO_CCOO_NO0_X419)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y192, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x419, G_IF_SIGMA_CCOO_CCOO_NO1_X419)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y420, G_IF_SIGMA_CCOO_CCOO_Y420)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y193, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x420, G_IF_SIGMA_CCOO_CCOO_NO0_X420)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y193, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x420, G_IF_SIGMA_CCOO_CCOO_NO1_X420)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x421, G_IF_SIGMA_CCOO_CCOO_NO0_X421)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x421, G_IF_SIGMA_CCOO_CCOO_NO1_X421)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x422, G_IF_SIGMA_CCOO_CCOO_NO0_X422)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x422, G_IF_SIGMA_CCOO_CCOO_NO1_X422)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x423, G_IF_SIGMA_CCOO_CCOO_NO0_X423)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x423, G_IF_SIGMA_CCOO_CCOO_NO1_X423)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x424, G_IF_SIGMA_CCOO_CCOO_NO0_X424)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x424, G_IF_SIGMA_CCOO_CCOO_NO1_X424)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x425, G_IF_SIGMA_CCOO_CCOO_NO0_X425)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x425, G_IF_SIGMA_CCOO_CCOO_NO1_X425)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y426, G_IF_SIGMA_CCOO_CCOO_Y426)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y194, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x426, G_IF_SIGMA_CCOO_CCOO_NO0_X426)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y194, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x427, G_IF_SIGMA_CCOO_CCOO_NO0_X427)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x428, G_IF_SIGMA_CCOO_CCOO_NO0_X428)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x429, G_IF_SIGMA_CCOO_CCOO_NO0_X429)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x430, G_IF_SIGMA_CCOO_CCOO_NO0_X430)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x431, G_IF_SIGMA_CCOO_CCOO_NO0_X431)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x432, G_IF_SIGMA_CCOO_CCOO_NO0_X432)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y433, G_IF_SIGMA_CCOO_CCOO_Y433)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y195, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x433, G_IF_SIGMA_CCOO_CCOO_NO0_X433)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y195, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x434, G_IF_SIGMA_CCOO_CCOO_NO0_X434)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x435, G_IF_SIGMA_CCOO_CCOO_NO0_X435)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x436, G_IF_SIGMA_CCOO_CCOO_NO0_X436)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x437, G_IF_SIGMA_CCOO_CCOO_NO0_X437)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x438, G_IF_SIGMA_CCOO_CCOO_NO0_X438)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x439, G_IF_SIGMA_CCOO_CCOO_NO0_X439)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x440, G_IF_SIGMA_CCOO_CCOO_NO0_X440)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x440, G_IF_SIGMA_CCOO_CCOO_NO1_X440)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x441, G_IF_SIGMA_CCOO_CCOO_NO0_X441)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x441, G_IF_SIGMA_CCOO_CCOO_NO1_X441)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x442, G_IF_SIGMA_CCOO_CCOO_NO0_X442)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x442, G_IF_SIGMA_CCOO_CCOO_NO1_X442)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x443, G_IF_SIGMA_CCOO_CCOO_NO0_X443)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x443, G_IF_SIGMA_CCOO_CCOO_NO1_X443)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x444, G_IF_SIGMA_CCOO_CCOO_NO0_X444)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x444, G_IF_SIGMA_CCOO_CCOO_NO1_X444)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x445, G_IF_SIGMA_CCOO_CCOO_NO0_X445)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x445, G_IF_SIGMA_CCOO_CCOO_NO1_X445)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x446, G_IF_SIGMA_CCOO_CCOO_NO0_X446)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x446, G_IF_SIGMA_CCOO_CCOO_NO1_X446)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x447, G_IF_SIGMA_CCOO_CCOO_NO0_X447)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x447, G_IF_SIGMA_CCOO_CCOO_NO1_X447)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x448, G_IF_SIGMA_CCOO_CCOO_NO0_X448)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x448, G_IF_SIGMA_CCOO_CCOO_NO1_X448)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x449, G_IF_SIGMA_CCOO_CCOO_NO0_X449)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x449, G_IF_SIGMA_CCOO_CCOO_NO1_X449)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x450, G_IF_SIGMA_CCOO_CCOO_NO0_X450)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x450, G_IF_SIGMA_CCOO_CCOO_NO1_X450)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x451, G_IF_SIGMA_CCOO_CCOO_NO0_X451)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x451, G_IF_SIGMA_CCOO_CCOO_NO1_X451)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x452, G_IF_SIGMA_CCOO_CCOO_NO0_X452)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x452, G_IF_SIGMA_CCOO_CCOO_NO1_X452)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x453, G_IF_SIGMA_CCOO_CCOO_NO0_X453)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x453, G_IF_SIGMA_CCOO_CCOO_NO1_X453)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x454, G_IF_SIGMA_CCOO_CCOO_NO0_X454)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x454, G_IF_SIGMA_CCOO_CCOO_NO1_X454)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x455, G_IF_SIGMA_CCOO_CCOO_NO0_X455)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x455, G_IF_SIGMA_CCOO_CCOO_NO1_X455)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x456, G_IF_SIGMA_CCOO_CCOO_NO0_X456)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x456, G_IF_SIGMA_CCOO_CCOO_NO1_X456)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x457, G_IF_SIGMA_CCOO_CCOO_NO0_X457)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x457, G_IF_SIGMA_CCOO_CCOO_NO1_X457)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x458, G_IF_SIGMA_CCOO_CCOO_NO0_X458)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x458, G_IF_SIGMA_CCOO_CCOO_NO1_X458)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x459, G_IF_SIGMA_CCOO_CCOO_NO0_X459)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x459, G_IF_SIGMA_CCOO_CCOO_NO1_X459)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x460, G_IF_SIGMA_CCOO_CCOO_NO0_X460)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x460, G_IF_SIGMA_CCOO_CCOO_NO1_X460)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x461, G_IF_SIGMA_CCOO_CCOO_NO0_X461)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x461, G_IF_SIGMA_CCOO_CCOO_NO1_X461)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x462, G_IF_SIGMA_CCOO_CCOO_NO0_X462)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x462, G_IF_SIGMA_CCOO_CCOO_NO1_X462)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x463, G_IF_SIGMA_CCOO_CCOO_NO0_X463)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x463, G_IF_SIGMA_CCOO_CCOO_NO1_X463)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y464, G_IF_SIGMA_CCOO_CCOO_Y464)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y196, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x464, G_IF_SIGMA_CCOO_CCOO_NO0_X464)
  (const double * const Y196, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x464, G_IF_SIGMA_CCOO_CCOO_NO1_X464)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x465, G_IF_SIGMA_CCOO_CCOO_NO0_X465)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x465, G_IF_SIGMA_CCOO_CCOO_NO1_X465)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x466, G_IF_SIGMA_CCOO_CCOO_NO0_X466)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x466, G_IF_SIGMA_CCOO_CCOO_NO1_X466)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y467, G_IF_SIGMA_CCOO_CCOO_Y467)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y197, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x467, G_IF_SIGMA_CCOO_CCOO_NO0_X467)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const Y197, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x467, G_IF_SIGMA_CCOO_CCOO_NO1_X467)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x468, G_IF_SIGMA_CCOO_CCOO_NO0_X468)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x468, G_IF_SIGMA_CCOO_CCOO_NO1_X468)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x469, G_IF_SIGMA_CCOO_CCOO_NO0_X469)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x469, G_IF_SIGMA_CCOO_CCOO_NO1_X469)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x470, G_IF_SIGMA_CCOO_CCOO_NO0_X470)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x470, G_IF_SIGMA_CCOO_CCOO_NO1_X470)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y471, G_IF_SIGMA_CCOO_CCOO_Y471)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y198, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x471, G_IF_SIGMA_CCOO_CCOO_NO0_X471)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const Y198, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x471, G_IF_SIGMA_CCOO_CCOO_NO1_X471)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x472, G_IF_SIGMA_CCOO_CCOO_NO0_X472)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x472, G_IF_SIGMA_CCOO_CCOO_NO1_X472)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y473, G_IF_SIGMA_CCOO_CCOO_Y473)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y199, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x473, G_IF_SIGMA_CCOO_CCOO_NO0_X473)
  (const double * const Y199, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x473, G_IF_SIGMA_CCOO_CCOO_NO1_X473)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x474, G_IF_SIGMA_CCOO_CCOO_NO0_X474)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x474, G_IF_SIGMA_CCOO_CCOO_NO1_X474)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x475, G_IF_SIGMA_CCOO_CCOO_NO0_X475)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x475, G_IF_SIGMA_CCOO_CCOO_NO1_X475)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y476, G_IF_SIGMA_CCOO_CCOO_Y476)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y200, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x476, G_IF_SIGMA_CCOO_CCOO_NO0_X476)
  (const FC_INT &so2, const FC_INT &io2, 
   const double * const Y200, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x476, G_IF_SIGMA_CCOO_CCOO_NO1_X476)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x477, G_IF_SIGMA_CCOO_CCOO_NO0_X477)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x477, G_IF_SIGMA_CCOO_CCOO_NO1_X477)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x478, G_IF_SIGMA_CCOO_CCOO_NO0_X478)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x478, G_IF_SIGMA_CCOO_CCOO_NO1_X478)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x479, G_IF_SIGMA_CCOO_CCOO_NO0_X479)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x479, G_IF_SIGMA_CCOO_CCOO_NO1_X479)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y480, G_IF_SIGMA_CCOO_CCOO_Y480)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y201, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x480, G_IF_SIGMA_CCOO_CCOO_NO0_X480)
  (const double * const Y201, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x480, G_IF_SIGMA_CCOO_CCOO_NO1_X480)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x481, G_IF_SIGMA_CCOO_CCOO_NO0_X481)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x481, G_IF_SIGMA_CCOO_CCOO_NO1_X481)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x482, G_IF_SIGMA_CCOO_CCOO_NO0_X482)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x482, G_IF_SIGMA_CCOO_CCOO_NO1_X482)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x483, G_IF_SIGMA_CCOO_CCOO_NO0_X483)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x483, G_IF_SIGMA_CCOO_CCOO_NO1_X483)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x484, G_IF_SIGMA_CCOO_CCOO_NO0_X484)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x484, G_IF_SIGMA_CCOO_CCOO_NO1_X484)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x485, G_IF_SIGMA_CCOO_CCOO_NO0_X485)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x485, G_IF_SIGMA_CCOO_CCOO_NO1_X485)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x486, G_IF_SIGMA_CCOO_CCOO_NO0_X486)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x486, G_IF_SIGMA_CCOO_CCOO_NO1_X486)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x487, G_IF_SIGMA_CCOO_CCOO_NO0_X487)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &si, const FC_INT &ii, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x487, G_IF_SIGMA_CCOO_CCOO_NO1_X487)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x488, G_IF_SIGMA_CCOO_CCOO_NO0_X488)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x488, G_IF_SIGMA_CCOO_CCOO_NO1_X488)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x489, G_IF_SIGMA_CCOO_CCOO_NO0_X489)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x489, G_IF_SIGMA_CCOO_CCOO_NO1_X489)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x490, G_IF_SIGMA_CCOO_CCOO_NO0_X490)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x490, G_IF_SIGMA_CCOO_CCOO_NO1_X490)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x491, G_IF_SIGMA_CCOO_CCOO_NO0_X491)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x491, G_IF_SIGMA_CCOO_CCOO_NO1_X491)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x492, G_IF_SIGMA_CCOO_CCOO_NO0_X492)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x492, G_IF_SIGMA_CCOO_CCOO_NO1_X492)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x493, G_IF_SIGMA_CCOO_CCOO_NO0_X493)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x493, G_IF_SIGMA_CCOO_CCOO_NO1_X493)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x494, G_IF_SIGMA_CCOO_CCOO_NO0_X494)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x495, G_IF_SIGMA_CCOO_CCOO_NO0_X495)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y496, G_IF_SIGMA_CCOO_CCOO_Y496)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y202, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x496, G_IF_SIGMA_CCOO_CCOO_NO0_X496)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y202, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x497, G_IF_SIGMA_CCOO_CCOO_NO0_X497)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x498, G_IF_SIGMA_CCOO_CCOO_NO0_X498)
  (const FC_INT &sc1, const FC_INT &ic1, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y499, G_IF_SIGMA_CCOO_CCOO_Y499)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y203, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x499, G_IF_SIGMA_CCOO_CCOO_NO0_X499)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const Y203, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x500, G_IF_SIGMA_CCOO_CCOO_NO0_X500)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x500, G_IF_SIGMA_CCOO_CCOO_NO1_X500)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x501, G_IF_SIGMA_CCOO_CCOO_NO0_X501)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x501, G_IF_SIGMA_CCOO_CCOO_NO1_X501)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x502, G_IF_SIGMA_CCOO_CCOO_NO0_X502)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x502, G_IF_SIGMA_CCOO_CCOO_NO1_X502)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x503, G_IF_SIGMA_CCOO_CCOO_NO0_X503)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x503, G_IF_SIGMA_CCOO_CCOO_NO1_X503)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x504, G_IF_SIGMA_CCOO_CCOO_NO0_X504)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x504, G_IF_SIGMA_CCOO_CCOO_NO1_X504)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x505, G_IF_SIGMA_CCOO_CCOO_NO0_X505)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x505, G_IF_SIGMA_CCOO_CCOO_NO1_X505)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x506, G_IF_SIGMA_CCOO_CCOO_NO0_X506)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x506, G_IF_SIGMA_CCOO_CCOO_NO1_X506)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x507, G_IF_SIGMA_CCOO_CCOO_NO0_X507)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x507, G_IF_SIGMA_CCOO_CCOO_NO1_X507)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x508, G_IF_SIGMA_CCOO_CCOO_NO0_X508)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x508, G_IF_SIGMA_CCOO_CCOO_NO1_X508)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x509, G_IF_SIGMA_CCOO_CCOO_NO0_X509)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x509, G_IF_SIGMA_CCOO_CCOO_NO1_X509)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x510, G_IF_SIGMA_CCOO_CCOO_NO0_X510)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x510, G_IF_SIGMA_CCOO_CCOO_NO1_X510)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x511, G_IF_SIGMA_CCOO_CCOO_NO0_X511)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x511, G_IF_SIGMA_CCOO_CCOO_NO1_X511)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x512, G_IF_SIGMA_CCOO_CCOO_NO0_X512)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y513, G_IF_SIGMA_CCOO_CCOO_Y513)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y204, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x513, G_IF_SIGMA_CCOO_CCOO_NO0_X513)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y204, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x514, G_IF_SIGMA_CCOO_CCOO_NO0_X514)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x515, G_IF_SIGMA_CCOO_CCOO_NO0_X515)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_y516, G_IF_SIGMA_CCOO_CCOO_Y516)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y205, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x516, G_IF_SIGMA_CCOO_CCOO_NO0_X516)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const Y205, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x517, G_IF_SIGMA_CCOO_CCOO_NO0_X517)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x518, G_IF_SIGMA_CCOO_CCOO_NO0_X518)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, const FC_INT &so5, const FC_INT &io5, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x518, G_IF_SIGMA_CCOO_CCOO_NO1_X518)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x519, G_IF_SIGMA_CCOO_CCOO_NO0_X519)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, const FC_INT &so5, const FC_INT &io5, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x519, G_IF_SIGMA_CCOO_CCOO_NO1_X519)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x520, G_IF_SIGMA_CCOO_CCOO_NO0_X520)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x520, G_IF_SIGMA_CCOO_CCOO_NO1_X520)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x521, G_IF_SIGMA_CCOO_CCOO_NO0_X521)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x521, G_IF_SIGMA_CCOO_CCOO_NO1_X521)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x522, G_IF_SIGMA_CCOO_CCOO_NO0_X522)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x522, G_IF_SIGMA_CCOO_CCOO_NO1_X522)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x523, G_IF_SIGMA_CCOO_CCOO_NO0_X523)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x523, G_IF_SIGMA_CCOO_CCOO_NO1_X523)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x524, G_IF_SIGMA_CCOO_CCOO_NO0_X524)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x524, G_IF_SIGMA_CCOO_CCOO_NO1_X524)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x525, G_IF_SIGMA_CCOO_CCOO_NO0_X525)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x525, G_IF_SIGMA_CCOO_CCOO_NO1_X525)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x526, G_IF_SIGMA_CCOO_CCOO_NO0_X526)
  (const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x526, G_IF_SIGMA_CCOO_CCOO_NO1_X526)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x527, G_IF_SIGMA_CCOO_CCOO_NO0_X527)
  (const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x527, G_IF_SIGMA_CCOO_CCOO_NO1_X527)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x528, G_IF_SIGMA_CCOO_CCOO_NO0_X528)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x528, G_IF_SIGMA_CCOO_CCOO_NO1_X528)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x529, G_IF_SIGMA_CCOO_CCOO_NO0_X529)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x529, G_IF_SIGMA_CCOO_CCOO_NO1_X529)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x530, G_IF_SIGMA_CCOO_CCOO_NO0_X530)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x530, G_IF_SIGMA_CCOO_CCOO_NO1_X530)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x531, G_IF_SIGMA_CCOO_CCOO_NO0_X531)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x531, G_IF_SIGMA_CCOO_CCOO_NO1_X531)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x532, G_IF_SIGMA_CCOO_CCOO_NO0_X532)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x532, G_IF_SIGMA_CCOO_CCOO_NO1_X532)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x533, G_IF_SIGMA_CCOO_CCOO_NO0_X533)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x533, G_IF_SIGMA_CCOO_CCOO_NO1_X533)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x534, G_IF_SIGMA_CCOO_CCOO_NO0_X534)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x534, G_IF_SIGMA_CCOO_CCOO_NO1_X534)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x535, G_IF_SIGMA_CCOO_CCOO_NO0_X535)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x535, G_IF_SIGMA_CCOO_CCOO_NO1_X535)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x536, G_IF_SIGMA_CCOO_CCOO_NO0_X536)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x536, G_IF_SIGMA_CCOO_CCOO_NO1_X536)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x537, G_IF_SIGMA_CCOO_CCOO_NO0_X537)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x537, G_IF_SIGMA_CCOO_CCOO_NO1_X537)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x538, G_IF_SIGMA_CCOO_CCOO_NO0_X538)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so4, const FC_INT &io4, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x538, G_IF_SIGMA_CCOO_CCOO_NO1_X538)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x539, G_IF_SIGMA_CCOO_CCOO_NO0_X539)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so4, const FC_INT &io4, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x539, G_IF_SIGMA_CCOO_CCOO_NO1_X539)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x540, G_IF_SIGMA_CCOO_CCOO_NO0_X540)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x540, G_IF_SIGMA_CCOO_CCOO_NO1_X540)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x541, G_IF_SIGMA_CCOO_CCOO_NO0_X541)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x541, G_IF_SIGMA_CCOO_CCOO_NO1_X541)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const X, 
   const double * const T2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x542, G_IF_SIGMA_CCOO_CCOO_NO0_X542)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x542, G_IF_SIGMA_CCOO_CCOO_NO1_X542)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x543, G_IF_SIGMA_CCOO_CCOO_NO0_X543)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x543, G_IF_SIGMA_CCOO_CCOO_NO1_X543)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x544, G_IF_SIGMA_CCOO_CCOO_NO0_X544)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x544, G_IF_SIGMA_CCOO_CCOO_NO1_X544)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x545, G_IF_SIGMA_CCOO_CCOO_NO0_X545)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x545, G_IF_SIGMA_CCOO_CCOO_NO1_X545)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x546, G_IF_SIGMA_CCOO_CCOO_NO0_X546)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x546, G_IF_SIGMA_CCOO_CCOO_NO1_X546)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x547, G_IF_SIGMA_CCOO_CCOO_NO0_X547)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so4, const FC_INT &io4, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x547, G_IF_SIGMA_CCOO_CCOO_NO1_X547)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x548, G_IF_SIGMA_CCOO_CCOO_NO0_X548)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x548, G_IF_SIGMA_CCOO_CCOO_NO1_X548)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x549, G_IF_SIGMA_CCOO_CCOO_NO0_X549)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x549, G_IF_SIGMA_CCOO_CCOO_NO1_X549)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x550, G_IF_SIGMA_CCOO_CCOO_NO0_X550)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x550, G_IF_SIGMA_CCOO_CCOO_NO1_X550)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x551, G_IF_SIGMA_CCOO_CCOO_NO0_X551)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x551, G_IF_SIGMA_CCOO_CCOO_NO1_X551)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x552, G_IF_SIGMA_CCOO_CCOO_NO0_X552)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x552, G_IF_SIGMA_CCOO_CCOO_NO1_X552)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x553, G_IF_SIGMA_CCOO_CCOO_NO0_X553)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x553, G_IF_SIGMA_CCOO_CCOO_NO1_X553)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x554, G_IF_SIGMA_CCOO_CCOO_NO0_X554)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x554, G_IF_SIGMA_CCOO_CCOO_NO1_X554)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x555, G_IF_SIGMA_CCOO_CCOO_NO0_X555)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x555, G_IF_SIGMA_CCOO_CCOO_NO1_X555)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x556, G_IF_SIGMA_CCOO_CCOO_NO0_X556)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x556, G_IF_SIGMA_CCOO_CCOO_NO1_X556)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x557, G_IF_SIGMA_CCOO_CCOO_NO0_X557)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x557, G_IF_SIGMA_CCOO_CCOO_NO1_X557)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x558, G_IF_SIGMA_CCOO_CCOO_NO0_X558)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x558, G_IF_SIGMA_CCOO_CCOO_NO1_X558)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x559, G_IF_SIGMA_CCOO_CCOO_NO0_X559)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x559, G_IF_SIGMA_CCOO_CCOO_NO1_X559)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x560, G_IF_SIGMA_CCOO_CCOO_NO0_X560)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x560, G_IF_SIGMA_CCOO_CCOO_NO1_X560)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x561, G_IF_SIGMA_CCOO_CCOO_NO0_X561)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x561, G_IF_SIGMA_CCOO_CCOO_NO1_X561)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x562, G_IF_SIGMA_CCOO_CCOO_NO0_X562)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x562, G_IF_SIGMA_CCOO_CCOO_NO1_X562)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x563, G_IF_SIGMA_CCOO_CCOO_NO0_X563)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x563, G_IF_SIGMA_CCOO_CCOO_NO1_X563)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x564, G_IF_SIGMA_CCOO_CCOO_NO0_X564)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x564, G_IF_SIGMA_CCOO_CCOO_NO1_X564)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x565, G_IF_SIGMA_CCOO_CCOO_NO0_X565)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x565, G_IF_SIGMA_CCOO_CCOO_NO1_X565)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x566, G_IF_SIGMA_CCOO_CCOO_NO0_X566)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x566, G_IF_SIGMA_CCOO_CCOO_NO1_X566)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x567, G_IF_SIGMA_CCOO_CCOO_NO0_X567)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x567, G_IF_SIGMA_CCOO_CCOO_NO1_X567)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x568, G_IF_SIGMA_CCOO_CCOO_NO0_X568)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x568, G_IF_SIGMA_CCOO_CCOO_NO1_X568)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x569, G_IF_SIGMA_CCOO_CCOO_NO0_X569)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x569, G_IF_SIGMA_CCOO_CCOO_NO1_X569)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x570, G_IF_SIGMA_CCOO_CCOO_NO0_X570)
  (const FC_INT &si, const FC_INT &ii, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x570, G_IF_SIGMA_CCOO_CCOO_NO1_X570)
  (const FC_INT &si, const FC_INT &ii, const FC_INT &sk, const FC_INT &ik, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x571, G_IF_SIGMA_CCOO_CCOO_NO0_X571)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x571, G_IF_SIGMA_CCOO_CCOO_NO1_X571)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x572, G_IF_SIGMA_CCOO_CCOO_NO0_X572)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x572, G_IF_SIGMA_CCOO_CCOO_NO1_X572)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x573, G_IF_SIGMA_CCOO_CCOO_NO0_X573)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so5, const FC_INT &io5, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x573, G_IF_SIGMA_CCOO_CCOO_NO1_X573)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so5, const FC_INT &io5, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x574, G_IF_SIGMA_CCOO_CCOO_NO0_X574)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x574, G_IF_SIGMA_CCOO_CCOO_NO1_X574)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x575, G_IF_SIGMA_CCOO_CCOO_NO0_X575)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x575, G_IF_SIGMA_CCOO_CCOO_NO1_X575)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x576, G_IF_SIGMA_CCOO_CCOO_NO0_X576)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x576, G_IF_SIGMA_CCOO_CCOO_NO1_X576)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x577, G_IF_SIGMA_CCOO_CCOO_NO0_X577)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x577, G_IF_SIGMA_CCOO_CCOO_NO1_X577)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x578, G_IF_SIGMA_CCOO_CCOO_NO0_X578)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x578, G_IF_SIGMA_CCOO_CCOO_NO1_X578)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x579, G_IF_SIGMA_CCOO_CCOO_NO0_X579)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x579, G_IF_SIGMA_CCOO_CCOO_NO1_X579)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x580, G_IF_SIGMA_CCOO_CCOO_NO0_X580)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x580, G_IF_SIGMA_CCOO_CCOO_NO1_X580)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x581, G_IF_SIGMA_CCOO_CCOO_NO0_X581)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x581, G_IF_SIGMA_CCOO_CCOO_NO1_X581)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x582, G_IF_SIGMA_CCOO_CCOO_NO0_X582)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x582, G_IF_SIGMA_CCOO_CCOO_NO1_X582)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x583, G_IF_SIGMA_CCOO_CCOO_NO0_X583)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x583, G_IF_SIGMA_CCOO_CCOO_NO1_X583)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x584, G_IF_SIGMA_CCOO_CCOO_NO0_X584)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x584, G_IF_SIGMA_CCOO_CCOO_NO1_X584)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x585, G_IF_SIGMA_CCOO_CCOO_NO0_X585)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x585, G_IF_SIGMA_CCOO_CCOO_NO1_X585)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x586, G_IF_SIGMA_CCOO_CCOO_NO0_X586)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x586, G_IF_SIGMA_CCOO_CCOO_NO1_X586)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x587, G_IF_SIGMA_CCOO_CCOO_NO0_X587)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x587, G_IF_SIGMA_CCOO_CCOO_NO1_X587)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x588, G_IF_SIGMA_CCOO_CCOO_NO0_X588)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x588, G_IF_SIGMA_CCOO_CCOO_NO1_X588)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x589, G_IF_SIGMA_CCOO_CCOO_NO0_X589)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x589, G_IF_SIGMA_CCOO_CCOO_NO1_X589)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x590, G_IF_SIGMA_CCOO_CCOO_NO0_X590)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x590, G_IF_SIGMA_CCOO_CCOO_NO1_X590)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x591, G_IF_SIGMA_CCOO_CCOO_NO0_X591)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x591, G_IF_SIGMA_CCOO_CCOO_NO1_X591)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x592, G_IF_SIGMA_CCOO_CCOO_NO0_X592)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x592, G_IF_SIGMA_CCOO_CCOO_NO1_X592)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x593, G_IF_SIGMA_CCOO_CCOO_NO0_X593)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x593, G_IF_SIGMA_CCOO_CCOO_NO1_X593)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x594, G_IF_SIGMA_CCOO_CCOO_NO0_X594)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x594, G_IF_SIGMA_CCOO_CCOO_NO1_X594)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x595, G_IF_SIGMA_CCOO_CCOO_NO0_X595)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x595, G_IF_SIGMA_CCOO_CCOO_NO1_X595)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x596, G_IF_SIGMA_CCOO_CCOO_NO0_X596)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x596, G_IF_SIGMA_CCOO_CCOO_NO1_X596)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x597, G_IF_SIGMA_CCOO_CCOO_NO0_X597)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x597, G_IF_SIGMA_CCOO_CCOO_NO1_X597)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x598, G_IF_SIGMA_CCOO_CCOO_NO0_X598)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x598, G_IF_SIGMA_CCOO_CCOO_NO1_X598)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x599, G_IF_SIGMA_CCOO_CCOO_NO0_X599)
  (const FC_INT &so4, const FC_INT &io4, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x599, G_IF_SIGMA_CCOO_CCOO_NO1_X599)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x600, G_IF_SIGMA_CCOO_CCOO_NO0_X600)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x600, G_IF_SIGMA_CCOO_CCOO_NO1_X600)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x601, G_IF_SIGMA_CCOO_CCOO_NO0_X601)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x601, G_IF_SIGMA_CCOO_CCOO_NO1_X601)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x602, G_IF_SIGMA_CCOO_CCOO_NO0_X602)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x602, G_IF_SIGMA_CCOO_CCOO_NO1_X602)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x603, G_IF_SIGMA_CCOO_CCOO_NO0_X603)
  (const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x603, G_IF_SIGMA_CCOO_CCOO_NO1_X603)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x604, G_IF_SIGMA_CCOO_CCOO_NO0_X604)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x604, G_IF_SIGMA_CCOO_CCOO_NO1_X604)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x605, G_IF_SIGMA_CCOO_CCOO_NO0_X605)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x605, G_IF_SIGMA_CCOO_CCOO_NO1_X605)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x606, G_IF_SIGMA_CCOO_CCOO_NO0_X606)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x606, G_IF_SIGMA_CCOO_CCOO_NO1_X606)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x607, G_IF_SIGMA_CCOO_CCOO_NO0_X607)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so3, const FC_INT &io3, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no1_x607, G_IF_SIGMA_CCOO_CCOO_NO1_X607)
  (const FC_INT &sk, const FC_INT &ik, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x608, G_IF_SIGMA_CCOO_CCOO_NO0_X608)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x609, G_IF_SIGMA_CCOO_CCOO_NO0_X609)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x610, G_IF_SIGMA_CCOO_CCOO_NO0_X610)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so1, const FC_INT &io1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccoo_ccoo_no0_x611, G_IF_SIGMA_CCOO_CCOO_NO0_X611)
  (const FC_INT &sk, const FC_INT &ik, const FC_INT &so2, const FC_INT &io2, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

      
 }     
       
       
 #endif
       
       
 