                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_ccoo_cooo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//   .----------------.  .----------------.  .----------------.  .----------------.  .----------------.       
//  | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |      
//  | |  _________   | || |  _________   | || | ____    ____ | || |  _________   | || |     ____     | |      
//  | | |_   ___  |  | || | |_   ___  |  | || ||_   \  /   _|| || | |  _   _  |  | || |   .'    `.   | |     
//  | |   | |_  \_|  | || |   | |_  \_|  | || |  |   \/   |  | || | |_/ | | \_|  | || |  /  .--.  \  | | 
//  | |   |  _|      | || |   |  _|  _   | || |  | |\  /| |  | || |     | |      | || |  | |    | |  | |     
//  | |  _| |_       | || |  _| |___/ |  | || | _| |_\/_| |_ | || |    _| |_     | || |  \  `--'  /  | |    
//  | | |_____|      | || | |_________|  | || ||_____||_____|| || |   |_____|    | || |   `.____.'   | |      
//  | |              | || |              | || |              | || |              | || |              | |      
//  | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |      
//   '----------------'  '----------------'  '----------------'  '----------------'  '----------------'       

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_ccoo_cooo(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::DTensor &rdm4,                                                 
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                        


  {
  // No.0
  //* X(w,i,k,o2,o4,o1)  <--  (    1.00000000)  D3(i,o3,k,o2,o4,o1) h(w,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o2,o1) X(w,i,k,o2,o4,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x0, G_IF_SIGMA_CCOO_COOO_NO0_X0)
        (sk, ik, so1, io1, moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x0, G_IF_SIGMA_CCOO_COOO_NO1_X0)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.1
  //* X(y,i,o2,k,o1,o4)  <--  (    1.00000000)  D3(i,o2,k,o3,o1,o4) h(y,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o1,o2,o4) X(y,i,o2,k,o1,o4) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^so4, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x1, G_IF_SIGMA_CCOO_COOO_NO0_X1)
        (sk, ik, so4, io4, moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x1, G_IF_SIGMA_CCOO_COOO_NO1_X1)
        (sk, ik, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.2
  //* X(w,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) h(w,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o3,i,o1) X(w,k,o3,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x2, G_IF_SIGMA_CCOO_COOO_NO0_X2)
        (sk, ik, so1, io1, moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x2, G_IF_SIGMA_CCOO_COOO_NO1_X2)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.3
  //* X(y,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) h(y,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o3,i,o1) X(y,k,o3,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x3, G_IF_SIGMA_CCOO_COOO_NO0_X3)
        (sk, ik, so1, io1, moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x3, G_IF_SIGMA_CCOO_COOO_NO1_X3)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.4
  //* X(y,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y0(y,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(w,o3,i,o1) X(y,k,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y0 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y4, G_IF_SIGMA_CCOO_COOO_Y4)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x4, G_IF_SIGMA_CCOO_COOO_NO0_X4)
        (sk, ik, so1, io1, Y0.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x4, G_IF_SIGMA_CCOO_COOO_NO1_X4)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.5
  //* X(y,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y1(y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,o3,i,o1) X(y,k,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y1 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y5, G_IF_SIGMA_CCOO_COOO_Y5)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x5, G_IF_SIGMA_CCOO_COOO_NO0_X5)
        (sk, ik, so1, io1, Y1.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x5, G_IF_SIGMA_CCOO_COOO_NO1_X5)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.6
  //* X(y,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) h(y,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o3,o1,i) X(y,k,o3,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x6, G_IF_SIGMA_CCOO_COOO_NO0_X6)
      (sk, ik, moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x6, G_IF_SIGMA_CCOO_COOO_NO1_X6)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.7
  //* X(w,k,o2,o3)  <--  (    1.00000000)  D2(k,o2,o3,o1) h(w,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o3,o2,i) X(w,k,o2,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x7, G_IF_SIGMA_CCOO_COOO_NO0_X7)
      (sk, ik, moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x7, G_IF_SIGMA_CCOO_COOO_NO1_X7)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.8
  //* X(y,k)  <--  (    1.00000000)  D2(k,o2,o3,o1) T2(y,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) X(y,k) h(w,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x8, G_IF_SIGMA_CCOO_COOO_NO0_X8)
        (sk, ik, so1, io1, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x8, G_IF_SIGMA_CCOO_COOO_NO1_X8)
      (sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.9
  //* X(y,k)  <--  (    1.00000000)  D2(k,o2,o3,o1) T2(y,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(y,k) Y2(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y2 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y9, G_IF_SIGMA_CCOO_COOO_Y9)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x9, G_IF_SIGMA_CCOO_COOO_NO0_X9)
        (sk, ik, so1, io1, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x9, G_IF_SIGMA_CCOO_COOO_NO1_X9)
      (sk, ik, Xc.cptr(), Y2.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.10
  //* X(y,k)  <--  (    1.00000000)  D2(k,o2,o3,o1) T2(y,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(y,k) Y3(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y3 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y10, G_IF_SIGMA_CCOO_COOO_Y10)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x10, G_IF_SIGMA_CCOO_COOO_NO0_X10)
        (sk, ik, so1, io1, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x10, G_IF_SIGMA_CCOO_COOO_NO1_X10)
      (sk, ik, Xc.cptr(), Y3.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.11
  //* X(w,k)  <--  (    1.00000000)  D2(k,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) X(w,k) h(y,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x11, G_IF_SIGMA_CCOO_COOO_NO0_X11)
        (sk, ik, so1, io1, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x11, G_IF_SIGMA_CCOO_COOO_NO1_X11)
      (sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.12
  //* X(y,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(y,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o3,k,o1) X(y,i,o3,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x12, G_IF_SIGMA_CCOO_COOO_NO0_X12)
      (so1, io1, moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x12, G_IF_SIGMA_CCOO_COOO_NO1_X12)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.13
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(w,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o3,k,o1) X(w,i,o3,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x13, G_IF_SIGMA_CCOO_COOO_NO0_X13)
      (so1, io1, moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x13, G_IF_SIGMA_CCOO_COOO_NO1_X13)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.14
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y4(w,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(y,o3,k,o1) X(w,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y4 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y14, G_IF_SIGMA_CCOO_COOO_Y14)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x14, G_IF_SIGMA_CCOO_COOO_NO0_X14)
      (so1, io1, Y4.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x14, G_IF_SIGMA_CCOO_COOO_NO1_X14)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.15
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y5(w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,o3,k,o1) X(w,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y5 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y15, G_IF_SIGMA_CCOO_COOO_Y15)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x15, G_IF_SIGMA_CCOO_COOO_NO0_X15)
      (so1, io1, Y5.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x15, G_IF_SIGMA_CCOO_COOO_NO1_X15)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.16
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(w,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o3,o1,k) X(w,i,o3,o1) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x16, G_IF_SIGMA_CCOO_COOO_NO0_X16)
    (moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x16, G_IF_SIGMA_CCOO_COOO_NO1_X16)
      (sk, ik, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.17
  //* X(y,i,o2,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(y,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o3,o2,k) X(y,i,o2,o3) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x17, G_IF_SIGMA_CCOO_COOO_NO0_X17)
    (moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x17, G_IF_SIGMA_CCOO_COOO_NO1_X17)
      (sk, ik, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) X(w,i) h(y,k) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x18, G_IF_SIGMA_CCOO_COOO_NO0_X18)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x18, G_IF_SIGMA_CCOO_COOO_NO1_X18)
      (sk, ik, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.19
  //* X(w,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(w,i) Y6(y,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y6 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y19, G_IF_SIGMA_CCOO_COOO_Y19)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x19, G_IF_SIGMA_CCOO_COOO_NO0_X19)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x19, G_IF_SIGMA_CCOO_COOO_NO1_X19)
      (sk, ik, Xca.cptr(), Y6.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.20
  //* X(w,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(w,i) Y7(y,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y7 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y20, G_IF_SIGMA_CCOO_COOO_Y20)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x20, G_IF_SIGMA_CCOO_COOO_NO0_X20)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x20, G_IF_SIGMA_CCOO_COOO_NO1_X20)
      (sk, ik, Xca.cptr(), Y7.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.21
  //* X(y,i)  <--  (    1.00000000)  D2(i,o2,o1,o3) T2(y,o1,o2,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) X(y,i) h(w,k) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x21, G_IF_SIGMA_CCOO_COOO_NO0_X21)
      (so3, io3, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x21, G_IF_SIGMA_CCOO_COOO_NO1_X21)
      (sk, ik, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.22
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) h(w,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o1,i,k) X(w,o1) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x22, G_IF_SIGMA_CCOO_COOO_NO0_X22)
    (moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x22, G_IF_SIGMA_CCOO_COOO_NO1_X22)
      (sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.23
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) h(y,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o1,i,k) X(y,o1) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x23, G_IF_SIGMA_CCOO_COOO_NO0_X23)
    (moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x23, G_IF_SIGMA_CCOO_COOO_NO1_X23)
      (sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.24
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) Y8(y,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(w,o1,i,k) X(y,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y8 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y24, G_IF_SIGMA_CCOO_COOO_Y24)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x24, G_IF_SIGMA_CCOO_COOO_NO0_X24)
    (Y8.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x24, G_IF_SIGMA_CCOO_COOO_NO1_X24)
      (sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.25
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) Y9(y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,o1,i,k) X(y,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y9 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y25, G_IF_SIGMA_CCOO_COOO_Y25)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x25, G_IF_SIGMA_CCOO_COOO_NO0_X25)
    (Y9.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x25, G_IF_SIGMA_CCOO_COOO_NO1_X25)
      (sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.26
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,i,o2) 
  //* S2(w,y,i,k)  <--  (    4.00000000) X(w,i) h(y,k) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x26, G_IF_SIGMA_CCOO_COOO_NO0_X26)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x26, G_IF_SIGMA_CCOO_COOO_NO1_X26)
      (sk, ik, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.27
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,i,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) X(y,i) h(w,k) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x27, G_IF_SIGMA_CCOO_COOO_NO0_X27)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x27, G_IF_SIGMA_CCOO_COOO_NO1_X27)
      (sk, ik, Xca.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.28
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,i,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(y,i) Y10(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y10 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y28, G_IF_SIGMA_CCOO_COOO_Y28)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x28, G_IF_SIGMA_CCOO_COOO_NO0_X28)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x28, G_IF_SIGMA_CCOO_COOO_NO1_X28)
      (sk, ik, Xca.cptr(), Y10.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.29
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,i,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(y,i) Y11(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y11 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y29, G_IF_SIGMA_CCOO_COOO_Y29)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x29, G_IF_SIGMA_CCOO_COOO_NO0_X29)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x29, G_IF_SIGMA_CCOO_COOO_NO1_X29)
      (sk, ik, Xca.cptr(), Y11.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.30
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,i) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) X(w,i) h(y,k) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x30, G_IF_SIGMA_CCOO_COOO_NO0_X30)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x30, G_IF_SIGMA_CCOO_COOO_NO1_X30)
        (si, ii, sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.31
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,i) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(w,i) Y12(y,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y12 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y31, G_IF_SIGMA_CCOO_COOO_Y31)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x31, G_IF_SIGMA_CCOO_COOO_NO0_X31)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x31, G_IF_SIGMA_CCOO_COOO_NO1_X31)
        (si, ii, sk, ik, Xc.cptr(), Y12.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.32
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,i) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(w,i) Y13(y,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y13 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y32, G_IF_SIGMA_CCOO_COOO_Y32)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x32, G_IF_SIGMA_CCOO_COOO_NO0_X32)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x32, G_IF_SIGMA_CCOO_COOO_NO1_X32)
        (si, ii, sk, ik, Xc.cptr(), Y13.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.33
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,i) 
  //* S2(w,y,i,k)  <--  (    1.00000000) X(y,i) h(w,k) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x33, G_IF_SIGMA_CCOO_COOO_NO0_X33)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x33, G_IF_SIGMA_CCOO_COOO_NO1_X33)
        (si, ii, sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.34
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) h(y,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o1,k,i) X(y,o1) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x34, G_IF_SIGMA_CCOO_COOO_NO0_X34)
    (moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x34, G_IF_SIGMA_CCOO_COOO_NO1_X34)
        (si, ii, sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.35
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) h(w,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o1,k,i) X(w,o1) 
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x35, G_IF_SIGMA_CCOO_COOO_NO0_X35)
    (moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x35, G_IF_SIGMA_CCOO_COOO_NO1_X35)
        (si, ii, sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.36
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) Y14(w,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) T2(y,o1,k,i) X(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y14 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y36, G_IF_SIGMA_CCOO_COOO_Y36)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x36, G_IF_SIGMA_CCOO_COOO_NO0_X36)
    (Y14.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x36, G_IF_SIGMA_CCOO_COOO_NO1_X36)
        (si, ii, sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.37
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) Y15(w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,o1,k,i) X(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y15 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y37, G_IF_SIGMA_CCOO_COOO_Y37)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x37, G_IF_SIGMA_CCOO_COOO_NO0_X37)
    (Y15.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x37, G_IF_SIGMA_CCOO_COOO_NO1_X37)
        (si, ii, sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.38
  //* X(y,k)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,k,o2) 
  //* S2(w,y,i,k)  <--  (    4.00000000) X(y,k) h(w,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x38, G_IF_SIGMA_CCOO_COOO_NO0_X38)
        (sk, ik, so2, io2, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x38, G_IF_SIGMA_CCOO_COOO_NO1_X38)
      (sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.39
  //* X(w,k)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,k,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) X(w,k) h(y,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x39, G_IF_SIGMA_CCOO_COOO_NO0_X39)
        (sk, ik, so2, io2, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x39, G_IF_SIGMA_CCOO_COOO_NO1_X39)
      (sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.40
  //* X(w,k)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,k,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(w,k) Y16(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y16 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y40, G_IF_SIGMA_CCOO_COOO_Y40)
      (sc1, ic1, V2_sym.cptr(), Y16.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x40, G_IF_SIGMA_CCOO_COOO_NO0_X40)
        (sk, ik, so2, io2, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x40, G_IF_SIGMA_CCOO_COOO_NO1_X40)
      (sk, ik, Xc.cptr(), Y16.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.41
  //* X(w,k)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,k,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(w,k) Y17(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y17 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y41, G_IF_SIGMA_CCOO_COOO_Y41)
      (sc1, ic1, V2_sym.cptr(), Y17.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x41, G_IF_SIGMA_CCOO_COOO_NO0_X41)
        (sk, ik, so2, io2, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x41, G_IF_SIGMA_CCOO_COOO_NO1_X41)
      (sk, ik, Xc.cptr(), Y17.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.42
  //* X(y,k)  <--  (    1.00000000)  D1(o1,o2) T2(y,o2,o1,k) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) X(y,k) h(w,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x42, G_IF_SIGMA_CCOO_COOO_NO0_X42)
      (sk, ik, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x42, G_IF_SIGMA_CCOO_COOO_NO1_X42)
      (sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.43
  //* X(w,k)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,k) 
  //* S2(w,y,i,k)  <--  (    1.00000000) X(w,k) h(y,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x43, G_IF_SIGMA_CCOO_COOO_NO0_X43)
      (sk, ik, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x43, G_IF_SIGMA_CCOO_COOO_NO1_X43)
      (sk, ik, Xc.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.44
  //* X(w,y,o4,o3,o1,o2)  <--  (    1.00000000)  T2(c1,o4,o3,o1) V2(c1,w,y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D3(i,o3,k,o2,o4,o1) X(w,y,o4,o3,o1,o2) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, so1, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x44, G_IF_SIGMA_CCOO_COOO_NO0_X44)
        (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x44, G_IF_SIGMA_CCOO_COOO_NO1_X44)
        (sk, ik, so1, io1, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.45
  //* X(y,w,o4,o2,o1,o3)  <--  (    1.00000000)  T2(c1,o4,o2,o1) V2(c1,y,w,o3) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D3(i,o3,k,o2,o4,o1) X(y,w,o4,o2,o1,o3) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, so1, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x45, G_IF_SIGMA_CCOO_COOO_NO0_X45)
        (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x45, G_IF_SIGMA_CCOO_COOO_NO1_X45)
        (sk, ik, so1, io1, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.46
  //* X(y,i,o3,k,o4,o1)  <--  (    1.00000000)  D3(i,o3,k,o2,o4,o1) Y18(y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,o4,o3,o1) X(y,i,o3,k,o4,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y18 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y46, G_IF_SIGMA_CCOO_COOO_Y46)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x46, G_IF_SIGMA_CCOO_COOO_NO0_X46)
        (sk, ik, so1, io1, Y18.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x46, G_IF_SIGMA_CCOO_COOO_NO1_X46)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.47
  //* X(y,i,o3,k,o4,o1)  <--  (    1.00000000)  D3(i,o3,k,o2,o4,o1) Y19(y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(w,o4,o3,o1) X(y,i,o3,k,o4,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y19 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y47, G_IF_SIGMA_CCOO_COOO_Y47)
      (sc1, ic1, V2_sym.cptr(), Y19.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x47, G_IF_SIGMA_CCOO_COOO_NO0_X47)
        (sk, ik, so1, io1, Y19.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x47, G_IF_SIGMA_CCOO_COOO_NO1_X47)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.48
  //* X(w,i,k,o2,o4,o1)  <--  (    1.00000000)  D3(i,o3,k,o2,o4,o1) Y20(w,o3) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,o4,o2,o1) X(w,i,k,o2,o4,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y20 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y48, G_IF_SIGMA_CCOO_COOO_Y48)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x48, G_IF_SIGMA_CCOO_COOO_NO0_X48)
        (sk, ik, so1, io1, Y20.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x48, G_IF_SIGMA_CCOO_COOO_NO1_X48)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.49
  //* X(w,i,k,o2,o4,o1)  <--  (    1.00000000)  D3(i,o3,k,o2,o4,o1) Y21(w,o3) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(y,o4,o2,o1) X(w,i,k,o2,o4,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y21 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y49, G_IF_SIGMA_CCOO_COOO_Y49)
      (sc1, ic1, V2_sym.cptr(), Y21.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x49, G_IF_SIGMA_CCOO_COOO_NO0_X49)
        (sk, ik, so1, io1, Y21.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x49, G_IF_SIGMA_CCOO_COOO_NO1_X49)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.50
  //* X(w,y,o3,i,o1,o2)  <--  (    1.00000000)  T2(c1,o3,i,o1) V2(c1,w,y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(k,o2,o3,o1) X(w,y,o3,i,o1,o2) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, so1, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x50, G_IF_SIGMA_CCOO_COOO_NO0_X50)
        (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x50, G_IF_SIGMA_CCOO_COOO_NO1_X50)
        (sk, ik, so1, io1, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.51
  //* X(y,w,o3,i,o1,o2)  <--  (    1.00000000)  T2(c1,o3,i,o1) V2(c1,y,w,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(k,o2,o3,o1) X(y,w,o3,i,o1,o2) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, so1, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x51, G_IF_SIGMA_CCOO_COOO_NO0_X51)
        (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x51, G_IF_SIGMA_CCOO_COOO_NO1_X51)
        (sk, ik, so1, io1, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.52
  //* X(w,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y22(w,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(y,o3,i,o1) X(w,k,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y22 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y52, G_IF_SIGMA_CCOO_COOO_Y52)
      (sc1, ic1, V2_sym.cptr(), Y22.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x52, G_IF_SIGMA_CCOO_COOO_NO0_X52)
        (sk, ik, so1, io1, Y22.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x52, G_IF_SIGMA_CCOO_COOO_NO1_X52)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.53
  //* X(w,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y23(w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,o3,i,o1) X(w,k,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y23 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y53, G_IF_SIGMA_CCOO_COOO_Y53)
      (sc1, ic1, V2_sym.cptr(), Y23.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x53, G_IF_SIGMA_CCOO_COOO_NO0_X53)
        (sk, ik, so1, io1, Y23.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x53, G_IF_SIGMA_CCOO_COOO_NO1_X53)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.54
  //* X(y,w,o3,o2,i,o1)  <--  (    1.00000000)  T2(c1,o3,o2,i) V2(c1,y,w,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(k,o2,o3,o1) X(y,w,o3,o2,i,o1) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, si, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x54, G_IF_SIGMA_CCOO_COOO_NO0_X54)
        (sc1, ic1, si, ii, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x54, G_IF_SIGMA_CCOO_COOO_NO1_X54)
        (si, ii, sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.55
  //* X(w,y,o3,o1,i,o2)  <--  (    1.00000000)  T2(c1,o3,o1,i) V2(c1,w,y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(k,o2,o3,o1) X(w,y,o3,o1,i,o2) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, si, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x55, G_IF_SIGMA_CCOO_COOO_NO0_X55)
        (sc1, ic1, si, ii, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x55, G_IF_SIGMA_CCOO_COOO_NO1_X55)
        (si, ii, sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.56
  //* X(w,k,o2,o3)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y24(w,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,o3,o2,i) X(w,k,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y24 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y56, G_IF_SIGMA_CCOO_COOO_Y56)
      (sc1, ic1, V2_sym.cptr(), Y24.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x56, G_IF_SIGMA_CCOO_COOO_NO0_X56)
      (sk, ik, Y24.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x56, G_IF_SIGMA_CCOO_COOO_NO1_X56)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.57
  //* X(w,k,o2,o3)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y25(w,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(y,o3,o2,i) X(w,k,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y25 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y57, G_IF_SIGMA_CCOO_COOO_Y57)
      (sc1, ic1, V2_sym.cptr(), Y25.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x57, G_IF_SIGMA_CCOO_COOO_NO0_X57)
      (sk, ik, Y25.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x57, G_IF_SIGMA_CCOO_COOO_NO1_X57)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.58
  //* X(y,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y26(y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,o3,o1,i) X(y,k,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y26 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y58, G_IF_SIGMA_CCOO_COOO_Y58)
      (sc1, ic1, V2_sym.cptr(), Y26.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x58, G_IF_SIGMA_CCOO_COOO_NO0_X58)
      (sk, ik, Y26.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x58, G_IF_SIGMA_CCOO_COOO_NO1_X58)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.59
  //* X(y,k,o3,o1)  <--  (    1.00000000)  D2(k,o2,o3,o1) Y27(y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(w,o3,o1,i) X(y,k,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y27 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y59, G_IF_SIGMA_CCOO_COOO_Y59)
      (sc1, ic1, V2_sym.cptr(), Y27.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x59, G_IF_SIGMA_CCOO_COOO_NO0_X59)
      (sk, ik, Y27.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x59, G_IF_SIGMA_CCOO_COOO_NO1_X59)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.60
  //* X(w,y,o3,o2,o1,i)  <--  (    1.00000000)  T2(c1,o3,o2,o1) V2(c1,w,y,i) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(k,o2,o3,o1) X(w,y,o3,o2,o1,i) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, so1, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x60, G_IF_SIGMA_CCOO_COOO_NO0_X60)
        (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x60, G_IF_SIGMA_CCOO_COOO_NO1_X60)
        (sk, ik, so1, io1, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.61
  //* X(y,w,o3,o2,o1,i)  <--  (    1.00000000)  T2(c1,o3,o2,o1) V2(c1,y,w,i) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(k,o2,o3,o1) X(y,w,o3,o2,o1,i) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, so1, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x61, G_IF_SIGMA_CCOO_COOO_NO0_X61)
        (sc1, ic1, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x61, G_IF_SIGMA_CCOO_COOO_NO1_X61)
        (sk, ik, so1, io1, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.62
  //* X(w,k)  <--  (    1.00000000)  D2(k,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(w,k) Y28(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y28 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y62, G_IF_SIGMA_CCOO_COOO_Y62)
      (sc1, ic1, V2_sym.cptr(), Y28.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x62, G_IF_SIGMA_CCOO_COOO_NO0_X62)
        (sk, ik, so1, io1, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x62, G_IF_SIGMA_CCOO_COOO_NO1_X62)
      (sk, ik, Xc.cptr(), Y28.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.63
  //* X(w,k)  <--  (    1.00000000)  D2(k,o2,o3,o1) T2(w,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) X(w,k) Y29(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y29 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y63, G_IF_SIGMA_CCOO_COOO_Y63)
      (sc1, ic1, V2_sym.cptr(), Y29.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x63, G_IF_SIGMA_CCOO_COOO_NO0_X63)
        (sk, ik, so1, io1, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x63, G_IF_SIGMA_CCOO_COOO_NO1_X63)
      (sk, ik, Xc.cptr(), Y29.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.64
  //* X(y,w,o3,k,o1,o2)  <--  (    1.00000000)  T2(c1,o3,k,o1) V2(c1,y,w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(i,o2,o3,o1) X(y,w,o3,k,o1,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, sk^so1, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x64, G_IF_SIGMA_CCOO_COOO_NO0_X64)
          (sc1, ic1, sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x64, G_IF_SIGMA_CCOO_COOO_NO1_X64)
        (sk, ik, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.65
  //* X(w,y,o3,k,o1,o2)  <--  (    1.00000000)  T2(c1,o3,k,o1) V2(c1,w,y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,y,o3,k,o1,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, sk^so1, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x65, G_IF_SIGMA_CCOO_COOO_NO0_X65)
          (sc1, ic1, sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x65, G_IF_SIGMA_CCOO_COOO_NO1_X65)
        (sk, ik, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.66
  //* X(y,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y30(y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(w,o3,k,o1) X(y,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y30 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y66, G_IF_SIGMA_CCOO_COOO_Y66)
      (sc1, ic1, V2_sym.cptr(), Y30.cptr(), nir, nsym, psym);
  }
  }
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x66, G_IF_SIGMA_CCOO_COOO_NO0_X66)
      (so1, io1, Y30.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x66, G_IF_SIGMA_CCOO_COOO_NO1_X66)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.67
  //* X(y,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y31(y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,o3,k,o1) X(y,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y31 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y67, G_IF_SIGMA_CCOO_COOO_Y67)
      (sc1, ic1, V2_sym.cptr(), Y31.cptr(), nir, nsym, psym);
  }
  }
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x67, G_IF_SIGMA_CCOO_COOO_NO0_X67)
      (so1, io1, Y31.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x67, G_IF_SIGMA_CCOO_COOO_NO1_X67)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.68
  //* X(w,y,o3,o2,k,o1)  <--  (    1.00000000)  T2(c1,o3,o2,k) V2(c1,w,y,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,y,o3,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x68, G_IF_SIGMA_CCOO_COOO_NO0_X68)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x68, G_IF_SIGMA_CCOO_COOO_NO1_X68)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.69
  //* X(y,w,o3,o1,k,o2)  <--  (    1.00000000)  T2(c1,o3,o1,k) V2(c1,y,w,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(y,w,o3,o1,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x69, G_IF_SIGMA_CCOO_COOO_NO0_X69)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x69, G_IF_SIGMA_CCOO_COOO_NO1_X69)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.70
  //* X(y,i,o2,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y32(y,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,o3,o2,k) X(y,i,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y32 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y70, G_IF_SIGMA_CCOO_COOO_Y70)
      (sc1, ic1, V2_sym.cptr(), Y32.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x70, G_IF_SIGMA_CCOO_COOO_NO0_X70)
    (Y32.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x70, G_IF_SIGMA_CCOO_COOO_NO1_X70)
      (sk, ik, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.71
  //* X(y,i,o2,o3)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y33(y,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(w,o3,o2,k) X(y,i,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y33 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y71, G_IF_SIGMA_CCOO_COOO_Y71)
      (sc1, ic1, V2_sym.cptr(), Y33.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x71, G_IF_SIGMA_CCOO_COOO_NO0_X71)
    (Y33.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x71, G_IF_SIGMA_CCOO_COOO_NO1_X71)
      (sk, ik, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.72
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y34(w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,o3,o1,k) X(w,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y34 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y72, G_IF_SIGMA_CCOO_COOO_Y72)
      (sc1, ic1, V2_sym.cptr(), Y34.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x72, G_IF_SIGMA_CCOO_COOO_NO0_X72)
    (Y34.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x72, G_IF_SIGMA_CCOO_COOO_NO1_X72)
      (sk, ik, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.73
  //* X(w,i,o3,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y35(w,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(y,o3,o1,k) X(w,i,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y35 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y73, G_IF_SIGMA_CCOO_COOO_Y73)
      (sc1, ic1, V2_sym.cptr(), Y35.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x73, G_IF_SIGMA_CCOO_COOO_NO0_X73)
    (Y35.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x73, G_IF_SIGMA_CCOO_COOO_NO1_X73)
      (sk, ik, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.74
  //* X(w,y,o3,o2,o1,k)  <--  (    1.00000000)  T2(c1,o3,o2,o1) V2(k,w,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,y,o3,o2,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x74, G_IF_SIGMA_CCOO_COOO_NO0_X74)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x74, G_IF_SIGMA_CCOO_COOO_NO1_X74)
        (sk, ik, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.75
  //* X(y,w,o3,o2,o1,k)  <--  (    1.00000000)  T2(c1,o3,o2,o1) V2(k,y,c1,w) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D2(i,o2,o3,o1) X(y,w,o3,o2,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so1^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x75, G_IF_SIGMA_CCOO_COOO_NO0_X75)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x75, G_IF_SIGMA_CCOO_COOO_NO1_X75)
        (sk, ik, so1, io1, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.76
  //* X(y,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(y,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(y,i) Y36(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y36 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y76, G_IF_SIGMA_CCOO_COOO_Y76)
      (sc1, ic1, V2_sym.cptr(), Y36.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x76, G_IF_SIGMA_CCOO_COOO_NO0_X76)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x76, G_IF_SIGMA_CCOO_COOO_NO1_X76)
      (sk, ik, Xca.cptr(), Y36.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.77
  //* X(y,i)  <--  (    1.00000000)  D2(i,o2,o3,o1) T2(y,o3,o2,o1) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) X(y,i) Y37(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y37 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y77, G_IF_SIGMA_CCOO_COOO_Y77)
      (sc1, ic1, V2_sym.cptr(), Y37.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x77, G_IF_SIGMA_CCOO_COOO_NO0_X77)
      (so1, io1, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x77, G_IF_SIGMA_CCOO_COOO_NO1_X77)
      (sk, ik, Xca.cptr(), Y37.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.78
  //* X(c1,w,y,o1)  <--  (    1.00000000)  D1(o1,o2) V2(c1,w,y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(c1,o1,i,k) X(c1,w,y,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x78, G_IF_SIGMA_CCOO_COOO_NO0_X78)
      (sc1, ic1, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x78, G_IF_SIGMA_CCOO_COOO_NO1_X78)
        (sc1, ic1, sk, ik, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.79
  //* X(c1,y,w,o1)  <--  (    1.00000000)  D1(o1,o2) V2(c1,y,w,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(c1,o1,i,k) X(c1,y,w,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x79, G_IF_SIGMA_CCOO_COOO_NO0_X79)
      (sc1, ic1, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x79, G_IF_SIGMA_CCOO_COOO_NO1_X79)
        (sc1, ic1, sk, ik, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.80
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) Y38(w,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(y,o1,i,k) X(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y38 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y80, G_IF_SIGMA_CCOO_COOO_Y80)
      (sc1, ic1, V2_sym.cptr(), Y38.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x80, G_IF_SIGMA_CCOO_COOO_NO0_X80)
    (Y38.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x80, G_IF_SIGMA_CCOO_COOO_NO1_X80)
      (sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.81
  //* X(w,o1)  <--  (    1.00000000)  D1(o1,o2) Y39(w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(y,o1,i,k) X(w,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y39 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y81, G_IF_SIGMA_CCOO_COOO_Y81)
      (sc1, ic1, V2_sym.cptr(), Y39.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x81, G_IF_SIGMA_CCOO_COOO_NO0_X81)
    (Y39.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x81, G_IF_SIGMA_CCOO_COOO_NO1_X81)
      (sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.82
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,i,o2) 
  //* S2(w,y,i,k)  <--  (    8.00000000) X(w,i) Y40(y,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y40 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y82, G_IF_SIGMA_CCOO_COOO_Y82)
      (sc1, ic1, V2_sym.cptr(), Y40.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x82, G_IF_SIGMA_CCOO_COOO_NO0_X82)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x82, G_IF_SIGMA_CCOO_COOO_NO1_X82)
      (sk, ik, Xca.cptr(), Y40.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.83
  //* X(w,i)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,i,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(w,i) Y41(y,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y41 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y83, G_IF_SIGMA_CCOO_COOO_Y83)
      (sc1, ic1, V2_sym.cptr(), Y41.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x83, G_IF_SIGMA_CCOO_COOO_NO0_X83)
      (so2, io2, T2b.cptr(), Xca.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x83, G_IF_SIGMA_CCOO_COOO_NO1_X83)
      (sk, ik, Xca.cptr(), Y41.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.84
  //* X(y,w,o1,i,o2,k)  <--  (    1.00000000)  T2(c1,o1,i,o2) V2(k,y,c1,w) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(o1,o2) X(y,w,o1,i,o2,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x84, G_IF_SIGMA_CCOO_COOO_NO0_X84)
        (sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x84, G_IF_SIGMA_CCOO_COOO_NO1_X84)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.85
  //* X(w,y,o1,i,o2,k)  <--  (    1.00000000)  T2(c1,o1,i,o2) V2(k,w,c1,y) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(o1,o2) X(w,y,o1,i,o2,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x85, G_IF_SIGMA_CCOO_COOO_NO0_X85)
        (sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x85, G_IF_SIGMA_CCOO_COOO_NO1_X85)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.86
  //* X(w,y,o1,o2,i,k)  <--  (    1.00000000)  T2(c1,o1,o2,i) V2(k,w,c1,y) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(o1,o2) X(w,y,o1,o2,i,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, si^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x86, G_IF_SIGMA_CCOO_COOO_NO0_X86)
        (si, ii, sk, ik, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x86, G_IF_SIGMA_CCOO_COOO_NO1_X86)
        (si, ii, sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.87
  //* X(y,w,o1,o2,i,k)  <--  (    1.00000000)  T2(c1,o1,o2,i) V2(k,y,c1,w) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(o1,o2) X(y,w,o1,o2,i,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, si^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x87, G_IF_SIGMA_CCOO_COOO_NO0_X87)
        (si, ii, sk, ik, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x87, G_IF_SIGMA_CCOO_COOO_NO1_X87)
        (si, ii, sk, ik, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.88
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,i) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(y,i) Y42(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y42 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y88, G_IF_SIGMA_CCOO_COOO_Y88)
      (sc1, ic1, V2_sym.cptr(), Y42.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x88, G_IF_SIGMA_CCOO_COOO_NO0_X88)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x88, G_IF_SIGMA_CCOO_COOO_NO1_X88)
        (si, ii, sk, ik, Xc.cptr(), Y42.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.89
  //* X(y,i)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,i) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) X(y,i) Y43(w,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y43 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y89, G_IF_SIGMA_CCOO_COOO_Y89)
      (sc1, ic1, V2_sym.cptr(), Y43.cptr(), nir, nsym, psym);
  }
  }
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    T2b = T2.get_amp2(ii);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x89, G_IF_SIGMA_CCOO_COOO_NO0_X89)
      (si, ii, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x89, G_IF_SIGMA_CCOO_COOO_NO1_X89)
        (si, ii, sk, ik, Xc.cptr(), Y43.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.90
  //* X(c1,y,w,o1)  <--  (    1.00000000)  D1(o1,o2) V2(c1,y,w,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(c1,o1,k,i) X(c1,y,w,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x90, G_IF_SIGMA_CCOO_COOO_NO0_X90)
      (sc1, ic1, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x90, G_IF_SIGMA_CCOO_COOO_NO1_X90)
          (sc1, ic1, si, ii, sk, ik, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.91
  //* X(c1,w,y,o1)  <--  (    1.00000000)  D1(o1,o2) V2(c1,w,y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(c1,o1,k,i) X(c1,w,y,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x91, G_IF_SIGMA_CCOO_COOO_NO0_X91)
      (sc1, ic1, V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x91, G_IF_SIGMA_CCOO_COOO_NO1_X91)
          (sc1, ic1, si, ii, sk, ik, T2b.cptr(), Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.92
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) Y44(y,o2) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) T2(w,o1,k,i) X(y,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y44 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y92, G_IF_SIGMA_CCOO_COOO_Y92)
      (sc1, ic1, V2_sym.cptr(), Y44.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x92, G_IF_SIGMA_CCOO_COOO_NO0_X92)
    (Y44.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x92, G_IF_SIGMA_CCOO_COOO_NO1_X92)
        (si, ii, sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.93
  //* X(y,o1)  <--  (    1.00000000)  D1(o1,o2) Y45(y,o2) 
  //* S2(w,y,i,k)  <--  (    2.00000000) T2(w,o1,k,i) X(y,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y45 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y93, G_IF_SIGMA_CCOO_COOO_Y93)
      (sc1, ic1, V2_sym.cptr(), Y45.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc);
  orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccoo_cooo_no0_x93, G_IF_SIGMA_CCOO_COOO_NO0_X93)
    (Y45.cptr(), Xca.cptr(), nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x93, G_IF_SIGMA_CCOO_COOO_NO1_X93)
        (si, ii, sk, ik, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.94
  //* X(y,k)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,k,o2) 
  //* S2(w,y,i,k)  <--  (    8.00000000) X(y,k) Y46(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y46 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y94, G_IF_SIGMA_CCOO_COOO_Y94)
      (sc1, ic1, V2_sym.cptr(), Y46.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x94, G_IF_SIGMA_CCOO_COOO_NO0_X94)
        (sk, ik, so2, io2, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x94, G_IF_SIGMA_CCOO_COOO_NO1_X94)
      (sk, ik, Xc.cptr(), Y46.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.95
  //* X(y,k)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,k,o2) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(y,k) Y47(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y47 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y95, G_IF_SIGMA_CCOO_COOO_Y95)
      (sc1, ic1, V2_sym.cptr(), Y47.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x95, G_IF_SIGMA_CCOO_COOO_NO0_X95)
        (sk, ik, so2, io2, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x95, G_IF_SIGMA_CCOO_COOO_NO1_X95)
      (sk, ik, Xc.cptr(), Y47.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.96
  //* X(y,w,o1,k,o2,i)  <--  (    1.00000000)  T2(c1,o1,k,o2) V2(c1,y,w,i) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) D1(o1,o2) X(y,w,o1,k,o2,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, sk^so2, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x96, G_IF_SIGMA_CCOO_COOO_NO0_X96)
          (sc1, ic1, sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x96, G_IF_SIGMA_CCOO_COOO_NO1_X96)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.97
  //* X(w,y,o1,k,o2,i)  <--  (    1.00000000)  T2(c1,o1,k,o2) V2(c1,w,y,i) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(o1,o2) X(w,y,o1,k,o2,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, sk^so2, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x97, G_IF_SIGMA_CCOO_COOO_NO0_X97)
          (sc1, ic1, sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x97, G_IF_SIGMA_CCOO_COOO_NO1_X97)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.98
  //* X(w,y,o1,o2,k,i)  <--  (    1.00000000)  T2(c1,o1,o2,k) V2(c1,w,y,i) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) D1(o1,o2) X(w,y,o1,o2,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x98, G_IF_SIGMA_CCOO_COOO_NO0_X98)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x98, G_IF_SIGMA_CCOO_COOO_NO1_X98)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.99
  //* X(y,w,o1,o2,k,i)  <--  (    1.00000000)  T2(c1,o1,o2,k) V2(c1,y,w,i) 
  //* S2(w,y,i,k)  <--  (    2.00000000) D1(o1,o2) X(y,w,o1,o2,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x99, G_IF_SIGMA_CCOO_COOO_NO0_X99)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x99, G_IF_SIGMA_CCOO_COOO_NO1_X99)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.100
  //* X(w,k)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,k) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(w,k) Y48(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y48 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y100, G_IF_SIGMA_CCOO_COOO_Y100)
      (sc1, ic1, V2_sym.cptr(), Y48.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x100, G_IF_SIGMA_CCOO_COOO_NO0_X100)
      (sk, ik, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x100, G_IF_SIGMA_CCOO_COOO_NO1_X100)
      (sk, ik, Xc.cptr(), Y48.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.101
  //* X(w,k)  <--  (    1.00000000)  D1(o1,o2) T2(w,o1,o2,k) 
  //* S2(w,y,i,k)  <--  (   -1.00000000) X(w,k) Y49(y,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y49 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y101, G_IF_SIGMA_CCOO_COOO_Y101)
      (sc1, ic1, V2_sym.cptr(), Y49.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x101, G_IF_SIGMA_CCOO_COOO_NO0_X101)
      (sk, ik, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x101, G_IF_SIGMA_CCOO_COOO_NO1_X101)
      (sk, ik, Xc.cptr(), Y49.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.102
  //* X(y,k)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,k) 
  //* S2(w,y,i,k)  <--  (   -4.00000000) X(y,k) Y50(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y50 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y102, G_IF_SIGMA_CCOO_COOO_Y102)
      (sc1, ic1, V2_sym.cptr(), Y50.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x102, G_IF_SIGMA_CCOO_COOO_NO0_X102)
      (sk, ik, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x102, G_IF_SIGMA_CCOO_COOO_NO1_X102)
      (sk, ik, Xc.cptr(), Y50.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.103
  //* X(y,k)  <--  (    1.00000000)  D1(o1,o2) T2(y,o1,o2,k) 
  //* S2(w,y,i,k)  <--  (    2.00000000) X(y,k) Y51(w,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nocc);
  orz::DTensor Y51 = orz::ct::sympack_Xca(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccoo_cooo_y103, G_IF_SIGMA_CCOO_COOO_Y103)
      (sc1, ic1, V2_sym.cptr(), Y51.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x103, G_IF_SIGMA_CCOO_COOO_NO0_X103)
      (sk, ik, T2b.cptr(), Xc.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x103, G_IF_SIGMA_CCOO_COOO_NO1_X103)
      (sk, ik, Xc.cptr(), Y51.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.104
  //* X(y,k,o4,i,o2,o6)  <--  (    1.00000000)  D4(o3,k,o4,i,o1,o5,o2,o6) V2(o3,y,o1,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o6,o4,o2) X(y,k,o4,i,o2,o6) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^so2, X);
      for(int so3 = 0;so3 < nir;++so3){ 
      for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io3);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io3, so3, V2); // V2=(IR-COV index) 
        // Load D4 from disk, or GA ....                                                     
        int imoi = amo2imo[io3] - nclosed;                              
        int imoj = amo2imo[ik] - nclosed;                              
                                                                                             
        orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice()).copy();    
        rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io3, so3, ik, sk, rdm4_ij_sliced);    
        FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so3, sk, io3, ik, rdm4_sym.cptr(), nir, nsym, psym);  
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x104, G_IF_SIGMA_CCOO_COOO_NO0_X104)
          (sk, ik, so2, io2, so3, io3, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
        FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
      }
      }
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x104, G_IF_SIGMA_CCOO_COOO_NO1_X104)
        (sk, ik, so2, io2, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.105
  //* X(w,i,o4,k,o5,o1)  <--  (    1.00000000)  D4(o3,i,o4,k,o5,o1,o6,o2) V2(o3,w,o2,o6) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o1,o4,o5) X(w,i,o4,k,o5,o1) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int so5 = 0;so5 < nir;++so5){ 
      for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
        orz::DTensor X(nclosed, nocc, nocc);
        orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, si^sk^so5, X);
        for(int so3 = 0;so3 < nir;++so3){ 
        for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
          // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
          V2 <<= 0.0;                                                                          
          shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io3);
          for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
            // Load a signle record of integals                                                             
            const int &imo2 = loadbuf_ptr->i0;                                                              
            const int &imo3 = loadbuf_ptr->i1;                                                              
            const int &imo4 = loadbuf_ptr->i2;                                                              
            const double &v = loadbuf_ptr->v;                                                               
            V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
          }                                                                                                 
          const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io3, so3, V2); // V2=(IR-COV index) 
          // Load D4 from disk, or GA ....                                                     
          int imoi = amo2imo[io3] - nclosed;                              
          int imoj = amo2imo[ii] - nclosed;                              
                                                                                               
          orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice()).copy();    
          rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io3, so3, ii, si, rdm4_ij_sliced);    
          FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so3, si, io3, ii, rdm4_sym.cptr(), nir, nsym, psym);  
          FC_FUNC(g_if_sigma_ccoo_cooo_no0_x105, G_IF_SIGMA_CCOO_COOO_NO0_X105)
            (si, ii, sk, ik, so3, io3, so5, io5, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
          FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
        }
        }
        T2b = T2.get_amp2(io5);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x105, G_IF_SIGMA_CCOO_COOO_NO1_X105)
          (si, ii, sk, ik, so5, io5, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.106
  //* X(y,k,o4,o1)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(y,o3,o2,o5) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o4,i,o1) X(y,k,o4,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int so1 = 0;so1 < nir;++so1){ 
      for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
        orz::DTensor X(nocc);
        orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sy^sk^so1, X);
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x106, G_IF_SIGMA_CCOO_COOO_NO0_X106)
          (sk, ik, so1, io1, sy, iy, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x106, G_IF_SIGMA_CCOO_COOO_NO1_X106)
          (sk, ik, so1, io1, sy, iy, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.107
  //* X(w,k,o4,o1)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(w,o3,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,i,o1) X(w,k,o4,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int so1 = 0;so1 < nir;++so1){ 
      for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
        orz::DTensor X(nocc);
        orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sw^sk^so1, X);
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x107, G_IF_SIGMA_CCOO_COOO_NO0_X107)
          (sk, ik, so1, io1, sw, iw, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x107, G_IF_SIGMA_CCOO_COOO_NO1_X107)
          (sk, ik, so1, io1, sw, iw, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.108
  //* X(w,k,o3,o4)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(w,o1,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o3,i) X(w,k,o3,o4) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sw^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x108, G_IF_SIGMA_CCOO_COOO_NO0_X108)
        (sk, ik, sw, iw, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x108, G_IF_SIGMA_CCOO_COOO_NO1_X108)
          (si, ii, sk, ik, sw, iw, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.109
  //* X(y,k,o4,o1)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(y,o3,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,o1,i) X(y,k,o4,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sy^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x109, G_IF_SIGMA_CCOO_COOO_NO0_X109)
        (sk, ik, sy, iy, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x109, G_IF_SIGMA_CCOO_COOO_NO1_X109)
          (si, ii, sk, ik, sy, iy, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.110
  //* X(y,k,o3,o4,o1,i)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(y,i,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,o3,o1) X(y,k,o3,o4,o1,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int so1 = 0;so1 < nir;++so1){ 
      for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
        orz::DTensor X(nocc, nocc, nocc);
        orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy^sk^so1, X);
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x110, G_IF_SIGMA_CCOO_COOO_NO0_X110)
          (sk, ik, so1, io1, sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x110, G_IF_SIGMA_CCOO_COOO_NO1_X110)
          (sk, ik, so1, io1, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.111
  //* X(w,k,o3,o4,o1,i)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(w,i,o2,o5) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o4,o3,o1) X(w,k,o3,o4,o1,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int so1 = 0;so1 < nir;++so1){ 
      for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
        orz::DTensor X(nocc, nocc, nocc);
        orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw^sk^so1, X);
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x111, G_IF_SIGMA_CCOO_COOO_NO0_X111)
          (sk, ik, so1, io1, sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x111, G_IF_SIGMA_CCOO_COOO_NO1_X111)
          (sk, ik, so1, io1, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.112
  //* X(w,k,o3,o4,o1,i)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(w,o2,i,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o3,o1) X(w,k,o3,o4,o1,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int so1 = 0;so1 < nir;++so1){ 
      for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
        orz::DTensor X(nocc, nocc, nocc);
        orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw^sk^so1, X);
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x112, G_IF_SIGMA_CCOO_COOO_NO0_X112)
          (sk, ik, so1, io1, sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x112, G_IF_SIGMA_CCOO_COOO_NO1_X112)
          (sk, ik, so1, io1, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.113
  //* X(y,k,o4,o1,o2,i)  <--  (    1.00000000)  D3(k,o3,o4,o1,o5,o2) V2(y,o3,i,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,o2,o1) X(y,k,o4,o1,o2,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int so1 = 0;so1 < nir;++so1){ 
      for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
        orz::DTensor X(nocc, nocc, nocc);
        orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy^sk^so1, X);
        FC_FUNC(g_if_sigma_ccoo_cooo_no0_x113, G_IF_SIGMA_CCOO_COOO_NO0_X113)
          (sk, ik, so1, io1, sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x113, G_IF_SIGMA_CCOO_COOO_NO1_X113)
          (sk, ik, so1, io1, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.114
  //* X(w,i,o4,o1)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(w,o3,o2,o5) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o4,k,o1) X(w,i,o4,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sw^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x114, G_IF_SIGMA_CCOO_COOO_NO0_X114)
        (so1, io1, sw, iw, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x114, G_IF_SIGMA_CCOO_COOO_NO1_X114)
          (sk, ik, so1, io1, sw, iw, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.115
  //* X(y,i,o4,o1)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(y,o3,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,k,o1) X(y,i,o4,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sy^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x115, G_IF_SIGMA_CCOO_COOO_NO0_X115)
        (so1, io1, sy, iy, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        T2b = T2.get_amp2(io1);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x115, G_IF_SIGMA_CCOO_COOO_NO1_X115)
          (sk, ik, so1, io1, sy, iy, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.116
  //* X(y,i,o3,o4)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(y,o1,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,o3,k) X(y,i,o3,o4) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x116, G_IF_SIGMA_CCOO_COOO_NO0_X116)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x116, G_IF_SIGMA_CCOO_COOO_NO1_X116)
        (sk, ik, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.117
  //* X(w,i,o4,o1)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(w,o3,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o1,k) X(w,i,o4,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x117, G_IF_SIGMA_CCOO_COOO_NO0_X117)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x117, G_IF_SIGMA_CCOO_COOO_NO1_X117)
        (sk, ik, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.118
  //* X(w,i,o3,o4,o1,k)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(k,w,o2,o5) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o3,o1) X(w,i,o3,o4,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so1^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x118, G_IF_SIGMA_CCOO_COOO_NO0_X118)
        (sk, ik, so1, io1, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x118, G_IF_SIGMA_CCOO_COOO_NO1_X118)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.119
  //* X(y,i,o3,o4,o1,k)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(k,y,o2,o5) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o4,o3,o1) X(y,i,o3,o4,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so1^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x119, G_IF_SIGMA_CCOO_COOO_NO0_X119)
        (sk, ik, so1, io1, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x119, G_IF_SIGMA_CCOO_COOO_NO1_X119)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.120
  //* X(y,i,o3,o4,o1,k)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(k,o5,y,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,o3,o1) X(y,i,o3,o4,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so1^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x120, G_IF_SIGMA_CCOO_COOO_NO0_X120)
        (sk, ik, so1, io1, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x120, G_IF_SIGMA_CCOO_COOO_NO1_X120)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.121
  //* X(w,i,o4,o1,o2,k)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(k,o5,w,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o2,o1) X(w,i,o4,o1,o2,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so1^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x121, G_IF_SIGMA_CCOO_COOO_NO0_X121)
        (sk, ik, so1, io1, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x121, G_IF_SIGMA_CCOO_COOO_NO1_X121)
        (sk, ik, so1, io1, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.122
  //* X(y,o1)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,o3,o2,o4) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o1,i,k) X(y,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x122, G_IF_SIGMA_CCOO_COOO_NO0_X122)
      (sy, iy, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x122, G_IF_SIGMA_CCOO_COOO_NO1_X122)
        (sk, ik, sy, iy, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.123
  //* X(w,o1)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,o3,o2,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o1,i,k) X(w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x123, G_IF_SIGMA_CCOO_COOO_NO0_X123)
      (sw, iw, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x123, G_IF_SIGMA_CCOO_COOO_NO1_X123)
        (sk, ik, sw, iw, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.124
  //* X(y,o1,o3,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,y,o2,o4) 
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(w,o1,i,o3) X(y,o1,o3,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x124, G_IF_SIGMA_CCOO_COOO_NO0_X124)
        (sk, ik, so3, io3, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x124, G_IF_SIGMA_CCOO_COOO_NO1_X124)
        (sk, ik, so3, io3, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.125
  //* X(w,o1,o3,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,w,o2,o4) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o1,i,o3) X(w,o1,o3,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x125, G_IF_SIGMA_CCOO_COOO_NO0_X125)
        (sk, ik, so3, io3, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x125, G_IF_SIGMA_CCOO_COOO_NO1_X125)
        (sk, ik, so3, io3, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.126
  //* X(y,o2,o4,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,o1,y,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o2,i,o4) X(y,o2,o4,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x126, G_IF_SIGMA_CCOO_COOO_NO0_X126)
        (sk, ik, so4, io4, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x126, G_IF_SIGMA_CCOO_COOO_NO1_X126)
        (sk, ik, so4, io4, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.127
  //* X(w,o2,o4,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,o1,w,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o2,i,o4) X(w,o2,o4,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x127, G_IF_SIGMA_CCOO_COOO_NO0_X127)
        (sk, ik, so4, io4, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x127, G_IF_SIGMA_CCOO_COOO_NO1_X127)
        (sk, ik, so4, io4, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.128
  //* X(w,o1,o3,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,w,o2,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o1,o3,i) X(w,o1,o3,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x128, G_IF_SIGMA_CCOO_COOO_NO0_X128)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x128, G_IF_SIGMA_CCOO_COOO_NO1_X128)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.129
  //* X(y,o1,o3,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,y,o2,o4) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o1,o3,i) X(y,o1,o3,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x129, G_IF_SIGMA_CCOO_COOO_NO0_X129)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x129, G_IF_SIGMA_CCOO_COOO_NO1_X129)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.130
  //* X(y,o1,o3,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,o2,y,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o1,o3,i) X(y,o1,o3,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x130, G_IF_SIGMA_CCOO_COOO_NO0_X130)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x130, G_IF_SIGMA_CCOO_COOO_NO1_X130)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.131
  //* X(w,o3,o2,k)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,o1,w,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o2,o3,i) X(w,o3,o2,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x131, G_IF_SIGMA_CCOO_COOO_NO0_X131)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x131, G_IF_SIGMA_CCOO_COOO_NO1_X131)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.132
  //* X(y,o3,o2,o4,k,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,o1,y,i) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o2,o3,o4) X(y,o3,o2,o4,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x132, G_IF_SIGMA_CCOO_COOO_NO0_X132)
        (sk, ik, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x132, G_IF_SIGMA_CCOO_COOO_NO1_X132)
        (sk, ik, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.133
  //* X(w,o3,o2,o4,k,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,o1,w,i) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o2,o3,o4) X(w,o3,o2,o4,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x133, G_IF_SIGMA_CCOO_COOO_NO0_X133)
        (sk, ik, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x133, G_IF_SIGMA_CCOO_COOO_NO1_X133)
        (sk, ik, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.134
  //* X(w,o3,o2,o4,k,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,w,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o2,o3,o4) X(w,o3,o2,o4,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x134, G_IF_SIGMA_CCOO_COOO_NO0_X134)
        (sk, ik, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x134, G_IF_SIGMA_CCOO_COOO_NO1_X134)
        (sk, ik, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.135
  //* X(w,o1)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,o3,o2,o4) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o1,k,i) X(w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x135, G_IF_SIGMA_CCOO_COOO_NO0_X135)
      (sw, iw, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x135, G_IF_SIGMA_CCOO_COOO_NO1_X135)
          (si, ii, sk, ik, sw, iw, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.136
  //* X(y,o1)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,o3,o2,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o1,k,i) X(y,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x136, G_IF_SIGMA_CCOO_COOO_NO0_X136)
      (sy, iy, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x136, G_IF_SIGMA_CCOO_COOO_NO1_X136)
          (si, ii, sk, ik, sy, iy, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.137
  //* X(w,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,i,o2,o4) 
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(y,o1,k,o3) X(w,o1,o3,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sw^so3, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x137, G_IF_SIGMA_CCOO_COOO_NO0_X137)
        (so3, io3, sw, iw, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        T2b = T2.get_amp2(io3);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x137, G_IF_SIGMA_CCOO_COOO_NO1_X137)
          (sk, ik, so3, io3, sw, iw, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.138
  //* X(y,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,i,o2,o4) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o1,k,o3) X(y,o1,o3,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sy^so3, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x138, G_IF_SIGMA_CCOO_COOO_NO0_X138)
        (so3, io3, sy, iy, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        T2b = T2.get_amp2(io3);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x138, G_IF_SIGMA_CCOO_COOO_NO1_X138)
          (sk, ik, so3, io3, sy, iy, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.139
  //* X(w,o2,o4,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,o3,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o2,k,o4) X(w,o2,o4,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sw^so4, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x139, G_IF_SIGMA_CCOO_COOO_NO0_X139)
        (so4, io4, sw, iw, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        T2b = T2.get_amp2(io4);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x139, G_IF_SIGMA_CCOO_COOO_NO1_X139)
          (sk, ik, so4, io4, sw, iw, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.140
  //* X(y,o2,o4,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,o3,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o2,k,o4) X(y,o2,o4,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sy^so4, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x140, G_IF_SIGMA_CCOO_COOO_NO0_X140)
        (so4, io4, sy, iy, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        T2b = T2.get_amp2(io4);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x140, G_IF_SIGMA_CCOO_COOO_NO1_X140)
          (sk, ik, so4, io4, sy, iy, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.141
  //* X(y,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,i,o2,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o1,o3,k) X(y,o1,o3,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x141, G_IF_SIGMA_CCOO_COOO_NO0_X141)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x141, G_IF_SIGMA_CCOO_COOO_NO1_X141)
        (sk, ik, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.142
  //* X(w,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,i,o2,o4) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o1,o3,k) X(w,o1,o3,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x142, G_IF_SIGMA_CCOO_COOO_NO0_X142)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x142, G_IF_SIGMA_CCOO_COOO_NO1_X142)
        (sk, ik, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.143
  //* X(w,o1,o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(w,o4,i,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o1,o3,k) X(w,o1,o3,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x143, G_IF_SIGMA_CCOO_COOO_NO0_X143)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x143, G_IF_SIGMA_CCOO_COOO_NO1_X143)
        (sk, ik, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.144
  //* X(y,o3,o2,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(y,o4,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o2,o3,k) X(y,o3,o2,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x144, G_IF_SIGMA_CCOO_COOO_NO0_X144)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x144, G_IF_SIGMA_CCOO_COOO_NO1_X144)
        (sk, ik, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.145
  //* X(y,o3,o2,o4,k,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(k,y,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o2,o3,o4) X(y,o3,o2,o4,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x145, G_IF_SIGMA_CCOO_COOO_NO0_X145)
        (sk, ik, so4, io4, V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x145, G_IF_SIGMA_CCOO_COOO_NO1_X145)
        (sk, ik, so4, io4, T2b.cptr(), Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.146
  //* X(w,y,o5,o2,o3,o4)  <--  (    1.00000000)  T2(w,o5,o1,o2) V2(y,o3,o1,o4) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D3(i,o4,k,o3,o5,o2) X(w,y,o5,o2,o3,o4) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sy^so2, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x146, G_IF_SIGMA_CCOO_COOO_NO0_X146)
        (so2, io2, sy, iy, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x146, G_IF_SIGMA_CCOO_COOO_NO1_X146)
          (sk, ik, so2, io2, sy, iy, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.147
  //* X(y,w,o5,o2,o4,o3)  <--  (    1.00000000)  T2(y,o5,o1,o2) V2(w,o4,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D3(i,o4,k,o3,o5,o2) X(y,w,o5,o2,o4,o3) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sw^so2, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x147, G_IF_SIGMA_CCOO_COOO_NO0_X147)
        (so2, io2, sw, iw, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x147, G_IF_SIGMA_CCOO_COOO_NO1_X147)
          (sk, ik, so2, io2, sw, iw, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.148
  //* X(w,k,o4,o1)  <--  (    1.00000000)  D2(k,o3,o4,o2) V2(w,o2,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o1,i) X(w,k,o4,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sw^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x148, G_IF_SIGMA_CCOO_COOO_NO0_X148)
        (sk, ik, sw, iw, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x148, G_IF_SIGMA_CCOO_COOO_NO1_X148)
          (si, ii, sk, ik, sw, iw, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.149
  //* X(y,k,o4,o1)  <--  (    1.00000000)  D2(k,o3,o4,o2) V2(y,o3,o1,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,o1,i) X(y,k,o4,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sy^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x149, G_IF_SIGMA_CCOO_COOO_NO0_X149)
        (sk, ik, sy, iy, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int si = 0;si < nir;++si){ 
      for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
        T2b = T2.get_amp2(ii);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x149, G_IF_SIGMA_CCOO_COOO_NO1_X149)
          (si, ii, sk, ik, sy, iy, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.150
  //* X(w,y,o4,o2,i,o3)  <--  (    1.00000000)  T2(w,o4,o1,o2) V2(y,i,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(k,o3,o4,o2) X(w,y,o4,o2,i,o3) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sy^so2, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x150, G_IF_SIGMA_CCOO_COOO_NO0_X150)
        (so2, io2, sy, iy, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x150, G_IF_SIGMA_CCOO_COOO_NO1_X150)
          (sk, ik, so2, io2, sy, iy, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.151
  //* X(y,w,o4,o2,i,o3)  <--  (    1.00000000)  T2(y,o4,o1,o2) V2(w,i,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D2(k,o3,o4,o2) X(y,w,o4,o2,i,o3) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sw^so2, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x151, G_IF_SIGMA_CCOO_COOO_NO0_X151)
        (so2, io2, sw, iw, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x151, G_IF_SIGMA_CCOO_COOO_NO1_X151)
          (sk, ik, so2, io2, sw, iw, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.152
  //* X(y,w,o4,o2,o3,i)  <--  (    1.00000000)  T2(y,o4,o1,o2) V2(w,o3,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(k,o3,o4,o2) X(y,w,o4,o2,o3,i) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sw^so2, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x152, G_IF_SIGMA_CCOO_COOO_NO0_X152)
        (so2, io2, sw, iw, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x152, G_IF_SIGMA_CCOO_COOO_NO1_X152)
          (sk, ik, so2, io2, sw, iw, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.153
  //* X(w,y,o4,o2,o3,i)  <--  (    1.00000000)  T2(w,o4,o1,o2) V2(y,o3,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D2(k,o3,o4,o2) X(w,y,o4,o2,o3,i) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sy^so2, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x153, G_IF_SIGMA_CCOO_COOO_NO0_X153)
        (so2, io2, sy, iy, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        S2b = orz::DTensor(retval.namps_iamp()[ik]);
        FC_FUNC(g_if_sigma_ccoo_cooo_no1_x153, G_IF_SIGMA_CCOO_COOO_NO1_X153)
          (sk, ik, so2, io2, sy, iy, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(ik, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.154
  //* X(y,i,o4,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(y,o2,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,o1,k) X(y,i,o4,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x154, G_IF_SIGMA_CCOO_COOO_NO0_X154)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x154, G_IF_SIGMA_CCOO_COOO_NO1_X154)
        (sk, ik, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.155
  //* X(w,i,o4,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(w,o3,o1,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,o1,k) X(w,i,o4,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x155, G_IF_SIGMA_CCOO_COOO_NO0_X155)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x155, G_IF_SIGMA_CCOO_COOO_NO1_X155)
        (sk, ik, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.156
  //* X(y,w,o4,o2,k,o3)  <--  (    1.00000000)  T2(y,o4,o1,o2) V2(k,w,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o3,o4,o2) X(y,w,o4,o2,k,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x156, G_IF_SIGMA_CCOO_COOO_NO0_X156)
        (sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x156, G_IF_SIGMA_CCOO_COOO_NO1_X156)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.157
  //* X(w,y,o4,o2,k,o3)  <--  (    1.00000000)  T2(w,o4,o1,o2) V2(k,y,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D2(i,o3,o4,o2) X(w,y,o4,o2,k,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x157, G_IF_SIGMA_CCOO_COOO_NO0_X157)
        (sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x157, G_IF_SIGMA_CCOO_COOO_NO1_X157)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.158
  //* X(w,y,o4,o2,k,o3)  <--  (    1.00000000)  T2(w,o4,o1,o2) V2(k,o1,y,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o3,o4,o2) X(w,y,o4,o2,k,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x158, G_IF_SIGMA_CCOO_COOO_NO0_X158)
        (sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x158, G_IF_SIGMA_CCOO_COOO_NO1_X158)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.159
  //* X(y,w,o4,o2,k,o3)  <--  (    1.00000000)  T2(y,o4,o1,o2) V2(k,o1,w,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D2(i,o3,o4,o2) X(y,w,o4,o2,k,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so2^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x159, G_IF_SIGMA_CCOO_COOO_NO0_X159)
        (sk, ik, so2, io2, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x159, G_IF_SIGMA_CCOO_COOO_NO1_X159)
        (sk, ik, so2, io2, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.160
  //* X(w,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,w,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o2,o1,i) X(w,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x160, G_IF_SIGMA_CCOO_COOO_NO0_X160)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x160, G_IF_SIGMA_CCOO_COOO_NO1_X160)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.161
  //* X(y,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,y,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o2,o1,i) X(y,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x161, G_IF_SIGMA_CCOO_COOO_NO0_X161)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x161, G_IF_SIGMA_CCOO_COOO_NO1_X161)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.162
  //* X(y,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,o1,y,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o2,o1,i) X(y,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x162, G_IF_SIGMA_CCOO_COOO_NO0_X162)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x162, G_IF_SIGMA_CCOO_COOO_NO1_X162)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.163
  //* X(w,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,o1,w,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o2,o1,i) X(w,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x163, G_IF_SIGMA_CCOO_COOO_NO0_X163)
      (sk, ik, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      T2b = T2.get_amp2(ii);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x163, G_IF_SIGMA_CCOO_COOO_NO1_X163)
        (si, ii, sk, ik, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.164
  //* X(y,w,o2,o3,k,i)  <--  (    1.00000000)  T2(y,o2,o1,o3) V2(k,o1,w,i) 
  //* S2(w,y,i,k)  <--  (    4.00000000) D1(o2,o3) X(y,w,o2,o3,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x164, G_IF_SIGMA_CCOO_COOO_NO0_X164)
        (sk, ik, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x164, G_IF_SIGMA_CCOO_COOO_NO1_X164)
        (sk, ik, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.165
  //* X(w,y,o2,o3,k,i)  <--  (    1.00000000)  T2(w,o2,o1,o3) V2(k,o1,y,i) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(o2,o3) X(w,y,o2,o3,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x165, G_IF_SIGMA_CCOO_COOO_NO0_X165)
        (sk, ik, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x165, G_IF_SIGMA_CCOO_COOO_NO1_X165)
        (sk, ik, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.166
  //* X(w,y,o2,o3,k,i)  <--  (    1.00000000)  T2(w,o2,o1,o3) V2(k,y,i,o1) 
  //* S2(w,y,i,k)  <--  (    4.00000000) D1(o2,o3) X(w,y,o2,o3,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x166, G_IF_SIGMA_CCOO_COOO_NO0_X166)
        (sk, ik, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x166, G_IF_SIGMA_CCOO_COOO_NO1_X166)
        (sk, ik, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.167
  //* X(y,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(y,i,o1,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o2,o1,k) X(y,o2,i,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x167, G_IF_SIGMA_CCOO_COOO_NO0_X167)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x167, G_IF_SIGMA_CCOO_COOO_NO1_X167)
        (sk, ik, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.168
  //* X(w,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(w,i,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o2,o1,k) X(w,o2,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x168, G_IF_SIGMA_CCOO_COOO_NO0_X168)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x168, G_IF_SIGMA_CCOO_COOO_NO1_X168)
        (sk, ik, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.169
  //* X(w,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(w,o3,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o2,o1,k) X(w,o2,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sw, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x169, G_IF_SIGMA_CCOO_COOO_NO0_X169)
      (sw, iw, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x169, G_IF_SIGMA_CCOO_COOO_NO1_X169)
        (sk, ik, sw, iw, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.170
  //* X(y,o2,i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(y,o3,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o2,o1,k) X(y,o2,i,o1) 
  for(int sy = 0;sy < nir;++sy){ 
  for(int iy = symblockinfo.psym()(sy,I_C,I_BEGIN);iy <= symblockinfo.psym()(sy,I_C,I_END);++iy){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iy);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iy, sy, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sy, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x170, G_IF_SIGMA_CCOO_COOO_NO0_X170)
      (sy, iy, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x170, G_IF_SIGMA_CCOO_COOO_NO1_X170)
        (sk, ik, sy, iy, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.171
  //* X(y,w,o2,o3,k,i)  <--  (    1.00000000)  T2(y,o2,o1,o3) V2(k,w,i,o1) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(o2,o3) X(y,w,o2,o3,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nclosed, nocc, nocc);
      orz::DTensor Xccaa = orz::ct::sympack_Xccaa(symblockinfo, so3^sk, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x171, G_IF_SIGMA_CCOO_COOO_NO0_X171)
        (sk, ik, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x171, G_IF_SIGMA_CCOO_COOO_NO1_X171)
        (sk, ik, so3, io3, Xccaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.172
  //* X(w,y,o5,o4,o2,o3)  <--  (    1.00000000)  T2(w,o5,o4,o1) V2(o1,o2,y,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D3(i,o4,k,o3,o5,o2) X(w,y,o5,o4,o2,o3) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc, nocc);
  orz::DTensor Xccaaaa = orz::ct::sympack_Xccaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x172, G_IF_SIGMA_CCOO_COOO_NO0_X172)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x172, G_IF_SIGMA_CCOO_COOO_NO1_X172)
      (sk, ik, Xccaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.173
  //* X(y,w,o1,o3,o4,o2)  <--  (    1.00000000)  T2(y,o1,o3,o5) V2(o5,o4,w,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D3(i,o2,k,o3,o1,o4) X(y,w,o1,o3,o4,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc, nocc);
  orz::DTensor Xccaaaa = orz::ct::sympack_Xccaaaa(symblockinfo, 0, X);
  for(int so5 = 0;so5 < nir;++so5){ 
  for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io5);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io5, so5, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io5);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x173, G_IF_SIGMA_CCOO_COOO_NO0_X173)
      (so5, io5, T2b.cptr(), V2_sym.cptr(), Xccaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x173, G_IF_SIGMA_CCOO_COOO_NO1_X173)
      (sk, ik, Xccaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.174
  //* X(y,k,o4,o1)  <--  (    1.00000000)  D2(k,o3,o4,o2) V2(o1,o2,y,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o4,i,o1) X(y,k,o4,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x174, G_IF_SIGMA_CCOO_COOO_NO0_X174)
        (sk, ik, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x174, G_IF_SIGMA_CCOO_COOO_NO1_X174)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.175
  //* X(w,k,o4,o1)  <--  (    1.00000000)  D2(k,o3,o4,o2) V2(o1,o2,w,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o4,i,o1) X(w,k,o4,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x175, G_IF_SIGMA_CCOO_COOO_NO0_X175)
        (sk, ik, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x175, G_IF_SIGMA_CCOO_COOO_NO1_X175)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.176
  //* X(w,y,o4,o3,o2,i)  <--  (    1.00000000)  T2(w,o4,o3,o1) V2(o1,o2,y,i) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(k,o3,o4,o2) X(w,y,o4,o3,o2,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc, nocc);
  orz::DTensor Xccaaaa = orz::ct::sympack_Xccaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x176, G_IF_SIGMA_CCOO_COOO_NO0_X176)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x176, G_IF_SIGMA_CCOO_COOO_NO1_X176)
      (sk, ik, Xccaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.177
  //* X(y,w,o4,o3,o2,i)  <--  (    1.00000000)  T2(y,o4,o3,o1) V2(o1,o2,w,i) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D2(k,o3,o4,o2) X(y,w,o4,o3,o2,i) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc, nocc);
  orz::DTensor Xccaaaa = orz::ct::sympack_Xccaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x177, G_IF_SIGMA_CCOO_COOO_NO0_X177)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x177, G_IF_SIGMA_CCOO_COOO_NO1_X177)
      (sk, ik, Xccaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.178
  //* X(y,w,o4,o3,i,o2)  <--  (    1.00000000)  T2(y,o4,o3,o1) V2(o1,i,w,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(k,o3,o4,o2) X(y,w,o4,o3,i,o2) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc, nocc);
  orz::DTensor Xccaaaa = orz::ct::sympack_Xccaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x178, G_IF_SIGMA_CCOO_COOO_NO0_X178)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x178, G_IF_SIGMA_CCOO_COOO_NO1_X178)
      (sk, ik, Xccaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.179
  //* X(w,y,o4,o2,i,o3)  <--  (    1.00000000)  T2(w,o4,o2,o1) V2(o1,i,y,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(k,o3,o4,o2) X(w,y,o4,o2,i,o3) 
  orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc, nocc);
  orz::DTensor Xccaaaa = orz::ct::sympack_Xccaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x179, G_IF_SIGMA_CCOO_COOO_NO0_X179)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x179, G_IF_SIGMA_CCOO_COOO_NO1_X179)
      (sk, ik, Xccaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.180
  //* X(w,i,o4,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,o2,w,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o4,k,o1) X(w,i,o4,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x180, G_IF_SIGMA_CCOO_COOO_NO0_X180)
      (so1, io1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x180, G_IF_SIGMA_CCOO_COOO_NO1_X180)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.181
  //* X(y,i,o4,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,o2,y,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o4,k,o1) X(y,i,o4,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x181, G_IF_SIGMA_CCOO_COOO_NO0_X181)
      (so1, io1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x181, G_IF_SIGMA_CCOO_COOO_NO1_X181)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.182
  //* X(y,w,o4,o3,k,o2)  <--  (    1.00000000)  T2(y,o4,o3,o1) V2(k,w,o1,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o3,o4,o2) X(y,w,o4,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x182, G_IF_SIGMA_CCOO_COOO_NO0_X182)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x182, G_IF_SIGMA_CCOO_COOO_NO1_X182)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.183
  //* X(w,y,o4,o3,k,o2)  <--  (    1.00000000)  T2(w,o4,o3,o1) V2(k,y,o1,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D2(i,o3,o4,o2) X(w,y,o4,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x183, G_IF_SIGMA_CCOO_COOO_NO0_X183)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x183, G_IF_SIGMA_CCOO_COOO_NO1_X183)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.184
  //* X(w,y,o4,o3,k,o2)  <--  (    1.00000000)  T2(w,o4,o3,o1) V2(k,o1,y,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o3,o4,o2) X(w,y,o4,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x184, G_IF_SIGMA_CCOO_COOO_NO0_X184)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x184, G_IF_SIGMA_CCOO_COOO_NO1_X184)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.185
  //* X(y,w,o1,o3,k,o2)  <--  (    1.00000000)  T2(y,o1,o3,o4) V2(k,o4,w,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D2(i,o2,o1,o3) X(y,w,o1,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x185, G_IF_SIGMA_CCOO_COOO_NO0_X185)
        (sk, ik, so4, io4, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x185, G_IF_SIGMA_CCOO_COOO_NO1_X185)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.186
  //* X(y,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,y,o1,o3) 
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(w,o2,i,o1) X(y,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x186, G_IF_SIGMA_CCOO_COOO_NO0_X186)
        (sk, ik, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x186, G_IF_SIGMA_CCOO_COOO_NO1_X186)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.187
  //* X(w,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,w,o1,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o2,i,o1) X(w,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x187, G_IF_SIGMA_CCOO_COOO_NO0_X187)
        (sk, ik, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x187, G_IF_SIGMA_CCOO_COOO_NO1_X187)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.188
  //* X(w,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,o1,w,o3) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(y,o2,i,o1) X(w,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x188, G_IF_SIGMA_CCOO_COOO_NO0_X188)
        (sk, ik, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x188, G_IF_SIGMA_CCOO_COOO_NO1_X188)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.189
  //* X(y,o2,k,o1)  <--  (    1.00000000)  D1(o2,o3) V2(k,o1,y,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o2,i,o1) X(y,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^so1, X);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x189, G_IF_SIGMA_CCOO_COOO_NO0_X189)
        (sk, ik, so1, io1, V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x189, G_IF_SIGMA_CCOO_COOO_NO1_X189)
        (sk, ik, so1, io1, T2b.cptr(), Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.190
  //* X(w,y,o3,o2,k,i)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(k,o1,y,i) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(o2,o3) X(w,y,o3,o2,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x190, G_IF_SIGMA_CCOO_COOO_NO0_X190)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x190, G_IF_SIGMA_CCOO_COOO_NO1_X190)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.191
  //* X(y,w,o3,o2,k,i)  <--  (    1.00000000)  T2(y,o3,o2,o1) V2(k,o1,w,i) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(o2,o3) X(y,w,o3,o2,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x191, G_IF_SIGMA_CCOO_COOO_NO0_X191)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x191, G_IF_SIGMA_CCOO_COOO_NO1_X191)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.192
  //* X(y,w,o3,o2,k,i)  <--  (    1.00000000)  T2(y,o3,o2,o1) V2(k,w,i,o1) 
  //* S2(w,y,i,k)  <--  (    1.00000000) D1(o2,o3) X(y,w,o3,o2,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x192, G_IF_SIGMA_CCOO_COOO_NO0_X192)
        (sk, ik, so1, io1, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x192, G_IF_SIGMA_CCOO_COOO_NO1_X192)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }


  {
  // No.193
  //* X(w,o3,o1,i)  <--  (    1.00000000)  D1(o2,o3) V2(o1,o2,w,i) 
  //* S2(w,y,i,k)  <--  (    4.00000000) T2(y,o3,k,o1) X(w,o3,o1,i) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x193, G_IF_SIGMA_CCOO_COOO_NO0_X193)
      (so1, io1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x193, G_IF_SIGMA_CCOO_COOO_NO1_X193)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.194
  //* X(y,o3,o1,i)  <--  (    1.00000000)  D1(o2,o3) V2(o1,o2,y,i) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(w,o3,k,o1) X(y,o3,o1,i) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x194, G_IF_SIGMA_CCOO_COOO_NO0_X194)
      (so1, io1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x194, G_IF_SIGMA_CCOO_COOO_NO1_X194)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.195
  //* X(y,o3,o1,i)  <--  (    1.00000000)  D1(o2,o3) V2(o1,i,y,o2) 
  //* S2(w,y,i,k)  <--  (    1.00000000) T2(w,o3,k,o1) X(y,o3,o1,i) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x195, G_IF_SIGMA_CCOO_COOO_NO0_X195)
      (so1, io1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x195, G_IF_SIGMA_CCOO_COOO_NO1_X195)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.196
  //* X(w,o3,o1,i)  <--  (    1.00000000)  D1(o2,o3) V2(o1,i,w,o2) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) T2(y,o3,k,o1) X(w,o3,o1,i) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccoo_cooo_no0_x196, G_IF_SIGMA_CCOO_COOO_NO0_X196)
      (so1, io1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      S2b = orz::DTensor(retval.namps_iamp()[ik]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_ccoo_cooo_no1_x196, G_IF_SIGMA_CCOO_COOO_NO1_X196)
        (sk, ik, so1, io1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, S2b);
    }
    }
  }
  }
  }


  {
  // No.197
  //* X(w,y,o1,o2,k,i)  <--  (    1.00000000)  T2(w,o1,o2,o3) V2(k,y,i,o3) 
  //* S2(w,y,i,k)  <--  (   -2.00000000) D1(o1,o2) X(w,y,o1,o2,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    S2b = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc, nocc, nocc);
    orz::DTensor Xccaaa = orz::ct::sympack_Xccaaa(symblockinfo, sk, X);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_ccoo_cooo_no0_x197, G_IF_SIGMA_CCOO_COOO_NO0_X197)
        (sk, ik, so3, io3, T2b.cptr(), V2_sym.cptr(), Xccaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccoo_cooo_no1_x197, G_IF_SIGMA_CCOO_COOO_NO1_X197)
      (sk, ik, Xccaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, S2b);
  }
  }
  }

  return retval; 
} 
