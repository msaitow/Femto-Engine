                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_coov_ocov.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//  8888888888                     888                  
//  888                            888                  
//  888                            888                  
//  8888888  .d88b.  88888b.d88b.  888888  .d88b.       
//  888     d8P  Y8b 888 "888 "88b 888    d88""88b  
//  888     88888888 888  888  888 888    888  888      
//  888     Y8b.     888  888  888 Y88b.  Y88..88P      
//  888      "Y8888  888  888  888  "Y888  "Y88P"   

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_coov_ocov(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::DTensor &rdm4,                                                 
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                        


  {
  // No.0
  //* S2(w,i,k,a)  <--  (   -2.00000000) Y0 D2(i,k,o2,o1) T2(o1,w,o2,a) 
  // The effective tensor is detected .... 
  double Y0 = 0;
  FC_FUNC(g_if_sigma_coov_ocov_y0, G_IF_SIGMA_COOV_OCOV_Y0)
    (moint1_sym.cptr(), &Y0, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x0, G_IF_SIGMA_COOV_OCOV_NO0_X0)
      (sa, ia, &Y0, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.1
  //* S2(w,i,k,a)  <--  (   -2.00000000) Y1 D2(i,k,o2,o1) T2(o1,w,o2,a) 
  // The effective tensor is detected .... 
  double Y1 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y1, G_IF_SIGMA_COOV_OCOV_Y1)
      (sc1, ic1, V2_sym.cptr(), &Y1, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x1, G_IF_SIGMA_COOV_OCOV_NO0_X1)
      (sa, ia, &Y1, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.2
  //* S2(w,i,k,a)  <--  (    1.00000000) Y2 D2(i,k,o2,o1) T2(o1,w,o2,a) 
  // The effective tensor is detected .... 
  double Y2 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y2, G_IF_SIGMA_COOV_OCOV_Y2)
      (sc1, ic1, V2_sym.cptr(), &Y2, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x2, G_IF_SIGMA_COOV_OCOV_NO0_X2)
      (sa, ia, &Y2, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.3
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(o1,c1,o2,a) h(c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,k,o2,o1) X(w,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x3, G_IF_SIGMA_COOV_OCOV_NO0_X3)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x3, G_IF_SIGMA_COOV_OCOV_NO1_X3)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.4
  //* S2(w,i,k,a)  <--  (   -2.00000000) Y3 D1(i,o1) T2(o1,w,k,a) 
  // The effective tensor is detected .... 
  double Y3 = 0;
  FC_FUNC(g_if_sigma_coov_ocov_y4, G_IF_SIGMA_COOV_OCOV_Y4)
    (moint1_sym.cptr(), &Y3, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x4, G_IF_SIGMA_COOV_OCOV_NO0_X4)
      (sa, ia, &Y3, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.5
  //* S2(w,i,k,a)  <--  (   -2.00000000) Y4 D1(i,o1) T2(o1,w,k,a) 
  // The effective tensor is detected .... 
  double Y4 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y5, G_IF_SIGMA_COOV_OCOV_Y5)
      (sc1, ic1, V2_sym.cptr(), &Y4, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x5, G_IF_SIGMA_COOV_OCOV_NO0_X5)
      (sa, ia, &Y4, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.6
  //* S2(w,i,k,a)  <--  (    1.00000000) Y5 D1(i,o1) T2(o1,w,k,a) 
  // The effective tensor is detected .... 
  double Y5 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y6, G_IF_SIGMA_COOV_OCOV_Y6)
      (sc1, ic1, V2_sym.cptr(), &Y5, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x6, G_IF_SIGMA_COOV_OCOV_NO0_X6)
      (sa, ia, &Y5, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.7
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,c1,k,a) h(c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o1) X(w,o1,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x7, G_IF_SIGMA_COOV_OCOV_NO0_X7)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x7, G_IF_SIGMA_COOV_OCOV_NO1_X7)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.8
  //* X(i,k,o1,o3)  <--  (    1.00000000)  D3(i,k,o1,o3,o2,o4) h(o2,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o3,w,o1,a) X(i,k,o1,o3) 
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x8, G_IF_SIGMA_COOV_OCOV_NO0_X8)
    (moint1_sym.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x8, G_IF_SIGMA_COOV_OCOV_NO1_X8)
      (sa, ia, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.9
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(o3,o1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o2,w,k,a) X(i,o2) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x9, G_IF_SIGMA_COOV_OCOV_NO0_X9)
    (moint1_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x9, G_IF_SIGMA_COOV_OCOV_NO1_X9)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.10
  //* X(i,o3,o1,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(k,o2) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o1,w,o3,a) X(i,o3,o1,k) 
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x10, G_IF_SIGMA_COOV_OCOV_NO0_X10)
    (moint1_sym.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x10, G_IF_SIGMA_COOV_OCOV_NO1_X10)
      (sa, ia, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.11
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(o2,w,o1,a) h(o3,o1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x11, G_IF_SIGMA_COOV_OCOV_NO0_X11)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x11, G_IF_SIGMA_COOV_OCOV_NO1_X11)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.12
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(o2,w,o1,a) h(k,o1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x12, G_IF_SIGMA_COOV_OCOV_NO0_X12)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x12, G_IF_SIGMA_COOV_OCOV_NO1_X12)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.13
  //* X(w,o2,o1,a)  <--  (    1.00000000)  T2(o2,w,o1,v1) h(a,v1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,k,o1,o2) X(w,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x13, G_IF_SIGMA_COOV_OCOV_NO0_X13)
        (sa, ia, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x13, G_IF_SIGMA_COOV_OCOV_NO1_X13)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.14
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,w,k,v1) h(a,v1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D1(i,o1) X(w,o1,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x14, G_IF_SIGMA_COOV_OCOV_NO0_X14)
        (sa, ia, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x14, G_IF_SIGMA_COOV_OCOV_NO1_X14)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.15
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(o1,c2,o2,a) Y6(c2,w) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,k,o2,o1) X(w,o1,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y6 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y15, G_IF_SIGMA_COOV_OCOV_Y15)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x15, G_IF_SIGMA_COOV_OCOV_NO0_X15)
      (sa, ia, T2b.cptr(), Y6.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x15, G_IF_SIGMA_COOV_OCOV_NO1_X15)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.16
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(o1,c2,o2,a) Y7(c2,w) 
  //* S2(w,i,k,a)  <--  (    2.00000000) D2(i,k,o2,o1) X(w,o1,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y7 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y16, G_IF_SIGMA_COOV_OCOV_Y16)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x16, G_IF_SIGMA_COOV_OCOV_NO0_X16)
      (sa, ia, T2b.cptr(), Y7.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x16, G_IF_SIGMA_COOV_OCOV_NO1_X16)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.17
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,c2,k,a) Y8(c2,w) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D1(i,o1) X(w,o1,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y8 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y17, G_IF_SIGMA_COOV_OCOV_Y17)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x17, G_IF_SIGMA_COOV_OCOV_NO0_X17)
      (sa, ia, T2b.cptr(), Y8.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x17, G_IF_SIGMA_COOV_OCOV_NO1_X17)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,c2,k,a) Y9(c2,w) 
  //* S2(w,i,k,a)  <--  (    2.00000000) D1(i,o1) X(w,o1,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y9 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y18, G_IF_SIGMA_COOV_OCOV_Y18)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x18, G_IF_SIGMA_COOV_OCOV_NO0_X18)
      (sa, ia, T2b.cptr(), Y9.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x18, G_IF_SIGMA_COOV_OCOV_NO1_X18)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.19
  //* X(c1,w,i,k,o3,o1)  <--  (    1.00000000)  D3(i,k,o3,o1,o4,o2) V2(c1,w,o2,o4) 
  //* S2(w,i,k,a)  <--  (    1.00000000) T2(o1,c1,o3,a) X(c1,w,i,k,o3,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x19, G_IF_SIGMA_COOV_OCOV_NO0_X19)
      (sc1, ic1, V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x19, G_IF_SIGMA_COOV_OCOV_NO1_X19)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.20
  //* X(i,k,o3,o1)  <--  (    1.00000000)  D3(i,k,o3,o1,o4,o2) Y10(o2,o4) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) T2(o1,w,o3,a) X(i,k,o3,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y10 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y20, G_IF_SIGMA_COOV_OCOV_Y20)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x20, G_IF_SIGMA_COOV_OCOV_NO0_X20)
    (Y10.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x20, G_IF_SIGMA_COOV_OCOV_NO1_X20)
      (sa, ia, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.21
  //* X(c1,w,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) T2(o2,c1,k,a) X(c1,w,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x21, G_IF_SIGMA_COOV_OCOV_NO0_X21)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x21, G_IF_SIGMA_COOV_OCOV_NO1_X21)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.22
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y11(o1,o3) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) T2(o2,w,k,a) X(i,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y11 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y22, G_IF_SIGMA_COOV_OCOV_Y22)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x22, G_IF_SIGMA_COOV_OCOV_NO0_X22)
    (Y11.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x22, G_IF_SIGMA_COOV_OCOV_NO1_X22)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.23
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y12(o1,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) T2(o2,w,k,a) X(i,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y12 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y23, G_IF_SIGMA_COOV_OCOV_Y23)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x23, G_IF_SIGMA_COOV_OCOV_NO0_X23)
    (Y12.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x23, G_IF_SIGMA_COOV_OCOV_NO1_X23)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.24
  //* X(w,o1,o3,k,o2,a)  <--  (    1.00000000)  T2(o1,c1,o3,a) V2(c1,w,k,o2) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o1,o3,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_coov_ocov_no0_x24, G_IF_SIGMA_COOV_OCOV_NO0_X24)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x24, G_IF_SIGMA_COOV_OCOV_NO1_X24)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.25
  //* X(i,o3,o1,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y13(k,o2) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) T2(o1,w,o3,a) X(i,o3,o1,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y13 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y25, G_IF_SIGMA_COOV_OCOV_Y25)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x25, G_IF_SIGMA_COOV_OCOV_NO0_X25)
    (Y13.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x25, G_IF_SIGMA_COOV_OCOV_NO1_X25)
      (sa, ia, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.26
  //* X(i,o3,o1,k)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y14(k,o2) 
  //* S2(w,i,k,a)  <--  (    1.00000000) T2(o1,w,o3,a) X(i,o3,o1,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y14 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y26, G_IF_SIGMA_COOV_OCOV_Y26)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x26, G_IF_SIGMA_COOV_OCOV_NO0_X26)
    (Y14.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x26, G_IF_SIGMA_COOV_OCOV_NO1_X26)
      (sa, ia, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.27
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(o2,c1,o1,a) V2(c1,w,o1,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_coov_ocov_no0_x27, G_IF_SIGMA_COOV_OCOV_NO0_X27)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x27, G_IF_SIGMA_COOV_OCOV_NO1_X27)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.28
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(o2,w,o1,a) Y15(o1,o3) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y15 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y28, G_IF_SIGMA_COOV_OCOV_Y28)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x28, G_IF_SIGMA_COOV_OCOV_NO0_X28)
      (sa, ia, T2b.cptr(), Y15.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x28, G_IF_SIGMA_COOV_OCOV_NO1_X28)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.29
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(o2,w,o1,a) Y16(o1,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y16 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y29, G_IF_SIGMA_COOV_OCOV_Y29)
      (sc1, ic1, V2_sym.cptr(), Y16.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x29, G_IF_SIGMA_COOV_OCOV_NO0_X29)
      (sa, ia, T2b.cptr(), Y16.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x29, G_IF_SIGMA_COOV_OCOV_NO1_X29)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.30
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(o2,c1,o1,a) V2(c1,w,k,o1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_coov_ocov_no0_x30, G_IF_SIGMA_COOV_OCOV_NO0_X30)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x30, G_IF_SIGMA_COOV_OCOV_NO1_X30)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.31
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(o2,w,o1,a) Y17(k,o1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y17 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y31, G_IF_SIGMA_COOV_OCOV_Y31)
      (sc1, ic1, V2_sym.cptr(), Y17.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x31, G_IF_SIGMA_COOV_OCOV_NO0_X31)
      (sa, ia, T2b.cptr(), Y17.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x31, G_IF_SIGMA_COOV_OCOV_NO1_X31)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.32
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(o2,w,o1,a) Y18(k,o1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y18 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y32, G_IF_SIGMA_COOV_OCOV_Y32)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x32, G_IF_SIGMA_COOV_OCOV_NO0_X32)
      (sa, ia, T2b.cptr(), Y18.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x32, G_IF_SIGMA_COOV_OCOV_NO1_X32)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.33
  //* X(i,k,o4,o2)  <--  (    1.00000000)  D3(i,k,o3,o1,o4,o2) Y19(o1,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) T2(o2,w,o4,a) X(i,k,o4,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y19 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y33, G_IF_SIGMA_COOV_OCOV_Y33)
      (sc1, ic1, V2_sym.cptr(), Y19.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_coov_ocov_no0_x33, G_IF_SIGMA_COOV_OCOV_NO0_X33)
    (Y19.cptr(), Xaaaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x33, G_IF_SIGMA_COOV_OCOV_NO1_X33)
      (sa, ia, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.34
  //* X(c1,w,i,k,o4,o1)  <--  (    1.00000000)  D3(i,o2,o3,k,o4,o1) V2(c1,o2,w,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) T2(o1,c1,o4,a) X(c1,w,i,k,o4,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x34, G_IF_SIGMA_COOV_OCOV_NO0_X34)
      (sc1, ic1, V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x34, G_IF_SIGMA_COOV_OCOV_NO1_X34)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.35
  //* X(c1,w,i,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,o2,w,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) T2(o1,c1,k,a) X(c1,w,i,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x35, G_IF_SIGMA_COOV_OCOV_NO0_X35)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x35, G_IF_SIGMA_COOV_OCOV_NO1_X35)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.36
  //* X(w,o1,o3,o2,k,a)  <--  (    1.00000000)  T2(o1,c1,o3,a) V2(c1,o2,w,k) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D2(i,o2,o3,o1) X(w,o1,o3,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_coov_ocov_no0_x36, G_IF_SIGMA_COOV_OCOV_NO0_X36)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x36, G_IF_SIGMA_COOV_OCOV_NO1_X36)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.37
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(o2,c1,o1,a) V2(c1,o1,w,o3) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_coov_ocov_no0_x37, G_IF_SIGMA_COOV_OCOV_NO0_X37)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x37, G_IF_SIGMA_COOV_OCOV_NO1_X37)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.38
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(o2,c1,o1,a) V2(c1,o1,w,k) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_coov_ocov_no0_x38, G_IF_SIGMA_COOV_OCOV_NO0_X38)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x38, G_IF_SIGMA_COOV_OCOV_NO1_X38)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.39
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(o1,c1,o2,v1) V2(a,v1,c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,k,o2,o1) X(w,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x39, G_IF_SIGMA_COOV_OCOV_NO0_X39)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x39, G_IF_SIGMA_COOV_OCOV_NO1_X39)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.40
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(o1,w,o2,v1) Y20(a,v1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D2(i,k,o2,o1) X(w,o1,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y20 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y40, G_IF_SIGMA_COOV_OCOV_Y40)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x40, G_IF_SIGMA_COOV_OCOV_NO0_X40)
        (sa, ia, sv1, iv1, T2b.cptr(), Y20.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x40, G_IF_SIGMA_COOV_OCOV_NO1_X40)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.41
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(o1,w,o2,v1) Y21(a,v1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D2(i,k,o2,o1) X(w,o1,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y21 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y41, G_IF_SIGMA_COOV_OCOV_Y41)
      (sc1, ic1, V2_sym.cptr(), Y21.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x41, G_IF_SIGMA_COOV_OCOV_NO0_X41)
        (sa, ia, sv1, iv1, T2b.cptr(), Y21.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x41, G_IF_SIGMA_COOV_OCOV_NO1_X41)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.42
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,c1,k,v1) V2(a,v1,c1,w) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o1) X(w,o1,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x42, G_IF_SIGMA_COOV_OCOV_NO0_X42)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x42, G_IF_SIGMA_COOV_OCOV_NO1_X42)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.43
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,w,k,v1) Y22(a,v1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o1) X(w,o1,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y22 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y43, G_IF_SIGMA_COOV_OCOV_Y43)
      (sc1, ic1, V2_sym.cptr(), Y22.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x43, G_IF_SIGMA_COOV_OCOV_NO0_X43)
        (sa, ia, sv1, iv1, T2b.cptr(), Y22.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x43, G_IF_SIGMA_COOV_OCOV_NO1_X43)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.44
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,w,k,v1) Y23(a,v1) 
  //* S2(w,i,k,a)  <--  (    1.00000000) D1(i,o1) X(w,o1,k,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y23 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_y44, G_IF_SIGMA_COOV_OCOV_Y44)
      (sc1, ic1, V2_sym.cptr(), Y23.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x44, G_IF_SIGMA_COOV_OCOV_NO0_X44)
        (sa, ia, sv1, iv1, T2b.cptr(), Y23.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x44, G_IF_SIGMA_COOV_OCOV_NO1_X44)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.45
  //* X(w,o1,o2,a)  <--  (    1.00000000)  T2(o1,c1,o2,v1) V2(a,w,c1,v1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D2(i,k,o2,o1) X(w,o1,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x45, G_IF_SIGMA_COOV_OCOV_NO0_X45)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x45, G_IF_SIGMA_COOV_OCOV_NO1_X45)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.46
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,c1,k,v1) V2(a,w,c1,v1) 
  //* S2(w,i,k,a)  <--  (   -2.00000000) D1(i,o1) X(w,o1,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x46, G_IF_SIGMA_COOV_OCOV_NO0_X46)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x46, G_IF_SIGMA_COOV_OCOV_NO1_X46)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.47
  //* X(i,k,o1,o4)  <--  (    1.00000000)  D4(o2,o5,i,k,o1,o4,o3,o6) V2(o2,o5,o3,o6) 
  //* S2(w,i,k,a)  <--  (   -0.50000000) T2(o4,w,o1,a) X(i,k,o1,o4) 
  orz::DTensor X(nocc, nocc, nocc, nocc);
  orz::DTensor Xaaaa = orz::ct::sympack_Xaaaa(symblockinfo, 0, X);
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io2);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io2, so2, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      // Load D4 from disk, or GA ....                                                     
      int imoi = amo2imo[io2] - nclosed;                              
      int imoj = amo2imo[io5] - nclosed;                              
                                                                                           
      orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice()).copy();    
      rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io2, so2, io5, so5, rdm4_ij_sliced);    
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so2, so5, io2, io5, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_sigma_coov_ocov_no0_x47, G_IF_SIGMA_COOV_OCOV_NO0_X47)
        (so2, io2, so5, io5, V2_sym.cptr(), Xaaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x47, G_IF_SIGMA_COOV_OCOV_NO1_X47)
      (sa, ia, T2b.cptr(), Xaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.48
  //* X(i,o3)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(o1,o4,o2,o5) 
  //* S2(w,i,k,a)  <--  (   -0.50000000) T2(o3,w,k,a) X(i,o3) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_coov_ocov_no0_x48, G_IF_SIGMA_COOV_OCOV_NO0_X48)
      (so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_coov_ocov_no1_x48, G_IF_SIGMA_COOV_OCOV_NO1_X48)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.49
  //* X(i,o4,o1,k)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(k,o3,o2,o5) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o1,w,o4,a) X(i,o4,o1,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x49, G_IF_SIGMA_COOV_OCOV_NO0_X49)
      (sk, ik, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x49, G_IF_SIGMA_COOV_OCOV_NO1_X49)
        (sa, ia, sk, ik, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.50
  //* X(i,k,o2,o1)  <--  (    1.00000000)  D3(i,k,o4,o2,o5,o3) V2(o1,o4,o3,o5) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o2,w,o1,a) X(i,k,o2,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x50, G_IF_SIGMA_COOV_OCOV_NO0_X50)
      (so1, io1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x50, G_IF_SIGMA_COOV_OCOV_NO1_X50)
        (sa, ia, so1, io1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.51
  //* X(i,o3,k,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(k,o1,o2,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o3,w,o1,a) X(i,o3,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x51, G_IF_SIGMA_COOV_OCOV_NO0_X51)
      (sk, ik, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x51, G_IF_SIGMA_COOV_OCOV_NO1_X51)
        (sa, ia, sk, ik, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.52
  //* X(i,o2,k,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(k,o3,o1,o4) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o2,w,o1,a) X(i,o2,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_coov_ocov_no0_x52, G_IF_SIGMA_COOV_OCOV_NO0_X52)
      (sk, ik, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x52, G_IF_SIGMA_COOV_OCOV_NO1_X52)
        (sa, ia, sk, ik, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.53
  //* X(w,o2,o4,o1,o3,a)  <--  (    1.00000000)  T2(o2,w,o4,v1) V2(a,v1,o1,o3) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D3(i,k,o3,o1,o4,o2) X(w,o2,o4,o1,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x53, G_IF_SIGMA_COOV_OCOV_NO0_X53)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x53, G_IF_SIGMA_COOV_OCOV_NO1_X53)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.54
  //* X(i,o2,a,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,v1,o1,o3) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o2,w,k,v1) X(i,o2,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x54, G_IF_SIGMA_COOV_OCOV_NO0_X54)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x54, G_IF_SIGMA_COOV_OCOV_NO1_X54)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.55
  //* X(w,o1,o3,k,o2,a)  <--  (    1.00000000)  T2(o1,w,o3,v1) V2(a,v1,k,o2) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,o2,o3,o1) X(w,o1,o3,k,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x55, G_IF_SIGMA_COOV_OCOV_NO0_X55)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x55, G_IF_SIGMA_COOV_OCOV_NO1_X55)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.56
  //* X(w,o2,o3,a)  <--  (    1.00000000)  T2(o2,w,o1,v1) V2(a,v1,o1,o3) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,k,o3,o2) X(w,o2,o3,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x56, G_IF_SIGMA_COOV_OCOV_NO0_X56)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x56, G_IF_SIGMA_COOV_OCOV_NO1_X56)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.57
  //* X(w,o2,k,a)  <--  (    1.00000000)  T2(o2,w,o1,v1) V2(a,v1,k,o1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D1(i,o2) X(w,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x57, G_IF_SIGMA_COOV_OCOV_NO0_X57)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x57, G_IF_SIGMA_COOV_OCOV_NO1_X57)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.58
  //* X(w,o4,o2,o3,o1,a)  <--  (    1.00000000)  T2(o4,w,o2,v1) V2(a,o3,o1,v1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D3(i,o3,o1,k,o2,o4) X(w,o4,o2,o3,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x58, G_IF_SIGMA_COOV_OCOV_NO0_X58)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x58, G_IF_SIGMA_COOV_OCOV_NO1_X58)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.59
  //* X(i,o1,a,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,o2,o3,v1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) T2(o1,w,k,v1) X(i,o1,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x59, G_IF_SIGMA_COOV_OCOV_NO0_X59)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no1_x59, G_IF_SIGMA_COOV_OCOV_NO1_X59)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.60
  //* X(w,o1,o3,o2,k,a)  <--  (    1.00000000)  T2(o1,w,o3,v1) V2(a,o2,k,v1) 
  //* S2(w,i,k,a)  <--  (    2.00000000) D2(i,o2,o3,o1) X(w,o1,o3,o2,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x60, G_IF_SIGMA_COOV_OCOV_NO0_X60)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x60, G_IF_SIGMA_COOV_OCOV_NO1_X60)
      (sa, ia, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.61
  //* X(w,o2,o1,a)  <--  (    1.00000000)  T2(o2,w,o3,v1) V2(a,o3,o1,v1) 
  //* S2(w,i,k,a)  <--  (   -1.00000000) D2(i,o2,o1,k) X(w,o2,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x61, G_IF_SIGMA_COOV_OCOV_NO0_X61)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x61, G_IF_SIGMA_COOV_OCOV_NO1_X61)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.62
  //* X(w,o1,k,a)  <--  (    1.00000000)  T2(o1,w,o2,v1) V2(a,o2,k,v1) 
  //* S2(w,i,k,a)  <--  (    2.00000000) D1(i,o1) X(w,o1,k,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_coov_ocov_no0_x62, G_IF_SIGMA_COOV_OCOV_NO0_X62)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_coov_ocov_no1_x62, G_IF_SIGMA_COOV_OCOV_NO1_X62)
      (sa, ia, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }

  return retval; 
} 
