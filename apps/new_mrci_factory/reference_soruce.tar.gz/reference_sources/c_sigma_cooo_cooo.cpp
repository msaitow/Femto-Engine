                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_cooo_cooo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//    o__ __o__/_                            o                         
//   <|    v                                <|>                        
//   < >                                    < >                        
//    |         o__  __o   \o__ __o__ __o    |        o__ __o         
//    o__/_    /v      |>   |     |     |>   o__/_   /v     v\        
//    |       />      //   / \   / \   / \   |      />       <\    
//   <o>      \o    o/     \o/   \o/   \o/   |      \         /   
//    |        v\  /v __o   |     |     |    o       o       o        
//   / \        <\/> __/>  / \   / \   / \   <\__    <\__ __/>  

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_cooo_cooo(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::DTensor &rdm4,                                                 
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma,
                                  const double Ecas) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             
  orz::DTensor rdm4_sym;                                                                                        


  {
  // No.0
  //* X(w,o1,o2,o3)  <--  (    1.00000000)  T2(c1,o1,o2,o3) h(c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o2,k,o3,o1) X(w,o1,o2,o3) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x0, G_IF_SIGMA_COOO_COOO_NO0_X0)
      (so3, io3, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x0, G_IF_SIGMA_COOO_COOO_NO1_X0)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.1
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(c1,o1,k,o2) h(c1,w) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so2, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x1, G_IF_SIGMA_COOO_COOO_NO0_X1)
      (so2, io2, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x1, G_IF_SIGMA_COOO_COOO_NO1_X1)
        (sm, im, so2, io2, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.2
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(c1,o1,o2,k) h(c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x2, G_IF_SIGMA_COOO_COOO_NO0_X2)
      (sk, ik, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x2, G_IF_SIGMA_COOO_COOO_NO1_X2)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.3
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(c1,o1,m,o2) h(c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o2,o1) X(w,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so2, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x3, G_IF_SIGMA_COOO_COOO_NO0_X3)
        (sm, im, so2, io2, T2b.cptr(), moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x3, G_IF_SIGMA_COOO_COOO_NO1_X3)
        (sm, im, so2, io2, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.4
  //* X(w,o1,o2,m)  <--  (    1.00000000)  T2(c1,o1,o2,m) h(c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o1,o2,k) X(w,o1,o2,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x4, G_IF_SIGMA_COOO_COOO_NO0_X4)
      (sm, im, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x4, G_IF_SIGMA_COOO_COOO_NO1_X4)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.5
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(c1,o1,k,m) h(c1,w) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o1) X(w,o1,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x5, G_IF_SIGMA_COOO_COOO_NO0_X5)
      (sm, im, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x5, G_IF_SIGMA_COOO_COOO_NO1_X5)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.6
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(c1,o1,m,k) h(c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o1) X(w,o1,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x6, G_IF_SIGMA_COOO_COOO_NO0_X6)
        (sk, ik, sm, im, T2b.cptr(), moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x6, G_IF_SIGMA_COOO_COOO_NO1_X6)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.7
  //* X(w,o2,o4,o3)  <--  (    1.00000000)  T2(w,o2,o1,o4) h(o3,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o4,o3) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x7, G_IF_SIGMA_COOO_COOO_NO0_X7)
      (so4, io4, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x7, G_IF_SIGMA_COOO_COOO_NO1_X7)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.8
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(w,o2,o1,k) h(o3,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x8, G_IF_SIGMA_COOO_COOO_NO0_X8)
      (sk, ik, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x8, G_IF_SIGMA_COOO_COOO_NO1_X8)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.9
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(w,o2,o1,o3) h(k,o1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x9, G_IF_SIGMA_COOO_COOO_NO0_X9)
      (so3, io3, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x9, G_IF_SIGMA_COOO_COOO_NO1_X9)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.10
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(w,o2,o1,o3) Y0(k,o1) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y0 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y10, G_IF_SIGMA_COOO_COOO_Y10)
      (sc1, ic1, V2_sym.cptr(), Y0.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x10, G_IF_SIGMA_COOO_COOO_NO0_X10)
      (so3, io3, T2b.cptr(), Y0.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x10, G_IF_SIGMA_COOO_COOO_NO1_X10)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.11
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(w,o2,o1,o3) Y1(k,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y1 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y11, G_IF_SIGMA_COOO_COOO_Y11)
      (sc1, ic1, V2_sym.cptr(), Y1.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x11, G_IF_SIGMA_COOO_COOO_NO0_X11)
      (so3, io3, T2b.cptr(), Y1.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x11, G_IF_SIGMA_COOO_COOO_NO1_X11)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.12
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(w,o2,o1,m) h(o3,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o2,o3,k) X(w,o2,m,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x12, G_IF_SIGMA_COOO_COOO_NO0_X12)
      (sm, im, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x12, G_IF_SIGMA_COOO_COOO_NO1_X12)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.13
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(w,o2,o1,o3) h(m,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o3,o2) X(w,o2,o3,m) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x13, G_IF_SIGMA_COOO_COOO_NO0_X13)
        (sm, im, so3, io3, T2b.cptr(), moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x13, G_IF_SIGMA_COOO_COOO_NO1_X13)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.14
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(w,o2,o1,k) h(m,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o2) X(w,o2,k,m) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x14, G_IF_SIGMA_COOO_COOO_NO0_X14)
        (sk, ik, sm, im, T2b.cptr(), moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x14, G_IF_SIGMA_COOO_COOO_NO1_X14)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.15
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(w,o2,o1,m) h(k,o1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o2) X(w,o2,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x15, G_IF_SIGMA_COOO_COOO_NO0_X15)
      (sm, im, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x15, G_IF_SIGMA_COOO_COOO_NO1_X15)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.16
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(w,o2,o1,m) Y2(k,o1) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D1(i,o2) X(w,o2,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y2 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y16, G_IF_SIGMA_COOO_COOO_Y16)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x16, G_IF_SIGMA_COOO_COOO_NO0_X16)
      (sm, im, T2b.cptr(), Y2.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x16, G_IF_SIGMA_COOO_COOO_NO1_X16)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.17
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(w,o2,o1,m) Y3(k,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y3 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y17, G_IF_SIGMA_COOO_COOO_Y17)
      (sc1, ic1, V2_sym.cptr(), Y3.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x17, G_IF_SIGMA_COOO_COOO_NO0_X17)
      (sm, im, T2b.cptr(), Y3.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x17, G_IF_SIGMA_COOO_COOO_NO1_X17)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.18
  //* X(w,o2,o3,o4)  <--  (    1.00000000)  T2(w,o2,o3,o1) h(o4,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o3,o4) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x18, G_IF_SIGMA_COOO_COOO_NO0_X18)
      (so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x18, G_IF_SIGMA_COOO_COOO_NO1_X18)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.19
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(w,o2,k,o1) h(o3,o1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x19, G_IF_SIGMA_COOO_COOO_NO0_X19)
      (so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x19, G_IF_SIGMA_COOO_COOO_NO1_X19)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.20
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(w,o2,k,o1) Y4(o1,o3) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y4 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y20, G_IF_SIGMA_COOO_COOO_Y20)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x20, G_IF_SIGMA_COOO_COOO_NO0_X20)
      (so1, io1, T2b.cptr(), Y4.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x20, G_IF_SIGMA_COOO_COOO_NO1_X20)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.21
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(w,o2,k,o1) Y5(o1,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y5 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y21, G_IF_SIGMA_COOO_COOO_Y21)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x21, G_IF_SIGMA_COOO_COOO_NO0_X21)
      (so1, io1, T2b.cptr(), Y5.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x21, G_IF_SIGMA_COOO_COOO_NO1_X21)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.22
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(w,o2,o3,o1) h(k,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x22, G_IF_SIGMA_COOO_COOO_NO0_X22)
      (so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x22, G_IF_SIGMA_COOO_COOO_NO1_X22)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.23
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(w,o2,m,o1) h(o3,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o3,o2) X(w,o2,m,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x23, G_IF_SIGMA_COOO_COOO_NO0_X23)
        (sm, im, so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x23, G_IF_SIGMA_COOO_COOO_NO1_X23)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.24
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(w,o2,o3,o1) h(m,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o2,o3,k) X(w,o2,o3,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x24, G_IF_SIGMA_COOO_COOO_NO0_X24)
        (sm, im, so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x24, G_IF_SIGMA_COOO_COOO_NO1_X24)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.25
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(w,o2,k,o1) h(m,o1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o2) X(w,o2,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x25, G_IF_SIGMA_COOO_COOO_NO0_X25)
        (sm, im, so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x25, G_IF_SIGMA_COOO_COOO_NO1_X25)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.26
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(w,o2,k,o1) Y6(m,o1) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D1(i,o2) X(w,o2,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y6 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y26, G_IF_SIGMA_COOO_COOO_Y26)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x26, G_IF_SIGMA_COOO_COOO_NO0_X26)
        (sm, im, so1, io1, T2b.cptr(), Y6.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x26, G_IF_SIGMA_COOO_COOO_NO1_X26)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.27
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(w,o2,k,o1) Y7(m,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y7 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y27, G_IF_SIGMA_COOO_COOO_Y27)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x27, G_IF_SIGMA_COOO_COOO_NO0_X27)
        (sm, im, so1, io1, T2b.cptr(), Y7.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x27, G_IF_SIGMA_COOO_COOO_NO1_X27)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.28
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(w,o2,m,o1) h(k,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o2) X(w,o2,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x28, G_IF_SIGMA_COOO_COOO_NO0_X28)
        (sm, im, so1, io1, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x28, G_IF_SIGMA_COOO_COOO_NO1_X28)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.29
  //* X(w,o1,o2,o3)  <--  (    1.00000000)  T2(w,o4,o1,o2) h(o3,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o1,k,o2,o3) X(w,o1,o2,o3) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so2, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x29, G_IF_SIGMA_COOO_COOO_NO0_X29)
      (so2, io2, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x29, G_IF_SIGMA_COOO_COOO_NO1_X29)
        (sm, im, so2, io2, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.30
  //* X(w,k,o3,o2)  <--  (    1.00000000)  T2(w,o1,k,o3) h(o2,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,k,o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x30, G_IF_SIGMA_COOO_COOO_NO0_X30)
      (so3, io3, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x30, G_IF_SIGMA_COOO_COOO_NO1_X30)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.31
  //* X(w,k,o3,o2)  <--  (    1.00000000)  T2(w,o1,k,o3) Y8(o1,o2) 
  //* S2(w,i,k,m)  <--  (   -4.00000000) D2(i,m,o3,o2) X(w,k,o3,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y8 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y31, G_IF_SIGMA_COOO_COOO_Y31)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x31, G_IF_SIGMA_COOO_COOO_NO0_X31)
      (so3, io3, T2b.cptr(), Y8.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x31, G_IF_SIGMA_COOO_COOO_NO1_X31)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.32
  //* X(w,k,o3,o2)  <--  (    1.00000000)  T2(w,o1,k,o3) Y9(o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o3,o2) X(w,k,o3,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y9 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y32, G_IF_SIGMA_COOO_COOO_Y32)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x32, G_IF_SIGMA_COOO_COOO_NO0_X32)
      (so3, io3, T2b.cptr(), Y9.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x32, G_IF_SIGMA_COOO_COOO_NO1_X32)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.33
  //* X(w,o3,k,o2)  <--  (    1.00000000)  T2(w,o1,o3,k) h(o2,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x33, G_IF_SIGMA_COOO_COOO_NO0_X33)
      (sk, ik, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x33, G_IF_SIGMA_COOO_COOO_NO1_X33)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.34
  //* X(w,m,o3,o2)  <--  (    1.00000000)  T2(w,o1,m,o3) h(o2,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,m,o3,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so3, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x34, G_IF_SIGMA_COOO_COOO_NO0_X34)
        (sm, im, so3, io3, T2b.cptr(), moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x34, G_IF_SIGMA_COOO_COOO_NO1_X34)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.35
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(w,o3,o1,m) h(o2,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o1,k) X(w,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x35, G_IF_SIGMA_COOO_COOO_NO0_X35)
      (sm, im, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x35, G_IF_SIGMA_COOO_COOO_NO1_X35)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.36
  //* X(w,k,m,o2)  <--  (    1.00000000)  T2(w,o1,k,m) h(o2,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,k,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x36, G_IF_SIGMA_COOO_COOO_NO0_X36)
      (sm, im, T2b.cptr(), moint1_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x36, G_IF_SIGMA_COOO_COOO_NO1_X36)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.37
  //* X(w,k,m,o2)  <--  (    1.00000000)  T2(w,o1,k,m) Y10(o1,o2) 
  //* S2(w,i,k,m)  <--  (   -4.00000000) D1(i,o2) X(w,k,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y10 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y37, G_IF_SIGMA_COOO_COOO_Y37)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x37, G_IF_SIGMA_COOO_COOO_NO0_X37)
      (sm, im, T2b.cptr(), Y10.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x37, G_IF_SIGMA_COOO_COOO_NO1_X37)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.38
  //* X(w,k,m,o2)  <--  (    1.00000000)  T2(w,o1,k,m) Y11(o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o2) X(w,k,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y11 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y38, G_IF_SIGMA_COOO_COOO_Y38)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x38, G_IF_SIGMA_COOO_COOO_NO0_X38)
      (sm, im, T2b.cptr(), Y11.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x38, G_IF_SIGMA_COOO_COOO_NO1_X38)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.39
  //* X(w,m,k,o1)  <--  (    1.00000000)  T2(w,o2,m,k) h(o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o1) X(w,m,k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x39, G_IF_SIGMA_COOO_COOO_NO0_X39)
        (sk, ik, sm, im, T2b.cptr(), moint1_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x39, G_IF_SIGMA_COOO_COOO_NO1_X39)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.40
  //* X(w,o1,o2,o3)  <--  (    1.00000000)  T2(c2,o1,o2,o3) Y12(c2,w) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D3(i,m,o2,k,o3,o1) X(w,o1,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y12 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y40, G_IF_SIGMA_COOO_COOO_Y40)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x40, G_IF_SIGMA_COOO_COOO_NO0_X40)
      (so3, io3, T2b.cptr(), Y12.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x40, G_IF_SIGMA_COOO_COOO_NO1_X40)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.41
  //* X(w,o1,o2,o3)  <--  (    1.00000000)  T2(c2,o1,o2,o3) Y13(c2,w) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o2,k,o3,o1) X(w,o1,o2,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y13 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y41, G_IF_SIGMA_COOO_COOO_Y41)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x41, G_IF_SIGMA_COOO_COOO_NO0_X41)
      (so3, io3, T2b.cptr(), Y13.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x41, G_IF_SIGMA_COOO_COOO_NO1_X41)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.42
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(c2,o1,k,o2) Y14(c2,w) 
  //* S2(w,i,k,m)  <--  (   -4.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y14 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y42, G_IF_SIGMA_COOO_COOO_Y42)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so2, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x42, G_IF_SIGMA_COOO_COOO_NO0_X42)
      (so2, io2, T2b.cptr(), Y14.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x42, G_IF_SIGMA_COOO_COOO_NO1_X42)
        (sm, im, so2, io2, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.43
  //* X(w,o1,k,o2)  <--  (    1.00000000)  T2(c2,o1,k,o2) Y15(c2,w) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o2,o1) X(w,o1,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y15 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y43, G_IF_SIGMA_COOO_COOO_Y43)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    T2b = T2.get_amp2(io2);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so2, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x43, G_IF_SIGMA_COOO_COOO_NO0_X43)
      (so2, io2, T2b.cptr(), Y15.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x43, G_IF_SIGMA_COOO_COOO_NO1_X43)
        (sm, im, so2, io2, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.44
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(c2,o1,o2,k) Y16(c2,w) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y16 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y44, G_IF_SIGMA_COOO_COOO_Y44)
      (sc1, ic1, V2_sym.cptr(), Y16.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x44, G_IF_SIGMA_COOO_COOO_NO0_X44)
      (sk, ik, T2b.cptr(), Y16.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x44, G_IF_SIGMA_COOO_COOO_NO1_X44)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.45
  //* X(w,o1,o2,k)  <--  (    1.00000000)  T2(c2,o1,o2,k) Y17(c2,w) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o2,o1) X(w,o1,o2,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y17 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y45, G_IF_SIGMA_COOO_COOO_Y45)
      (sc1, ic1, V2_sym.cptr(), Y17.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x45, G_IF_SIGMA_COOO_COOO_NO0_X45)
      (sk, ik, T2b.cptr(), Y17.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x45, G_IF_SIGMA_COOO_COOO_NO1_X45)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.46
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(c2,o1,m,o2) Y18(c2,w) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,k,o2,o1) X(w,o1,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y18 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y46, G_IF_SIGMA_COOO_COOO_Y46)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so2, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x46, G_IF_SIGMA_COOO_COOO_NO0_X46)
        (sm, im, so2, io2, T2b.cptr(), Y18.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x46, G_IF_SIGMA_COOO_COOO_NO1_X46)
        (sm, im, so2, io2, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.47
  //* X(w,o1,m,o2)  <--  (    1.00000000)  T2(c2,o1,m,o2) Y19(c2,w) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o2,o1) X(w,o1,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y19 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y47, G_IF_SIGMA_COOO_COOO_Y47)
      (sc1, ic1, V2_sym.cptr(), Y19.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so2, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x47, G_IF_SIGMA_COOO_COOO_NO0_X47)
        (sm, im, so2, io2, T2b.cptr(), Y19.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x47, G_IF_SIGMA_COOO_COOO_NO1_X47)
        (sm, im, so2, io2, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.48
  //* X(w,o1,o2,m)  <--  (    1.00000000)  T2(c2,o1,o2,m) Y20(c2,w) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,o1,o2,k) X(w,o1,o2,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y20 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y48, G_IF_SIGMA_COOO_COOO_Y48)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x48, G_IF_SIGMA_COOO_COOO_NO0_X48)
      (sm, im, T2b.cptr(), Y20.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x48, G_IF_SIGMA_COOO_COOO_NO1_X48)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.49
  //* X(w,o1,o2,m)  <--  (    1.00000000)  T2(c2,o1,o2,m) Y21(c2,w) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o1,o2,k) X(w,o1,o2,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y21 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y49, G_IF_SIGMA_COOO_COOO_Y49)
      (sc1, ic1, V2_sym.cptr(), Y21.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x49, G_IF_SIGMA_COOO_COOO_NO0_X49)
      (sm, im, T2b.cptr(), Y21.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x49, G_IF_SIGMA_COOO_COOO_NO1_X49)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.50
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(c2,o1,k,m) Y22(c2,w) 
  //* S2(w,i,k,m)  <--  (   -4.00000000) D1(i,o1) X(w,o1,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y22 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y50, G_IF_SIGMA_COOO_COOO_Y50)
      (sc1, ic1, V2_sym.cptr(), Y22.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x50, G_IF_SIGMA_COOO_COOO_NO0_X50)
      (sm, im, T2b.cptr(), Y22.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x50, G_IF_SIGMA_COOO_COOO_NO1_X50)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.51
  //* X(w,o1,k,m)  <--  (    1.00000000)  T2(c2,o1,k,m) Y23(c2,w) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o1) X(w,o1,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y23 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y51, G_IF_SIGMA_COOO_COOO_Y51)
      (sc1, ic1, V2_sym.cptr(), Y23.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x51, G_IF_SIGMA_COOO_COOO_NO0_X51)
      (sm, im, T2b.cptr(), Y23.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x51, G_IF_SIGMA_COOO_COOO_NO1_X51)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.52
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(c2,o1,m,k) Y24(c2,w) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o1) X(w,o1,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y24 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y52, G_IF_SIGMA_COOO_COOO_Y52)
      (sc1, ic1, V2_sym.cptr(), Y24.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x52, G_IF_SIGMA_COOO_COOO_NO0_X52)
        (sk, ik, sm, im, T2b.cptr(), Y24.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x52, G_IF_SIGMA_COOO_COOO_NO1_X52)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.53
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(c2,o1,m,k) Y25(c2,w) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o1) X(w,o1,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y25 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y53, G_IF_SIGMA_COOO_COOO_Y53)
      (sc1, ic1, V2_sym.cptr(), Y25.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x53, G_IF_SIGMA_COOO_COOO_NO0_X53)
        (sk, ik, sm, im, T2b.cptr(), Y25.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x53, G_IF_SIGMA_COOO_COOO_NO1_X53)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.54
  //* X(w,o2,o4,o3)  <--  (    1.00000000)  T2(c1,o2,o1,o4) V2(c1,w,o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o4,o3) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x54, G_IF_SIGMA_COOO_COOO_NO0_X54)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x54, G_IF_SIGMA_COOO_COOO_NO1_X54)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.55
  //* X(w,o2,o4,o3)  <--  (    1.00000000)  T2(w,o2,o1,o4) Y26(o1,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o4,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y26 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y55, G_IF_SIGMA_COOO_COOO_Y55)
      (sc1, ic1, V2_sym.cptr(), Y26.cptr(), nir, nsym, psym);
  }
  }
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x55, G_IF_SIGMA_COOO_COOO_NO0_X55)
      (so4, io4, T2b.cptr(), Y26.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x55, G_IF_SIGMA_COOO_COOO_NO1_X55)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.56
  //* X(w,o2,o4,o3)  <--  (    1.00000000)  T2(w,o2,o1,o4) Y27(o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o4,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y27 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y56, G_IF_SIGMA_COOO_COOO_Y56)
      (sc1, ic1, V2_sym.cptr(), Y27.cptr(), nir, nsym, psym);
  }
  }
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x56, G_IF_SIGMA_COOO_COOO_NO0_X56)
      (so4, io4, T2b.cptr(), Y27.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x56, G_IF_SIGMA_COOO_COOO_NO1_X56)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.57
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(c1,o2,o1,k) V2(c1,w,o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x57, G_IF_SIGMA_COOO_COOO_NO0_X57)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x57, G_IF_SIGMA_COOO_COOO_NO1_X57)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.58
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(w,o2,o1,k) Y28(o1,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y28 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y58, G_IF_SIGMA_COOO_COOO_Y58)
      (sc1, ic1, V2_sym.cptr(), Y28.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x58, G_IF_SIGMA_COOO_COOO_NO0_X58)
      (sk, ik, T2b.cptr(), Y28.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x58, G_IF_SIGMA_COOO_COOO_NO1_X58)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.59
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(w,o2,o1,k) Y29(o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y29 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y59, G_IF_SIGMA_COOO_COOO_Y59)
      (sc1, ic1, V2_sym.cptr(), Y29.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x59, G_IF_SIGMA_COOO_COOO_NO0_X59)
      (sk, ik, T2b.cptr(), Y29.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x59, G_IF_SIGMA_COOO_COOO_NO1_X59)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.60
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(c1,o2,o1,o3) V2(c1,w,k,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x60, G_IF_SIGMA_COOO_COOO_NO0_X60)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x60, G_IF_SIGMA_COOO_COOO_NO1_X60)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.61
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(c1,o2,o1,o3) V2(c1,o1,w,k) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x61, G_IF_SIGMA_COOO_COOO_NO0_X61)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x61, G_IF_SIGMA_COOO_COOO_NO1_X61)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.62
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(c1,o2,o1,m) V2(c1,w,o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o2,m,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x62, G_IF_SIGMA_COOO_COOO_NO0_X62)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x62, G_IF_SIGMA_COOO_COOO_NO1_X62)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.63
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(w,o2,o1,m) Y30(o1,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,o3,k) X(w,o2,m,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y30 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y63, G_IF_SIGMA_COOO_COOO_Y63)
      (sc1, ic1, V2_sym.cptr(), Y30.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x63, G_IF_SIGMA_COOO_COOO_NO0_X63)
      (sm, im, T2b.cptr(), Y30.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x63, G_IF_SIGMA_COOO_COOO_NO1_X63)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.64
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(w,o2,o1,m) Y31(o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o2,m,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y31 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y64, G_IF_SIGMA_COOO_COOO_Y64)
      (sc1, ic1, V2_sym.cptr(), Y31.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x64, G_IF_SIGMA_COOO_COOO_NO0_X64)
      (sm, im, T2b.cptr(), Y31.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x64, G_IF_SIGMA_COOO_COOO_NO1_X64)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.65
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(c1,o2,o1,o3) V2(m,o1,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,o3,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x65, G_IF_SIGMA_COOO_COOO_NO0_X65)
        (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x65, G_IF_SIGMA_COOO_COOO_NO1_X65)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.66
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(w,o2,o1,o3) Y32(m,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o2,o3,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y32 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y66, G_IF_SIGMA_COOO_COOO_Y66)
      (sc1, ic1, V2_sym.cptr(), Y32.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x66, G_IF_SIGMA_COOO_COOO_NO0_X66)
        (sm, im, so3, io3, T2b.cptr(), Y32.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x66, G_IF_SIGMA_COOO_COOO_NO1_X66)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.67
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(w,o2,o1,o3) Y33(m,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,o3,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y33 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y67, G_IF_SIGMA_COOO_COOO_Y67)
      (sc1, ic1, V2_sym.cptr(), Y33.cptr(), nir, nsym, psym);
  }
  }
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x67, G_IF_SIGMA_COOO_COOO_NO0_X67)
        (sm, im, so3, io3, T2b.cptr(), Y33.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x67, G_IF_SIGMA_COOO_COOO_NO1_X67)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.68
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(c1,o2,o1,k) V2(m,o1,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x68, G_IF_SIGMA_COOO_COOO_NO0_X68)
        (sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x68, G_IF_SIGMA_COOO_COOO_NO1_X68)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.69
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(w,o2,o1,k) Y34(m,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y34 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y69, G_IF_SIGMA_COOO_COOO_Y69)
      (sc1, ic1, V2_sym.cptr(), Y34.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x69, G_IF_SIGMA_COOO_COOO_NO0_X69)
        (sk, ik, sm, im, T2b.cptr(), Y34.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x69, G_IF_SIGMA_COOO_COOO_NO1_X69)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.70
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(w,o2,o1,k) Y35(m,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y35 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y70, G_IF_SIGMA_COOO_COOO_Y70)
      (sc1, ic1, V2_sym.cptr(), Y35.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x70, G_IF_SIGMA_COOO_COOO_NO0_X70)
        (sk, ik, sm, im, T2b.cptr(), Y35.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x70, G_IF_SIGMA_COOO_COOO_NO1_X70)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.71
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(c1,o2,o1,m) V2(c1,w,k,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x71, G_IF_SIGMA_COOO_COOO_NO0_X71)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x71, G_IF_SIGMA_COOO_COOO_NO1_X71)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.72
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(c1,o2,o1,m) V2(c1,o1,w,k) 
  //* S2(w,i,k,m)  <--  (    4.00000000) D1(i,o2) X(w,o2,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x72, G_IF_SIGMA_COOO_COOO_NO0_X72)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x72, G_IF_SIGMA_COOO_COOO_NO1_X72)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.73
  //* X(w,o2,o3,o4)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(o1,o4,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o3,o4) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x73, G_IF_SIGMA_COOO_COOO_NO0_X73)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x73, G_IF_SIGMA_COOO_COOO_NO1_X73)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.74
  //* X(w,o2,o3,o4)  <--  (    1.00000000)  T2(w,o2,o3,o1) Y36(o1,o4) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o3,o4) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y36 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y74, G_IF_SIGMA_COOO_COOO_Y74)
      (sc1, ic1, V2_sym.cptr(), Y36.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x74, G_IF_SIGMA_COOO_COOO_NO0_X74)
      (so1, io1, T2b.cptr(), Y36.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x74, G_IF_SIGMA_COOO_COOO_NO1_X74)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.75
  //* X(w,o2,o3,o4)  <--  (    1.00000000)  T2(w,o2,o3,o1) Y37(o1,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o3,o4) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y37 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y75, G_IF_SIGMA_COOO_COOO_Y75)
      (sc1, ic1, V2_sym.cptr(), Y37.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x75, G_IF_SIGMA_COOO_COOO_NO0_X75)
      (so1, io1, T2b.cptr(), Y37.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x75, G_IF_SIGMA_COOO_COOO_NO1_X75)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.76
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(c1,o2,k,o1) V2(o1,o3,c1,w) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x76, G_IF_SIGMA_COOO_COOO_NO0_X76)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x76, G_IF_SIGMA_COOO_COOO_NO1_X76)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.77
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(c1,o2,k,o1) V2(o1,c1,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x77, G_IF_SIGMA_COOO_COOO_NO0_X77)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x77, G_IF_SIGMA_COOO_COOO_NO1_X77)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.78
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(o1,k,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x78, G_IF_SIGMA_COOO_COOO_NO0_X78)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x78, G_IF_SIGMA_COOO_COOO_NO1_X78)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.79
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(w,o2,o3,o1) Y38(k,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y38 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y79, G_IF_SIGMA_COOO_COOO_Y79)
      (sc1, ic1, V2_sym.cptr(), Y38.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x79, G_IF_SIGMA_COOO_COOO_NO0_X79)
      (so1, io1, T2b.cptr(), Y38.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x79, G_IF_SIGMA_COOO_COOO_NO1_X79)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.80
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(w,o2,o3,o1) Y39(k,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y39 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y80, G_IF_SIGMA_COOO_COOO_Y80)
      (sc1, ic1, V2_sym.cptr(), Y39.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x80, G_IF_SIGMA_COOO_COOO_NO0_X80)
      (so1, io1, T2b.cptr(), Y39.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x80, G_IF_SIGMA_COOO_COOO_NO1_X80)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.81
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(c1,o2,m,o1) V2(o1,o3,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,m,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x81, G_IF_SIGMA_COOO_COOO_NO0_X81)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x81, G_IF_SIGMA_COOO_COOO_NO1_X81)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.82
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(w,o2,m,o1) Y40(o1,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o2,m,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y40 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y82, G_IF_SIGMA_COOO_COOO_Y82)
      (sc1, ic1, V2_sym.cptr(), Y40.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x82, G_IF_SIGMA_COOO_COOO_NO0_X82)
        (sm, im, so1, io1, T2b.cptr(), Y40.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x82, G_IF_SIGMA_COOO_COOO_NO1_X82)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.83
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(w,o2,m,o1) Y41(o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,m,o3) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y41 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y83, G_IF_SIGMA_COOO_COOO_Y83)
      (sc1, ic1, V2_sym.cptr(), Y41.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x83, G_IF_SIGMA_COOO_COOO_NO0_X83)
        (sm, im, so1, io1, T2b.cptr(), Y41.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x83, G_IF_SIGMA_COOO_COOO_NO1_X83)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.84
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(m,o1,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o2,o3,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x84, G_IF_SIGMA_COOO_COOO_NO0_X84)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x84, G_IF_SIGMA_COOO_COOO_NO1_X84)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.85
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(w,o2,o3,o1) Y42(m,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,o3,k) X(w,o2,o3,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y42 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y85, G_IF_SIGMA_COOO_COOO_Y85)
      (sc1, ic1, V2_sym.cptr(), Y42.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x85, G_IF_SIGMA_COOO_COOO_NO0_X85)
        (sm, im, so1, io1, T2b.cptr(), Y42.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x85, G_IF_SIGMA_COOO_COOO_NO1_X85)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.86
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(w,o2,o3,o1) Y43(m,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o2,o3,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y43 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y86, G_IF_SIGMA_COOO_COOO_Y86)
      (sc1, ic1, V2_sym.cptr(), Y43.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x86, G_IF_SIGMA_COOO_COOO_NO0_X86)
        (sm, im, so1, io1, T2b.cptr(), Y43.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x86, G_IF_SIGMA_COOO_COOO_NO1_X86)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.87
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(c1,o2,k,o1) V2(m,o1,c1,w) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x87, G_IF_SIGMA_COOO_COOO_NO0_X87)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x87, G_IF_SIGMA_COOO_COOO_NO1_X87)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.88
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(c1,o2,k,o1) V2(m,w,c1,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o2) X(w,o2,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x88, G_IF_SIGMA_COOO_COOO_NO0_X88)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x88, G_IF_SIGMA_COOO_COOO_NO1_X88)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.89
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(c1,o2,m,o1) V2(o1,k,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o2) X(w,o2,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x89, G_IF_SIGMA_COOO_COOO_NO0_X89)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x89, G_IF_SIGMA_COOO_COOO_NO1_X89)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.90
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(w,o2,m,o1) Y44(k,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y44 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y90, G_IF_SIGMA_COOO_COOO_Y90)
      (sc1, ic1, V2_sym.cptr(), Y44.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x90, G_IF_SIGMA_COOO_COOO_NO0_X90)
        (sm, im, so1, io1, T2b.cptr(), Y44.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x90, G_IF_SIGMA_COOO_COOO_NO1_X90)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.91
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(w,o2,m,o1) Y45(k,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o2) X(w,o2,m,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y45 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y91, G_IF_SIGMA_COOO_COOO_Y91)
      (sc1, ic1, V2_sym.cptr(), Y45.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x91, G_IF_SIGMA_COOO_COOO_NO0_X91)
        (sm, im, so1, io1, T2b.cptr(), Y45.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x91, G_IF_SIGMA_COOO_COOO_NO1_X91)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.92
  //* X(w,o1,o3,o4,o2,o5)  <--  (    1.00000000)  T2(c1,o1,o3,o4) V2(o2,o5,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D4(o2,o5,m,i,k,o3,o1,o4) X(w,o1,o3,o4,o2,o5) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io2);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io2, so2, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      for(int so5 = 0;so5 < nir;++so5){ 
      for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
        orz::DTensor X(nclosed, nocc, nocc);
        orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4^so2^so5, X);
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x92, G_IF_SIGMA_COOO_COOO_NO0_X92)
          (so2, io2, so4, io4, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
        for(int sm = 0;sm < nir;++sm){ 
        for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
          S2b = orz::DTensor(retval.namps_iamp()[im]);
          // Load D4 from disk, or GA ....                                                     
          int imoi = amo2imo[io2] - nclosed;                              
          int imoj = amo2imo[io5] - nclosed;                              
                                                                                               
          orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice()).copy();    
          rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io2, so2, io5, so5, rdm4_ij_sliced);    
          FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so2, so5, io2, io5, rdm4_sym.cptr(), nir, nsym, psym);  
          FC_FUNC(g_if_sigma_cooo_cooo_no1_x92, G_IF_SIGMA_COOO_COOO_NO1_X92)
            (sm, im, so2, io2, so4, io4, so5, io5, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
          retval.acc_amp2(im, S2b);
          FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
        }
        }
      }
      }
    }
    }
  }
  }
  }


  {
  // No.93
  //* X(w,o1,k,o3,o2,o4)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(c1,w,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D3(i,m,o3,o1,o4,o2) X(w,o1,k,o3,o2,o4) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x93, G_IF_SIGMA_COOO_COOO_NO0_X93)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x93, G_IF_SIGMA_COOO_COOO_NO1_X93)
        (sm, im, so3, io3, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.94
  //* X(w,o1,o3,k,o2,o4)  <--  (    1.00000000)  T2(c1,o1,o3,k) V2(c1,w,o2,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,o1,o4,o2) X(w,o1,o3,k,o2,o4) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x94, G_IF_SIGMA_COOO_COOO_NO0_X94)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x94, G_IF_SIGMA_COOO_COOO_NO1_X94)
        (sk, ik, sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.95
  //* X(w,o2,o3,o4,k,o1)  <--  (    1.00000000)  T2(c1,o2,o3,o4) V2(c1,w,k,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,o1,o4,o2) X(w,o2,o3,o4,k,o1) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x95, G_IF_SIGMA_COOO_COOO_NO0_X95)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x95, G_IF_SIGMA_COOO_COOO_NO1_X95)
        (sm, im, so4, io4, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.96
  //* X(w,o1,m,o3,o2,o4)  <--  (    1.00000000)  T2(c1,o1,m,o3) V2(c1,w,o2,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,k,o3,o1,o4,o2) X(w,o1,m,o3,o2,o4) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sm^so3, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x96, G_IF_SIGMA_COOO_COOO_NO0_X96)
          (sc1, ic1, sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x96, G_IF_SIGMA_COOO_COOO_NO1_X96)
        (sm, im, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.97
  //* X(w,o2,o3,m,o1,o4)  <--  (    1.00000000)  T2(c1,o2,o3,m) V2(c1,w,o1,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,o2,o3,k,o4,o1) X(w,o2,o3,m,o1,o4) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x97, G_IF_SIGMA_COOO_COOO_NO0_X97)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x97, G_IF_SIGMA_COOO_COOO_NO1_X97)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.98
  //* X(w,o1,o3,o4,m,o2)  <--  (    1.00000000)  T2(c1,o1,o3,o4) V2(m,o2,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,o2,o3,k,o4,o1) X(w,o1,o3,o4,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x98, G_IF_SIGMA_COOO_COOO_NO0_X98)
        (sm, im, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x98, G_IF_SIGMA_COOO_COOO_NO1_X98)
        (sm, im, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.99
  //* X(c1,w,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) T2(c1,o2,k,m) X(c1,w,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x99, G_IF_SIGMA_COOO_COOO_NO0_X99)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x99, G_IF_SIGMA_COOO_COOO_NO1_X99)
        (sc1, ic1, sm, im, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.100
  //* X(c1,w,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,o1,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(c1,o2,k,m) X(c1,w,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x100, G_IF_SIGMA_COOO_COOO_NO0_X100)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x100, G_IF_SIGMA_COOO_COOO_NO1_X100)
        (sc1, ic1, sm, im, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.101
  //* X(w,o1,k,o3,m,o2)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(m,o2,c1,w) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,o3,o1) X(w,o1,k,o3,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x101, G_IF_SIGMA_COOO_COOO_NO0_X101)
        (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x101, G_IF_SIGMA_COOO_COOO_NO1_X101)
        (sm, im, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.102
  //* X(w,o1,k,o3,m,o2)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(m,w,c1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o1,k,o3,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x102, G_IF_SIGMA_COOO_COOO_NO0_X102)
        (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x102, G_IF_SIGMA_COOO_COOO_NO1_X102)
        (sm, im, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.103
  //* X(w,o1,o3,k,m,o2)  <--  (    1.00000000)  T2(c1,o1,o3,k) V2(m,o2,c1,w) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o1,o3,k,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x103, G_IF_SIGMA_COOO_COOO_NO0_X103)
        (sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x103, G_IF_SIGMA_COOO_COOO_NO1_X103)
        (sk, ik, sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.104
  //* X(c1,w,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(c1,o2,m,k) X(c1,w,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x104, G_IF_SIGMA_COOO_COOO_NO0_X104)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        T2b = T2.get_amp2(ik);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x104, G_IF_SIGMA_COOO_COOO_NO1_X104)
          (sc1, ic1, sk, ik, sm, im, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.105
  //* X(w,o1,m,o3,k,o2)  <--  (    1.00000000)  T2(c1,o1,m,o3) V2(c1,w,k,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o1,m,o3,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sm^so3, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x105, G_IF_SIGMA_COOO_COOO_NO0_X105)
          (sc1, ic1, sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x105, G_IF_SIGMA_COOO_COOO_NO1_X105)
        (sm, im, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.106
  //* X(w,o2,o3,m,k,o1)  <--  (    1.00000000)  T2(c1,o2,o3,m) V2(c1,w,k,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o2,o3,m,k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x106, G_IF_SIGMA_COOO_COOO_NO0_X106)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x106, G_IF_SIGMA_COOO_COOO_NO1_X106)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.107
  //* X(w,o3,o4,o2)  <--  (    1.00000000)  T2(c1,o1,o3,o4) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o3,k,o4,o2) X(w,o3,o4,o2) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x107, G_IF_SIGMA_COOO_COOO_NO0_X107)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x107, G_IF_SIGMA_COOO_COOO_NO1_X107)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.108
  //* X(w,o3,o4,o2)  <--  (    1.00000000)  T2(w,o1,o3,o4) Y46(o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D3(i,m,o3,k,o4,o2) X(w,o3,o4,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y46 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y108, G_IF_SIGMA_COOO_COOO_Y108)
      (sc1, ic1, V2_sym.cptr(), Y46.cptr(), nir, nsym, psym);
  }
  }
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x108, G_IF_SIGMA_COOO_COOO_NO0_X108)
      (so4, io4, T2b.cptr(), Y46.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x108, G_IF_SIGMA_COOO_COOO_NO1_X108)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.109
  //* X(w,o3,o4,o2)  <--  (    1.00000000)  T2(w,o1,o3,o4) Y47(o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o3,k,o4,o2) X(w,o3,o4,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y47 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y109, G_IF_SIGMA_COOO_COOO_Y109)
      (sc1, ic1, V2_sym.cptr(), Y47.cptr(), nir, nsym, psym);
  }
  }
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x109, G_IF_SIGMA_COOO_COOO_NO0_X109)
      (so4, io4, T2b.cptr(), Y47.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x109, G_IF_SIGMA_COOO_COOO_NO1_X109)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.110
  //* X(w,k,o3,o2)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o3,o2) X(w,k,o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x110, G_IF_SIGMA_COOO_COOO_NO0_X110)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x110, G_IF_SIGMA_COOO_COOO_NO1_X110)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.111
  //* X(w,k,o3,o2)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,k,o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x111, G_IF_SIGMA_COOO_COOO_NO0_X111)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x111, G_IF_SIGMA_COOO_COOO_NO1_X111)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.112
  //* X(w,k,o3,o2)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o3,o2) X(w,k,o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x112, G_IF_SIGMA_COOO_COOO_NO0_X112)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x112, G_IF_SIGMA_COOO_COOO_NO1_X112)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.113
  //* X(w,k,o3,o2)  <--  (    1.00000000)  T2(c1,o1,k,o3) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,k,o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x113, G_IF_SIGMA_COOO_COOO_NO0_X113)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x113, G_IF_SIGMA_COOO_COOO_NO1_X113)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.114
  //* X(w,o3,k,o2)  <--  (    1.00000000)  T2(c1,o1,o3,k) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o3,o2) X(w,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x114, G_IF_SIGMA_COOO_COOO_NO0_X114)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x114, G_IF_SIGMA_COOO_COOO_NO1_X114)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.115
  //* X(w,o3,k,o2)  <--  (    1.00000000)  T2(w,o1,o3,k) Y48(o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o3,o2) X(w,o3,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y48 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y115, G_IF_SIGMA_COOO_COOO_Y115)
      (sc1, ic1, V2_sym.cptr(), Y48.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x115, G_IF_SIGMA_COOO_COOO_NO0_X115)
      (sk, ik, T2b.cptr(), Y48.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x115, G_IF_SIGMA_COOO_COOO_NO1_X115)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.116
  //* X(w,o3,k,o2)  <--  (    1.00000000)  T2(w,o1,o3,k) Y49(o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o3,o2) X(w,o3,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y49 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y116, G_IF_SIGMA_COOO_COOO_Y116)
      (sc1, ic1, V2_sym.cptr(), Y49.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x116, G_IF_SIGMA_COOO_COOO_NO0_X116)
      (sk, ik, T2b.cptr(), Y49.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x116, G_IF_SIGMA_COOO_COOO_NO1_X116)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.117
  //* X(w,m,o3,o2)  <--  (    1.00000000)  T2(c1,o1,m,o3) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o3,o2) X(w,m,o3,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so3, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x117, G_IF_SIGMA_COOO_COOO_NO0_X117)
          (sc1, ic1, sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x117, G_IF_SIGMA_COOO_COOO_NO1_X117)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.118
  //* X(w,m,o3,o2)  <--  (    1.00000000)  T2(w,o1,m,o3) Y50(o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,k,o3,o2) X(w,m,o3,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y50 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y118, G_IF_SIGMA_COOO_COOO_Y118)
      (sc1, ic1, V2_sym.cptr(), Y50.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so3, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x118, G_IF_SIGMA_COOO_COOO_NO0_X118)
        (sm, im, so3, io3, T2b.cptr(), Y50.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x118, G_IF_SIGMA_COOO_COOO_NO1_X118)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.119
  //* X(w,m,o3,o2)  <--  (    1.00000000)  T2(w,o1,m,o3) Y51(o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o3,o2) X(w,m,o3,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y51 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y119, G_IF_SIGMA_COOO_COOO_Y119)
      (sc1, ic1, V2_sym.cptr(), Y51.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so3, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x119, G_IF_SIGMA_COOO_COOO_NO0_X119)
        (sm, im, so3, io3, T2b.cptr(), Y51.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x119, G_IF_SIGMA_COOO_COOO_NO1_X119)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.120
  //* X(w,o3,m,o2)  <--  (    1.00000000)  T2(c1,o1,o3,m) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o2,o3,k) X(w,o3,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x120, G_IF_SIGMA_COOO_COOO_NO0_X120)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x120, G_IF_SIGMA_COOO_COOO_NO1_X120)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.121
  //* X(w,o3,m,o2)  <--  (    1.00000000)  T2(w,o1,o3,m) Y52(o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,o2,o3,k) X(w,o3,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y52 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y121, G_IF_SIGMA_COOO_COOO_Y121)
      (sc1, ic1, V2_sym.cptr(), Y52.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x121, G_IF_SIGMA_COOO_COOO_NO0_X121)
      (sm, im, T2b.cptr(), Y52.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x121, G_IF_SIGMA_COOO_COOO_NO1_X121)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.122
  //* X(w,o3,m,o2)  <--  (    1.00000000)  T2(w,o1,o3,m) Y53(o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o2,o3,k) X(w,o3,m,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y53 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y122, G_IF_SIGMA_COOO_COOO_Y122)
      (sc1, ic1, V2_sym.cptr(), Y53.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x122, G_IF_SIGMA_COOO_COOO_NO0_X122)
      (sm, im, T2b.cptr(), Y53.cptr(), Xcaa.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x122, G_IF_SIGMA_COOO_COOO_NO1_X122)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.123
  //* X(w,k,m,o2)  <--  (    1.00000000)  T2(c1,o1,k,m) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o2) X(w,k,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x123, G_IF_SIGMA_COOO_COOO_NO0_X123)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x123, G_IF_SIGMA_COOO_COOO_NO1_X123)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.124
  //* X(w,k,m,o2)  <--  (    1.00000000)  T2(c1,o1,k,m) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,k,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x124, G_IF_SIGMA_COOO_COOO_NO0_X124)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x124, G_IF_SIGMA_COOO_COOO_NO1_X124)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.125
  //* X(w,k,m,o2)  <--  (    1.00000000)  T2(c1,o1,k,m) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o2) X(w,k,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x125, G_IF_SIGMA_COOO_COOO_NO0_X125)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x125, G_IF_SIGMA_COOO_COOO_NO1_X125)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.126
  //* X(w,k,m,o2)  <--  (    1.00000000)  T2(c1,o1,k,m) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o2) X(w,k,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x126, G_IF_SIGMA_COOO_COOO_NO0_X126)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x126, G_IF_SIGMA_COOO_COOO_NO1_X126)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.127
  //* X(w,m,k,o2)  <--  (    1.00000000)  T2(c1,o1,m,k) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o2) X(w,m,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x127, G_IF_SIGMA_COOO_COOO_NO0_X127)
          (sc1, ic1, sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x127, G_IF_SIGMA_COOO_COOO_NO1_X127)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.128
  //* X(w,m,k,o2)  <--  (    1.00000000)  T2(w,o1,m,k) Y54(o1,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o2) X(w,m,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y54 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y128, G_IF_SIGMA_COOO_COOO_Y128)
      (sc1, ic1, V2_sym.cptr(), Y54.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x128, G_IF_SIGMA_COOO_COOO_NO0_X128)
        (sk, ik, sm, im, T2b.cptr(), Y54.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x128, G_IF_SIGMA_COOO_COOO_NO1_X128)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.129
  //* X(w,m,k,o2)  <--  (    1.00000000)  T2(w,o1,m,k) Y55(o1,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o2) X(w,m,k,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y55 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_cooo_cooo_y129, G_IF_SIGMA_COOO_COOO_Y129)
      (sc1, ic1, V2_sym.cptr(), Y55.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x129, G_IF_SIGMA_COOO_COOO_NO0_X129)
        (sk, ik, sm, im, T2b.cptr(), Y55.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x129, G_IF_SIGMA_COOO_COOO_NO1_X129)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.130
  //* X(w,o3,o4,o2)  <--  (    1.00000000)  T2(c1,o1,o3,o4) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,k,o4,o2) X(w,o3,o4,o2) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x130, G_IF_SIGMA_COOO_COOO_NO0_X130)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x130, G_IF_SIGMA_COOO_COOO_NO1_X130)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.131
  //* X(w,o3,k,o2)  <--  (    1.00000000)  T2(c1,o1,o3,k) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,m,o3,o2) X(w,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x131, G_IF_SIGMA_COOO_COOO_NO0_X131)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x131, G_IF_SIGMA_COOO_COOO_NO1_X131)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.132
  //* X(w,m,o3,o2)  <--  (    1.00000000)  T2(c1,o1,m,o3) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,m,o3,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so3, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x132, G_IF_SIGMA_COOO_COOO_NO0_X132)
          (sc1, ic1, sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x132, G_IF_SIGMA_COOO_COOO_NO1_X132)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.133
  //* X(w,o3,m,o2)  <--  (    1.00000000)  T2(c1,o1,o3,m) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o3,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x133, G_IF_SIGMA_COOO_COOO_NO0_X133)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x133, G_IF_SIGMA_COOO_COOO_NO1_X133)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.134
  //* X(w,m,k,o2)  <--  (    1.00000000)  T2(c1,o1,m,k) V2(c1,w,o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D1(i,o2) X(w,m,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x134, G_IF_SIGMA_COOO_COOO_NO0_X134)
          (sc1, ic1, sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x134, G_IF_SIGMA_COOO_COOO_NO1_X134)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.135
  //* X(w,o2,o4,o3)  <--  (    1.00000000)  T2(c1,o2,o1,o4) V2(c1,o1,w,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D3(i,m,o3,k,o4,o2) X(w,o2,o4,o3) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x135, G_IF_SIGMA_COOO_COOO_NO0_X135)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x135, G_IF_SIGMA_COOO_COOO_NO1_X135)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.136
  //* X(w,o2,k,o3)  <--  (    1.00000000)  T2(c1,o2,o1,k) V2(c1,o1,w,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,k,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x136, G_IF_SIGMA_COOO_COOO_NO0_X136)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x136, G_IF_SIGMA_COOO_COOO_NO1_X136)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.137
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(c1,o2,o1,m) V2(c1,o1,w,o3) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,o3,k) X(w,o2,m,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x137, G_IF_SIGMA_COOO_COOO_NO0_X137)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x137, G_IF_SIGMA_COOO_COOO_NO1_X137)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.138
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(c1,o2,o1,o3) V2(m,w,c1,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,k,o3,o2) X(w,o2,o3,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x138, G_IF_SIGMA_COOO_COOO_NO0_X138)
        (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x138, G_IF_SIGMA_COOO_COOO_NO1_X138)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.139
  //* X(w,o2,k,m)  <--  (    1.00000000)  T2(c1,o2,o1,k) V2(m,w,c1,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sk^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x139, G_IF_SIGMA_COOO_COOO_NO0_X139)
        (sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x139, G_IF_SIGMA_COOO_COOO_NO1_X139)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.140
  //* X(w,o2,o3,o4)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(o1,c1,w,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,o2,o4,k) X(w,o2,o3,o4) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x140, G_IF_SIGMA_COOO_COOO_NO0_X140)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x140, G_IF_SIGMA_COOO_COOO_NO1_X140)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.141
  //* X(w,o2,o3,k)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(o1,c1,w,k) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o2,o3,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x141, G_IF_SIGMA_COOO_COOO_NO0_X141)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x141, G_IF_SIGMA_COOO_COOO_NO1_X141)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.142
  //* X(w,o2,m,o3)  <--  (    1.00000000)  T2(c1,o2,m,o1) V2(o1,c1,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,o2,m,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x142, G_IF_SIGMA_COOO_COOO_NO0_X142)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x142, G_IF_SIGMA_COOO_COOO_NO1_X142)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.143
  //* X(w,o2,o3,m)  <--  (    1.00000000)  T2(c1,o2,o3,o1) V2(m,w,c1,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o2,o3,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x143, G_IF_SIGMA_COOO_COOO_NO0_X143)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x143, G_IF_SIGMA_COOO_COOO_NO1_X143)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.144
  //* X(w,o2,m,k)  <--  (    1.00000000)  T2(c1,o2,m,o1) V2(o1,c1,w,k) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,o2,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x144, G_IF_SIGMA_COOO_COOO_NO0_X144)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x144, G_IF_SIGMA_COOO_COOO_NO1_X144)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.145
  //* X(w,o1,o5,o4,o2,o3)  <--  (    1.00000000)  T2(c1,o1,o5,o4) V2(o2,c1,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D4(o2,o5,m,i,k,o3,o1,o4) X(w,o1,o5,o4,o2,o3) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io2);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io2, so2, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      for(int so4 = 0;so4 < nir;++so4){ 
      for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
        T2b = T2.get_amp2(io4);
        orz::DTensor X(nclosed, nocc, nocc);
        orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so5^so4^so2, X);
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x145, G_IF_SIGMA_COOO_COOO_NO0_X145)
          (so2, io2, so4, io4, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
        for(int sm = 0;sm < nir;++sm){ 
        for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
          S2b = orz::DTensor(retval.namps_iamp()[im]);
          // Load D4 from disk, or GA ....                                                     
          int imoi = amo2imo[io2] - nclosed;                              
          int imoj = amo2imo[io5] - nclosed;                              
                                                                                               
          orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice()).copy();    
          rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io2, so2, io5, so5, rdm4_ij_sliced);    
          FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so2, so5, io2, io5, rdm4_sym.cptr(), nir, nsym, psym);  
          FC_FUNC(g_if_sigma_cooo_cooo_no1_x145, G_IF_SIGMA_COOO_COOO_NO1_X145)
            (sm, im, so2, io2, so4, io4, so5, io5, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
          retval.acc_amp2(im, S2b);
          FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
        }
        }
      }
      }
    }
    }
  }
  }
  }


  {
  // No.146
  //* X(w,o2,k,o4,o1,o3)  <--  (    1.00000000)  T2(c1,o2,k,o4) V2(c1,o1,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,o1,o4,o2) X(w,o2,k,o4,o1,o3) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x146, G_IF_SIGMA_COOO_COOO_NO0_X146)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x146, G_IF_SIGMA_COOO_COOO_NO1_X146)
        (sm, im, so4, io4, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.147
  //* X(w,o1,o4,k,o2,o3)  <--  (    1.00000000)  T2(c1,o1,o4,k) V2(c1,o2,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,o1,o4,o2) X(w,o1,o4,k,o2,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x147, G_IF_SIGMA_COOO_COOO_NO0_X147)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x147, G_IF_SIGMA_COOO_COOO_NO1_X147)
        (sk, ik, sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.148
  //* X(w,o1,o4,o3,o2,k)  <--  (    1.00000000)  T2(c1,o1,o4,o3) V2(c1,o2,w,k) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D3(i,m,o3,o1,o4,o2) X(w,o1,o4,o3,o2,k) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x148, G_IF_SIGMA_COOO_COOO_NO0_X148)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x148, G_IF_SIGMA_COOO_COOO_NO1_X148)
        (sm, im, so3, io3, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.149
  //* X(w,o1,m,o4,o2,o3)  <--  (    1.00000000)  T2(c1,o1,m,o4) V2(c1,o2,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,o2,o3,k,o4,o1) X(w,o1,m,o4,o2,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sm^so4, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x149, G_IF_SIGMA_COOO_COOO_NO0_X149)
          (sc1, ic1, sm, im, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x149, G_IF_SIGMA_COOO_COOO_NO1_X149)
        (sm, im, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.150
  //* X(w,o2,o4,m,o1,o3)  <--  (    1.00000000)  T2(c1,o2,o4,m) V2(c1,o1,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,o2,o3,k,o4,o1) X(w,o2,o4,m,o1,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x150, G_IF_SIGMA_COOO_COOO_NO0_X150)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x150, G_IF_SIGMA_COOO_COOO_NO1_X150)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.151
  //* X(w,o1,o4,o3,m,o2)  <--  (    1.00000000)  T2(c1,o1,o4,o3) V2(m,w,c1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,k,o3,o1,o4,o2) X(w,o1,o4,o3,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so3^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x151, G_IF_SIGMA_COOO_COOO_NO0_X151)
        (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x151, G_IF_SIGMA_COOO_COOO_NO1_X151)
        (sm, im, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.152
  //* X(w,o2,o3,k,m,o1)  <--  (    1.00000000)  T2(c1,o2,o3,k) V2(m,w,c1,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,o1) X(w,o2,o3,k,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sk^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x152, G_IF_SIGMA_COOO_COOO_NO0_X152)
        (sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x152, G_IF_SIGMA_COOO_COOO_NO1_X152)
        (sk, ik, sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.153
  //* X(c1,w,i,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,o2,w,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(c1,o1,m,k) X(c1,w,i,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x153, G_IF_SIGMA_COOO_COOO_NO0_X153)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        T2b = T2.get_amp2(ik);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x153, G_IF_SIGMA_COOO_COOO_NO1_X153)
          (sc1, ic1, sk, ik, sm, im, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.154
  //* X(w,o1,m,o3,o2,k)  <--  (    1.00000000)  T2(c1,o1,m,o3) V2(c1,o2,w,k) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,o3,o1) X(w,o1,m,o3,o2,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, sm^so3, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x154, G_IF_SIGMA_COOO_COOO_NO0_X154)
          (sc1, ic1, sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x154, G_IF_SIGMA_COOO_COOO_NO1_X154)
        (sm, im, so3, io3, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.155
  //* X(w,o2,o3,m,o1,k)  <--  (    1.00000000)  T2(c1,o2,o3,m) V2(c1,o1,w,k) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,o3,o1) X(w,o2,o3,m,o1,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x155, G_IF_SIGMA_COOO_COOO_NO0_X155)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x155, G_IF_SIGMA_COOO_COOO_NO1_X155)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.156
  //* X(w,o3,o4,o2)  <--  (    1.00000000)  T2(c1,o1,o3,o4) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o3,o2,o4,k) X(w,o3,o4,o2) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    T2b = T2.get_amp2(io4);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so4, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x156, G_IF_SIGMA_COOO_COOO_NO0_X156)
        (sc1, ic1, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x156, G_IF_SIGMA_COOO_COOO_NO1_X156)
        (sm, im, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.157
  //* X(w,o3,k,o2)  <--  (    1.00000000)  T2(c1,o1,o3,k) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o3,o2) X(w,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x157, G_IF_SIGMA_COOO_COOO_NO0_X157)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x157, G_IF_SIGMA_COOO_COOO_NO1_X157)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.158
  //* X(w,o3,k,o2)  <--  (    1.00000000)  T2(c1,o1,o3,k) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o3,o2) X(w,o3,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    T2b = T2.get_amp2(ik);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sk, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x158, G_IF_SIGMA_COOO_COOO_NO0_X158)
        (sc1, ic1, sk, ik, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x158, G_IF_SIGMA_COOO_COOO_NO1_X158)
        (sk, ik, sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.159
  //* X(w,m,o3,o2)  <--  (    1.00000000)  T2(c1,o1,m,o3) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o2,o3,k) X(w,m,o3,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so3, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x159, G_IF_SIGMA_COOO_COOO_NO0_X159)
          (sc1, ic1, sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x159, G_IF_SIGMA_COOO_COOO_NO1_X159)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.160
  //* X(w,o3,m,o2)  <--  (    1.00000000)  T2(c1,o1,o3,m) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o3,o2) X(w,o3,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x160, G_IF_SIGMA_COOO_COOO_NO0_X160)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x160, G_IF_SIGMA_COOO_COOO_NO1_X160)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.161
  //* X(w,m,k,o2)  <--  (    1.00000000)  T2(c1,o1,m,k) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o2) X(w,m,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x161, G_IF_SIGMA_COOO_COOO_NO0_X161)
          (sc1, ic1, sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x161, G_IF_SIGMA_COOO_COOO_NO1_X161)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.162
  //* X(w,m,k,o2)  <--  (    1.00000000)  T2(c1,o1,m,k) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) D1(i,o2) X(w,m,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^sk, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x162, G_IF_SIGMA_COOO_COOO_NO0_X162)
          (sc1, ic1, sk, ik, sm, im, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x162, G_IF_SIGMA_COOO_COOO_NO1_X162)
        (sk, ik, sm, im, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.163
  //* X(w,o4,o3,o2)  <--  (    1.00000000)  T2(c1,o1,o4,o3) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o3,k,o4,o2) X(w,o4,o3,o2) 
  for(int so3 = 0;so3 < nir;++so3){ 
  for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
    T2b = T2.get_amp2(io3);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x163, G_IF_SIGMA_COOO_COOO_NO0_X163)
        (sc1, ic1, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x163, G_IF_SIGMA_COOO_COOO_NO1_X163)
        (sm, im, so3, io3, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.164
  //* X(w,m,o3,o2)  <--  (    1.00000000)  T2(c1,o1,m,o3) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,o2,o3,k) X(w,m,o3,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      orz::DTensor X(nclosed, nocc);
      orz::DTensor Xca = orz::ct::sympack_Xca(symblockinfo, sm^so3, X);
      for(int sc1 = 0;sc1 < nir;++sc1){ 
      for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
        // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
        V2 <<= 0.0;                                                                          
        shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
        for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
          // Load a signle record of integals                                                             
          const int &imo2 = loadbuf_ptr->i0;                                                              
          const int &imo3 = loadbuf_ptr->i1;                                                              
          const int &imo4 = loadbuf_ptr->i2;                                                              
          const double &v = loadbuf_ptr->v;                                                               
          V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
        }                                                                                                 
        const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x164, G_IF_SIGMA_COOO_COOO_NO0_X164)
          (sc1, ic1, sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xca.cptr(), nir, nsym, psym);
      }
      }
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x164, G_IF_SIGMA_COOO_COOO_NO1_X164)
        (sm, im, so3, io3, Xca.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.165
  //* X(w,o3,m,o2)  <--  (    1.00000000)  T2(c1,o1,o3,m) V2(c1,o2,w,o1) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D2(i,k,o3,o2) X(w,o3,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x165, G_IF_SIGMA_COOO_COOO_NO0_X165)
        (sc1, ic1, sm, im, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x165, G_IF_SIGMA_COOO_COOO_NO1_X165)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.166
  //* X(w,o2,o5,o4,o3,o6)  <--  (    1.00000000)  T2(w,o2,o1,o5) V2(o4,o1,o3,o6) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D4(o4,k,i,m,o5,o2,o6,o3) X(w,o2,o5,o4,o3,o6) 
  for(int so4 = 0;so4 < nir;++so4){ 
  for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io4);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io4, so4, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so5^so4, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x166, G_IF_SIGMA_COOO_COOO_NO0_X166)
        (so4, io4, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        for(int sk = 0;sk < nir;++sk){ 
        for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
          // Load D4 from disk, or GA ....                                                     
          int imoi = amo2imo[io4] - nclosed;                              
          int imoj = amo2imo[ik] - nclosed;                              
                                                                                               
          orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice()).copy();    
          rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io4, so4, ik, sk, rdm4_ij_sliced);    
          FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so4, sk, io4, ik, rdm4_sym.cptr(), nir, nsym, psym);  
          FC_FUNC(g_if_sigma_cooo_cooo_no1_x166, G_IF_SIGMA_COOO_COOO_NO1_X166)
            (sk, ik, sm, im, so4, io4, so5, io5, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
          FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
        }
        }
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.167
  //* X(i,m,o2,o1)  <--  (    1.00000000)  D3(i,m,o4,o2,o5,o3) V2(o1,o4,o3,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o2,o1,k) X(i,m,o2,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^so1, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x167, G_IF_SIGMA_COOO_COOO_NO0_X167)
        (sm, im, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        T2b = T2.get_amp2(ik);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x167, G_IF_SIGMA_COOO_COOO_NO1_X167)
          (sk, ik, sm, im, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.168
  //* X(w,o2,o4,k,o3,o5)  <--  (    1.00000000)  T2(w,o2,o1,o4) V2(k,o1,o3,o5) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D3(i,m,o4,o2,o5,o3) X(w,o2,o4,k,o3,o5) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x168, G_IF_SIGMA_COOO_COOO_NO0_X168)
        (sk, ik, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x168, G_IF_SIGMA_COOO_COOO_NO1_X168)
          (sk, ik, sm, im, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.169
  //* X(w,o3,o5,k,o2,o4)  <--  (    1.00000000)  T2(w,o3,o1,o5) V2(k,o2,o1,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o4,o2,o5,o3) X(w,o3,o5,k,o2,o4) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so5^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x169, G_IF_SIGMA_COOO_COOO_NO0_X169)
        (sk, ik, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x169, G_IF_SIGMA_COOO_COOO_NO1_X169)
          (sk, ik, sm, im, so5, io5, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.170
  //* X(i,o3,k,o1)  <--  (    1.00000000)  D3(i,o3,o4,k,o5,o2) V2(o1,o4,o2,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o3,o1,m) X(i,o3,k,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x170, G_IF_SIGMA_COOO_COOO_NO0_X170)
      (so1, io1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x170, G_IF_SIGMA_COOO_COOO_NO1_X170)
        (sm, im, so1, io1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.171
  //* X(w,o2,o4,m,o3,o5)  <--  (    1.00000000)  T2(w,o2,o1,o4) V2(m,o1,o3,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,k,o4,o2,o5,o3) X(w,o2,o4,m,o3,o5) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x171, G_IF_SIGMA_COOO_COOO_NO0_X171)
        (sm, im, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x171, G_IF_SIGMA_COOO_COOO_NO1_X171)
        (sm, im, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.172
  //* X(w,o2,o5,m,o3,o4)  <--  (    1.00000000)  T2(w,o2,o1,o5) V2(m,o3,o1,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,o3,o4,k,o5,o2) X(w,o2,o5,m,o3,o4) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so5^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x172, G_IF_SIGMA_COOO_COOO_NO0_X172)
        (sm, im, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x172, G_IF_SIGMA_COOO_COOO_NO1_X172)
        (sm, im, so5, io5, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.173
  //* X(i,o3,m,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(m,o1,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o3,o1,k) X(i,o3,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x173, G_IF_SIGMA_COOO_COOO_NO0_X173)
      (sm, im, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x173, G_IF_SIGMA_COOO_COOO_NO1_X173)
        (sk, ik, sm, im, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.174
  //* X(i,o2,m,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(m,o3,o1,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o2,o1,k) X(i,o2,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x174, G_IF_SIGMA_COOO_COOO_NO0_X174)
      (sm, im, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x174, G_IF_SIGMA_COOO_COOO_NO1_X174)
        (sk, ik, sm, im, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.175
  //* X(w,o2,o4,m,o3,k)  <--  (    1.00000000)  T2(w,o2,o1,o4) V2(m,o3,k,o1) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,o3,o4,o2) X(w,o2,o4,m,o3,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x175, G_IF_SIGMA_COOO_COOO_NO0_X175)
        (sm, im, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x175, G_IF_SIGMA_COOO_COOO_NO1_X175)
        (sm, im, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.176
  //* X(w,o2,o4,m,k,o3)  <--  (    1.00000000)  T2(w,o2,o1,o4) V2(m,o1,k,o3) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o3,o4,o2) X(w,o2,o4,m,k,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      T2b = T2.get_amp2(io4);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so4^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x176, G_IF_SIGMA_COOO_COOO_NO0_X176)
        (sm, im, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x176, G_IF_SIGMA_COOO_COOO_NO1_X176)
        (sm, im, so4, io4, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.177
  //* X(i,o3,k,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(k,o1,o2,o4) 
  //* S2(w,i,k,m)  <--  (    2.00000000) T2(w,o3,o1,m) X(i,o3,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x177, G_IF_SIGMA_COOO_COOO_NO0_X177)
      (sk, ik, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x177, G_IF_SIGMA_COOO_COOO_NO1_X177)
        (sk, ik, sm, im, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.178
  //* X(i,o3,k,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(k,o2,o1,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o3,o1,m) X(i,o3,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x178, G_IF_SIGMA_COOO_COOO_NO0_X178)
      (sk, ik, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x178, G_IF_SIGMA_COOO_COOO_NO1_X178)
        (sk, ik, sm, im, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.179
  //* X(w,o2,o4,o5,o3,o6)  <--  (    1.00000000)  T2(w,o2,o4,o1) V2(o1,o5,o3,o6) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D4(i,m,o4,k,o5,o2,o6,o3) X(w,o2,o4,o5,o3,o6) 
  orz::DTensor X(nclosed, nocc, nocc, nocc, nocc, nocc);
  orz::DTensor Xcaaaaa = orz::ct::sympack_Xcaaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x179, G_IF_SIGMA_COOO_COOO_NO0_X179)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      // Load D4 from disk, or GA ....                                                     
      int imoi = amo2imo[ii] - nclosed;                              
      int imoj = amo2imo[im] - nclosed;                              
                                                                                           
      orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice()).copy();    
      rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(si, sm, ii, im, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x179, G_IF_SIGMA_COOO_COOO_NO1_X179)
        (si, ii, sm, im, Xcaaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.180
  //* X(i,m,o2,o1)  <--  (    1.00000000)  D3(i,m,o4,o2,o5,o3) V2(o1,o4,o3,o5) 
  //* S2(w,i,k,m)  <--  (    2.00000000) T2(w,o2,k,o1) X(i,m,o2,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^so1, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x180, G_IF_SIGMA_COOO_COOO_NO0_X180)
        (sm, im, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x180, G_IF_SIGMA_COOO_COOO_NO1_X180)
        (sm, im, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.181
  //* X(w,o2,o4,k,o3,o5)  <--  (    1.00000000)  T2(w,o2,o4,o1) V2(o1,k,o3,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o4,o2,o5,o3) X(w,o2,o4,k,o3,o5) 
  orz::DTensor X(nclosed, nocc, nocc, nocc, nocc, nocc);
  orz::DTensor Xcaaaaa = orz::ct::sympack_Xcaaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x181, G_IF_SIGMA_COOO_COOO_NO0_X181)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x181, G_IF_SIGMA_COOO_COOO_NO1_X181)
      (sm, im, Xcaaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.182
  //* X(w,o3,o4,o5,k,o2)  <--  (    1.00000000)  T2(w,o3,o4,o1) V2(o1,o5,k,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o4,o2,o5,o3) X(w,o3,o4,o5,k,o2) 
  orz::DTensor X(nclosed, nocc, nocc, nocc, nocc, nocc);
  orz::DTensor Xcaaaaa = orz::ct::sympack_Xcaaaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x182, G_IF_SIGMA_COOO_COOO_NO0_X182)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x182, G_IF_SIGMA_COOO_COOO_NO1_X182)
      (sm, im, Xcaaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.183
  //* X(i,k,o2,o1)  <--  (    1.00000000)  D3(i,k,o4,o2,o5,o3) V2(o1,o4,o3,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o2,m,o1) X(i,k,o2,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x183, G_IF_SIGMA_COOO_COOO_NO0_X183)
      (so1, io1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x183, G_IF_SIGMA_COOO_COOO_NO1_X183)
        (sm, im, so1, io1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.184
  //* X(w,o3,o4,m,o2,o5)  <--  (    1.00000000)  T2(w,o3,o4,o1) V2(m,o1,o2,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,o3,o4,k,o5,o2) X(w,o3,o4,m,o2,o5) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x184, G_IF_SIGMA_COOO_COOO_NO0_X184)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x184, G_IF_SIGMA_COOO_COOO_NO1_X184)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.185
  //* X(w,o2,o4,m,o3,o5)  <--  (    1.00000000)  T2(w,o2,o4,o1) V2(m,o3,o1,o5) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,o3,o4,k,o5,o2) X(w,o2,o4,m,o3,o5) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x185, G_IF_SIGMA_COOO_COOO_NO0_X185)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x185, G_IF_SIGMA_COOO_COOO_NO1_X185)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.186
  //* X(i,o3,m,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(m,o1,o2,o4) 
  //* S2(w,i,k,m)  <--  (    2.00000000) T2(w,o3,k,o1) X(i,o3,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^so1, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x186, G_IF_SIGMA_COOO_COOO_NO0_X186)
        (sm, im, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x186, G_IF_SIGMA_COOO_COOO_NO1_X186)
        (sm, im, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.187
  //* X(i,o2,m,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(m,o3,o1,o4) 
  //* S2(w,i,k,m)  <--  (    2.00000000) T2(w,o2,k,o1) X(i,o2,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^so1, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x187, G_IF_SIGMA_COOO_COOO_NO0_X187)
        (sm, im, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x187, G_IF_SIGMA_COOO_COOO_NO1_X187)
        (sm, im, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.188
  //* X(w,o2,o4,m,o3,k)  <--  (    1.00000000)  T2(w,o2,o4,o1) V2(m,o3,k,o1) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o3,o4,o2) X(w,o2,o4,m,o3,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x188, G_IF_SIGMA_COOO_COOO_NO0_X188)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x188, G_IF_SIGMA_COOO_COOO_NO1_X188)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.189
  //* X(i,o3,o1,k)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,k,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o3,m,o1) X(i,o3,o1,k) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x189, G_IF_SIGMA_COOO_COOO_NO0_X189)
      (so1, io1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x189, G_IF_SIGMA_COOO_COOO_NO1_X189)
        (sm, im, so1, io1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.190
  //* X(i,o2,o1,k)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,o4,k,o3) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) T2(w,o2,m,o1) X(i,o2,o1,k) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x190, G_IF_SIGMA_COOO_COOO_NO0_X190)
      (so1, io1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x190, G_IF_SIGMA_COOO_COOO_NO1_X190)
        (sm, im, so1, io1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.191
  //* X(w,o3,o4,m,k,o2)  <--  (    1.00000000)  T2(w,o3,o4,o1) V2(m,o1,k,o2) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o3,o4,o2) X(w,o3,o4,m,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc, nocc, nocc);
    orz::DTensor Xcaaaa = orz::ct::sympack_Xcaaaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x191, G_IF_SIGMA_COOO_COOO_NO0_X191)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x191, G_IF_SIGMA_COOO_COOO_NO1_X191)
      (sm, im, Xcaaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.192
  //* X(w,o3,o5,o4)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(o1,o5,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o4,k,o5,o3) X(w,o3,o5,o4) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x192, G_IF_SIGMA_COOO_COOO_NO0_X192)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x192, G_IF_SIGMA_COOO_COOO_NO1_X192)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.193
  //* X(w,o3,o4,k)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(o1,o4,k,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D2(i,m,o4,o3) X(w,o3,o4,k) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x193, G_IF_SIGMA_COOO_COOO_NO0_X193)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x193, G_IF_SIGMA_COOO_COOO_NO1_X193)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.194
  //* X(w,o3,k,o4)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(o1,k,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,m,o4,o3) X(w,o3,k,o4) 
  orz::DTensor X(nclosed, nocc, nocc, nocc);
  orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    T2b = T2.get_amp2(io1);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x194, G_IF_SIGMA_COOO_COOO_NO0_X194)
      (so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x194, G_IF_SIGMA_COOO_COOO_NO1_X194)
      (sm, im, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.195
  //* X(w,o3,m,o4)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(m,o2,o1,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,k,o4,o3) X(w,o3,m,o4) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x195, G_IF_SIGMA_COOO_COOO_NO0_X195)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x195, G_IF_SIGMA_COOO_COOO_NO1_X195)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.196
  //* X(w,o3,m,o4)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(m,o1,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D2(i,o3,o4,k) X(w,o3,m,o4) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x196, G_IF_SIGMA_COOO_COOO_NO0_X196)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x196, G_IF_SIGMA_COOO_COOO_NO1_X196)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.197
  //* X(w,o3,m,k)  <--  (    1.00000000)  T2(w,o3,o2,o1) V2(m,o1,k,o2) 
  //* S2(w,i,k,m)  <--  (    2.00000000) D1(i,o3) X(w,o3,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so1 = 0;so1 < nir;++so1){ 
    for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
      T2b = T2.get_amp2(io1);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x197, G_IF_SIGMA_COOO_COOO_NO0_X197)
        (sm, im, so1, io1, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x197, G_IF_SIGMA_COOO_COOO_NO1_X197)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.198
  //* X(w,o1,m,k)  <--  (    1.00000000)  T2(w,o1,o2,o3) V2(m,o2,k,o3) 
  //* S2(w,i,k,m)  <--  (   -1.00000000) D1(i,o1) X(w,o1,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sm, X);
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x198, G_IF_SIGMA_COOO_COOO_NO0_X198)
        (sm, im, so3, io3, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_cooo_cooo_no1_x198, G_IF_SIGMA_COOO_COOO_NO1_X198)
      (sm, im, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.199
  //* X(w,o1,o3,o2,o4,o5)  <--  (    1.00000000)  T2(w,o6,o1,o3) V2(o2,o4,o5,o6) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D4(o2,o4,i,m,o1,k,o3,o5) X(w,o1,o3,o2,o4,o5) 
  for(int so2 = 0;so2 < nir;++so2){ 
  for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io2);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io2, so2, V2); // V2=(IR-COV index) 
    for(int so3 = 0;so3 < nir;++so3){ 
    for(int io3 = symblockinfo.psym()(so3,I_O,I_BEGIN);io3 <= symblockinfo.psym()(so3,I_O,I_END);++io3){ 
      T2b = T2.get_amp2(io3);
      for(int so4 = 0;so4 < nir;++so4){ 
      for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
        orz::DTensor X(nclosed, nocc, nocc);
        orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, so3^so2^so4, X);
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x199, G_IF_SIGMA_COOO_COOO_NO0_X199)
          (so2, io2, so3, io3, so4, io4, T2b.cptr(), V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
        for(int sm = 0;sm < nir;++sm){ 
        for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
          S2b = orz::DTensor(retval.namps_iamp()[im]);
          // Load D4 from disk, or GA ....                                                     
          int imoi = amo2imo[io2] - nclosed;                              
          int imoj = amo2imo[io4] - nclosed;                              
                                                                                               
          orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice(),            
                                             orz::Slice(),            orz::Slice()).copy();    
          rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io2, so2, io4, so4, rdm4_ij_sliced);    
          FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so2, so4, io2, io4, rdm4_sym.cptr(), nir, nsym, psym);  
          FC_FUNC(g_if_sigma_cooo_cooo_no1_x199, G_IF_SIGMA_COOO_COOO_NO1_X199)
            (sm, im, so2, io2, so3, io3, so4, io4, Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
          retval.acc_amp2(im, S2b);
          FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
        }
        }
      }
      }
    }
    }
  }
  }
  }


  {
  // No.200
  //* X(i,m,o4,o1)  <--  (    1.00000000)  D3(i,m,o4,o2,o5,o3) V2(o1,o2,o3,o5) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) T2(w,o1,k,o4) X(i,m,o4,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      for(int so4 = 0;so4 < nir;++so4){ 
      for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
        orz::DTensor X(nocc);
        orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, sm^so4^so1, X);
        FC_FUNC(g_if_sigma_cooo_cooo_no0_x200, G_IF_SIGMA_COOO_COOO_NO0_X200)
          (sm, im, so1, io1, so4, io4, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
        T2b = T2.get_amp2(io4);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x200, G_IF_SIGMA_COOO_COOO_NO1_X200)
          (sm, im, so1, io1, so4, io4, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.201
  //* X(i,m,o4,o1)  <--  (    1.00000000)  D3(i,m,o4,o2,o5,o3) V2(o1,o2,o3,o5) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(w,o1,o4,k) X(i,m,o4,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sm^so1, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x201, G_IF_SIGMA_COOO_COOO_NO0_X201)
        (sm, im, so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        T2b = T2.get_amp2(ik);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x201, G_IF_SIGMA_COOO_COOO_NO1_X201)
          (sk, ik, sm, im, so1, io1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.202
  //* X(w,o4,o5,k,o2,o3)  <--  (    1.00000000)  T2(w,o1,o4,o5) V2(k,o2,o1,o3) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,m,o4,o2,o5,o3) X(w,o4,o5,k,o2,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so5 = 0;so5 < nir;++so5){ 
    for(int io5 = symblockinfo.psym()(so5,I_O,I_BEGIN);io5 <= symblockinfo.psym()(so5,I_O,I_END);++io5){ 
      T2b = T2.get_amp2(io5);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so5^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x202, G_IF_SIGMA_COOO_COOO_NO0_X202)
        (sk, ik, so5, io5, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x202, G_IF_SIGMA_COOO_COOO_NO1_X202)
          (sk, ik, sm, im, so5, io5, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.203
  //* X(i,k,o4,o1)  <--  (    1.00000000)  D3(i,k,o4,o2,o5,o3) V2(o1,o2,o3,o5) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(w,o1,m,o4) X(i,k,o4,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so4^so1, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x203, G_IF_SIGMA_COOO_COOO_NO0_X203)
        (so1, io1, so4, io4, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        T2b = T2.get_amp2(io4);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x203, G_IF_SIGMA_COOO_COOO_NO1_X203)
          (sm, im, so1, io1, so4, io4, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.204
  //* X(i,o4,k,o1)  <--  (    1.00000000)  D3(i,o3,o4,k,o5,o2) V2(o1,o3,o2,o5) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(w,o1,o4,m) X(i,o4,k,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x204, G_IF_SIGMA_COOO_COOO_NO0_X204)
      (so1, io1, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x204, G_IF_SIGMA_COOO_COOO_NO1_X204)
        (sm, im, so1, io1, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.205
  //* X(w,o1,o2,m,o3,o4)  <--  (    1.00000000)  T2(w,o5,o1,o2) V2(m,o3,o4,o5) 
  //* S2(w,i,k,m)  <--  (    1.00000000) D3(i,o3,o1,k,o2,o4) X(w,o1,o2,m,o3,o4) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      orz::DTensor X(nclosed, nocc, nocc, nocc);
      orz::DTensor Xcaaa = orz::ct::sympack_Xcaaa(symblockinfo, so2^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x205, G_IF_SIGMA_COOO_COOO_NO0_X205)
        (sm, im, so2, io2, T2b.cptr(), V2_sym.cptr(), Xcaaa.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x205, G_IF_SIGMA_COOO_COOO_NO1_X205)
        (sm, im, so2, io2, Xcaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.206
  //* X(i,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) T2(w,o1,k,m) X(i,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x206, G_IF_SIGMA_COOO_COOO_NO0_X206)
      (so1, io1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x206, G_IF_SIGMA_COOO_COOO_NO1_X206)
        (sm, im, so1, io1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.207
  //* X(i,o4,m,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(m,o3,o1,o2) 
  //* S2(w,i,k,m)  <--  (   -2.00000000) T2(w,o1,k,o4) X(i,o4,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so4^sm, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x207, G_IF_SIGMA_COOO_COOO_NO0_X207)
        (sm, im, so4, io4, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(io4);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x207, G_IF_SIGMA_COOO_COOO_NO1_X207)
        (sm, im, so4, io4, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.208
  //* X(i,o4,m,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(m,o3,o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(w,o1,o4,k) X(i,o4,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sm, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x208, G_IF_SIGMA_COOO_COOO_NO0_X208)
      (sm, im, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x208, G_IF_SIGMA_COOO_COOO_NO1_X208)
        (sk, ik, sm, im, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.209
  //* X(i,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(w,o1,m,k) X(i,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x209, G_IF_SIGMA_COOO_COOO_NO0_X209)
      (so1, io1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        T2b = T2.get_amp2(ik);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x209, G_IF_SIGMA_COOO_COOO_NO1_X209)
          (sk, ik, sm, im, so1, io1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      }
      }
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.210
  //* X(i,o4,k,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(k,o3,o1,o2) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(w,o1,m,o4) X(i,o4,k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int so4 = 0;so4 < nir;++so4){ 
    for(int io4 = symblockinfo.psym()(so4,I_O,I_BEGIN);io4 <= symblockinfo.psym()(so4,I_O,I_END);++io4){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, so4^sk, X);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x210, G_IF_SIGMA_COOO_COOO_NO0_X210)
        (sk, ik, so4, io4, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      for(int sm = 0;sm < nir;++sm){ 
      for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
        S2b = orz::DTensor(retval.namps_iamp()[im]);
        T2b = T2.get_amp2(io4);
        FC_FUNC(g_if_sigma_cooo_cooo_no1_x210, G_IF_SIGMA_COOO_COOO_NO1_X210)
          (sk, ik, sm, im, so4, io4, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
        retval.acc_amp2(im, S2b);
      }
      }
    }
    }
  }
  }
  }


  {
  // No.211
  //* X(i,o1,k,o4)  <--  (    1.00000000)  D2(i,o2,o1,o3) V2(k,o3,o2,o4) 
  //* S2(w,i,k,m)  <--  (    1.00000000) T2(w,o4,o1,m) X(i,o1,k,o4) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc, nocc, nocc);
    orz::DTensor Xaaa = orz::ct::sympack_Xaaa(symblockinfo, sk, X);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x211, G_IF_SIGMA_COOO_COOO_NO0_X211)
      (sk, ik, V2_sym.cptr(), Xaaa.cptr(), nir, nsym, psym);
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      S2b = orz::DTensor(retval.namps_iamp()[im]);
      T2b = T2.get_amp2(im);
      FC_FUNC(g_if_sigma_cooo_cooo_no1_x211, G_IF_SIGMA_COOO_COOO_NO1_X211)
        (sk, ik, sm, im, T2b.cptr(), Xaaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, S2b);
    }
    }
  }
  }
  }


  {
  // No.212
  //* S2(w,i,k,m)  <--  (   -1.00000000) Ecas D3(i,m,o1,k,o2,o3) T2(w,o3,o1,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x212, G_IF_SIGMA_COOO_COOO_NO0_X212)
        (sm, im, so2, io2, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.213
  //* S2(w,i,k,m)  <--  (    2.00000000) Ecas D2(i,m,o2,o1) T2(w,o1,k,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x213, G_IF_SIGMA_COOO_COOO_NO0_X213)
        (sm, im, so2, io2, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.214
  //* S2(w,i,k,m)  <--  (   -1.00000000) Ecas D2(i,m,o2,o1) T2(w,o1,o2,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x214, G_IF_SIGMA_COOO_COOO_NO0_X214)
        (sk, ik, sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.215
  //* S2(w,i,k,m)  <--  (   -1.00000000) Ecas D2(i,k,o2,o1) T2(w,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int so2 = 0;so2 < nir;++so2){ 
    for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
      T2b = T2.get_amp2(io2);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x215, G_IF_SIGMA_COOO_COOO_NO0_X215)
        (sm, im, so2, io2, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.216
  //* S2(w,i,k,m)  <--  (   -1.00000000) Ecas D2(i,o2,o1,k) T2(w,o2,o1,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x216, G_IF_SIGMA_COOO_COOO_NO0_X216)
      (sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.217
  //* S2(w,i,k,m)  <--  (    2.00000000) Ecas D1(i,o1) T2(w,o1,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    T2b = T2.get_amp2(im);
    FC_FUNC(g_if_sigma_cooo_cooo_no0_x217, G_IF_SIGMA_COOO_COOO_NO0_X217)
      (sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, S2b);
  }
  }
  }


  {
  // No.218
  //* S2(w,i,k,m)  <--  (   -1.00000000) Ecas D1(i,o1) T2(w,o1,m,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    S2b = orz::DTensor(retval.namps_iamp()[im]);
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      T2b = T2.get_amp2(ik);
      FC_FUNC(g_if_sigma_cooo_cooo_no0_x218, G_IF_SIGMA_COOO_COOO_NO0_X218)
        (sk, ik, sm, im, &Ecas, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(im, S2b);
  }
  }
  }

  return retval; 
} 
