

#ifndef C_OVERLAP_OCOV_H
#define C_OVERLAP_OCOV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//                                                              
//   _______________                                  ______    
//  |          |                 .'. .`. `````|`````.~      ~.  
//  |______    |______         .'   `   `.    |    |          | 
//  |          |             .'           `.  |    |          | 
//  |          |___________.'               `.|     `.______.'  
//                                                              

void FC_FUNC(g_if_overlap_ocov_no0_x0, G_IF_OVERLAP_OCOV_NO0_X0)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const O2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_overlap_ocov_no0_x1, G_IF_OVERLAP_OCOV_NO0_X1)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const O2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

      
 }     
       
       
 #endif
       
       
 