                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_diag_cooo.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//  8 8888888888   8 8888888888            ,8.       ,8.    8888888 8888888888 ,o888888o.     
//  8 8888         8 8888                 ,888.     ,888.         8 8888    . 8888     `88.   
//  8 8888         8 8888                .`8888.   .`8888.        8 8888   ,8 8888       `8b  
//  8 8888         8 8888               ,8.`8888. ,8.`8888.       8 8888   88 8888        `8b 
//  8 888888888888 8 888888888888      ,8'8.`8888,8^8.`8888.      8 8888   88 8888         88 
//  8 8888         8 8888             ,8' `8.`8888' `8.`8888.     8 8888   88 8888         88 
//  8 8888         8 8888            ,8'   `8.`88'   `8.`8888.    8 8888   88 8888        ,8P 
//  8 8888         8 8888           ,8'     `8.`'     `8.`8888.   8 8888   `8 8888       ,8P  
//  8 8888         8 8888          ,8'       `8        `8.`8888.  8 8888    ` 8888     ,88'   
//  8 8888         8 888888888888 ,8'         `         `8.`8888. 8 8888       `8888888P'     

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::diag_cooo(const orz::ct::Input &ctinp,                                    
					 const orz::ct::SymBlockInfo &symblockinfo,                                
					 const orz::ct::HintMO &hintmo,                                            
					 const orz::ct::RdmPack &rdmPack_sym,                                      
					 const orz::DTensor &rdm4,                                                 
					 const int num_sigma,
					 const double Ecas) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "Hdiag" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor Hdiagb; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor rdm4_sym;                                                                                        


  {
  // No.0
  //* Hdiag(w,i,k,k)  <--  (   -4.00000000) Y0 D2(i,k,k,i) 
  // The effective tensor is detected .... 
  double Y0 = 0;
  FC_FUNC(g_if_diag_cooo_y0, G_IF_DIAG_COOO_Y0)
    (moint1_sym.cptr(), &Y0, nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x0, G_IF_DIAG_COOO_NO0_X0)
      (sk, ik, &Y0, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.1
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D2(i,k,k,i) h(w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x1, G_IF_DIAG_COOO_NO0_X1)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.2
  //* Hdiag(w,i,k,k)  <--  (    4.00000000) Y1 D2(i,k,k,i) 
  // The effective tensor is detected .... 
  double Y1 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y2, G_IF_DIAG_COOO_Y2)
      (sc1, ic1, V2_sym.cptr(), &Y1, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x2, G_IF_DIAG_COOO_NO0_X2)
      (sk, ik, &Y1, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.3
  //* Hdiag(w,i,k,k)  <--  (   -4.00000000) D2(i,k,k,i) Y2(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y2 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y3, G_IF_DIAG_COOO_Y3)
      (sc1, ic1, V2_sym.cptr(), Y2.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x3, G_IF_DIAG_COOO_NO0_X3)
      (sk, ik, Y2.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.4
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) Y3 D2(i,k,k,i) 
  // The effective tensor is detected .... 
  double Y3 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y4, G_IF_DIAG_COOO_Y4)
      (sc1, ic1, V2_sym.cptr(), &Y3, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x4, G_IF_DIAG_COOO_NO0_X4)
      (sk, ik, &Y3, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.5
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D2(i,k,k,i) Y4(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y4 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y5, G_IF_DIAG_COOO_Y5)
      (sc1, ic1, V2_sym.cptr(), Y4.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x5, G_IF_DIAG_COOO_NO0_X5)
      (sk, ik, Y4.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.6
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D2(i,k,k,i) Y5(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y5 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y6, G_IF_DIAG_COOO_Y6)
      (sc1, ic1, V2_sym.cptr(), Y5.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x6, G_IF_DIAG_COOO_NO0_X6)
      (sk, ik, Y5.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.7
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,k,i) Y6(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y6 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y7, G_IF_DIAG_COOO_Y7)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x7, G_IF_DIAG_COOO_NO0_X7)
      (sk, ik, Y6.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.8
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D2(i,k,k,i) Y7(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y7 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y8, G_IF_DIAG_COOO_Y8)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x8, G_IF_DIAG_COOO_NO0_X8)
      (sk, ik, Y7.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.9
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,k,i) Y8(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y8 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y9, G_IF_DIAG_COOO_Y9)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x9, G_IF_DIAG_COOO_NO0_X9)
      (sk, ik, Y8.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.10
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) Y9 D1(i,i) 
  // The effective tensor is detected .... 
  double Y9 = 0;
  FC_FUNC(g_if_diag_cooo_y10, G_IF_DIAG_COOO_Y10)
    (moint1_sym.cptr(), &Y9, nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x10, G_IF_DIAG_COOO_NO0_X10)
      (sk, ik, &Y9, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.11
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D1(i,i) h(w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x11, G_IF_DIAG_COOO_NO0_X11)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.12
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) Y10 D1(i,i) 
  // The effective tensor is detected .... 
  double Y10 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y12, G_IF_DIAG_COOO_Y12)
      (sc1, ic1, V2_sym.cptr(), &Y10, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x12, G_IF_DIAG_COOO_NO0_X12)
      (sk, ik, &Y10, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.13
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D1(i,i) Y11(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y11 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y13, G_IF_DIAG_COOO_Y13)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x13, G_IF_DIAG_COOO_NO0_X13)
      (sk, ik, Y11.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.14
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) Y12 D1(i,i) 
  // The effective tensor is detected .... 
  double Y12 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y14, G_IF_DIAG_COOO_Y14)
      (sc1, ic1, V2_sym.cptr(), &Y12, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x14, G_IF_DIAG_COOO_NO0_X14)
      (sk, ik, &Y12, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.15
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D1(i,i) Y13(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y13 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y15, G_IF_DIAG_COOO_Y15)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x15, G_IF_DIAG_COOO_NO0_X15)
      (sk, ik, Y13.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.16
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D1(i,i) Y14(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y14 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y16, G_IF_DIAG_COOO_Y16)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x16, G_IF_DIAG_COOO_NO0_X16)
      (sk, ik, Y14.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.17
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D1(i,i) Y15(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y15 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y17, G_IF_DIAG_COOO_Y17)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x17, G_IF_DIAG_COOO_NO0_X17)
      (sk, ik, Y15.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.18
  //* Hdiag(w,i,k,k)  <--  (    4.00000000) Y16 D2(i,k,k,i) 
  // The effective tensor is detected .... 
  double Y16 = 0;
  FC_FUNC(g_if_diag_cooo_y18, G_IF_DIAG_COOO_Y18)
    (moint1_sym.cptr(), &Y16, nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x18, G_IF_DIAG_COOO_NO0_X18)
      (sk, ik, &Y16, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.19
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,k,k,i) h(w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x19, G_IF_DIAG_COOO_NO0_X19)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.20
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,k,i) h(w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x20, G_IF_DIAG_COOO_NO0_X20)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.21
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,k,i) h(w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x21, G_IF_DIAG_COOO_NO0_X21)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.22
  //* Hdiag(w,i,k,k)  <--  (   -4.00000000) Y17 D2(i,k,k,i) 
  // The effective tensor is detected .... 
  double Y17 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y22, G_IF_DIAG_COOO_Y22)
      (sc1, ic1, V2_sym.cptr(), &Y17, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x22, G_IF_DIAG_COOO_NO0_X22)
      (sk, ik, &Y17, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.23
  //* Hdiag(w,i,k,k)  <--  (    4.00000000) D2(i,k,k,i) Y18(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y18 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y23, G_IF_DIAG_COOO_Y23)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x23, G_IF_DIAG_COOO_NO0_X23)
      (sk, ik, Y18.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.24
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) Y19 D2(i,k,k,i) 
  // The effective tensor is detected .... 
  double Y19 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y24, G_IF_DIAG_COOO_Y24)
      (sc1, ic1, V2_sym.cptr(), &Y19, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x24, G_IF_DIAG_COOO_NO0_X24)
      (sk, ik, &Y19, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.25
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,k,k,i) Y20(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y20 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y25, G_IF_DIAG_COOO_Y25)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x25, G_IF_DIAG_COOO_NO0_X25)
      (sk, ik, Y20.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.26
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) Y21 D1(i,i) 
  // The effective tensor is detected .... 
  double Y21 = 0;
  FC_FUNC(g_if_diag_cooo_y26, G_IF_DIAG_COOO_Y26)
    (moint1_sym.cptr(), &Y21, nir, nsym, psym);
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x26, G_IF_DIAG_COOO_NO0_X26)
      (sk, ik, &Y21, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.27
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D1(i,i) h(w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x27, G_IF_DIAG_COOO_NO0_X27)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.28
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D1(i,i) h(w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x28, G_IF_DIAG_COOO_NO0_X28)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.29
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) Y22 D1(i,i) 
  // The effective tensor is detected .... 
  double Y22 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y29, G_IF_DIAG_COOO_Y29)
      (sc1, ic1, V2_sym.cptr(), &Y22, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x29, G_IF_DIAG_COOO_NO0_X29)
      (sk, ik, &Y22, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.30
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D1(i,i) Y23(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y23 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y30, G_IF_DIAG_COOO_Y30)
      (sc1, ic1, V2_sym.cptr(), Y23.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x30, G_IF_DIAG_COOO_NO0_X30)
      (sk, ik, Y23.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.31
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) Y24 D1(i,i) 
  // The effective tensor is detected .... 
  double Y24 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y31, G_IF_DIAG_COOO_Y31)
      (sc1, ic1, V2_sym.cptr(), &Y24, nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x31, G_IF_DIAG_COOO_NO0_X31)
      (sk, ik, &Y24, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.32
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D1(i,i) Y25(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y25 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y32, G_IF_DIAG_COOO_Y32)
      (sc1, ic1, V2_sym.cptr(), Y25.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x32, G_IF_DIAG_COOO_NO0_X32)
      (sk, ik, Y25.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.33
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,k,m,i) h(w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x33, G_IF_DIAG_COOO_NO0_X33)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.34
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,m,i) h(w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x34, G_IF_DIAG_COOO_NO0_X34)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.35
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,m,m,i) h(k,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x35, G_IF_DIAG_COOO_NO0_X35)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.36
  //* Hdiag(w,i,k,m)  <--  (   -4.00000000) D2(i,m,m,i) Y26(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y26 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y36, G_IF_DIAG_COOO_Y36)
      (sc1, ic1, V2_sym.cptr(), Y26.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x36, G_IF_DIAG_COOO_NO0_X36)
      (sm, im, Y26.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.37
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,m,m,i) Y27(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y27 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y37, G_IF_DIAG_COOO_Y37)
      (sc1, ic1, V2_sym.cptr(), Y27.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x37, G_IF_DIAG_COOO_NO0_X37)
      (sm, im, Y27.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.38
  //* Hdiag(w,i,k,m)  <--  (    4.00000000) D2(i,m,m,i) Y28(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y28 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y38, G_IF_DIAG_COOO_Y38)
      (sc1, ic1, V2_sym.cptr(), Y28.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x38, G_IF_DIAG_COOO_NO0_X38)
      (sm, im, Y28.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.39
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,m,i) V2(w,w,k,k) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x39, G_IF_DIAG_COOO_NO0_X39)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.40
  //* Hdiag(w,i,k,m)  <--  (    4.00000000) D2(i,m,m,i) V2(w,k,w,k) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x40, G_IF_DIAG_COOO_NO0_X40)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.41
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,m,i) Y29(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y29 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y41, G_IF_DIAG_COOO_Y41)
      (sc1, ic1, V2_sym.cptr(), Y29.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x41, G_IF_DIAG_COOO_NO0_X41)
      (sm, im, Y29.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.42
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,i,k,k) h(w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x42, G_IF_DIAG_COOO_NO0_X42)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.43
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D1(i,i) h(w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x43, G_IF_DIAG_COOO_NO0_X43)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.44
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D1(i,i) h(k,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x44, G_IF_DIAG_COOO_NO0_X44)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.45
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D1(i,i) h(m,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x45, G_IF_DIAG_COOO_NO0_X45)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.46
  //* Hdiag(w,i,k,m)  <--  (   -4.00000000) D1(i,i) Y30(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y30 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y46, G_IF_DIAG_COOO_Y46)
      (sc1, ic1, V2_sym.cptr(), Y30.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x46, G_IF_DIAG_COOO_NO0_X46)
      (sm, im, Y30.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.47
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D1(i,i) Y31(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y31 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y47, G_IF_DIAG_COOO_Y47)
      (sc1, ic1, V2_sym.cptr(), Y31.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x47, G_IF_DIAG_COOO_NO0_X47)
      (sm, im, Y31.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.48
  //* Hdiag(w,i,k,m)  <--  (    4.00000000) D1(i,i) Y32(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y32 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y48, G_IF_DIAG_COOO_Y48)
      (sc1, ic1, V2_sym.cptr(), Y32.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x48, G_IF_DIAG_COOO_NO0_X48)
      (sm, im, Y32.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.49
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D1(i,i) V2(w,w,k,k) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x49, G_IF_DIAG_COOO_NO0_X49)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.50
  //* Hdiag(w,i,k,m)  <--  (    4.00000000) D1(i,i) Y33(m,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y33 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y50, G_IF_DIAG_COOO_Y50)
      (sc1, ic1, V2_sym.cptr(), Y33.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x50, G_IF_DIAG_COOO_NO0_X50)
      (sm, im, Y33.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.51
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D1(i,i) V2(m,m,w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x51, G_IF_DIAG_COOO_NO0_X51)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.52
  //* Hdiag(w,i,k,m)  <--  (    4.00000000) D1(i,i) V2(w,k,w,k) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x52, G_IF_DIAG_COOO_NO0_X52)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.53
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D1(i,i) Y34(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y34 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y53, G_IF_DIAG_COOO_Y53)
      (sc1, ic1, V2_sym.cptr(), Y34.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x53, G_IF_DIAG_COOO_NO0_X53)
      (sm, im, Y34.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.54
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D1(i,i) V2(m,w,w,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x54, G_IF_DIAG_COOO_NO0_X54)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.55
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D1(i,i) Y35(m,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y35 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y55, G_IF_DIAG_COOO_Y55)
      (sc1, ic1, V2_sym.cptr(), Y35.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x55, G_IF_DIAG_COOO_NO0_X55)
      (sm, im, Y35.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.56
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D1(i,i) V2(m,m,k,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x56, G_IF_DIAG_COOO_NO0_X56)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.57
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D1(i,i) V2(m,k,k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x57, G_IF_DIAG_COOO_NO0_X57)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.58
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,k,o1,m,i) h(k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x58, G_IF_DIAG_COOO_NO0_X58)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.59
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,k,k,o1,i) h(m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x59, G_IF_DIAG_COOO_NO0_X59)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.60
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,m,o1,i) h(m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x60, G_IF_DIAG_COOO_NO0_X60)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.61
  //* Hdiag(w,i,k,m)  <--  (    4.00000000) D2(i,m,o1,i) Y36(m,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y36 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y61, G_IF_DIAG_COOO_Y61)
      (sc1, ic1, V2_sym.cptr(), Y36.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x61, G_IF_DIAG_COOO_NO0_X61)
      (sm, im, Y36.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.62
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o1,i) V2(m,o1,w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x62, G_IF_DIAG_COOO_NO0_X62)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.63
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o1,i) V2(m,o1,w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x63, G_IF_DIAG_COOO_NO0_X63)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.64
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,m,o1,i) V2(m,w,w,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x64, G_IF_DIAG_COOO_NO0_X64)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.65
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o1,i) Y37(m,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y37 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y65, G_IF_DIAG_COOO_Y65)
      (sc1, ic1, V2_sym.cptr(), Y37.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x65, G_IF_DIAG_COOO_NO0_X65)
      (sm, im, Y37.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.66
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,m,o1,i) V2(m,w,w,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x66, G_IF_DIAG_COOO_NO0_X66)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.67
  //* Hdiag(w,i,k,m)  <--  (    4.00000000) D2(i,m,o1,i) V2(m,o1,k,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x67, G_IF_DIAG_COOO_NO0_X67)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.68
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,o1,i) V2(m,k,k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x68, G_IF_DIAG_COOO_NO0_X68)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.69
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,o1,i) h(k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x69, G_IF_DIAG_COOO_NO0_X69)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.70
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,o1,i) h(k,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x70, G_IF_DIAG_COOO_NO0_X70)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.71
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,i,k,o1) h(k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x71, G_IF_DIAG_COOO_NO0_X71)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.72
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,k,m,i) h(k,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x72, G_IF_DIAG_COOO_NO0_X72)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.73
  //* Hdiag(w,i,k,m)  <--  (   -4.00000000) D2(i,k,m,i) Y38(k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y38 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y73, G_IF_DIAG_COOO_Y73)
      (sc1, ic1, V2_sym.cptr(), Y38.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x73, G_IF_DIAG_COOO_NO0_X73)
      (sm, im, Y38.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.74
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,k,m,i) V2(m,k,w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x74, G_IF_DIAG_COOO_NO0_X74)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.75
  //* Hdiag(w,i,k,m)  <--  (   -4.00000000) D2(i,k,m,i) V2(m,w,w,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x75, G_IF_DIAG_COOO_NO0_X75)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.76
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,k,m,i) Y39(k,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y39 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y76, G_IF_DIAG_COOO_Y76)
      (sc1, ic1, V2_sym.cptr(), Y39.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x76, G_IF_DIAG_COOO_NO0_X76)
      (sm, im, Y39.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.77
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D1(i,i) h(k,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x77, G_IF_DIAG_COOO_NO0_X77)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.78
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D1(i,i) Y40(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y40 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y78, G_IF_DIAG_COOO_Y78)
      (sc1, ic1, V2_sym.cptr(), Y40.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x78, G_IF_DIAG_COOO_NO0_X78)
      (sk, ik, Y40.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.79
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D1(i,i) V2(k,k,w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x79, G_IF_DIAG_COOO_NO0_X79)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.80
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,i,k,k) h(m,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x80, G_IF_DIAG_COOO_NO0_X80)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.81
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,k,m,o1) h(i,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x81, G_IF_DIAG_COOO_NO0_X81)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.82
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,m,o1) h(i,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x82, G_IF_DIAG_COOO_NO0_X82)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.83
  //* Hdiag(w,i,k,m)  <--  (   -4.00000000) D2(i,m,m,o1) Y41(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y41 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y83, G_IF_DIAG_COOO_Y83)
      (sc1, ic1, V2_sym.cptr(), Y41.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x83, G_IF_DIAG_COOO_NO0_X83)
      (sm, im, Y41.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.84
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,m,m,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x84, G_IF_DIAG_COOO_NO0_X84)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.85
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,m,m,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x85, G_IF_DIAG_COOO_NO0_X85)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.86
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,m,m,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x86, G_IF_DIAG_COOO_NO0_X86)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.87
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,m,m,o1) Y42(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y42 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y87, G_IF_DIAG_COOO_Y87)
      (sc1, ic1, V2_sym.cptr(), Y42.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x87, G_IF_DIAG_COOO_NO0_X87)
      (sm, im, Y42.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.88
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,m,m,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x88, G_IF_DIAG_COOO_NO0_X88)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.89
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,k,o1) h(i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x89, G_IF_DIAG_COOO_NO0_X89)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.90
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,k,o1) h(i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x90, G_IF_DIAG_COOO_NO0_X90)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.91
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,o1,k,k) h(i,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x91, G_IF_DIAG_COOO_NO0_X91)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.92
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D1(i,o1) h(i,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x92, G_IF_DIAG_COOO_NO0_X92)
      (sm, im, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.93
  //* Hdiag(w,i,k,m)  <--  (   -4.00000000) D1(i,o1) Y43(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y43 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y93, G_IF_DIAG_COOO_Y93)
      (sc1, ic1, V2_sym.cptr(), Y43.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x93, G_IF_DIAG_COOO_NO0_X93)
      (sm, im, Y43.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.94
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D1(i,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x94, G_IF_DIAG_COOO_NO0_X94)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.95
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D1(i,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x95, G_IF_DIAG_COOO_NO0_X95)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.96
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D1(i,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x96, G_IF_DIAG_COOO_NO0_X96)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.97
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D1(i,o1) Y44(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y44 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y97, G_IF_DIAG_COOO_Y97)
      (sc1, ic1, V2_sym.cptr(), Y44.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x97, G_IF_DIAG_COOO_NO0_X97)
      (sm, im, Y44.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.98
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D1(i,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x98, G_IF_DIAG_COOO_NO0_X98)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.99
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D1(i,o1) h(i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x99, G_IF_DIAG_COOO_NO0_X99)
      (sk, ik, moint1_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.100
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D3(i,m,k,k,m,i) Y45(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y45 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y100, G_IF_DIAG_COOO_Y100)
      (sc1, ic1, V2_sym.cptr(), Y45.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x100, G_IF_DIAG_COOO_NO0_X100)
      (sm, im, Y45.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.101
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,k,k,m,i) Y46(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y46 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y101, G_IF_DIAG_COOO_Y101)
      (sc1, ic1, V2_sym.cptr(), Y46.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x101, G_IF_DIAG_COOO_NO0_X101)
      (sm, im, Y46.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.102
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,i,k,k) Y47(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y47 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y102, G_IF_DIAG_COOO_Y102)
      (sc1, ic1, V2_sym.cptr(), Y47.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x102, G_IF_DIAG_COOO_NO0_X102)
      (sm, im, Y47.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.103
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,i,k,k) Y48(w,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y48 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y103, G_IF_DIAG_COOO_Y103)
      (sc1, ic1, V2_sym.cptr(), Y48.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x103, G_IF_DIAG_COOO_NO0_X103)
      (sm, im, Y48.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.104
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,i,k,k) Y49(m,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y49 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y104, G_IF_DIAG_COOO_Y104)
      (sc1, ic1, V2_sym.cptr(), Y49.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x104, G_IF_DIAG_COOO_NO0_X104)
      (sm, im, Y49.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.105
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,i,k,k) V2(m,m,w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x105, G_IF_DIAG_COOO_NO0_X105)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.106
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,i,k,k) Y50(m,m) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y50 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y106, G_IF_DIAG_COOO_Y106)
      (sc1, ic1, V2_sym.cptr(), Y50.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x106, G_IF_DIAG_COOO_NO0_X106)
      (sm, im, Y50.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.107
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D3(i,k,k,i,o1,o2) Y51(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y51 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y107, G_IF_DIAG_COOO_Y107)
      (sc1, ic1, V2_sym.cptr(), Y51.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x107, G_IF_DIAG_COOO_NO0_X107)
      (sk, ik, Y51.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.108
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D3(i,k,k,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x108, G_IF_DIAG_COOO_NO0_X108)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.109
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,m,k,o1,m,i) Y52(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y52 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y109, G_IF_DIAG_COOO_Y109)
      (sc1, ic1, V2_sym.cptr(), Y52.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x109, G_IF_DIAG_COOO_NO0_X109)
      (sm, im, Y52.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.110
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,o1,m,i) V2(w,w,k,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x110, G_IF_DIAG_COOO_NO0_X110)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.111
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,o1,m,i) V2(w,w,k,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x111, G_IF_DIAG_COOO_NO0_X111)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.112
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,o1,m,i) Y53(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y53 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y112, G_IF_DIAG_COOO_Y112)
      (sc1, ic1, V2_sym.cptr(), Y53.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x112, G_IF_DIAG_COOO_NO0_X112)
      (sm, im, Y53.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.113
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,m,k,o1,m,i) V2(w,k,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x113, G_IF_DIAG_COOO_NO0_X113)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.114
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,m,k,o1,m,i) V2(w,k,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x114, G_IF_DIAG_COOO_NO0_X114)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.115
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,m,k,k,o1,i) Y54(m,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y54 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y115, G_IF_DIAG_COOO_Y115)
      (sc1, ic1, V2_sym.cptr(), Y54.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x115, G_IF_DIAG_COOO_NO0_X115)
      (sm, im, Y54.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.116
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,k,o1,i) V2(m,o1,w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x116, G_IF_DIAG_COOO_NO0_X116)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.117
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,k,o1,i) V2(m,o1,w,w) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x117, G_IF_DIAG_COOO_NO0_X117)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.118
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,k,o1,i) Y55(m,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y55 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y118, G_IF_DIAG_COOO_Y118)
      (sc1, ic1, V2_sym.cptr(), Y55.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x118, G_IF_DIAG_COOO_NO0_X118)
      (sm, im, Y55.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.119
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,k,o1,i) Y56(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y56 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y119, G_IF_DIAG_COOO_Y119)
      (sc1, ic1, V2_sym.cptr(), Y56.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x119, G_IF_DIAG_COOO_NO0_X119)
      (sk, ik, Y56.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.120
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,o1,i) V2(k,o1,w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x120, G_IF_DIAG_COOO_NO0_X120)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.121
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,i,o1,o2) Y57(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y57 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y121, G_IF_DIAG_COOO_Y121)
      (sc1, ic1, V2_sym.cptr(), Y57.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x121, G_IF_DIAG_COOO_NO0_X121)
      (sk, ik, Y57.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.122
  //* Hdiag(w,i,k,k)  <--  (    0.50000000) D2(i,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x122, G_IF_DIAG_COOO_NO0_X122)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.123
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,k,o1,i) Y58(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y58 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y123, G_IF_DIAG_COOO_Y123)
      (sc1, ic1, V2_sym.cptr(), Y58.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x123, G_IF_DIAG_COOO_NO0_X123)
      (sk, ik, Y58.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.124
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,o1,i) V2(k,o1,w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x124, G_IF_DIAG_COOO_NO0_X124)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.125
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,i,k,o1) Y59(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y59 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y125, G_IF_DIAG_COOO_Y125)
      (sc1, ic1, V2_sym.cptr(), Y59.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x125, G_IF_DIAG_COOO_NO0_X125)
      (sm, im, Y59.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.126
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,i,k,o1) V2(w,w,k,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x126, G_IF_DIAG_COOO_NO0_X126)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.127
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,i,k,o1) V2(w,w,k,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x127, G_IF_DIAG_COOO_NO0_X127)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.128
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,i,k,o1) Y60(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y60 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y128, G_IF_DIAG_COOO_Y128)
      (sc1, ic1, V2_sym.cptr(), Y60.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x128, G_IF_DIAG_COOO_NO0_X128)
      (sm, im, Y60.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.129
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,i,k,o1) V2(w,k,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x129, G_IF_DIAG_COOO_NO0_X129)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.130
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,i,k,o1) V2(w,k,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x130, G_IF_DIAG_COOO_NO0_X130)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.131
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,i,k,o1) V2(m,m,k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x131, G_IF_DIAG_COOO_NO0_X131)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.132
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D3(i,k,k,i,o1,o2) Y61(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y61 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y132, G_IF_DIAG_COOO_Y132)
      (sc1, ic1, V2_sym.cptr(), Y61.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x132, G_IF_DIAG_COOO_NO0_X132)
      (sk, ik, Y61.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.133
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D3(i,k,k,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x133, G_IF_DIAG_COOO_NO0_X133)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.134
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D3(i,k,k,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x134, G_IF_DIAG_COOO_NO0_X134)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.135
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D3(i,k,k,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x135, G_IF_DIAG_COOO_NO0_X135)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.136
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,i,o1,o2) Y62(o1,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y62 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y136, G_IF_DIAG_COOO_Y136)
      (sc1, ic1, V2_sym.cptr(), Y62.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x136, G_IF_DIAG_COOO_NO0_X136)
      (sk, ik, Y62.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.137
  //* Hdiag(w,i,k,k)  <--  (   -0.50000000) D2(i,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x137, G_IF_DIAG_COOO_NO0_X137)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.138
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D4(o1,o2,i,m,k,k,m,i) V2(o1,o2,w,w) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      for(int so2 = 0;so2 < nir;++so2){ 
      for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
        // Load D4 from disk, or GA ....                                                     
        int imoi = amo2imo[io1] - nclosed;                              
        int imoj = amo2imo[io2] - nclosed;                              
                                                                                             
        orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice()).copy();    
        rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io1, so1, io2, so2, rdm4_ij_sliced);    
        FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, so2, io1, io2, rdm4_sym.cptr(), nir, nsym, psym);  
        FC_FUNC(g_if_diag_cooo_no0_x138, G_IF_DIAG_COOO_NO0_X138)
          (sm, im, so1, io1, so2, io2, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
        FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
      }
      }
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.139
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,m,m,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x139, G_IF_DIAG_COOO_NO0_X139)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.140
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,m,i,o1,o2) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x140, G_IF_DIAG_COOO_NO0_X140)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.141
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D3(i,m,m,i,o1,o2) V2(k,k,o1,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x141, G_IF_DIAG_COOO_NO0_X141)
        (sk, ik, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.142
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,m,i,o1,o2) V2(k,o1,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x142, G_IF_DIAG_COOO_NO0_X142)
        (sk, ik, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.143
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,i,k,k,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x143, G_IF_DIAG_COOO_NO0_X143)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.144
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x144, G_IF_DIAG_COOO_NO0_X144)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.145
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,i,o1,o2) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x145, G_IF_DIAG_COOO_NO0_X145)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.146
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,i,o1,o2) V2(k,k,o1,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x146, G_IF_DIAG_COOO_NO0_X146)
        (sk, ik, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.147
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,i,o1,o2) V2(k,o1,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x147, G_IF_DIAG_COOO_NO0_X147)
        (sk, ik, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.148
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,i,o1,o2) V2(m,m,o1,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x148, G_IF_DIAG_COOO_NO0_X148)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.149
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,o1,i) V2(k,o1,w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x149, G_IF_DIAG_COOO_NO0_X149)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.150
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,i,o1,o2) V2(w,w,o1,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x150, G_IF_DIAG_COOO_NO0_X150)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.151
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,o1,i) V2(k,o1,w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x151, G_IF_DIAG_COOO_NO0_X151)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.152
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D3(i,m,k,k,m,o1) Y63(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y63 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y152, G_IF_DIAG_COOO_Y152)
      (sc1, ic1, V2_sym.cptr(), Y63.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x152, G_IF_DIAG_COOO_NO0_X152)
      (sm, im, Y63.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.153
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,k,k,m,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x153, G_IF_DIAG_COOO_NO0_X153)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.154
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,k,m,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x154, G_IF_DIAG_COOO_NO0_X154)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.155
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,k,k,m,o1) Y64(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y64 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y155, G_IF_DIAG_COOO_Y155)
      (sc1, ic1, V2_sym.cptr(), Y64.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x155, G_IF_DIAG_COOO_NO0_X155)
      (sm, im, Y64.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.156
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D2(i,k,k,o1) Y65(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y65 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y156, G_IF_DIAG_COOO_Y156)
      (sc1, ic1, V2_sym.cptr(), Y65.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x156, G_IF_DIAG_COOO_NO0_X156)
      (sk, ik, Y65.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.157
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,k,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x157, G_IF_DIAG_COOO_NO0_X157)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.158
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,k,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x158, G_IF_DIAG_COOO_NO0_X158)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.159
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,k,o1) Y66(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y66 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y159, G_IF_DIAG_COOO_Y159)
      (sc1, ic1, V2_sym.cptr(), Y66.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x159, G_IF_DIAG_COOO_NO0_X159)
      (sk, ik, Y66.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.160
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D2(i,k,k,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x160, G_IF_DIAG_COOO_NO0_X160)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.161
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,k,k,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x161, G_IF_DIAG_COOO_NO0_X161)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.162
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D2(i,k,k,o1) Y67(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y67 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y162, G_IF_DIAG_COOO_Y162)
      (sc1, ic1, V2_sym.cptr(), Y67.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x162, G_IF_DIAG_COOO_NO0_X162)
      (sk, ik, Y67.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.163
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,k,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x163, G_IF_DIAG_COOO_NO0_X163)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.164
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,k,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x164, G_IF_DIAG_COOO_NO0_X164)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.165
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,k,k,o1) Y68(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y68 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y165, G_IF_DIAG_COOO_Y165)
      (sc1, ic1, V2_sym.cptr(), Y68.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x165, G_IF_DIAG_COOO_NO0_X165)
      (sk, ik, Y68.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.166
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,o1,k,k) Y69(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y69 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y166, G_IF_DIAG_COOO_Y166)
      (sc1, ic1, V2_sym.cptr(), Y69.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x166, G_IF_DIAG_COOO_NO0_X166)
      (sm, im, Y69.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.167
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,o1,k,k) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x167, G_IF_DIAG_COOO_NO0_X167)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.168
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,o1,k,k) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x168, G_IF_DIAG_COOO_NO0_X168)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.169
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,o1,k,k) Y70(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y70 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y169, G_IF_DIAG_COOO_Y169)
      (sc1, ic1, V2_sym.cptr(), Y70.cptr(), nir, nsym, psym);
  }
  }
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x169, G_IF_DIAG_COOO_NO0_X169)
      (sm, im, Y70.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.170
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D1(i,o1) Y71(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y71 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y170, G_IF_DIAG_COOO_Y170)
      (sc1, ic1, V2_sym.cptr(), Y71.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x170, G_IF_DIAG_COOO_NO0_X170)
      (sk, ik, Y71.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.171
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D1(i,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x171, G_IF_DIAG_COOO_NO0_X171)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.172
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D1(i,o1) V2(w,w,i,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x172, G_IF_DIAG_COOO_NO0_X172)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.173
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D1(i,o1) Y72(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y72 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y173, G_IF_DIAG_COOO_Y173)
      (sc1, ic1, V2_sym.cptr(), Y72.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x173, G_IF_DIAG_COOO_NO0_X173)
      (sk, ik, Y72.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.174
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D1(i,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x174, G_IF_DIAG_COOO_NO0_X174)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.175
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D1(i,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x175, G_IF_DIAG_COOO_NO0_X175)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.176
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,k,k,o1,m,i) V2(m,w,w,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x176, G_IF_DIAG_COOO_NO0_X176)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.177
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,o1,i) Y73(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y73 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y177, G_IF_DIAG_COOO_Y177)
      (sc1, ic1, V2_sym.cptr(), Y73.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x177, G_IF_DIAG_COOO_NO0_X177)
      (sk, ik, Y73.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.178
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,i,k,o1) V2(k,w,w,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x178, G_IF_DIAG_COOO_NO0_X178)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.179
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,k,o1,i) Y74(k,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y74 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y179, G_IF_DIAG_COOO_Y179)
      (sc1, ic1, V2_sym.cptr(), Y74.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x179, G_IF_DIAG_COOO_NO0_X179)
      (sk, ik, Y74.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.180
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,k,o1,i) V2(k,w,w,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x180, G_IF_DIAG_COOO_NO0_X180)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.181
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,k,o1,i) V2(k,w,w,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x181, G_IF_DIAG_COOO_NO0_X181)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.182
  //* Hdiag(w,i,k,k)  <--  (   -4.00000000) D1(i,i) V2(k,w,w,k) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x182, G_IF_DIAG_COOO_NO0_X182)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.183
  //* Hdiag(w,i,k,k)  <--  (    2.00000000) D1(i,i) Y75(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y75 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y183, G_IF_DIAG_COOO_Y183)
      (sc1, ic1, V2_sym.cptr(), Y75.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x183, G_IF_DIAG_COOO_NO0_X183)
      (sk, ik, Y75.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.184
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D1(i,i) Y76(k,k) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y76 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_y184, G_IF_DIAG_COOO_Y184)
      (sc1, ic1, V2_sym.cptr(), Y76.cptr(), nir, nsym, psym);
  }
  }
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x184, G_IF_DIAG_COOO_NO0_X184)
      (sk, ik, Y76.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.185
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D1(i,i) V2(k,k,w,w) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x185, G_IF_DIAG_COOO_NO0_X185)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.186
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,k,k,i) V2(m,w,w,m) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x186, G_IF_DIAG_COOO_NO0_X186)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.187
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D4(o1,k,m,i,i,m,k,o2) V2(o1,w,w,o2) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      for(int sk = 0;sk < nir;++sk){ 
      for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
        // Load D4 from disk, or GA ....                                                     
        int imoi = amo2imo[io1] - nclosed;                              
        int imoj = amo2imo[ik] - nclosed;                              
                                                                                             
        orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice()).copy();    
        rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, io1, so1, ik, sk, rdm4_ij_sliced);    
        FC_FUNC(g_if_set_d4,G_IF_SET_D4)(so1, sk, io1, ik, rdm4_sym.cptr(), nir, nsym, psym);  
        FC_FUNC(g_if_diag_cooo_no0_x187, G_IF_DIAG_COOO_NO0_X187)
          (sk, ik, sm, im, so1, io1, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
        FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
      }
      }
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.188
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D3(i,k,k,o1,o2,i) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x188, G_IF_DIAG_COOO_NO0_X188)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.189
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D3(i,k,k,o1,o2,i) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x189, G_IF_DIAG_COOO_NO0_X189)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.190
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,i,k,o1,o2,k) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x190, G_IF_DIAG_COOO_NO0_X190)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.191
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,k,k,o1,m,i) V2(m,w,w,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x191, G_IF_DIAG_COOO_NO0_X191)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.192
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,i,k,o1) V2(k,w,w,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x192, G_IF_DIAG_COOO_NO0_X192)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.193
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,o1,o2,i) V2(w,o1,w,o2) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x193, G_IF_DIAG_COOO_NO0_X193)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.194
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,k,o1,m,k) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x194, G_IF_DIAG_COOO_NO0_X194)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.195
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D2(i,o1,k,k) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x195, G_IF_DIAG_COOO_NO0_X195)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.196
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D2(i,k,k,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x196, G_IF_DIAG_COOO_NO0_X196)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.197
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,o1,m,k) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x197, G_IF_DIAG_COOO_NO0_X197)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.198
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,o1,k,k) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x198, G_IF_DIAG_COOO_NO0_X198)
        (sk, ik, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.199
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,k,k,o1) V2(w,i,w,o1) 
  for(int sw = 0;sw < nir;++sw){ 
  for(int iw = symblockinfo.psym()(sw,I_C,I_BEGIN);iw <= symblockinfo.psym()(sw,I_C,I_END);++iw){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(iw);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, iw, sw, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x199, G_IF_DIAG_COOO_NO0_X199)
        (sm, im, sw, iw, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.200
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D4(k,o2,i,m,m,i,o3,o1) V2(k,o2,o1,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      for(int so2 = 0;so2 < nir;++so2){ 
      for(int io2 = symblockinfo.psym()(so2,I_O,I_BEGIN);io2 <= symblockinfo.psym()(so2,I_O,I_END);++io2){ 
        // Load D4 from disk, or GA ....                                                     
        int imoi = amo2imo[ik] - nclosed;                              
        int imoj = amo2imo[io2] - nclosed;                              
                                                                                             
        orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice(),            
                                           orz::Slice(),            orz::Slice()).copy();    
        rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, ik, sk, io2, so2, rdm4_ij_sliced);    
        FC_FUNC(g_if_set_d4,G_IF_SET_D4)(sk, so2, ik, io2, rdm4_sym.cptr(), nir, nsym, psym);  
        FC_FUNC(g_if_diag_cooo_no0_x200, G_IF_DIAG_COOO_NO0_X200)
          (sk, ik, sm, im, so2, io2, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
        FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
      }
      }
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.201
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D4(i,m,k,k,o1,o3,o2,i) V2(m,o2,o1,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    for(int si = 0;si < nir;++si){ 
    for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
      // Load D4 from disk, or GA ....                                                     
      int imoi = amo2imo[ii] - nclosed;                              
      int imoj = amo2imo[im] - nclosed;                              
                                                                                           
      orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice()).copy();    
      rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(si, sm, ii, im, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_diag_cooo_no0_x201, G_IF_DIAG_COOO_NO0_X201)
        (si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.202
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D3(i,m,o1,o3,o2,i) V2(m,o2,o1,o3) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x202, G_IF_DIAG_COOO_NO0_X202)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.203
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D3(i,k,o1,o3,o2,i) V2(k,o2,o1,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x203, G_IF_DIAG_COOO_NO0_X203)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.204
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,m,o1,k,o2,i) V2(m,o2,k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x204, G_IF_DIAG_COOO_NO0_X204)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.205
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) D3(i,k,o1,o3,o2,i) V2(k,o2,o1,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x205, G_IF_DIAG_COOO_NO0_X205)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.206
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,i,k,o2,o3,o1) V2(k,o2,o1,o3) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x206, G_IF_DIAG_COOO_NO0_X206)
        (sk, ik, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.207
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,k,m,i,o1,o2) V2(m,k,o1,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x207, G_IF_DIAG_COOO_NO0_X207)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.208
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,m,k,o1,o2,i) V2(m,o2,k,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x208, G_IF_DIAG_COOO_NO0_X208)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.209
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,i,o1,o2) V2(k,k,o1,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x209, G_IF_DIAG_COOO_NO0_X209)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.210
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) D2(i,o1,o2,i) V2(k,o1,k,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x210, G_IF_DIAG_COOO_NO0_X210)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.211
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,i,k,k,o1,o2) V2(m,m,o1,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x211, G_IF_DIAG_COOO_NO0_X211)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.212
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) D3(i,o1,k,k,o2,i) V2(m,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x212, G_IF_DIAG_COOO_NO0_X212)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.213
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) D2(i,o1,o2,i) V2(m,o1,m,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x213, G_IF_DIAG_COOO_NO0_X213)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.214
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,k,o1,i) V2(m,k,m,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x214, G_IF_DIAG_COOO_NO0_X214)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.215
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D4(i,m,k,k,m,o2,o1,o3) V2(i,o2,o1,o3) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      // Load D4 from disk, or GA ....                                                     
      int imoi = amo2imo[ii] - nclosed;                              
      int imoj = amo2imo[im] - nclosed;                              
                                                                                           
      orz::DTensor rdm4_ij_sliced = rdm4(orz::Slice(imoi,imoi+1), orz::Slice(imoj,imoj+1), 
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice(),            
                                         orz::Slice(),            orz::Slice()).copy();    
      rdm4_sym = orz::ct::sympack_rdm4_2(symblockinfo, ii, si, im, sm, rdm4_ij_sliced);    
      FC_FUNC(g_if_set_d4,G_IF_SET_D4)(si, sm, ii, im, rdm4_sym.cptr(), nir, nsym, psym);  
      FC_FUNC(g_if_diag_cooo_no0_x215, G_IF_DIAG_COOO_NO0_X215)
        (si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
      FC_FUNC(g_if_unset_d4,G_IF_UNSET_D4)();
    }
    }
  }
  }
  }


  {
  // No.216
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D3(i,m,m,o2,o3,o1) V2(i,o2,o1,o3) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x216, G_IF_DIAG_COOO_NO0_X216)
        (si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.217
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D3(i,k,k,o2,o3,o1) V2(i,o2,o1,o3) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x217, G_IF_DIAG_COOO_NO0_X217)
        (si, ii, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.218
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,m,k,o2,m,o1) V2(i,o1,k,o2) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x218, G_IF_DIAG_COOO_NO0_X218)
        (si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.219
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D3(i,k,k,o2,o1,o3) V2(i,o2,o1,o3) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x219, G_IF_DIAG_COOO_NO0_X219)
        (si, ii, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.220
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,o2,k,k,o3,o1) V2(i,o2,o1,o3) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x220, G_IF_DIAG_COOO_NO0_X220)
        (si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.221
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D3(i,o1,k,k,m,o2) V2(m,o1,i,o2) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x221, G_IF_DIAG_COOO_NO0_X221)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.222
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,o3,o1) V2(i,o2,o1,o3) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x222, G_IF_DIAG_COOO_NO0_X222)
        (si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.223
  //* Hdiag(w,i,k,m)  <--  (   -2.00000000) D2(i,o2,m,o1) V2(m,o2,i,o1) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(im);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, im, sm, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x223, G_IF_DIAG_COOO_NO0_X223)
      (sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.224
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,o2,k,o1) V2(k,o2,i,o1) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x224, G_IF_DIAG_COOO_NO0_X224)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.225
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,o2,o1,o3) V2(i,o2,o1,o3) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sk = 0;sk < nir;++sk){ 
    for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
      FC_FUNC(g_if_diag_cooo_no0_x225, G_IF_DIAG_COOO_NO0_X225)
        (si, ii, sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(ik, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.226
  //* Hdiag(w,i,k,k)  <--  (    1.00000000) D2(i,o1,k,o2) V2(k,o1,i,o2) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ik);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ik, sk, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_diag_cooo_no0_x226, G_IF_DIAG_COOO_NO0_X226)
      (sk, ik, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.227
  //* Hdiag(w,i,k,m)  <--  (    1.00000000) D2(i,o1,k,o2) V2(i,o1,k,o2) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    for(int sm = 0;sm < nir;++sm){ 
    for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
      Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
      FC_FUNC(g_if_diag_cooo_no0_x227, G_IF_DIAG_COOO_NO0_X227)
        (si, ii, sm, im, V2_sym.cptr(), Hdiagb.cptr(), nir, nsym, psym);
      retval.acc_amp2(im, Hdiagb);
    }
    }
  }
  }
  }


  {
  // No.228
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) Ecas D3(i,m,k,k,m,i) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x228, G_IF_DIAG_COOO_NO0_X228)
      (sm, im, &Ecas, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.229
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) Ecas D2(i,m,m,i) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x229, G_IF_DIAG_COOO_NO0_X229)
      (sm, im, &Ecas, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.230
  //* Hdiag(w,i,k,k)  <--  (   -2.00000000) Ecas D2(i,k,k,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x230, G_IF_DIAG_COOO_NO0_X230)
      (sk, ik, &Ecas, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }


  {
  // No.231
  //* Hdiag(w,i,k,m)  <--  (   -1.00000000) Ecas D2(i,i,k,k) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x231, G_IF_DIAG_COOO_NO0_X231)
      (sm, im, &Ecas, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.232
  //* Hdiag(w,i,k,m)  <--  (    2.00000000) Ecas D1(i,i) 
  for(int sm = 0;sm < nir;++sm){ 
  for(int im = symblockinfo.psym()(sm,I_O,I_BEGIN);im <= symblockinfo.psym()(sm,I_O,I_END);++im){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[im]);
    FC_FUNC(g_if_diag_cooo_no0_x232, G_IF_DIAG_COOO_NO0_X232)
      (sm, im, &Ecas, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(im, Hdiagb);
  }
  }
  }


  {
  // No.233
  //* Hdiag(w,i,k,k)  <--  (   -1.00000000) Ecas D1(i,i) 
  for(int sk = 0;sk < nir;++sk){ 
  for(int ik = symblockinfo.psym()(sk,I_O,I_BEGIN);ik <= symblockinfo.psym()(sk,I_O,I_END);++ik){ 
    Hdiagb = orz::DTensor(retval.namps_iamp()[ik]);
    FC_FUNC(g_if_diag_cooo_no0_x233, G_IF_DIAG_COOO_NO0_X233)
      (sk, ik, &Ecas, Hdiagb.cptr(), nir, nsym, psym);
    retval.acc_amp2(ik, Hdiagb);
  }
  }
  }

  return retval; 
} 
