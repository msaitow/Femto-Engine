

#ifndef C_DIAG_COVV_H
#define C_DIAG_COVV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//    o__ __o__/_                            o                         
//   <|    v                                <|>                        
//   < >                                    < >                        
//    |         o__  __o   \o__ __o__ __o    |        o__ __o         
//    o__/_    /v      |>   |     |     |>   o__/_   /v     v\        
//    |       />      //   / \   / \   / \   |      />       <\    
//   <o>      \o    o/     \o/   \o/   \o/   |      \         /   
//    |        v\  /v __o   |     |     |    o       o       o        
//   / \        <\/> __/>  / \   / \   / \   <\__    <\__ __/>  

void FC_FUNC(g_if_diag_covv_y0, G_IF_DIAG_COVV_Y0)
  (const double * const h, const double * const Y0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x0, G_IF_DIAG_COVV_NO0_X0)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y0, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x1, G_IF_DIAG_COVV_NO0_X1)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x2, G_IF_DIAG_COVV_NO0_X2)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x3, G_IF_DIAG_COVV_NO0_X3)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y4, G_IF_DIAG_COVV_Y4)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x4, G_IF_DIAG_COVV_NO0_X4)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y1, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y5, G_IF_DIAG_COVV_Y5)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x5, G_IF_DIAG_COVV_NO0_X5)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y6, G_IF_DIAG_COVV_Y6)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x6, G_IF_DIAG_COVV_NO0_X6)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y3, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y7, G_IF_DIAG_COVV_Y7)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x7, G_IF_DIAG_COVV_NO0_X7)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y4, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y8, G_IF_DIAG_COVV_Y8)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x8, G_IF_DIAG_COVV_NO0_X8)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y5, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x9, G_IF_DIAG_COVV_NO0_X9)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y10, G_IF_DIAG_COVV_Y10)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x10, G_IF_DIAG_COVV_NO0_X10)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y6, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x11, G_IF_DIAG_COVV_NO0_X11)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x12, G_IF_DIAG_COVV_NO0_X12)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y13, G_IF_DIAG_COVV_Y13)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x13, G_IF_DIAG_COVV_NO0_X13)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y7, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x14, G_IF_DIAG_COVV_NO0_X14)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y15, G_IF_DIAG_COVV_Y15)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x15, G_IF_DIAG_COVV_NO0_X15)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y8, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x16, G_IF_DIAG_COVV_NO0_X16)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x17, G_IF_DIAG_COVV_NO0_X17)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y18, G_IF_DIAG_COVV_Y18)
  (const double * const h, const double * const Y9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x18, G_IF_DIAG_COVV_NO0_X18)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y9, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x19, G_IF_DIAG_COVV_NO0_X19)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y20, G_IF_DIAG_COVV_Y20)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x20, G_IF_DIAG_COVV_NO0_X20)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y10, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y21, G_IF_DIAG_COVV_Y21)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x21, G_IF_DIAG_COVV_NO0_X21)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y11, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y22, G_IF_DIAG_COVV_Y22)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x22, G_IF_DIAG_COVV_NO0_X22)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y12, 
   const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y23, G_IF_DIAG_COVV_Y23)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x23, G_IF_DIAG_COVV_NO0_X23)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y13, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x24, G_IF_DIAG_COVV_NO0_X24)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y25, G_IF_DIAG_COVV_Y25)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x25, G_IF_DIAG_COVV_NO0_X25)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y14, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x26, G_IF_DIAG_COVV_NO0_X26)
  (const FC_INT &sc, const FC_INT &ic, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x27, G_IF_DIAG_COVV_NO0_X27)
  (const FC_INT &sc, const FC_INT &ic, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y28, G_IF_DIAG_COVV_Y28)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x28, G_IF_DIAG_COVV_NO0_X28)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const Y15, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x29, G_IF_DIAG_COVV_NO0_X29)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x30, G_IF_DIAG_COVV_NO0_X30)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x31, G_IF_DIAG_COVV_NO0_X31)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x32, G_IF_DIAG_COVV_NO0_X32)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x33, G_IF_DIAG_COVV_NO0_X33)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const h, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x34, G_IF_DIAG_COVV_NO0_X34)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y35, G_IF_DIAG_COVV_Y35)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y16, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x35, G_IF_DIAG_COVV_NO0_X35)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y16, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y36, G_IF_DIAG_COVV_Y36)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y17, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x36, G_IF_DIAG_COVV_NO0_X36)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y17, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x37, G_IF_DIAG_COVV_NO0_X37)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y38, G_IF_DIAG_COVV_Y38)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y18, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x38, G_IF_DIAG_COVV_NO0_X38)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y18, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x39, G_IF_DIAG_COVV_NO0_X39)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x40, G_IF_DIAG_COVV_NO0_X40)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y41, G_IF_DIAG_COVV_Y41)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y19, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x41, G_IF_DIAG_COVV_NO0_X41)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y19, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y42, G_IF_DIAG_COVV_Y42)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y20, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x42, G_IF_DIAG_COVV_NO0_X42)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y20, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x43, G_IF_DIAG_COVV_NO0_X43)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x44, G_IF_DIAG_COVV_NO0_X44)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y45, G_IF_DIAG_COVV_Y45)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y21, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x45, G_IF_DIAG_COVV_NO0_X45)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y21, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_y46, G_IF_DIAG_COVV_Y46)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y22, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x46, G_IF_DIAG_COVV_NO0_X46)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const Y22, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x47, G_IF_DIAG_COVV_NO0_X47)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sw, const FC_INT &iw, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x48, G_IF_DIAG_COVV_NO0_X48)
  (const FC_INT &sc, const FC_INT &ic, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x49, G_IF_DIAG_COVV_NO0_X49)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &so1, const FC_INT &io1, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x50, G_IF_DIAG_COVV_NO0_X50)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x51, G_IF_DIAG_COVV_NO0_X51)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x52, G_IF_DIAG_COVV_NO0_X52)
  (const FC_INT &sc, const FC_INT &ic, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_diag_covv_no0_x53, G_IF_DIAG_COVV_NO0_X53)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const V2, const double * const Hdiag, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

      
 }     
       
       
 #endif
       
       
 