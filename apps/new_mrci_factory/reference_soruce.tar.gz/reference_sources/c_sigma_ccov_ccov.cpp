                                                                                
#include <orz/orz.h>                                                            
#include <orz/openmp.h>                                                         
#include <orz/cblas.h>                                                          
#include <orz/clapack.h>                                                        
#include <tensor/tensor.h>                                                      
#include <sci/hint/para_disttools.h>                                            
#include <sci/ctnew2/ct.h>                                                      
#include <sci/ctnew2/ct_f.h>                                                    
#include <sci/ctnew2/ctclass_input.h>                                           
#include <sci/ctnew2/ctclass_symblock.h>                                        
#include <sci/ctnew2/ctclass_hintmo.h>                                          
#include <sci/ctnew2/ctclass_rdmpack.h>                                         
#include <sci/ctnew2/ctclass_bareamppack.h>                                     
#include <sci/ctnew2/ctclass_orthamppack.h>                                     
#include <sci/ctnew2/diaghessian.h>                                             
#include <sci/ctnew2/symamp2.h>                                                 
#include <sci/ctnew2/mrci.h>                                                    
#include <sci/ctnew2/c_sigma_ccov_ccov.h>                                            
                                                                                
using std::cout;                                                                
using std::endl;                                                                
                                                                                
#define FLOPCOUNT                                                               
                                                                                
//  `MMMMMMM                                         
//   MM    \                         /              
//   MM       ____  ___  __    __   /M      _____    
//   MM   ,  6MMMMb `MM 6MMb  6MMb /MMMMM  6MMMMMb   
//   MMMMMM 6M'  `Mb MM69 `MM69 `Mb MM    6M'   `Mb  
//   MM   ` MM    MM MM'   MM'   MM MM    MM     MM  
//   MM     MMMMMMMM MM    MM    MM MM    MM     MM  
//   MM     MM       MM    MM    MM MM    MM     MM  
//   MM     YM    d9 MM    MM    MM YM.  ,YM.   ,M9  
//  _MM_     YMMMM9 _MM_  _MM_  _MM_ YMMM9 YMMMMM9   

                                                                                
// ***************************************************************************  
// orz::ct::mrci                                                                
// ***************************************************************************  
									    /*!        
   @brief CT input                                                              
									     */        
                                                                                
orz::ct::BareAmpPack orz::ct::sigma_ccov_ccov(const orz::ct::Input &ctinp,                                    
                                  const orz::ct::SymBlockInfo &symblockinfo,                                
                                  const orz::ct::HintMO &hintmo,                                            
                                  const orz::ct::RdmPack &rdmPack_sym,                                      
                                  const orz::ct::BareAmpPack &T2,                             
                                  const int num_sigma) {
                                                                                                                
                                                                                                                
  // set up nmo nclosed, nocc                                                                                   
  const FC_INT nclosed = ctinp.nclosed();                                                                       
  const FC_INT nocc    = ctinp.nocc();                                                                          
  const FC_INT nvir    = ctinp.nvir();                                                                          
  const FC_INT nmo     = nclosed + nocc + nvir;                                                                 
  const FC_INT nir     = symblockinfo.nir();                                                                    
  const FC_INT * const nsym    = symblockinfo.nsym().cptr();                                                    
  const FC_INT * const psym    = symblockinfo.psym().cptr();                                                    
  const FC_INT * const amo2imo = symblockinfo.amo2imo().cptr();                                                 
                                                                                                                
  orz::DTensor moint1 = hintmo.int1(); // Setting up one-body integrals                                         
  const orz::DTensor moint1_sym = orz::ct::sympack_int1(symblockinfo, moint1); // moint1=(IR-COV index)         
  orz::DTensor V2(nmo,nmo,nmo);                                                                    
  double * const V2_ptr = V2.cptr();                                                  
                                                                                                                
  std::ostringstream stm;                                                                                       
  stm << num_sigma;                                                                                             
  std::string name_of_sigma = "S2" + stm.str() + "]"; // Name of the Sigma vector  
  orz::ct::BareAmpPack retval                                                                                   
    = orz::ct::BareAmpPack(ctinp, symblockinfo, name_of_sigma); // Sigma(a, a', e, e') tensor                   
                                                                                                                
  orz::DTensor S2b; // Container of S2_aae,[b] tensor                                   
                                                                                                                
  orz::DTensor T2b; // Container of T2_aae,[b] tensor                                             


  {
  // No.0
  //* S2(w,y,i,a)  <--  (    2.00000000) Y0 D1(i,o1) T2(y,w,o1,a) 
  // The effective tensor is detected .... 
  double Y0 = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_y0, G_IF_SIGMA_CCOV_CCOV_Y0)
    (moint1_sym.cptr(), &Y0, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x0, G_IF_SIGMA_CCOV_CCOV_NO0_X0)
      (sa, ia, &Y0, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.1
  //* S2(w,y,i,a)  <--  (    2.00000000) Y1 D1(i,o1) T2(y,w,o1,a) 
  // The effective tensor is detected .... 
  double Y1 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y1, G_IF_SIGMA_CCOV_CCOV_Y1)
      (sc1, ic1, V2_sym.cptr(), &Y1, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x1, G_IF_SIGMA_CCOV_CCOV_NO0_X1)
      (sa, ia, &Y1, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.2
  //* S2(w,y,i,a)  <--  (   -1.00000000) Y2 D1(i,o1) T2(y,w,o1,a) 
  // The effective tensor is detected .... 
  double Y2 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y2, G_IF_SIGMA_CCOV_CCOV_Y2)
      (sc1, ic1, V2_sym.cptr(), &Y2, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x2, G_IF_SIGMA_CCOV_CCOV_NO0_X2)
      (sa, ia, &Y2, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.3
  //* S2(w,y,i,a)  <--  (   -4.00000000) Y3 D1(i,o1) T2(w,y,o1,a) 
  // The effective tensor is detected .... 
  double Y3 = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_y3, G_IF_SIGMA_CCOV_CCOV_Y3)
    (moint1_sym.cptr(), &Y3, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x3, G_IF_SIGMA_CCOV_CCOV_NO0_X3)
      (sa, ia, &Y3, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.4
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,c1,o1,a) h(c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x4, G_IF_SIGMA_CCOV_CCOV_NO0_X4)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x4, G_IF_SIGMA_CCOV_CCOV_NO1_X4)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.5
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(c1,y,o1,a) h(c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x5, G_IF_SIGMA_CCOV_CCOV_NO0_X5)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x5, G_IF_SIGMA_CCOV_CCOV_NO1_X5)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.6
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,c1,o1,a) h(c1,y) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x6, G_IF_SIGMA_CCOV_CCOV_NO0_X6)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x6, G_IF_SIGMA_CCOV_CCOV_NO1_X6)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.7
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(c1,w,o1,a) h(c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x7, G_IF_SIGMA_CCOV_CCOV_NO0_X7)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x7, G_IF_SIGMA_CCOV_CCOV_NO1_X7)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.8
  //* S2(w,y,i,a)  <--  (    8.00000000) Y4 T2(w,y,i,a) 
  // The effective tensor is detected .... 
  double Y4 = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_y8, G_IF_SIGMA_CCOV_CCOV_Y8)
    (moint1_sym.cptr(), &Y4, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x8, G_IF_SIGMA_CCOV_CCOV_NO0_X8)
      (sa, ia, &Y4, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.9
  //* S2(w,y,i,a)  <--  (   -4.00000000) Y5 T2(y,w,i,a) 
  // The effective tensor is detected .... 
  double Y5 = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_y9, G_IF_SIGMA_CCOV_CCOV_Y9)
    (moint1_sym.cptr(), &Y5, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x9, G_IF_SIGMA_CCOV_CCOV_NO0_X9)
      (sa, ia, &Y5, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.10
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,y,i,a) h(c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x10, G_IF_SIGMA_CCOV_CCOV_NO0_X10)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.11
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,i,a) h(c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x11, G_IF_SIGMA_CCOV_CCOV_NO0_X11)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.12
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,i,a) h(c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x12, G_IF_SIGMA_CCOV_CCOV_NO0_X12)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.13
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,c1,i,a) h(c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x13, G_IF_SIGMA_CCOV_CCOV_NO0_X13)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.14
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) h(o3,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o2,a) X(i,o2) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x14, G_IF_SIGMA_CCOV_CCOV_NO0_X14)
    (moint1_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x14, G_IF_SIGMA_CCOV_CCOV_NO1_X14)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.15
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y6(o1,o3) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,y,o2,a) X(i,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y6 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y15, G_IF_SIGMA_CCOV_CCOV_Y15)
      (sc1, ic1, V2_sym.cptr(), Y6.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x15, G_IF_SIGMA_CCOV_CCOV_NO0_X15)
    (Y6.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x15, G_IF_SIGMA_CCOV_CCOV_NO1_X15)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.16
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y7(o1,o3) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,y,o2,a) X(i,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y7 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y16, G_IF_SIGMA_CCOV_CCOV_Y16)
      (sc1, ic1, V2_sym.cptr(), Y7.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x16, G_IF_SIGMA_CCOV_CCOV_NO0_X16)
    (Y7.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x16, G_IF_SIGMA_CCOV_CCOV_NO1_X16)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.17
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o1,o3) h(o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o2,a) X(i,o2) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x17, G_IF_SIGMA_CCOV_CCOV_NO0_X17)
    (moint1_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x17, G_IF_SIGMA_CCOV_CCOV_NO1_X17)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.18
  //* X()  <--  (    1.00000000)  D1(o1,o2) h(o2,o1) 
  //* S2(w,y,i,a)  <--  (    4.00000000) X T2(w,y,i,a) 
  double X = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x18, G_IF_SIGMA_CCOV_CCOV_NO0_X18)
    (moint1_sym.cptr(), &X, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x18, G_IF_SIGMA_CCOV_CCOV_NO1_X18)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.19
  //* X()  <--  (    1.00000000)  D1(o1,o2) h(o2,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) X T2(y,w,i,a) 
  double X = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x19, G_IF_SIGMA_CCOV_CCOV_NO0_X19)
    (moint1_sym.cptr(), &X, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x19, G_IF_SIGMA_CCOV_CCOV_NO1_X19)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.20
  //* X()  <--  (    1.00000000)  D1(o1,o2) Y8(o1,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) X T2(y,w,i,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y8 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y20, G_IF_SIGMA_CCOV_CCOV_Y20)
      (sc1, ic1, V2_sym.cptr(), Y8.cptr(), nir, nsym, psym);
  }
  }
  double X = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x20, G_IF_SIGMA_CCOV_CCOV_NO0_X20)
    (Y8.cptr(), &X, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x20, G_IF_SIGMA_CCOV_CCOV_NO1_X20)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.21
  //* X()  <--  (    1.00000000)  D1(o1,o2) Y9(o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X T2(y,w,i,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y9 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y21, G_IF_SIGMA_CCOV_CCOV_Y21)
      (sc1, ic1, V2_sym.cptr(), Y9.cptr(), nir, nsym, psym);
  }
  }
  double X = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x21, G_IF_SIGMA_CCOV_CCOV_NO0_X21)
    (Y9.cptr(), &X, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x21, G_IF_SIGMA_CCOV_CCOV_NO1_X21)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.22
  //* X(o1,i)  <--  (    1.00000000)  D1(o1,o2) h(i,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,a) X(o1,i) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x22, G_IF_SIGMA_CCOV_CCOV_NO0_X22)
    (moint1_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x22, G_IF_SIGMA_CCOV_CCOV_NO1_X22)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.23
  //* X(o1,i)  <--  (    1.00000000)  D1(o1,o2) h(i,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o1,a) X(o1,i) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x23, G_IF_SIGMA_CCOV_CCOV_NO0_X23)
    (moint1_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x23, G_IF_SIGMA_CCOV_CCOV_NO1_X23)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.24
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o1,a) h(o2,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x24, G_IF_SIGMA_CCOV_CCOV_NO0_X24)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x24, G_IF_SIGMA_CCOV_CCOV_NO1_X24)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.25
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o1,a) Y10(o1,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o2) X(w,y,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y10 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y25, G_IF_SIGMA_CCOV_CCOV_Y25)
      (sc1, ic1, V2_sym.cptr(), Y10.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x25, G_IF_SIGMA_CCOV_CCOV_NO0_X25)
      (sa, ia, T2b.cptr(), Y10.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x25, G_IF_SIGMA_CCOV_CCOV_NO1_X25)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.26
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o1,a) Y11(o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y11 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y26, G_IF_SIGMA_CCOV_CCOV_Y26)
      (sc1, ic1, V2_sym.cptr(), Y11.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x26, G_IF_SIGMA_CCOV_CCOV_NO0_X26)
      (sa, ia, T2b.cptr(), Y11.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x26, G_IF_SIGMA_CCOV_CCOV_NO1_X26)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.27
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,a) h(o2,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x27, G_IF_SIGMA_CCOV_CCOV_NO0_X27)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x27, G_IF_SIGMA_CCOV_CCOV_NO1_X27)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.28
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,o1,a) h(i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x28, G_IF_SIGMA_CCOV_CCOV_NO0_X28)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.29
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o1,a) h(i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x29, G_IF_SIGMA_CCOV_CCOV_NO0_X29)
      (sa, ia, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.30
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,w,o1,a) Y12(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y12 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y30, G_IF_SIGMA_CCOV_CCOV_Y30)
      (sc1, ic1, V2_sym.cptr(), Y12.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x30, G_IF_SIGMA_CCOV_CCOV_NO0_X30)
      (sa, ia, T2b.cptr(), Y12.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.31
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,w,o1,a) Y13(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y13 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y31, G_IF_SIGMA_CCOV_CCOV_Y31)
      (sc1, ic1, V2_sym.cptr(), Y13.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x31, G_IF_SIGMA_CCOV_CCOV_NO0_X31)
      (sa, ia, T2b.cptr(), Y13.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.32
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,y,o1,v1) h(a,v1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x32, G_IF_SIGMA_CCOV_CCOV_NO0_X32)
        (sa, ia, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x32, G_IF_SIGMA_CCOV_CCOV_NO1_X32)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.33
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,y,o1,v1) Y14(a,v1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o1) X(w,y,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y14 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y33, G_IF_SIGMA_CCOV_CCOV_Y33)
      (sc1, ic1, V2_sym.cptr(), Y14.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x33, G_IF_SIGMA_CCOV_CCOV_NO0_X33)
        (sa, ia, sv1, iv1, T2b.cptr(), Y14.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x33, G_IF_SIGMA_CCOV_CCOV_NO1_X33)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.34
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,y,o1,v1) Y15(a,v1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(w,y,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y15 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y34, G_IF_SIGMA_CCOV_CCOV_Y34)
      (sc1, ic1, V2_sym.cptr(), Y15.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x34, G_IF_SIGMA_CCOV_CCOV_NO0_X34)
        (sa, ia, sv1, iv1, T2b.cptr(), Y15.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x34, G_IF_SIGMA_CCOV_CCOV_NO1_X34)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.35
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,w,o1,v1) h(a,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x35, G_IF_SIGMA_CCOV_CCOV_NO0_X35)
        (sa, ia, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x35, G_IF_SIGMA_CCOV_CCOV_NO1_X35)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.36
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,i,v1) h(a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x36, G_IF_SIGMA_CCOV_CCOV_NO0_X36)
        (sa, ia, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.37
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,i,v1) h(a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x37, G_IF_SIGMA_CCOV_CCOV_NO0_X37)
        (sa, ia, sv1, iv1, T2b.cptr(), moint1_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.38
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,w,i,v1) Y16(a,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y16 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y38, G_IF_SIGMA_CCOV_CCOV_Y38)
      (sc1, ic1, V2_sym.cptr(), Y16.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x38, G_IF_SIGMA_CCOV_CCOV_NO0_X38)
        (sa, ia, sv1, iv1, T2b.cptr(), Y16.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.39
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,w,i,v1) Y17(a,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y17 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y39, G_IF_SIGMA_CCOV_CCOV_Y39)
      (sc1, ic1, V2_sym.cptr(), Y17.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x39, G_IF_SIGMA_CCOV_CCOV_NO0_X39)
        (sa, ia, sv1, iv1, T2b.cptr(), Y17.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.40
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,c2,o1,a) Y18(c2,w) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o1) X(y,w,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y18 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y40, G_IF_SIGMA_CCOV_CCOV_Y40)
      (sc1, ic1, V2_sym.cptr(), Y18.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x40, G_IF_SIGMA_CCOV_CCOV_NO0_X40)
      (sa, ia, T2b.cptr(), Y18.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x40, G_IF_SIGMA_CCOV_CCOV_NO1_X40)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.41
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,c2,o1,a) Y19(c2,w) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o1) X(y,w,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y19 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y41, G_IF_SIGMA_CCOV_CCOV_Y41)
      (sc1, ic1, V2_sym.cptr(), Y19.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x41, G_IF_SIGMA_CCOV_CCOV_NO0_X41)
      (sa, ia, T2b.cptr(), Y19.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x41, G_IF_SIGMA_CCOV_CCOV_NO1_X41)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.42
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(c2,y,o1,a) Y20(c2,w) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o1) X(y,w,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y20 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y42, G_IF_SIGMA_CCOV_CCOV_Y42)
      (sc1, ic1, V2_sym.cptr(), Y20.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x42, G_IF_SIGMA_CCOV_CCOV_NO0_X42)
      (sa, ia, T2b.cptr(), Y20.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x42, G_IF_SIGMA_CCOV_CCOV_NO1_X42)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.43
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(c2,y,o1,a) Y21(c2,w) 
  //* S2(w,y,i,a)  <--  (    4.00000000) D1(i,o1) X(y,w,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y21 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y43, G_IF_SIGMA_CCOV_CCOV_Y43)
      (sc1, ic1, V2_sym.cptr(), Y21.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x43, G_IF_SIGMA_CCOV_CCOV_NO0_X43)
      (sa, ia, T2b.cptr(), Y21.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x43, G_IF_SIGMA_CCOV_CCOV_NO1_X43)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.44
  //* S2(w,y,i,a)  <--  (   -4.00000000) Y22 D1(i,o1) T2(w,y,o1,a) 
  // The effective tensor is detected .... 
  double Y22 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y44, G_IF_SIGMA_CCOV_CCOV_Y44)
      (sc1, ic1, V2_sym.cptr(), &Y22, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x44, G_IF_SIGMA_CCOV_CCOV_NO0_X44)
      (sa, ia, &Y22, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.45
  //* S2(w,y,i,a)  <--  (    2.00000000) Y23 D1(i,o1) T2(w,y,o1,a) 
  // The effective tensor is detected .... 
  double Y23 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y45, G_IF_SIGMA_CCOV_CCOV_Y45)
      (sc1, ic1, V2_sym.cptr(), &Y23, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x45, G_IF_SIGMA_CCOV_CCOV_NO0_X45)
      (sa, ia, &Y23, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.46
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(c2,c1,o1,a) V2(c1,w,c2,y) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x46, G_IF_SIGMA_CCOV_CCOV_NO0_X46)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x46, G_IF_SIGMA_CCOV_CCOV_NO1_X46)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.47
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(c2,w,o1,a) Y24(c2,y) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o1) X(w,y,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y24 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y47, G_IF_SIGMA_CCOV_CCOV_Y47)
      (sc1, ic1, V2_sym.cptr(), Y24.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x47, G_IF_SIGMA_CCOV_CCOV_NO0_X47)
      (sa, ia, T2b.cptr(), Y24.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x47, G_IF_SIGMA_CCOV_CCOV_NO1_X47)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.48
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(c2,w,o1,a) Y25(c2,y) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o1) X(w,y,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y25 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y48, G_IF_SIGMA_CCOV_CCOV_Y48)
      (sc1, ic1, V2_sym.cptr(), Y25.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x48, G_IF_SIGMA_CCOV_CCOV_NO0_X48)
      (sa, ia, T2b.cptr(), Y25.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x48, G_IF_SIGMA_CCOV_CCOV_NO1_X48)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.49
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(c2,c1,o1,a) V2(c1,y,c2,w) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x49, G_IF_SIGMA_CCOV_CCOV_NO0_X49)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x49, G_IF_SIGMA_CCOV_CCOV_NO1_X49)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.50
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,c2,o1,a) Y26(c2,y) 
  //* S2(w,y,i,a)  <--  (    4.00000000) D1(i,o1) X(w,y,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y26 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y50, G_IF_SIGMA_CCOV_CCOV_Y50)
      (sc1, ic1, V2_sym.cptr(), Y26.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x50, G_IF_SIGMA_CCOV_CCOV_NO0_X50)
      (sa, ia, T2b.cptr(), Y26.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x50, G_IF_SIGMA_CCOV_CCOV_NO1_X50)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.51
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,c2,o1,a) Y27(c2,y) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o1) X(w,y,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y27 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y51, G_IF_SIGMA_CCOV_CCOV_Y51)
      (sc1, ic1, V2_sym.cptr(), Y27.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x51, G_IF_SIGMA_CCOV_CCOV_NO0_X51)
      (sa, ia, T2b.cptr(), Y27.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x51, G_IF_SIGMA_CCOV_CCOV_NO1_X51)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.52
  //* S2(w,y,i,a)  <--  (    8.00000000) Y28 T2(w,y,i,a) 
  // The effective tensor is detected .... 
  double Y28 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y52, G_IF_SIGMA_CCOV_CCOV_Y52)
      (sc1, ic1, V2_sym.cptr(), &Y28, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x52, G_IF_SIGMA_CCOV_CCOV_NO0_X52)
      (sa, ia, &Y28, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.53
  //* S2(w,y,i,a)  <--  (   -4.00000000) Y29 T2(w,y,i,a) 
  // The effective tensor is detected .... 
  double Y29 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y53, G_IF_SIGMA_CCOV_CCOV_Y53)
      (sc1, ic1, V2_sym.cptr(), &Y29, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x53, G_IF_SIGMA_CCOV_CCOV_NO0_X53)
      (sa, ia, &Y29, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.54
  //* S2(w,y,i,a)  <--  (   -8.00000000) T2(w,c2,i,a) Y30(c2,y) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y30 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y54, G_IF_SIGMA_CCOV_CCOV_Y54)
      (sc1, ic1, V2_sym.cptr(), Y30.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x54, G_IF_SIGMA_CCOV_CCOV_NO0_X54)
      (sa, ia, T2b.cptr(), Y30.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.55
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,c2,i,a) Y31(c2,y) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y31 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y55, G_IF_SIGMA_CCOV_CCOV_Y55)
      (sc1, ic1, V2_sym.cptr(), Y31.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x55, G_IF_SIGMA_CCOV_CCOV_NO0_X55)
      (sa, ia, T2b.cptr(), Y31.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.56
  //* S2(w,y,i,a)  <--  (   -4.00000000) Y32 T2(y,w,i,a) 
  // The effective tensor is detected .... 
  double Y32 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y56, G_IF_SIGMA_CCOV_CCOV_Y56)
      (sc1, ic1, V2_sym.cptr(), &Y32, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x56, G_IF_SIGMA_CCOV_CCOV_NO0_X56)
      (sa, ia, &Y32, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.57
  //* S2(w,y,i,a)  <--  (    2.00000000) Y33 T2(y,w,i,a) 
  // The effective tensor is detected .... 
  double Y33 = 0;
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y57, G_IF_SIGMA_CCOV_CCOV_Y57)
      (sc1, ic1, V2_sym.cptr(), &Y33, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x57, G_IF_SIGMA_CCOV_CCOV_NO0_X57)
      (sa, ia, &Y33, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.58
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(c2,w,i,a) Y34(c2,y) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y34 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y58, G_IF_SIGMA_CCOV_CCOV_Y58)
      (sc1, ic1, V2_sym.cptr(), Y34.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x58, G_IF_SIGMA_CCOV_CCOV_NO0_X58)
      (sa, ia, T2b.cptr(), Y34.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.59
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(c2,w,i,a) Y35(c2,y) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y35 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y59, G_IF_SIGMA_CCOV_CCOV_Y59)
      (sc1, ic1, V2_sym.cptr(), Y35.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x59, G_IF_SIGMA_CCOV_CCOV_NO0_X59)
      (sa, ia, T2b.cptr(), Y35.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.60
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(y,c2,i,a) Y36(c2,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y36 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y60, G_IF_SIGMA_CCOV_CCOV_Y60)
      (sc1, ic1, V2_sym.cptr(), Y36.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x60, G_IF_SIGMA_CCOV_CCOV_NO0_X60)
      (sa, ia, T2b.cptr(), Y36.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.61
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,c2,i,a) Y37(c2,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y37 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y61, G_IF_SIGMA_CCOV_CCOV_Y61)
      (sc1, ic1, V2_sym.cptr(), Y37.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x61, G_IF_SIGMA_CCOV_CCOV_NO0_X61)
      (sa, ia, T2b.cptr(), Y37.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.62
  //* S2(w,y,i,a)  <--  (   -8.00000000) T2(c2,y,i,a) Y38(c2,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y38 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y62, G_IF_SIGMA_CCOV_CCOV_Y62)
      (sc1, ic1, V2_sym.cptr(), Y38.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x62, G_IF_SIGMA_CCOV_CCOV_NO0_X62)
      (sa, ia, T2b.cptr(), Y38.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.63
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(c2,y,i,a) Y39(c2,w) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nclosed, nclosed);
  orz::DTensor Y39 = orz::ct::sympack_Xcc(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y63, G_IF_SIGMA_CCOV_CCOV_Y63)
      (sc1, ic1, V2_sym.cptr(), Y39.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x63, G_IF_SIGMA_CCOV_CCOV_NO0_X63)
      (sa, ia, T2b.cptr(), Y39.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.64
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(c2,c1,i,a) V2(c1,y,c2,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x64, G_IF_SIGMA_CCOV_CCOV_NO0_X64)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.65
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(c2,c1,i,a) V2(c1,w,c2,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x65, G_IF_SIGMA_CCOV_CCOV_NO0_X65)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.66
  //* X(c1,w,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,c1,o2,a) X(c1,w,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x66, G_IF_SIGMA_CCOV_CCOV_NO0_X66)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x66, G_IF_SIGMA_CCOV_CCOV_NO1_X66)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.67
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y40(o1,o3) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,w,o2,a) X(i,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y40 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y67, G_IF_SIGMA_CCOV_CCOV_Y67)
      (sc1, ic1, V2_sym.cptr(), Y40.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x67, G_IF_SIGMA_CCOV_CCOV_NO0_X67)
    (Y40.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x67, G_IF_SIGMA_CCOV_CCOV_NO1_X67)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.68
  //* X(i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) Y41(o1,o3) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,w,o2,a) X(i,o2) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y41 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y68, G_IF_SIGMA_CCOV_CCOV_Y68)
      (sc1, ic1, V2_sym.cptr(), Y41.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x68, G_IF_SIGMA_CCOV_CCOV_NO0_X68)
    (Y41.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x68, G_IF_SIGMA_CCOV_CCOV_NO1_X68)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.69
  //* X(c1,w,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,w,o1,o3) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,o2,a) X(c1,w,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x69, G_IF_SIGMA_CCOV_CCOV_NO0_X69)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x69, G_IF_SIGMA_CCOV_CCOV_NO1_X69)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.70
  //* X(c1,y,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,y,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,w,o2,a) X(c1,y,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x70, G_IF_SIGMA_CCOV_CCOV_NO0_X70)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x70, G_IF_SIGMA_CCOV_CCOV_NO1_X70)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.71
  //* X(c1,y,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,y,o1,o3) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,c1,o2,a) X(c1,y,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x71, G_IF_SIGMA_CCOV_CCOV_NO0_X71)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x71, G_IF_SIGMA_CCOV_CCOV_NO1_X71)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.72
  //* X(c1,y,i,o2)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,o3,y,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(w,c1,o2,a) X(c1,y,i,o2) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x72, G_IF_SIGMA_CCOV_CCOV_NO0_X72)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x72, G_IF_SIGMA_CCOV_CCOV_NO1_X72)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.73
  //* X()  <--  (    1.00000000)  D1(o1,o2) Y42(o1,o2) 
  //* S2(w,y,i,a)  <--  (    8.00000000) X T2(w,y,i,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y42 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y73, G_IF_SIGMA_CCOV_CCOV_Y73)
      (sc1, ic1, V2_sym.cptr(), Y42.cptr(), nir, nsym, psym);
  }
  }
  double X = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x73, G_IF_SIGMA_CCOV_CCOV_NO0_X73)
    (Y42.cptr(), &X, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x73, G_IF_SIGMA_CCOV_CCOV_NO1_X73)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.74
  //* X(c1,y)  <--  (    1.00000000)  D1(o1,o2) V2(c1,y,o1,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,c1,i,a) X(c1,y) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x74, G_IF_SIGMA_CCOV_CCOV_NO0_X74)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x74, G_IF_SIGMA_CCOV_CCOV_NO1_X74)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.75
  //* X(c1,y)  <--  (    1.00000000)  D1(o1,o2) V2(c1,y,o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,i,a) X(c1,y) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x75, G_IF_SIGMA_CCOV_CCOV_NO0_X75)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x75, G_IF_SIGMA_CCOV_CCOV_NO1_X75)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.76
  //* X(c1,y)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,y,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,w,i,a) X(c1,y) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x76, G_IF_SIGMA_CCOV_CCOV_NO0_X76)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x76, G_IF_SIGMA_CCOV_CCOV_NO1_X76)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.77
  //* X(c1,w)  <--  (    1.00000000)  D1(o1,o2) V2(c1,w,o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,i,a) X(c1,w) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x77, G_IF_SIGMA_CCOV_CCOV_NO0_X77)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x77, G_IF_SIGMA_CCOV_CCOV_NO1_X77)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.78
  //* X(c1,w)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,w,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,c1,i,a) X(c1,w) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x78, G_IF_SIGMA_CCOV_CCOV_NO0_X78)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x78, G_IF_SIGMA_CCOV_CCOV_NO1_X78)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.79
  //* X(c1,w)  <--  (    1.00000000)  D1(o1,o2) V2(c1,w,o1,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,y,i,a) X(c1,w) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x79, G_IF_SIGMA_CCOV_CCOV_NO0_X79)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x79, G_IF_SIGMA_CCOV_CCOV_NO1_X79)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.80
  //* X(c1,w,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,w,i,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,c1,o2,a) X(c1,w,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x80, G_IF_SIGMA_CCOV_CCOV_NO0_X80)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x80, G_IF_SIGMA_CCOV_CCOV_NO1_X80)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.81
  //* X(o2,i)  <--  (    1.00000000)  D1(o1,o2) Y43(i,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,w,o2,a) X(o2,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y43 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y81, G_IF_SIGMA_CCOV_CCOV_Y81)
      (sc1, ic1, V2_sym.cptr(), Y43.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x81, G_IF_SIGMA_CCOV_CCOV_NO0_X81)
    (Y43.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x81, G_IF_SIGMA_CCOV_CCOV_NO1_X81)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.82
  //* X(o2,i)  <--  (    1.00000000)  D1(o1,o2) Y44(i,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,w,o2,a) X(o2,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y44 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y82, G_IF_SIGMA_CCOV_CCOV_Y82)
      (sc1, ic1, V2_sym.cptr(), Y44.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x82, G_IF_SIGMA_CCOV_CCOV_NO0_X82)
    (Y44.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x82, G_IF_SIGMA_CCOV_CCOV_NO1_X82)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.83
  //* X(c1,w,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,w,i,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,o2,a) X(c1,w,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x83, G_IF_SIGMA_CCOV_CCOV_NO0_X83)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x83, G_IF_SIGMA_CCOV_CCOV_NO1_X83)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.84
  //* X(c1,w,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,w,i) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,y,o2,a) X(c1,w,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x84, G_IF_SIGMA_CCOV_CCOV_NO0_X84)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x84, G_IF_SIGMA_CCOV_CCOV_NO1_X84)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.85
  //* X(o2,i)  <--  (    1.00000000)  D1(o1,o2) Y45(i,o1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,y,o2,a) X(o2,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y45 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y85, G_IF_SIGMA_CCOV_CCOV_Y85)
      (sc1, ic1, V2_sym.cptr(), Y45.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x85, G_IF_SIGMA_CCOV_CCOV_NO0_X85)
    (Y45.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x85, G_IF_SIGMA_CCOV_CCOV_NO1_X85)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.86
  //* X(c1,y,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,y,i,o1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,w,o2,a) X(c1,y,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x86, G_IF_SIGMA_CCOV_CCOV_NO0_X86)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x86, G_IF_SIGMA_CCOV_CCOV_NO1_X86)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.87
  //* X(c1,y,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,y,i,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,c1,o2,a) X(c1,y,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x87, G_IF_SIGMA_CCOV_CCOV_NO0_X87)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x87, G_IF_SIGMA_CCOV_CCOV_NO1_X87)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.88
  //* X(c1,y,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,y,i) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(w,c1,o2,a) X(c1,y,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x88, G_IF_SIGMA_CCOV_CCOV_NO0_X88)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x88, G_IF_SIGMA_CCOV_CCOV_NO1_X88)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.89
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,c1,o1,a) V2(c1,w,o1,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x89, G_IF_SIGMA_CCOV_CCOV_NO0_X89)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x89, G_IF_SIGMA_CCOV_CCOV_NO1_X89)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.90
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,a) Y46(o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y46 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y90, G_IF_SIGMA_CCOV_CCOV_Y90)
      (sc1, ic1, V2_sym.cptr(), Y46.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x90, G_IF_SIGMA_CCOV_CCOV_NO0_X90)
      (sa, ia, T2b.cptr(), Y46.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x90, G_IF_SIGMA_CCOV_CCOV_NO1_X90)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.91
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,a) Y47(o1,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(y,w,o2,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y47 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y91, G_IF_SIGMA_CCOV_CCOV_Y91)
      (sc1, ic1, V2_sym.cptr(), Y47.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x91, G_IF_SIGMA_CCOV_CCOV_NO0_X91)
      (sa, ia, T2b.cptr(), Y47.cptr(), Xcca.cptr(), nir, nsym, psym);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x91, G_IF_SIGMA_CCOV_CCOV_NO1_X91)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.92
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(c1,y,o1,a) V2(c1,w,o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x92, G_IF_SIGMA_CCOV_CCOV_NO0_X92)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x92, G_IF_SIGMA_CCOV_CCOV_NO1_X92)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.93
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(c1,y,o1,a) V2(c1,o1,w,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x93, G_IF_SIGMA_CCOV_CCOV_NO0_X93)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x93, G_IF_SIGMA_CCOV_CCOV_NO1_X93)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.94
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,a) V2(c1,y,o1,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x94, G_IF_SIGMA_CCOV_CCOV_NO0_X94)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x94, G_IF_SIGMA_CCOV_CCOV_NO1_X94)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.95
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,a) V2(c1,y,o1,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x95, G_IF_SIGMA_CCOV_CCOV_NO0_X95)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x95, G_IF_SIGMA_CCOV_CCOV_NO1_X95)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.96
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,c1,o1,a) V2(c1,o1,y,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x96, G_IF_SIGMA_CCOV_CCOV_NO0_X96)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x96, G_IF_SIGMA_CCOV_CCOV_NO1_X96)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.97
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(w,y,o1,a) Y48(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y48 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y97, G_IF_SIGMA_CCOV_CCOV_Y97)
      (sc1, ic1, V2_sym.cptr(), Y48.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x97, G_IF_SIGMA_CCOV_CCOV_NO0_X97)
      (sa, ia, T2b.cptr(), Y48.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.98
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,c1,o1,a) V2(c1,y,i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x98, G_IF_SIGMA_CCOV_CCOV_NO0_X98)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.99
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,o1,a) V2(c1,y,i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x99, G_IF_SIGMA_CCOV_CCOV_NO0_X99)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.100
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,w,o1,a) V2(c1,o1,y,i) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x100, G_IF_SIGMA_CCOV_CCOV_NO0_X100)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.101
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,o1,a) V2(c1,w,i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x101, G_IF_SIGMA_CCOV_CCOV_NO0_X101)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.102
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,c1,o1,a) V2(c1,o1,w,i) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x102, G_IF_SIGMA_CCOV_CCOV_NO0_X102)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.103
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,y,o1,a) V2(c1,w,i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x103, G_IF_SIGMA_CCOV_CCOV_NO0_X103)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.104
  //* X(c1,w,i,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,o3,w,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(y,c1,o1,a) X(c1,w,i,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x104, G_IF_SIGMA_CCOV_CCOV_NO0_X104)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x104, G_IF_SIGMA_CCOV_CCOV_NO1_X104)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.105
  //* X(c1,w,i,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,o3,w,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,o1,a) X(c1,w,i,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x105, G_IF_SIGMA_CCOV_CCOV_NO0_X105)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x105, G_IF_SIGMA_CCOV_CCOV_NO1_X105)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.106
  //* X(c1,y,i,o1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(c1,o3,y,o2) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(c1,w,o1,a) X(c1,y,i,o1) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x106, G_IF_SIGMA_CCOV_CCOV_NO0_X106)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x106, G_IF_SIGMA_CCOV_CCOV_NO1_X106)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.107
  //* X()  <--  (    1.00000000)  D1(o1,o2) Y49(o1,o2) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) X T2(w,y,i,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y49 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y107, G_IF_SIGMA_CCOV_CCOV_Y107)
      (sc1, ic1, V2_sym.cptr(), Y49.cptr(), nir, nsym, psym);
  }
  }
  double X = 0;
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x107, G_IF_SIGMA_CCOV_CCOV_NO0_X107)
    (Y49.cptr(), &X, nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x107, G_IF_SIGMA_CCOV_CCOV_NO1_X107)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.108
  //* X(c1,y)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,y,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,c1,i,a) X(c1,y) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x108, G_IF_SIGMA_CCOV_CCOV_NO0_X108)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x108, G_IF_SIGMA_CCOV_CCOV_NO1_X108)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.109
  //* X(c1,w)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,w,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,i,a) X(c1,w) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed);
    orz::DTensor Xc = orz::ct::sympack_Xc(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x109, G_IF_SIGMA_CCOV_CCOV_NO0_X109)
      (sc1, ic1, V2_sym.cptr(), Xc.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x109, G_IF_SIGMA_CCOV_CCOV_NO1_X109)
        (sa, ia, sc1, ic1, T2b.cptr(), Xc.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.110
  //* X(c1,w,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,w,i) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,o2,a) X(c1,w,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x110, G_IF_SIGMA_CCOV_CCOV_NO0_X110)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x110, G_IF_SIGMA_CCOV_CCOV_NO1_X110)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.111
  //* X(o2,i)  <--  (    1.00000000)  D1(o1,o2) Y50(i,o1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,y,o2,a) X(o2,i) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y50 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y111, G_IF_SIGMA_CCOV_CCOV_Y111)
      (sc1, ic1, V2_sym.cptr(), Y50.cptr(), nir, nsym, psym);
  }
  }
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  FC_FUNC(g_if_sigma_ccov_ccov_no0_x111, G_IF_SIGMA_CCOV_CCOV_NO0_X111)
    (Y50.cptr(), Xaa.cptr(), nir, nsym, psym);
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x111, G_IF_SIGMA_CCOV_CCOV_NO1_X111)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.112
  //* X(c1,y,o2,i)  <--  (    1.00000000)  D1(o1,o2) V2(c1,o1,y,i) 
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,o2,a) X(c1,y,o2,i) 
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nocc, nocc);
    orz::DTensor Xcaa = orz::ct::sympack_Xcaa(symblockinfo, sc1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x112, G_IF_SIGMA_CCOV_CCOV_NO0_X112)
      (sc1, ic1, V2_sym.cptr(), Xcaa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x112, G_IF_SIGMA_CCOV_CCOV_NO1_X112)
        (sa, ia, sc1, ic1, T2b.cptr(), Xcaa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.113
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(c1,w,o1,a) V2(c1,o1,y,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x113, G_IF_SIGMA_CCOV_CCOV_NO0_X113)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x113, G_IF_SIGMA_CCOV_CCOV_NO1_X113)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.114
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,c1,o1,a) V2(c1,o1,w,o2) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x114, G_IF_SIGMA_CCOV_CCOV_NO0_X114)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x114, G_IF_SIGMA_CCOV_CCOV_NO1_X114)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.115
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(c1,y,o1,a) V2(c1,o1,w,i) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x115, G_IF_SIGMA_CCOV_CCOV_NO0_X115)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.116
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(w,c1,o1,a) V2(c1,o1,y,i) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    for(int sc1 = 0;sc1 < nir;++sc1){ 
    for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
      // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
      V2 <<= 0.0;                                                                          
      shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
      for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
        // Load a signle record of integals                                                             
        const int &imo2 = loadbuf_ptr->i0;                                                              
        const int &imo3 = loadbuf_ptr->i1;                                                              
        const int &imo4 = loadbuf_ptr->i2;                                                              
        const double &v = loadbuf_ptr->v;                                                               
        V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
      }                                                                                                 
      const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x116, G_IF_SIGMA_CCOV_CCOV_NO0_X116)
        (sa, ia, sc1, ic1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.117
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,y,o1,a) Y51(i,o1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nocc, nocc);
  orz::DTensor Y51 = orz::ct::sympack_Xaa(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y117, G_IF_SIGMA_CCOV_CCOV_Y117)
      (sc1, ic1, V2_sym.cptr(), Y51.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x117, G_IF_SIGMA_CCOV_CCOV_NO0_X117)
      (sa, ia, T2b.cptr(), Y51.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.118
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(a,v1,c1,w) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x118, G_IF_SIGMA_CCOV_CCOV_NO0_X118)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x118, G_IF_SIGMA_CCOV_CCOV_NO1_X118)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.119
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,w,o1,v1) Y52(a,v1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(y,w,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y52 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y119, G_IF_SIGMA_CCOV_CCOV_Y119)
      (sc1, ic1, V2_sym.cptr(), Y52.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x119, G_IF_SIGMA_CCOV_CCOV_NO0_X119)
        (sa, ia, sv1, iv1, T2b.cptr(), Y52.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x119, G_IF_SIGMA_CCOV_CCOV_NO1_X119)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.120
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,w,o1,v1) Y53(a,v1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o1) X(y,w,o1,a) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y53 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y120, G_IF_SIGMA_CCOV_CCOV_Y120)
      (sc1, ic1, V2_sym.cptr(), Y53.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x120, G_IF_SIGMA_CCOV_CCOV_NO0_X120)
        (sa, ia, sv1, iv1, T2b.cptr(), Y53.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x120, G_IF_SIGMA_CCOV_CCOV_NO1_X120)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.121
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(c1,y,o1,v1) V2(a,v1,c1,w) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x121, G_IF_SIGMA_CCOV_CCOV_NO0_X121)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x121, G_IF_SIGMA_CCOV_CCOV_NO1_X121)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.122
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(c1,y,o1,v1) V2(a,w,c1,v1) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x122, G_IF_SIGMA_CCOV_CCOV_NO0_X122)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x122, G_IF_SIGMA_CCOV_CCOV_NO1_X122)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.123
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(c1,w,o1,v1) V2(a,v1,c1,y) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x123, G_IF_SIGMA_CCOV_CCOV_NO0_X123)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x123, G_IF_SIGMA_CCOV_CCOV_NO1_X123)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.124
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,c1,o1,v1) V2(a,v1,c1,y) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x124, G_IF_SIGMA_CCOV_CCOV_NO0_X124)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x124, G_IF_SIGMA_CCOV_CCOV_NO1_X124)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.125
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,c1,o1,v1) V2(a,y,c1,v1) 
  //* S2(w,y,i,a)  <--  (   -4.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x125, G_IF_SIGMA_CCOV_CCOV_NO0_X125)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x125, G_IF_SIGMA_CCOV_CCOV_NO1_X125)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.126
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(w,y,i,v1) Y54(a,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y54 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y126, G_IF_SIGMA_CCOV_CCOV_Y126)
      (sc1, ic1, V2_sym.cptr(), Y54.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x126, G_IF_SIGMA_CCOV_CCOV_NO0_X126)
        (sa, ia, sv1, iv1, T2b.cptr(), Y54.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.127
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,c1,i,v1) V2(a,v1,c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x127, G_IF_SIGMA_CCOV_CCOV_NO0_X127)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.128
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,w,i,v1) V2(a,v1,c1,y) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x128, G_IF_SIGMA_CCOV_CCOV_NO0_X128)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.129
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,w,i,v1) V2(a,y,c1,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x129, G_IF_SIGMA_CCOV_CCOV_NO0_X129)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.130
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(y,c1,i,v1) V2(a,v1,c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x130, G_IF_SIGMA_CCOV_CCOV_NO0_X130)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.131
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(y,c1,i,v1) V2(a,w,c1,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x131, G_IF_SIGMA_CCOV_CCOV_NO0_X131)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.132
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(c1,y,i,v1) V2(a,v1,c1,w) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x132, G_IF_SIGMA_CCOV_CCOV_NO0_X132)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.133
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(c1,w,o1,v1) V2(a,y,c1,v1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x133, G_IF_SIGMA_CCOV_CCOV_NO0_X133)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x133, G_IF_SIGMA_CCOV_CCOV_NO1_X133)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.134
  //* X(y,w,o1,a)  <--  (    1.00000000)  T2(y,c1,o1,v1) V2(a,w,c1,v1) 
  //* S2(w,y,i,a)  <--  (    2.00000000) D1(i,o1) X(y,w,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x134, G_IF_SIGMA_CCOV_CCOV_NO0_X134)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x134, G_IF_SIGMA_CCOV_CCOV_NO1_X134)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.135
  //* S2(w,y,i,a)  <--  (    8.00000000) T2(w,c1,i,v1) V2(a,y,c1,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x135, G_IF_SIGMA_CCOV_CCOV_NO0_X135)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.136
  //* S2(w,y,i,a)  <--  (   -4.00000000) T2(w,y,i,v1) Y55(a,v1) 
  // The effective tensor is detected .... 
  orz::DTensor Y(nvir, nvir);
  orz::DTensor Y55 = orz::ct::sympack_Xvv(symblockinfo, 0, Y);
  for(int sc1 = 0;sc1 < nir;++sc1){ 
  for(int ic1 = symblockinfo.psym()(sc1,I_C,I_BEGIN);ic1 <= symblockinfo.psym()(sc1,I_C,I_END);++ic1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ic1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ic1, sc1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_y136, G_IF_SIGMA_CCOV_CCOV_Y136)
      (sc1, ic1, V2_sym.cptr(), Y55.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x136, G_IF_SIGMA_CCOV_CCOV_NO0_X136)
        (sa, ia, sv1, iv1, T2b.cptr(), Y55.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.137
  //* S2(w,y,i,a)  <--  (    2.00000000) T2(c1,y,i,v1) V2(a,w,c1,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x137, G_IF_SIGMA_CCOV_CCOV_NO0_X137)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.138
  //* X(i,o3)  <--  (    1.00000000)  D3(i,o3,o4,o1,o5,o2) V2(o1,o4,o2,o5) 
  //* S2(w,y,i,a)  <--  (    0.50000000) T2(y,w,o3,a) X(i,o3) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x138, G_IF_SIGMA_CCOV_CCOV_NO0_X138)
      (so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x138, G_IF_SIGMA_CCOV_CCOV_NO1_X138)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.139
  //* X(i,o3)  <--  (    1.00000000)  D3(i,o3,o1,o4,o2,o5) V2(o1,o4,o2,o5) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) T2(w,y,o3,a) X(i,o3) 
  orz::DTensor X(nocc, nocc);
  orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, 0, X);
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x139, G_IF_SIGMA_CCOV_CCOV_NO0_X139)
      (so1, io1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x139, G_IF_SIGMA_CCOV_CCOV_NO1_X139)
      (sa, ia, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.140
  //* X()  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  //* S2(w,y,i,a)  <--  (    2.00000000) X T2(w,y,i,a) 
  double X = 0;
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x140, G_IF_SIGMA_CCOV_CCOV_NO0_X140)
      (so1, io1, V2_sym.cptr(), &X, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x140, G_IF_SIGMA_CCOV_CCOV_NO1_X140)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.141
  //* X()  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(o1,o3,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -1.00000000) X T2(y,w,i,a) 
  double X = 0;
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x141, G_IF_SIGMA_CCOV_CCOV_NO0_X141)
      (so1, io1, V2_sym.cptr(), &X, nir, nsym, psym);
  }
  }
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    T2b = T2.get_amp2(ia);
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x141, G_IF_SIGMA_CCOV_CCOV_NO1_X141)
      (sa, ia, &X, T2b.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.142
  //* X(o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(i,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o3,a) X(o3,i) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x142, G_IF_SIGMA_CCOV_CCOV_NO0_X142)
      (si, ii, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x142, G_IF_SIGMA_CCOV_CCOV_NO1_X142)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.143
  //* X(o3,i)  <--  (    1.00000000)  D2(o1,o3,o2,o4) V2(i,o1,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o3,a) X(o3,i) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x143, G_IF_SIGMA_CCOV_CCOV_NO0_X143)
      (si, ii, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x143, G_IF_SIGMA_CCOV_CCOV_NO1_X143)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.144
  //* X(i,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o1,a) X(i,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x144, G_IF_SIGMA_CCOV_CCOV_NO0_X144)
      (so1, io1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x144, G_IF_SIGMA_CCOV_CCOV_NO1_X144)
        (sa, ia, so1, io1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.145
  //* X(i,o1)  <--  (    1.00000000)  D2(i,o3,o4,o2) V2(o1,o3,o2,o4) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,a) X(i,o1) 
  for(int so1 = 0;so1 < nir;++so1){ 
  for(int io1 = symblockinfo.psym()(so1,I_O,I_BEGIN);io1 <= symblockinfo.psym()(so1,I_O,I_END);++io1){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(io1);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, io1, so1, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, so1, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x145, G_IF_SIGMA_CCOV_CCOV_NO0_X145)
      (so1, io1, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x145, G_IF_SIGMA_CCOV_CCOV_NO1_X145)
        (sa, ia, so1, io1, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.146
  //* X(i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(i,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,o1,a) X(i,o1) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x146, G_IF_SIGMA_CCOV_CCOV_NO0_X146)
      (si, ii, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x146, G_IF_SIGMA_CCOV_CCOV_NO1_X146)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.147
  //* X(i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(i,o1,o2,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o1,a) X(i,o1) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x147, G_IF_SIGMA_CCOV_CCOV_NO0_X147)
      (si, ii, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x147, G_IF_SIGMA_CCOV_CCOV_NO1_X147)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.148
  //* X(i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(i,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o1,a) X(i,o1) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x148, G_IF_SIGMA_CCOV_CCOV_NO0_X148)
      (si, ii, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x148, G_IF_SIGMA_CCOV_CCOV_NO1_X148)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.149
  //* X(i,o1)  <--  (    1.00000000)  D1(o2,o3) V2(i,o2,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,a) X(i,o1) 
  for(int si = 0;si < nir;++si){ 
  for(int ii = symblockinfo.psym()(si,I_O,I_BEGIN);ii <= symblockinfo.psym()(si,I_O,I_END);++ii){ 
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ii);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ii, si, V2); // V2=(IR-COV index) 
    orz::DTensor X(nocc);
    orz::DTensor Xa = orz::ct::sympack_Xa(symblockinfo, si, X);
    FC_FUNC(g_if_sigma_ccov_ccov_no0_x149, G_IF_SIGMA_CCOV_CCOV_NO0_X149)
      (si, ii, V2_sym.cptr(), Xa.cptr(), nir, nsym, psym);
    for(int sa = 0;sa < nir;++sa){ 
    for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
      S2b = orz::DTensor(retval.namps_iamp()[ia]);
      T2b = T2.get_amp2(ia);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x149, G_IF_SIGMA_CCOV_CCOV_NO1_X149)
        (sa, ia, si, ii, T2b.cptr(), Xa.cptr(), S2b.cptr(), nir, nsym, psym);
      retval.acc_amp2(ia, S2b);
    }
    }
  }
  }
  }


  {
  // No.150
  //* X(i,o2,a,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,v1,o1,o3) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o2,v1) X(i,o2,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x150, G_IF_SIGMA_CCOV_CCOV_NO0_X150)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x150, G_IF_SIGMA_CCOV_CCOV_NO1_X150)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.151
  //* X(i,o2,a,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,v1,o1,o3) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o2,v1) X(i,o2,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x151, G_IF_SIGMA_CCOV_CCOV_NO0_X151)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x151, G_IF_SIGMA_CCOV_CCOV_NO1_X151)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.152
  //* X(i,o2,a,v1)  <--  (    1.00000000)  D2(i,o2,o3,o1) V2(a,o3,o1,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o2,v1) X(i,o2,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x152, G_IF_SIGMA_CCOV_CCOV_NO0_X152)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x152, G_IF_SIGMA_CCOV_CCOV_NO1_X152)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.153
  //* X(a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,v1,o1,o2) 
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,i,v1) X(a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x153, G_IF_SIGMA_CCOV_CCOV_NO0_X153)
        (sa, ia, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x153, G_IF_SIGMA_CCOV_CCOV_NO1_X153)
        (sa, ia, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.154
  //* X(a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,v1,o1,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,i,v1) X(a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x154, G_IF_SIGMA_CCOV_CCOV_NO0_X154)
        (sa, ia, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x154, G_IF_SIGMA_CCOV_CCOV_NO1_X154)
        (sa, ia, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.155
  //* X(a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,o2,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,i,v1) X(a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x155, G_IF_SIGMA_CCOV_CCOV_NO0_X155)
        (sa, ia, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x155, G_IF_SIGMA_CCOV_CCOV_NO1_X155)
        (sa, ia, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.156
  //* X(o2,i,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,v1,i,o1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o2,v1) X(o2,i,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x156, G_IF_SIGMA_CCOV_CCOV_NO0_X156)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x156, G_IF_SIGMA_CCOV_CCOV_NO1_X156)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.157
  //* X(o2,i,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,v1,i,o1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o2,v1) X(o2,i,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x157, G_IF_SIGMA_CCOV_CCOV_NO0_X157)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x157, G_IF_SIGMA_CCOV_CCOV_NO1_X157)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.158
  //* X(o2,i,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,i,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(w,y,o2,v1) X(o2,i,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x158, G_IF_SIGMA_CCOV_CCOV_NO0_X158)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x158, G_IF_SIGMA_CCOV_CCOV_NO1_X158)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.159
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,v1) V2(a,v1,o1,o2) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x159, G_IF_SIGMA_CCOV_CCOV_NO0_X159)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x159, G_IF_SIGMA_CCOV_CCOV_NO1_X159)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.160
  //* X(w,y,o2,a)  <--  (    1.00000000)  T2(w,y,o1,v1) V2(a,v1,o1,o2) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o2) X(w,y,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x160, G_IF_SIGMA_CCOV_CCOV_NO0_X160)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x160, G_IF_SIGMA_CCOV_CCOV_NO1_X160)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.161
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(w,y,o1,v1) V2(a,v1,i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x161, G_IF_SIGMA_CCOV_CCOV_NO0_X161)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.162
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o1,v1) V2(a,v1,i,o1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x162, G_IF_SIGMA_CCOV_CCOV_NO0_X162)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.163
  //* S2(w,y,i,a)  <--  (    4.00000000) T2(y,w,o1,v1) V2(a,o1,i,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x163, G_IF_SIGMA_CCOV_CCOV_NO0_X163)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.164
  //* X(i,o3,a,v1)  <--  (    1.00000000)  D2(i,o2,o1,o3) V2(a,o1,o2,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) T2(y,w,o3,v1) X(i,o3,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x164, G_IF_SIGMA_CCOV_CCOV_NO0_X164)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x164, G_IF_SIGMA_CCOV_CCOV_NO1_X164)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.165
  //* X(a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,o2,v1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,i,v1) X(a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      double X = 0;
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x165, G_IF_SIGMA_CCOV_CCOV_NO0_X165)
        (sa, ia, sv1, iv1, V2_sym.cptr(), &X, nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x165, G_IF_SIGMA_CCOV_CCOV_NO1_X165)
        (sa, ia, sv1, iv1, T2b.cptr(), &X, S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.166
  //* X(o2,i,a,v1)  <--  (    1.00000000)  D1(o1,o2) V2(a,o1,i,v1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(y,w,o2,v1) X(o2,i,a,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      orz::DTensor X(nocc, nocc);
      orz::DTensor Xaa = orz::ct::sympack_Xaa(symblockinfo, sa^sv1, X);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x166, G_IF_SIGMA_CCOV_CCOV_NO0_X166)
        (sa, ia, sv1, iv1, V2_sym.cptr(), Xaa.cptr(), nir, nsym, psym);
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no1_x166, G_IF_SIGMA_CCOV_CCOV_NO1_X166)
        (sa, ia, sv1, iv1, T2b.cptr(), Xaa.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.167
  //* X(y,w,o2,a)  <--  (    1.00000000)  T2(y,w,o1,v1) V2(a,o1,o2,v1) 
  //* S2(w,y,i,a)  <--  (   -2.00000000) D1(i,o2) X(y,w,o2,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x167, G_IF_SIGMA_CCOV_CCOV_NO0_X167)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x167, G_IF_SIGMA_CCOV_CCOV_NO1_X167)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.168
  //* X(w,y,o1,a)  <--  (    1.00000000)  T2(w,y,o2,v1) V2(a,o2,o1,v1) 
  //* S2(w,y,i,a)  <--  (    1.00000000) D1(i,o1) X(w,y,o1,a) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    orz::DTensor X(nclosed, nclosed, nocc);
    orz::DTensor Xcca = orz::ct::sympack_Xcca(symblockinfo, sa, X);
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x168, G_IF_SIGMA_CCOV_CCOV_NO0_X168)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), Xcca.cptr(), nir, nsym, psym);
    }
    }
    FC_FUNC(g_if_sigma_ccov_ccov_no1_x168, G_IF_SIGMA_CCOV_CCOV_NO1_X168)
      (sa, ia, Xcca.cptr(), S2b.cptr(), nir, nsym, psym);
    retval.acc_amp2(ia, S2b);
  }
  }
  }


  {
  // No.169
  //* S2(w,y,i,a)  <--  (   -2.00000000) T2(w,y,o1,v1) V2(a,o1,i,v1) 
  for(int sa = 0;sa < nir;++sa){ 
  for(int ia = symblockinfo.psym()(sa,I_V,I_BEGIN);ia <= symblockinfo.psym()(sa,I_V,I_END);++ia){ 
    S2b = orz::DTensor(retval.namps_iamp()[ia]);
    // Load ERIs from somewhere, e.g. disk, GA, etc..                                                 
    V2 <<= 0.0;                                                                          
    shared_ptr<orz::hint::LoadSortBuffer> loadbuf_ptr = hintmo.get_LoadSortBuffer(ia);
    for(; !loadbuf_ptr->out_of_range(); ++(*loadbuf_ptr)) {                                           
      // Load a signle record of integals                                                             
      const int &imo2 = loadbuf_ptr->i0;                                                              
      const int &imo3 = loadbuf_ptr->i1;                                                              
      const int &imo4 = loadbuf_ptr->i2;                                                              
      const double &v = loadbuf_ptr->v;                                                               
      V2_ptr[((imo2)*nmo+imo3)*nmo+imo4] = v;                                       
    }                                                                                                 
    const orz::DTensor V2_sym = orz::ct::sympack_int2(symblockinfo, ia, sa, V2); // V2=(IR-COV index) 
    for(int sv1 = 0;sv1 < nir;++sv1){ 
    for(int iv1 = symblockinfo.psym()(sv1,I_V,I_BEGIN);iv1 <= symblockinfo.psym()(sv1,I_V,I_END);++iv1){ 
      T2b = T2.get_amp2(iv1);
      FC_FUNC(g_if_sigma_ccov_ccov_no0_x169, G_IF_SIGMA_CCOV_CCOV_NO0_X169)
        (sa, ia, sv1, iv1, T2b.cptr(), V2_sym.cptr(), S2b.cptr(), nir, nsym, psym);
    }
    }
    retval.acc_amp2(ia, S2b);
  }
  }
  }

  return retval; 
} 
