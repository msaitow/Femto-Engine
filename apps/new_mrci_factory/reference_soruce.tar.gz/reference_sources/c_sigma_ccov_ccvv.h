

#ifndef C_SIGMA_CCOV_CCVV_H
#define C_SIGMA_CCOV_CCVV_H

// #include <tensor/tensor.h>                  
// #include <sci/hint/hintmo/hintmo.h>         
// #include <sci/ctnew2/ctclass_input.h>       
// #include <sci/ctnew2/ctclass_symblock.h>    
// #include <sci/ctnew2/ctclass_rdmpack.h>     
// #include <sci/ctnew2/ctclass_bareamppack.h> 
                                               
extern "C"{                                  
                                               
                                               
//  __/\\\\\\\\\\\\\\\____________________________________________________________________                                   
//   _\/\\\///////////_____________________________________________________________________                                             
//    _\/\\\_______________________________________________________/\\\_____________________                                         
//     _\/\\\\\\\\\\\__________/\\\\\\\\______/\\\\\__/\\\\\_____/\\\\\\\\\\\______/\\\\\____ 
//      _\/\\\///////_________/\\\/////\\\___/\\\///\\\\\///\\\__\////\\\////_____/\\\///\\\__               
//       _\/\\\_______________/\\\\\\\\\\\___\/\\\_\//\\\__\/\\\_____\/\\\________/\\\__\//\\\_       
//        _\/\\\______________\//\\///////____\/\\\__\/\\\__\/\\\_____\/\\\_/\\___\//\\\__/\\\__            
//         _\/\\\_______________\//\\\\\\\\\\__\/\\\__\/\\\__\/\\\_____\//\\\\\_____\///\\\\\/___    
//          _\///_________________\//////////___\///___\///___\///_______\/////________\/////_____                                   

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x0, G_IF_SIGMA_CCOV_CCVV_NO0_X0)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x0, G_IF_SIGMA_CCOV_CCVV_NO1_X0)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y1, G_IF_SIGMA_CCOV_CCVV_Y1)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y0, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x1, G_IF_SIGMA_CCOV_CCVV_NO0_X1)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y0, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x1, G_IF_SIGMA_CCOV_CCVV_NO1_X1)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y2, G_IF_SIGMA_CCOV_CCVV_Y2)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y1, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x2, G_IF_SIGMA_CCOV_CCVV_NO0_X2)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y1, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x2, G_IF_SIGMA_CCOV_CCVV_NO1_X2)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x3, G_IF_SIGMA_CCOV_CCVV_NO0_X3)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x3, G_IF_SIGMA_CCOV_CCVV_NO1_X3)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x4, G_IF_SIGMA_CCOV_CCVV_NO0_X4)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x5, G_IF_SIGMA_CCOV_CCVV_NO0_X5)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y6, G_IF_SIGMA_CCOV_CCVV_Y6)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x6, G_IF_SIGMA_CCOV_CCVV_NO0_X6)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y7, G_IF_SIGMA_CCOV_CCVV_Y7)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y3, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x7, G_IF_SIGMA_CCOV_CCVV_NO0_X7)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y3, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x8, G_IF_SIGMA_CCOV_CCVV_NO0_X8)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x8, G_IF_SIGMA_CCOV_CCVV_NO1_X8)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y9, G_IF_SIGMA_CCOV_CCVV_Y9)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y4, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x9, G_IF_SIGMA_CCOV_CCVV_NO0_X9)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y4, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x9, G_IF_SIGMA_CCOV_CCVV_NO1_X9)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y10, G_IF_SIGMA_CCOV_CCVV_Y10)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y5, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x10, G_IF_SIGMA_CCOV_CCVV_NO0_X10)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y5, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x10, G_IF_SIGMA_CCOV_CCVV_NO1_X10)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x11, G_IF_SIGMA_CCOV_CCVV_NO0_X11)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const h, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x11, G_IF_SIGMA_CCOV_CCVV_NO1_X11)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x12, G_IF_SIGMA_CCOV_CCVV_NO0_X12)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x13, G_IF_SIGMA_CCOV_CCVV_NO0_X13)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const h, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y14, G_IF_SIGMA_CCOV_CCVV_Y14)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y6, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x14, G_IF_SIGMA_CCOV_CCVV_NO0_X14)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y6, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y15, G_IF_SIGMA_CCOV_CCVV_Y15)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y7, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x15, G_IF_SIGMA_CCOV_CCVV_NO0_X15)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y7, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x16, G_IF_SIGMA_CCOV_CCVV_NO0_X16)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x16, G_IF_SIGMA_CCOV_CCVV_NO1_X16)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y17, G_IF_SIGMA_CCOV_CCVV_Y17)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y8, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x17, G_IF_SIGMA_CCOV_CCVV_NO0_X17)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y8, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x17, G_IF_SIGMA_CCOV_CCVV_NO1_X17)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y18, G_IF_SIGMA_CCOV_CCVV_Y18)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y9, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x18, G_IF_SIGMA_CCOV_CCVV_NO0_X18)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y9, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x18, G_IF_SIGMA_CCOV_CCVV_NO1_X18)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x19, G_IF_SIGMA_CCOV_CCVV_NO0_X19)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x19, G_IF_SIGMA_CCOV_CCVV_NO1_X19)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x20, G_IF_SIGMA_CCOV_CCVV_NO0_X20)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x20, G_IF_SIGMA_CCOV_CCVV_NO1_X20)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x21, G_IF_SIGMA_CCOV_CCVV_NO0_X21)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x21, G_IF_SIGMA_CCOV_CCVV_NO1_X21)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x22, G_IF_SIGMA_CCOV_CCVV_NO0_X22)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x22, G_IF_SIGMA_CCOV_CCVV_NO1_X22)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x23, G_IF_SIGMA_CCOV_CCVV_NO0_X23)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x23, G_IF_SIGMA_CCOV_CCVV_NO1_X23)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y24, G_IF_SIGMA_CCOV_CCVV_Y24)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y10, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x24, G_IF_SIGMA_CCOV_CCVV_NO0_X24)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y10, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x25, G_IF_SIGMA_CCOV_CCVV_NO0_X25)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x26, G_IF_SIGMA_CCOV_CCVV_NO0_X26)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x27, G_IF_SIGMA_CCOV_CCVV_NO0_X27)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x28, G_IF_SIGMA_CCOV_CCVV_NO0_X28)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x29, G_IF_SIGMA_CCOV_CCVV_NO0_X29)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x30, G_IF_SIGMA_CCOV_CCVV_NO0_X30)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x31, G_IF_SIGMA_CCOV_CCVV_NO0_X31)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x31, G_IF_SIGMA_CCOV_CCVV_NO1_X31)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x32, G_IF_SIGMA_CCOV_CCVV_NO0_X32)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x32, G_IF_SIGMA_CCOV_CCVV_NO1_X32)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x33, G_IF_SIGMA_CCOV_CCVV_NO0_X33)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x33, G_IF_SIGMA_CCOV_CCVV_NO1_X33)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y34, G_IF_SIGMA_CCOV_CCVV_Y34)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y11, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x34, G_IF_SIGMA_CCOV_CCVV_NO0_X34)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y11, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x34, G_IF_SIGMA_CCOV_CCVV_NO1_X34)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y35, G_IF_SIGMA_CCOV_CCVV_Y35)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y12, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x35, G_IF_SIGMA_CCOV_CCVV_NO0_X35)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y12, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x35, G_IF_SIGMA_CCOV_CCVV_NO1_X35)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x36, G_IF_SIGMA_CCOV_CCVV_NO0_X36)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x36, G_IF_SIGMA_CCOV_CCVV_NO1_X36)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x37, G_IF_SIGMA_CCOV_CCVV_NO0_X37)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x37, G_IF_SIGMA_CCOV_CCVV_NO1_X37)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x38, G_IF_SIGMA_CCOV_CCVV_NO0_X38)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x38, G_IF_SIGMA_CCOV_CCVV_NO1_X38)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y39, G_IF_SIGMA_CCOV_CCVV_Y39)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y13, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x39, G_IF_SIGMA_CCOV_CCVV_NO0_X39)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y13, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x40, G_IF_SIGMA_CCOV_CCVV_NO0_X40)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x41, G_IF_SIGMA_CCOV_CCVV_NO0_X41)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x42, G_IF_SIGMA_CCOV_CCVV_NO0_X42)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x43, G_IF_SIGMA_CCOV_CCVV_NO0_X43)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x44, G_IF_SIGMA_CCOV_CCVV_NO0_X44)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x45, G_IF_SIGMA_CCOV_CCVV_NO0_X45)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x46, G_IF_SIGMA_CCOV_CCVV_NO0_X46)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x46, G_IF_SIGMA_CCOV_CCVV_NO1_X46)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x47, G_IF_SIGMA_CCOV_CCVV_NO0_X47)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x47, G_IF_SIGMA_CCOV_CCVV_NO1_X47)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x48, G_IF_SIGMA_CCOV_CCVV_NO0_X48)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x49, G_IF_SIGMA_CCOV_CCVV_NO0_X49)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y50, G_IF_SIGMA_CCOV_CCVV_Y50)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y14, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x50, G_IF_SIGMA_CCOV_CCVV_NO0_X50)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const T2, const double * const Y14, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x51, G_IF_SIGMA_CCOV_CCVV_NO0_X51)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x51, G_IF_SIGMA_CCOV_CCVV_NO1_X51)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x52, G_IF_SIGMA_CCOV_CCVV_NO0_X52)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x52, G_IF_SIGMA_CCOV_CCVV_NO1_X52)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x53, G_IF_SIGMA_CCOV_CCVV_NO0_X53)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_y54, G_IF_SIGMA_CCOV_CCVV_Y54)
  (const FC_INT &sc1, const FC_INT &ic1, 
   const double * const V2, const double * const Y15, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x54, G_IF_SIGMA_CCOV_CCVV_NO0_X54)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const Y15, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x55, G_IF_SIGMA_CCOV_CCVV_NO0_X55)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x56, G_IF_SIGMA_CCOV_CCVV_NO0_X56)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x56, G_IF_SIGMA_CCOV_CCVV_NO1_X56)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x57, G_IF_SIGMA_CCOV_CCVV_NO0_X57)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x57, G_IF_SIGMA_CCOV_CCVV_NO1_X57)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x58, G_IF_SIGMA_CCOV_CCVV_NO0_X58)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x58, G_IF_SIGMA_CCOV_CCVV_NO1_X58)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x59, G_IF_SIGMA_CCOV_CCVV_NO0_X59)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x59, G_IF_SIGMA_CCOV_CCVV_NO1_X59)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x60, G_IF_SIGMA_CCOV_CCVV_NO0_X60)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x60, G_IF_SIGMA_CCOV_CCVV_NO1_X60)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x61, G_IF_SIGMA_CCOV_CCVV_NO0_X61)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x61, G_IF_SIGMA_CCOV_CCVV_NO1_X61)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x62, G_IF_SIGMA_CCOV_CCVV_NO0_X62)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x62, G_IF_SIGMA_CCOV_CCVV_NO1_X62)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x63, G_IF_SIGMA_CCOV_CCVV_NO0_X63)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x63, G_IF_SIGMA_CCOV_CCVV_NO1_X63)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x64, G_IF_SIGMA_CCOV_CCVV_NO0_X64)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x64, G_IF_SIGMA_CCOV_CCVV_NO1_X64)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x65, G_IF_SIGMA_CCOV_CCVV_NO0_X65)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x65, G_IF_SIGMA_CCOV_CCVV_NO1_X65)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x66, G_IF_SIGMA_CCOV_CCVV_NO0_X66)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x66, G_IF_SIGMA_CCOV_CCVV_NO1_X66)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x67, G_IF_SIGMA_CCOV_CCVV_NO0_X67)
  (const FC_INT &sv1, const FC_INT &iv1, 
   const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x67, G_IF_SIGMA_CCOV_CCVV_NO1_X67)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x68, G_IF_SIGMA_CCOV_CCVV_NO0_X68)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x68, G_IF_SIGMA_CCOV_CCVV_NO1_X68)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x69, G_IF_SIGMA_CCOV_CCVV_NO0_X69)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x69, G_IF_SIGMA_CCOV_CCVV_NO1_X69)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x70, G_IF_SIGMA_CCOV_CCVV_NO0_X70)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x71, G_IF_SIGMA_CCOV_CCVV_NO0_X71)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x72, G_IF_SIGMA_CCOV_CCVV_NO0_X72)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x73, G_IF_SIGMA_CCOV_CCVV_NO0_X73)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv1, const FC_INT &iv1, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x73, G_IF_SIGMA_CCOV_CCVV_NO1_X73)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x74, G_IF_SIGMA_CCOV_CCVV_NO0_X74)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv2, const FC_INT &iv2, 
   const double * const T2, const double * const V2, const double * const X, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no1_x74, G_IF_SIGMA_CCOV_CCVV_NO1_X74)
  (const FC_INT &sa, const FC_INT &ia, 
   const double * const X, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

void FC_FUNC(g_if_sigma_ccov_ccvv_no0_x75, G_IF_SIGMA_CCOV_CCVV_NO0_X75)
  (const FC_INT &sa, const FC_INT &ia, const FC_INT &sv2, const FC_INT &iv2, 
   const double * const T2, const double * const V2, const double * const S2, 
   const FC_INT &nir, const FC_INT * const nsym,  const FC_INT * const psym);

      
 }     
       
       
 #endif
       
       
 